package com.ubs.testmanagement.controller;

import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.core.io.ClassPathResource;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.*;

/**
 * Handles test management task-level operations.
 *
 * Endpoint 3  : POST /app/EO7/api/testmanagement-task/{taskId}/upload         – upload document
 * Endpoint 3.1: POST /app/EO7/api/testmanagement-task/{taskId}/gitlabIssue   – gitlab upload
 * Endpoint 4  : POST /app/EO7/api/testmanagement-task/{taskId}/complete       – complete task
 * Endpoint 5  : GET  /app/EO7/api/testmanagement-task/{taskId}/variables      – fetch variables
 * Endpoint 6  : GET  /app/EO7/api/testmanagement-task/{taskId}/{action}       – approve / reject
 * Endpoint 7  : GET  /app/EO7/api/testmanagement-task/{taskId}/testcases      – fetch test cases
 * Endpoint 8  : GET  /app/EO7/api/testmanagement-task/{taskId}/export         – export test cases
 * Endpoint H1 : GET  /app/EO7/api/testmanagement-task/scripts/hierarchy        – fetch file hierarchy
 */
@RestController
@RequestMapping("/app/EO7/api/testmanagement-task")
public class TestManagementTaskController {

    // -----------------------------------------------------------------------
    // Endpoint 3 – Upload requirement document
    // POST /app/EO7/api/testmanagement-task/{taskId}/upload
    // Body: multipart/form-data  "file"
    // -----------------------------------------------------------------------
    @PostMapping("/{taskId}/upload")
    public ResponseEntity<String> uploadDocument(
            @PathVariable String taskId,
            @RequestParam("file") MultipartFile file) {

        if (file == null || file.isEmpty()) {
            return ResponseEntity.badRequest().body("Failed: No file received.");
        }
        return ResponseEntity.ok("Success");
    }

    // -----------------------------------------------------------------------
    // Endpoint 3.1 – Gitlab upload
    // POST /app/EO7/api/testmanagement-task/{taskId}/gitlabIssue
    //      ?gitlabIssue={url}&gitlabToken={token}
    // -----------------------------------------------------------------------
    @PostMapping("/{taskId}/gitlabIssue")
    public ResponseEntity<String> gitlabUpload(
            @PathVariable String taskId,
            @RequestParam("gitlabIssue") String gitlabIssue,
            @RequestParam("gitlabToken") String gitlabToken) {

        if (gitlabIssue == null || gitlabIssue.isBlank() || gitlabToken == null || gitlabToken.isBlank()) {
            return ResponseEntity.badRequest().body("Failed: Missing gitlab url or token.");
        }
        return ResponseEntity.ok("Success");
    }

    // -----------------------------------------------------------------------
    // Endpoint 4 – Post Upload – Complete task
    // POST /app/EO7/api/testmanagement-task/{taskId}/complete
    // -----------------------------------------------------------------------
    @PostMapping("/{taskId}/complete")
    public ResponseEntity<String> completeTask(@PathVariable String taskId) {
        return ResponseEntity.ok("Success");
    }

    // -----------------------------------------------------------------------
    // Endpoint 5 – Validation – Fetch variables on task
    // GET /app/EO7/api/testmanagement-task/{taskId}/variables
    // -----------------------------------------------------------------------
    @GetMapping("/{taskId}/variables")
    @SuppressWarnings("unchecked")
    public ResponseEntity<Map<String, Object>> getVariables(@PathVariable String taskId) {
        try {
            ClassPathResource resource = new ClassPathResource("validation.json");
            ObjectMapper mapper = new ObjectMapper();
            Map<String, Object> response = mapper.readValue(resource.getInputStream(), Map.class);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            return ResponseEntity.internalServerError().build();
        }
    }

    // -----------------------------------------------------------------------
    // Endpoint 6 – Approval / Rejection
    // GET /app/EO7/api/testmanagement-task/{taskId}/{action}
    //     where {action} = "approve" | "reject"
    // -----------------------------------------------------------------------
    @GetMapping("/{taskId}/{action}")
    public ResponseEntity<String> approveOrReject(
            @PathVariable String taskId,
            @PathVariable String action) {

        if ("approve".equalsIgnoreCase(action)) {
            return ResponseEntity.ok("Success");
        } else if ("reject".equalsIgnoreCase(action)) {
            return ResponseEntity.ok("Success");
        }
        return ResponseEntity.badRequest().body("Failed: Unknown action '" + action + "'. Use 'approve' or 'reject'.");
    }

    // -----------------------------------------------------------------------
    // Endpoint 7 – Fetch Test Cases
    // GET /app/EO7/api/testmanagement-task/{taskId}/testcases
    // -----------------------------------------------------------------------
    @GetMapping("/{taskId}/testcases")
    @SuppressWarnings("unchecked")
    public ResponseEntity<Map<String, Object>> getTestCases(@PathVariable String taskId) {
        try {
            ClassPathResource resource = new ClassPathResource("testgeneration.json");
            ObjectMapper mapper = new ObjectMapper();
            Map<String, Object> response = mapper.readValue(resource.getInputStream(), Map.class);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            return ResponseEntity.internalServerError().build();
        }
    }

    // -----------------------------------------------------------------------
    // Endpoint 8 – Export Test Cases (download)
    // GET /app/EO7/api/testmanagement-task/{taskId}/export
    // -----------------------------------------------------------------------
    @GetMapping("/{taskId}/export")
    public ResponseEntity<byte[]> exportTestCases(@PathVariable String taskId) {

        // Build a minimal CSV representing the exported test cases
        String csvContent =
                "Test Case Id,Requirement Id,Test Description,Pre-conditions,Test Step Action\r\n" +
                "TC-001,REQ-001,Verify successful login with valid credentials," +
                        "User account must exist in the system," +
                        "\"1. Navigate to login page. 2. Enter valid username and password. 3. Click Login. 4. Verify dashboard is displayed.\"\r\n" +
                "TC-002,REQ-002,Verify requirement document upload success," +
                        "User is logged in and has a valid PDF document," +
                        "\"1. Navigate to Upload screen. 2. Select a PDF file. 3. Click Upload. 4. Verify success notification.\"\r\n";

        byte[] csvBytes = csvContent.getBytes();

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION,
                        "attachment; filename=\"testcases-" + taskId + ".csv\"")
                .contentType(MediaType.parseMediaType("text/csv"))
                .contentLength(csvBytes.length)
                .body(csvBytes);
    }

    // -----------------------------------------------------------------------
    // Endpoint H1 – Fetch script file hierarchy JSON
    // GET /app/EO7/api/testmanagement-task/scripts/hierarchy
    // -----------------------------------------------------------------------
    @GetMapping("/scripts/hierarchy")
    @SuppressWarnings("unchecked")
    public ResponseEntity<Map<String, Object>> getScriptsHierarchy() {
        try {
            ClassPathResource resource = new ClassPathResource("tree_hierachy_with_select_checkbox.json");
            ObjectMapper mapper = new ObjectMapper();
            Map<String, Object> response = mapper.readValue(resource.getInputStream(), Map.class);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            return ResponseEntity.internalServerError().build();
        }
    }
}
