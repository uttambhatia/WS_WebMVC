/**
 * IdSelectorCreator — dropdown + create composite component.
 *
 * Props:
 *   fetchService  {async fn → string[]}   Optional. Called on mount to populate list.
 *   createService {async fn → string}     Called when "+" Create is clicked.
 *   placeholder   {string}                Dropdown placeholder text.
 *   label         {string}                Field label (optional).
 *   value         {string}                Controlled selected value.
 *   onSelect      {fn(id: string)}        Called when a value is selected or created.
 *   disabled      {boolean}
 *   className     {string}
 */

import {
  useCallback,
  useEffect,
  useRef,
  useState,
} from "react";
import "./IdSelectorCreator.css";

/* ---- Icons ---- */
function ChevronIcon({ className }) {
  return (
    <svg className={className} viewBox="0 0 16 16" fill="none" aria-hidden="true">
      <path d="M4 6l4 4 4-4" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  );
}

function TickIcon({ className }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="2"/>
      <path d="m8 12 3 3 5-5" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  );
}

function PlusIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 14 14" fill="none" aria-hidden="true">
      <path d="M7 2v10M2 7h10" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
    </svg>
  );
}

function SpinnerIcon({ className }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <circle cx="12" cy="12" r="9" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeDasharray="42 14"/>
    </svg>
  );
}

/* ---- Component ---- */
export default function IdSelectorCreator({
  fetchService,
  createService,
  placeholder = "Select or search…",
  label,
  value,
  onSelect,
  disabled = false,
  className = "",
}) {
  const [options, setOptions] = useState([]);
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [highlighted, setHighlighted] = useState(-1);
  const [fetching, setFetching] = useState(false);
  const [creating, setCreating] = useState(false);
  const [error, setError] = useState(null);

  const wrapRef = useRef(null);
  const searchRef = useRef(null);
  const listRef = useRef(null);

  /* Fetch on mount */
  useEffect(() => {
    if (!fetchService) return;
    let active = true;
    setFetching(true);
    fetchService()
      .then((list) => {
        if (!active) return;
        setOptions(Array.isArray(list) ? list : []);
      })
      .catch((err) => {
        if (!active) return;
        setError(err?.message ?? "Failed to load list.");
      })
      .finally(() => { if (active) setFetching(false); });
    return () => { active = false; };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  /* Close on outside click */
  useEffect(() => {
    const handler = (e) => {
      if (wrapRef.current && !wrapRef.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  /* Focus search on open */
  useEffect(() => {
    if (open) {
      setSearch("");
      setHighlighted(-1);
      setTimeout(() => searchRef.current?.focus(), 0);
    }
  }, [open]);

  const filtered = options.filter((o) =>
    o.toLowerCase().includes(search.toLowerCase())
  );

  const selectOption = useCallback((id) => {
    setOpen(false);
    onSelect?.(id);
  }, [onSelect]);

  const handleCreate = async () => {
    if (!createService || creating) return;
    setCreating(true);
    setError(null);
    try {
      const newId = await createService();
      setOptions((prev) => [newId, ...prev]);
      selectOption(newId);
    } catch (err) {
      setError(err?.message ?? "Failed to create.");
    } finally {
      setCreating(false);
    }
  };

  /* Keyboard navigation on search input */
  const onSearchKeyDown = (e) => {
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setHighlighted((h) => Math.min(h + 1, filtered.length - 1));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setHighlighted((h) => Math.max(h - 1, 0));
    } else if (e.key === "Enter" && highlighted >= 0 && filtered[highlighted]) {
      selectOption(filtered[highlighted]);
    } else if (e.key === "Escape") {
      setOpen(false);
    }
  };

  /* Scroll highlighted item into view */
  useEffect(() => {
    if (!listRef.current) return;
    const item = listRef.current.children[highlighted];
    if (item) item.scrollIntoView({ block: "nearest" });
  }, [highlighted]);

  const displayText = value || null;
  const hasSelection = !!value;

  return (
    <div className={`isc${className ? ` ${className}` : ""}`} ref={wrapRef}>
      {label && <label className="isc__label">{label}</label>}

      <div className="isc__row">
        {/* Dropdown trigger */}
        <div className="isc__dropdown-wrap">
          <button
            type="button"
            className="isc__trigger"
            aria-haspopup="listbox"
            aria-expanded={open}
            disabled={disabled || fetching}
            onClick={() => setOpen((o) => !o)}
          >
            {fetching ? (
              <SpinnerIcon className="isc__spinner" />
            ) : null}
            <span className={`isc__trigger-text${!displayText ? " isc__trigger-text--placeholder" : ""}`}>
              {displayText ?? placeholder}
            </span>
            <ChevronIcon className="isc__chevron" />
          </button>

          {open && (
            <div className="isc__menu" role="listbox">
              <input
                ref={searchRef}
                type="text"
                className="isc__search"
                placeholder="Search…"
                value={search}
                onChange={(e) => { setSearch(e.target.value); setHighlighted(-1); }}
                onKeyDown={onSearchKeyDown}
                aria-label="Search options"
              />
              <ul ref={listRef} className="isc__options">
                {filtered.length === 0 ? (
                  <li className="isc__empty">No results found</li>
                ) : (
                  filtered.map((opt, i) => (
                    <li
                      key={opt}
                      className={[
                        "isc__option",
                        opt === value ? "isc__option--selected" : "",
                        i === highlighted ? "isc__option--highlighted" : "",
                      ].filter(Boolean).join(" ")}
                      role="option"
                      aria-selected={opt === value}
                      onMouseDown={() => selectOption(opt)}
                      onMouseEnter={() => setHighlighted(i)}
                    >
                      {opt}
                    </li>
                  ))
                )}
              </ul>
            </div>
          )}
        </div>

        {/* Green tick badge */}
        {hasSelection && (
          <span className="isc__tick" aria-label="Selected" title={`Selected: ${value}`}>
            <TickIcon />
          </span>
        )}

        {/* Create button */}
        {createService && (
          <button
            type="button"
            className="isc__create-btn"
            onClick={handleCreate}
            disabled={disabled || creating || fetching}
            title="Create new ID"
          >
            {creating ? (
              <SpinnerIcon className="isc__spinner" />
            ) : (
              <span className="isc__create-icon" aria-hidden="true"><PlusIcon /></span>
            )}
            Create
          </button>
        )}
      </div>

      {error && <p className="isc__msg isc__msg--error" role="alert">{error}</p>}
    </div>
  );
}
