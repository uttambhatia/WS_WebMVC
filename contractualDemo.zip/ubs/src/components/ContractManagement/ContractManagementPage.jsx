import { useCallback, useState } from "react";
import DataTable from "../DataTable/DataTable";
import InlineFullscreenPanel from "../shared/InlineFullscreenPanel";
import {
  approveContract,
  downloadContract,
  fetchContractAudit,
  rejectContract,
  searchContracts,
  submitContractForReview,
  updateContract,
} from "../../services/contractManagementService";
import "./ContractManagementPage.css";

const COLUMNS = [
  { key: "documentName", label: "Document Name" },
  { key: "documentLink", label: "Document Link" },
  { key: "clientIdentifier", label: "Client Identifier" },
  { key: "cdokType", label: "CDOK Type" },
  { key: "status", label: "Status" },
  { key: "editedBy", label: "Edited By" },
];

const SORTABLE_COLUMNS = COLUMNS.map((c) => c.key);
const SEARCHABLE_COLUMNS = COLUMNS.map((c) => c.key);

function getActions(status) {
  if (status === "Draft") {
    return ["edit", "view", "download", "audit"];
  }
  if (status === "In review") {
    return ["view", "approve", "reject", "download", "audit"];
  }
  if (status === "Approved") {
    return ["view", "approve", "download", "audit"];
  }
  return ["view", "download", "audit"];
}

function emptyGoverningLaw() {
  return {
    applicable: "",
    accuracy: "",
    snippet: "",
    page: "",
    country: "",
  };
}

function emptyJurisdiction() {
  return {
    applicable: "",
    accuracy: "",
    snippet: "",
    page: "",
    risk: "",
    reasoning: "",
  };
}

function normalizeGoverningLaw(item) {
  if (!item || typeof item !== "object") {
    return emptyGoverningLaw();
  }
  return {
    applicable: item.applicable || "",
    accuracy: item.accuracy || "",
    snippet: item.snippet || "",
    page: item.page || "",
    country: item.country || "",
  };
}

function normalizeJurisdiction(item) {
  if (!item || typeof item !== "object") {
    return emptyJurisdiction();
  }
  return {
    applicable: item.applicable || "",
    accuracy: item.accuracy || "",
    snippet: item.snippet || "",
    page: item.page || "",
    risk: item.risk || "",
    reasoning: item.reasoning || "",
  };
}

export default function ContractManagementPage() {
  const [reloadToken, setReloadToken] = useState(0);
  const [error, setError] = useState("");

  const [enableRemotePaging, setEnableRemotePaging] = useState(true);
  const [enableRemoteSorting, setEnableRemoteSorting] = useState(true);
  const [enableRemoteFiltering, setEnableRemoteFiltering] = useState(true);
  const [statusTransitionEnabled, setStatusTransitionEnabled] = useState(true);
  const [auditingEnabled, setAuditingEnabled] = useState(true);

  const [panelMode, setPanelMode] = useState("");
  const [activeRecord, setActiveRecord] = useState(null);
  const [auditItems, setAuditItems] = useState([]);
  const [downloadOpenId, setDownloadOpenId] = useState("");

  // DataTable service: adapts DataTable result shape to { data, total }
  const contractTableService = useCallback(async (params) => {
    const result = await searchContracts(params);
    return {
      data: Array.isArray(result.content) ? result.content : [],
      total: result.totalElements ?? 0,
    };
  }, []);

  // Adapter: translates DataTable base params to backend query shape and injects toggle flags.
  // When toggle state changes this callback is recreated, causing DataTable to re-fetch.
  const buildServerQuery = useCallback(
    ({ page, pageSize, sort, filters }) => ({
      page: page - 1, // DataTable is 1-based; backend is 0-based
      size: pageSize,
      sortBy: sort?.[0]?.key || "documentName",
      sortDirection: sort?.[0]?.dir || "asc",
      filters,
      enableRemotePaging,
      enableRemoteSorting,
      enableRemoteFiltering,
    }),
    [enableRemotePaging, enableRemoteSorting, enableRemoteFiltering]
  );

  const openPanel = (mode, row) => {
    const legacyContainer = row.governingLawJurisdictionRows;
    const legacyRows = Array.isArray(legacyContainer) ? legacyContainer : [];
    const legacyGoverningRows =
      legacyContainer && !Array.isArray(legacyContainer) && Array.isArray(legacyContainer.governingLawRows)
        ? legacyContainer.governingLawRows
        : legacyRows.map((item) => item?.governingLaw);
    const legacyJurisdictionRows =
      legacyContainer && !Array.isArray(legacyContainer) && Array.isArray(legacyContainer.jurisdictionRows)
        ? legacyContainer.jurisdictionRows
        : legacyRows.map((item) => item?.jurisdiction);

    const next = {
      ...row,
      governingLawRows: Array.isArray(row.governingLawRows) && row.governingLawRows.length
        ? row.governingLawRows.map((item) => normalizeGoverningLaw(item))
        : legacyGoverningRows.length
          ? legacyGoverningRows.map((item) => normalizeGoverningLaw(item))
          : [emptyGoverningLaw()],
      jurisdictionRows: Array.isArray(row.jurisdictionRows) && row.jurisdictionRows.length
        ? row.jurisdictionRows.map((item) => normalizeJurisdiction(item))
        : legacyJurisdictionRows.length
          ? legacyJurisdictionRows.map((item) => normalizeJurisdiction(item))
          : [emptyJurisdiction()],
    };

    setActiveRecord(next);
    setPanelMode(mode);
  };

  const closePanel = () => {
    setActiveRecord(null);
    setAuditItems([]);
    setPanelMode("");
  };

  const updateActiveField = (key, value) => {
    setActiveRecord((prev) => ({ ...prev, [key]: value }));
  };

  const updateGoverningLawRow = (index, field, value) => {
    setActiveRecord((prev) => {
      const nextRows = [...(prev.governingLawRows || [])];
      const current = normalizeGoverningLaw(nextRows[index]);
      nextRows[index] = { ...current, [field]: value };
      return { ...prev, governingLawRows: nextRows };
    });
  };

  const updateJurisdictionRow = (index, field, value) => {
    setActiveRecord((prev) => {
      const nextRows = [...(prev.jurisdictionRows || [])];
      const current = normalizeJurisdiction(nextRows[index]);
      nextRows[index] = { ...current, [field]: value };
      return { ...prev, jurisdictionRows: nextRows };
    });
  };

  const addGoverningLawRow = () => {
    setActiveRecord((prev) => ({
      ...prev,
      governingLawRows: [...(prev.governingLawRows || []), emptyGoverningLaw()],
    }));
  };

  const addJurisdictionRow = () => {
    setActiveRecord((prev) => ({
      ...prev,
      jurisdictionRows: [...(prev.jurisdictionRows || []), emptyJurisdiction()],
    }));
  };

  const removeGoverningLawRow = (index) => {
    setActiveRecord((prev) => {
      const current = [...(prev.governingLawRows || [])];
      current.splice(index, 1);
      return {
        ...prev,
        governingLawRows: current.length ? current : [emptyGoverningLaw()],
      };
    });
  };

  const removeJurisdictionRow = (index) => {
    setActiveRecord((prev) => {
      const current = [...(prev.jurisdictionRows || [])];
      current.splice(index, 1);
      return {
        ...prev,
        jurisdictionRows: current.length ? current : [emptyJurisdiction()],
      };
    });
  };

  const onSave = async () => {
    if (!activeRecord) return;
    setError("");
    try {
      await updateContract(activeRecord.id, activeRecord, {
        statusTransitionEnabled,
        auditingEnabled,
      });

      if (statusTransitionEnabled) {
        const confirmSend = window.confirm("Send contract for review?");
        await submitContractForReview(activeRecord.id, {
          confirm: confirmSend,
          statusTransitionEnabled,
          auditingEnabled,
          actor: activeRecord.editedBy || "ui-user",
        });
      }

      closePanel();
      setReloadToken((t) => t + 1);
    } catch (saveError) {
      setError(saveError?.response?.data?.message || saveError.message || "Failed to save record");
    }
  };

  const onApprove = async (row) => {
    setError("");
    try {
      await approveContract(row.id, { statusTransitionEnabled, auditingEnabled });
      setReloadToken((t) => t + 1);
    } catch (approveError) {
      setError(approveError?.response?.data?.message || approveError.message || "Approve failed");
    }
  };

  const onReject = async (row) => {
    setError("");
    try {
      await rejectContract(row.id, { statusTransitionEnabled, auditingEnabled });
      setReloadToken((t) => t + 1);
    } catch (rejectError) {
      setError(rejectError?.response?.data?.message || rejectError.message || "Reject failed");
    }
  };

  const onAudit = async (row) => {
    setError("");
    try {
      const audit = await fetchContractAudit(row.id);
      setAuditItems(audit || []);
      setActiveRecord(row);
      setPanelMode("audit");
    } catch (auditError) {
      setError(auditError?.response?.data?.message || auditError.message || "Failed to fetch audit");
    }
  };

  const onDownload = async (row, format) => {
    try {
      await downloadContract(row.id, format);
      setDownloadOpenId("");
    } catch (downloadError) {
      setError(downloadError?.response?.data?.message || downloadError.message || "Download failed");
    }
  };

  // Row actions renderer for DataTable — status-driven, with download submenu
  const renderRowActions = useCallback(
    ({ row }) => {
      const actions = getActions(row.status);
      return (
        <div className="contract-page__actions">
          {actions.includes("edit") && (
            <button type="button" onClick={() => openPanel("edit", row)}>Edit</button>
          )}
          {actions.includes("view") && (
            <button type="button" onClick={() => openPanel("view", row)}>View</button>
          )}
          {actions.includes("approve") && (
            <button type="button" onClick={() => onApprove(row)}>Approve</button>
          )}
          {actions.includes("reject") && (
            <button type="button" onClick={() => onReject(row)}>Reject</button>
          )}
          {actions.includes("audit") && auditingEnabled && (
            <button type="button" onClick={() => onAudit(row)}>Audit Detail</button>
          )}
          {actions.includes("download") && (
            <div className="contract-page__download-menu">
              <button
                type="button"
                onClick={() => setDownloadOpenId((prev) => (prev === row.id ? "" : row.id))}
              >
                Download
              </button>
              {downloadOpenId === row.id && (
                <div className="contract-page__download-options">
                  <button type="button" onClick={() => onDownload(row, "excel")}>Excel</button>
                  <button type="button" onClick={() => onDownload(row, "csv")}>CSV</button>
                  <button type="button" onClick={() => onDownload(row, "pdf")}>PDF</button>
                </div>
              )}
            </div>
          )}
        </div>
      );
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [downloadOpenId, auditingEnabled]
  );

  const panelOpen = Boolean(activeRecord && panelMode);
  const panelTitle = panelMode === "audit" ? "Audit Timeline" : panelMode === "edit" ? "Edit Contract" : "View Contract";

  const panelBody = panelMode === "audit" ? (
    <div className="contract-page__audit">
      {!auditItems.length ? <p>No audit records.</p> : null}
      {auditItems.map((item, index) => (
        <article key={`${item.timestamp}-${index}`}>
          <h4>{item.action}</h4>
          <p><strong>By:</strong> {item.performedBy}</p>
          <p><strong>When:</strong> {item.timestamp}</p>
          <p>{item.detail}</p>
        </article>
      ))}
    </div>
  ) : activeRecord ? (
    <div className="contract-page__form">
      <div className="contract-page__form-grid">
        <label>
          Document Name
          <input
            value={activeRecord.documentName || ""}
            onChange={(event) => updateActiveField("documentName", event.target.value)}
            disabled={panelMode === "view"}
          />
        </label>
        <label>
          Document Link
          <input
            value={activeRecord.documentLink || ""}
            onChange={(event) => updateActiveField("documentLink", event.target.value)}
            disabled={panelMode === "view"}
          />
        </label>
        <label>
          Client Identifier
          <input
            value={activeRecord.clientIdentifier || ""}
            onChange={(event) => updateActiveField("clientIdentifier", event.target.value)}
            disabled={panelMode === "view"}
          />
        </label>
        <label>
          CDOK Type
          <input
            value={activeRecord.cdokType || ""}
            onChange={(event) => updateActiveField("cdokType", event.target.value)}
            disabled={panelMode === "view"}
          />
        </label>
        <label>
          Edited By
          <input
            value={activeRecord.editedBy || ""}
            onChange={(event) => updateActiveField("editedBy", event.target.value)}
            disabled={panelMode === "view"}
          />
        </label>
      </div>

      <div className="contract-page__rules-head">
        <h3>Governing Law and Jurisdiction</h3>
      </div>

      <div className="contract-page__rules-sections">
        <section className="contract-page__rules-section">
          <div className="contract-page__rules-subhead">
            <h4>Governing Law</h4>
            {panelMode === "edit" ? (
              <button type="button" onClick={addGoverningLawRow}>Add Governing Law Row</button>
            ) : null}
          </div>
          <div className="contract-page__rules-table-wrap">
            <table className="contract-page__rules-table contract-page__rules-table--governing">
              <thead>
                <tr>
                  <th>Applicable</th>
                  <th>Accuracy</th>
                  <th>Snippet</th>
                  <th>Page</th>
                  <th>Country</th>
                  {panelMode === "edit" ? <th>Action</th> : null}
                </tr>
              </thead>
              <tbody>
                {(activeRecord.governingLawRows || []).map((rawRow, index) => {
                  const row = normalizeGoverningLaw(rawRow);
                  return (
                    <tr key={`gl-${index}`}>
                      <td>
                        <input
                          value={row.applicable}
                          onChange={(event) => updateGoverningLawRow(index, "applicable", event.target.value)}
                          disabled={panelMode === "view"}
                        />
                      </td>
                      <td>
                        <input
                          value={row.accuracy}
                          onChange={(event) => updateGoverningLawRow(index, "accuracy", event.target.value)}
                          disabled={panelMode === "view"}
                        />
                      </td>
                      <td>
                        <input
                          value={row.snippet}
                          onChange={(event) => updateGoverningLawRow(index, "snippet", event.target.value)}
                          disabled={panelMode === "view"}
                        />
                      </td>
                      <td>
                        <input
                          value={row.page}
                          onChange={(event) => updateGoverningLawRow(index, "page", event.target.value)}
                          disabled={panelMode === "view"}
                        />
                      </td>
                      <td>
                        <input
                          value={row.country}
                          onChange={(event) => updateGoverningLawRow(index, "country", event.target.value)}
                          disabled={panelMode === "view"}
                        />
                      </td>
                      {panelMode === "edit" ? (
                        <td>
                          <button type="button" onClick={() => removeGoverningLawRow(index)}>Remove</button>
                        </td>
                      ) : null}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </section>

        <section className="contract-page__rules-section">
          <div className="contract-page__rules-subhead">
            <h4>Jurisdiction</h4>
            {panelMode === "edit" ? (
              <button type="button" onClick={addJurisdictionRow}>Add Jurisdiction Row</button>
            ) : null}
          </div>
          <div className="contract-page__rules-table-wrap">
            <table className="contract-page__rules-table contract-page__rules-table--jurisdiction">
              <thead>
                <tr>
                  <th>Applicable</th>
                  <th>Accuracy</th>
                  <th>Snippet</th>
                  <th>Page</th>
                  <th>Risk</th>
                  <th>Reasoning</th>
                  {panelMode === "edit" ? <th>Action</th> : null}
                </tr>
              </thead>
              <tbody>
                {(activeRecord.jurisdictionRows || []).map((rawRow, index) => {
                  const row = normalizeJurisdiction(rawRow);
                  return (
                    <tr key={`jur-${index}`}>
                      <td>
                        <input
                          value={row.applicable}
                          onChange={(event) => updateJurisdictionRow(index, "applicable", event.target.value)}
                          disabled={panelMode === "view"}
                        />
                      </td>
                      <td>
                        <input
                          value={row.accuracy}
                          onChange={(event) => updateJurisdictionRow(index, "accuracy", event.target.value)}
                          disabled={panelMode === "view"}
                        />
                      </td>
                      <td>
                        <input
                          value={row.snippet}
                          onChange={(event) => updateJurisdictionRow(index, "snippet", event.target.value)}
                          disabled={panelMode === "view"}
                        />
                      </td>
                      <td>
                        <input
                          value={row.page}
                          onChange={(event) => updateJurisdictionRow(index, "page", event.target.value)}
                          disabled={panelMode === "view"}
                        />
                      </td>
                      <td>
                        <input
                          value={row.risk}
                          onChange={(event) => updateJurisdictionRow(index, "risk", event.target.value)}
                          disabled={panelMode === "view"}
                        />
                      </td>
                      <td>
                        <input
                          value={row.reasoning}
                          onChange={(event) => updateJurisdictionRow(index, "reasoning", event.target.value)}
                          disabled={panelMode === "view"}
                        />
                      </td>
                      {panelMode === "edit" ? (
                        <td>
                          <button type="button" onClick={() => removeJurisdictionRow(index)}>Remove</button>
                        </td>
                      ) : null}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </section>
      </div>

      {panelMode === "edit" ? (
        <div className="contract-page__form-actions">
          <button type="button" onClick={closePanel}>Cancel</button>
          <button type="button" onClick={onSave}>Save</button>
        </div>
      ) : null}
    </div>
  ) : null;

  if (panelOpen) {
    return (
      <section className="contract-page">
        <InlineFullscreenPanel
          isOpen={panelOpen}
          title={panelTitle}
          onBack={closePanel}
          enableFullscreenToggle
        >
          {panelBody}
        </InlineFullscreenPanel>
      </section>
    );
  }

  return (
    <section className="contract-page">
      <header className="contract-page__header">
        <div>
          <h1>Contract Management</h1>
          <p>Remote paging, sorting, filtering with workflow and audit controls.</p>
        </div>
      </header>

      <div className="contract-page__toggles">
        <label>
          <input type="checkbox" checked={enableRemotePaging} onChange={(e) => setEnableRemotePaging(e.target.checked)} />
          Remote Paging
        </label>
        <label>
          <input type="checkbox" checked={enableRemoteSorting} onChange={(e) => setEnableRemoteSorting(e.target.checked)} />
          Remote Sorting
        </label>
        <label>
          <input type="checkbox" checked={enableRemoteFiltering} onChange={(e) => setEnableRemoteFiltering(e.target.checked)} />
          Remote Filtering
        </label>
        <label>
          <input type="checkbox" checked={statusTransitionEnabled} onChange={(e) => setStatusTransitionEnabled(e.target.checked)} />
          Status Workflow Enabled
        </label>
        <label>
          <input type="checkbox" checked={auditingEnabled} onChange={(e) => setAuditingEnabled(e.target.checked)} />
          Auditing Enabled
        </label>
      </div>

      {error ? <div className="contract-page__error">{error}</div> : null}
      <DataTable
        columns={COLUMNS}
        serverSide
        service={contractTableService}
        buildServerQuery={buildServerQuery}
        reloadToken={reloadToken}
        sortableColumns={SORTABLE_COLUMNS}
        searchableColumns={SEARCHABLE_COLUMNS}
        filterMode="manual"
        pageSize={8}
        pageSizeOptions={[5, 8, 15, 25, 50]}
        toolbarExtra={
          <button type="button" className="dt__btn" onClick={() => setReloadToken((t) => t + 1)}>
            Refresh
          </button>
        }
        renderRowActions={renderRowActions}
        rowActionsColumnLabel="Action"
        rowActionsColumnWidth="200px"
      />

    </section>
  );
}
