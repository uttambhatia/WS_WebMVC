import { useEffect, useMemo, useState } from "react";
import "./left-nav.css";

function LeftNavItem({
  item,
  level,
  collapsed,
  selectedId,
  onSelect,
  enableMainMenuCollapse,
  expandedMainMenuIds,
}) {
  const isSelected = selectedId === item.id;
  const hasChildren = Array.isArray(item.children) && item.children.length > 0;
  const canToggleMainMenu = enableMainMenuCollapse && level === 0 && hasChildren;
  const isExpanded = !canToggleMainMenu || expandedMainMenuIds.has(item.id);

  return (
    <li className="left-nav__item">
      <button
        type="button"
        className={`left-nav__button ${isSelected ? "left-nav__button--selected" : ""}`}
        style={{ paddingLeft: `${12 + level * 12}px` }}
        onClick={() => onSelect(item, { canToggleMainMenu })}
      >
        <span className="left-nav__icon" aria-hidden="true">
          {item.icon}
        </span>
        {!collapsed && <span className="left-nav__text">{item.label}</span>}
        {!collapsed && canToggleMainMenu && (
          <span className="left-nav__group-indicator" aria-hidden="true">
            {isExpanded ? "-" : "+"}
          </span>
        )}
      </button>

      {hasChildren && isExpanded && (
        <ul className="left-nav__list">
          {item.children.map((child) => (
            <LeftNavItem
              key={child.id}
              item={child}
              level={level + 1}
              collapsed={collapsed}
              selectedId={selectedId}
              onSelect={onSelect}
              enableMainMenuCollapse={enableMainMenuCollapse}
              expandedMainMenuIds={expandedMainMenuIds}
            />
          ))}
        </ul>
      )}
    </li>
  );
}

export default function LeftNav({
  items,
  initialCollapsed = false,
  onChange,
  ariaLabel = "Main navigation",
  className = "",
  enableMobileOverlay = false,
  mobileBreakpoint = 900,
  enableMainMenuCollapse = false,
  expandMainMenusByDefault = true,
  enableCollapseTooltip = false,
}) {
  const [collapsed, setCollapsed] = useState(initialCollapsed);
  const [isMobileView, setIsMobileView] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    if (!enableMobileOverlay) {
      setIsMobileView(false);
      setMobileOpen(false);
      return;
    }

    const mediaQuery = window.matchMedia(`(max-width: ${mobileBreakpoint}px)`);
    const updateMode = (event) => {
      const matches = event.matches ?? mediaQuery.matches;
      setIsMobileView(matches);
      if (!matches) {
        setMobileOpen(false);
      }
    };

    updateMode(mediaQuery);

    if (mediaQuery.addEventListener) {
      mediaQuery.addEventListener("change", updateMode);
      return () => mediaQuery.removeEventListener("change", updateMode);
    }

    mediaQuery.addListener(updateMode);
    return () => mediaQuery.removeListener(updateMode);
  }, [enableMobileOverlay, mobileBreakpoint]);

  const allIds = useMemo(() => {
    const result = [];
    const walk = (nodes) => {
      (nodes || []).forEach((node) => {
        result.push(node.id);
        if (Array.isArray(node.children) && node.children.length > 0) {
          walk(node.children);
        }
      });
    };
    walk(items || []);
    return result;
  }, [items]);

  const defaultSelected = useMemo(() => {
    const first = items?.[0];
    if (!first) {
      return "";
    }
    return first.id;
  }, [items]);

  const [selectedId, setSelectedId] = useState(defaultSelected);
  const mainMenuIdsWithChildren = useMemo(
    () => (items || []).filter((item) => Array.isArray(item.children) && item.children.length > 0).map((item) => item.id),
    [items]
  );
  const [expandedMainMenuIds, setExpandedMainMenuIds] = useState(() => {
    if (!enableMainMenuCollapse || expandMainMenusByDefault) {
      return new Set(mainMenuIdsWithChildren);
    }
    return new Set();
  });

  useEffect(() => {
    if (!items || items.length === 0) {
      setSelectedId("");
      return;
    }

    const hasSelected = allIds.includes(selectedId);
    if (!hasSelected) {
      setSelectedId(items[0].id);
    }
  }, [items, selectedId, allIds]);

  useEffect(() => {
    if (!enableMainMenuCollapse) {
      setExpandedMainMenuIds(new Set(mainMenuIdsWithChildren));
      return;
    }

    setExpandedMainMenuIds((prev) => {
      const next = new Set([...prev].filter((id) => mainMenuIdsWithChildren.includes(id)));
      if (expandMainMenusByDefault && next.size === 0) {
        return new Set(mainMenuIdsWithChildren);
      }
      return next;
    });
  }, [enableMainMenuCollapse, expandMainMenusByDefault, mainMenuIdsWithChildren]);

  const handleSelect = (item, options = {}) => {
    setSelectedId(item.id);

    if (options.canToggleMainMenu) {
      setExpandedMainMenuIds((prev) => {
        const next = new Set(prev);
        if (next.has(item.id)) {
          next.delete(item.id);
        } else {
          next.add(item.id);
        }
        return next;
      });
    }

    if (isMobileView) {
      setMobileOpen(false);
    }
    if (onChange) {
      onChange(item);
    }
  };

  const navClassName = [
    "left-nav",
    collapsed ? "left-nav--collapsed" : "",
    className,
    enableMobileOverlay && isMobileView ? "left-nav--overlay" : "",
    enableMobileOverlay && isMobileView && mobileOpen ? "left-nav--overlay-open" : "",
  ]
    .filter(Boolean)
    .join(" ");

  const collapseTooltipText = collapsed ? "Open sidebar" : "Close sidebar";

  return (
    <>
      {enableMobileOverlay && isMobileView && (
        <button
          type="button"
          className="left-nav__mobile-toggle"
          onClick={() => setMobileOpen((prev) => !prev)}
          aria-label={mobileOpen ? "Close navigation menu" : "Open navigation menu"}
          aria-expanded={mobileOpen}
          aria-controls="left-nav-overlay-panel"
        >
          {mobileOpen ? "X" : "|||"}
        </button>
      )}

      {enableMobileOverlay && isMobileView && mobileOpen && (
        <button
          type="button"
          className="left-nav__overlay-backdrop"
          onClick={() => setMobileOpen(false)}
          aria-label="Close navigation overlay"
        />
      )}

      <aside className={navClassName} id={enableMobileOverlay && isMobileView ? "left-nav-overlay-panel" : undefined}>
        <div className="left-nav__header">
          {!collapsed && <span className="left-nav__title">Menu</span>}
          <div className="left-nav__collapse-toggle-wrapper">
            <button
              type="button"
              className={`left-nav__collapse-toggle ${collapsed ? "left-nav__collapse-toggle--collapsed" : ""}`}
              onClick={() => setCollapsed((prev) => !prev)}
              aria-label={collapsed ? "Expand navigation" : "Collapse navigation"}
            >
              {collapsed ? ">" : "<"}
            </button>
            {enableCollapseTooltip && (
              <div className="left-nav__tooltip" role="tooltip">
                {collapseTooltipText}
              </div>
            )}
          </div>
        </div>

        <nav aria-label={ariaLabel} className="left-nav__body">
          <ul className="left-nav__list">
            {(items || []).map((item) => (
              <LeftNavItem
                key={item.id}
                item={item}
                level={0}
                collapsed={collapsed}
                selectedId={selectedId}
                onSelect={handleSelect}
                enableMainMenuCollapse={enableMainMenuCollapse}
                expandedMainMenuIds={expandedMainMenuIds}
              />
            ))}
          </ul>
        </nav>
      </aside>
    </>
  );
}
