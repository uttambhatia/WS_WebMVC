/**
 * Grid — responsive CSS Grid layout container system.
 *
 * Exports: Grid (container), GridItem (cell)
 *
 * Grid props:
 *   cols      {number}        Total columns (default: 12)
 *   gap       {string|number} Shorthand gap (e.g. "16px" or 16)
 *   rowGap    {string|number} Row-only gap
 *   colGap    {string|number} Column-only gap
 *   className {string}
 *   style     {object}        Extra inline styles
 *   children  {ReactNode}
 *
 * GridItem props:
 *   span     {number}         Column span for all breakpoints (default: full cols)
 *   spanSm   {number}         Span at ≥ 480px (applied via CSS var)
 *   spanMd   {number}         Span at ≥ 768px
 *   spanLg   {number}         Span at ≥ 1024px
 *   offset   {number}         Column start offset (1-based)
 *   className {string}
 *   style    {object}
 *   children {ReactNode}
 */

import "./Grid.css";

function px(v) {
  if (v === undefined || v === null) return undefined;
  return typeof v === "number" ? `${v}px` : v;
}

export function Grid({
  cols = 12,
  gap,
  rowGap,
  colGap,
  className = "",
  style = {},
  children,
  ...rest
}) {
  const inlineStyle = {
    "--ubs-grid-cols": cols,
    gridTemplateColumns: `repeat(var(--ubs-grid-cols, ${cols}), 1fr)`,
    ...(gap !== undefined ? { gap: px(gap) } : {}),
    ...(rowGap !== undefined ? { rowGap: px(rowGap) } : {}),
    ...(colGap !== undefined ? { columnGap: px(colGap) } : {}),
    ...style,
  };

  return (
    <div
      className={`ubs-grid${className ? ` ${className}` : ""}`}
      style={inlineStyle}
      {...rest}
    >
      {children}
    </div>
  );
}

export function GridItem({
  span,
  spanSm,
  spanMd,
  spanLg,
  offset,
  className = "",
  style = {},
  children,
  ...rest
}) {
  const inlineStyle = {
    ...(span !== undefined
      ? { gridColumn: `span ${span}` }
      : {}),
    ...(spanSm !== undefined ? { "--ubs-gi-span-sm": spanSm } : {}),
    ...(spanMd !== undefined ? { "--ubs-gi-span-md": spanMd } : {}),
    ...(spanLg !== undefined ? { "--ubs-gi-span-lg": spanLg } : {}),
    ...(offset !== undefined ? { gridColumnStart: offset } : {}),
    ...style,
  };

  return (
    <div
      className={`ubs-grid-item${className ? ` ${className}` : ""}`}
      style={inlineStyle}
      {...rest}
    >
      {children}
    </div>
  );
}

export default Grid;
