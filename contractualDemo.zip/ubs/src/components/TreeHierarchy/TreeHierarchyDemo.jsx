import { useRef, useState } from "react";
import TreeHierarchySelector from "./TreeHierarchySelector";
import sampleHierarchy from "../../tree_hierachy_with_select_checkbox.json";
import { fetchTreeHierarchy } from "../../services/testManagementService";

export default function TreeHierarchyDemo() {
  const selectorRef = useRef(null);
  const [relativePreview, setRelativePreview] = useState([]);
  const [absolutePreview, setAbsolutePreview] = useState([]);

  const loadSelectionPreview = () => {
    const relative = selectorRef.current?.getSelectedRelativePaths?.() || [];
    const absolute = selectorRef.current?.getSelectedAbsolutePaths?.() || [];
    setRelativePreview(relative);
    setAbsolutePreview(absolute);
  };

  return (
    <div className="tree-hierarchy-demo">
      <TreeHierarchySelector
        ref={selectorRef}
        data={sampleHierarchy}
        fetchHierarchy={fetchTreeHierarchy}
        streamPathIndex={1}
        regionPathIndex={2}
        lockAutoSelectedParents
        title="File and Folder Selection"
      />

      <div className="tree-hierarchy-actions">
        <button type="button" onClick={loadSelectionPreview}>
          Preview Selected Paths
        </button>
        <button
          type="button"
          onClick={() => {
            selectorRef.current?.clearSelection?.();
            setRelativePreview([]);
            setAbsolutePreview([]);
          }}
        >
          Clear Selection
        </button>
      </div>

      <div className="tree-hierarchy-output-grid">
        <section>
          <h3>Selected Relative Paths</h3>
          <pre>
            {relativePreview.length > 0
              ? relativePreview.join("\n")
              : "No selected files yet."}
          </pre>
        </section>

        <section>
          <h3>Selected Absolute Paths</h3>
          <pre>
            {absolutePreview.length > 0
              ? absolutePreview.join("\n")
              : "No selected files yet."}
          </pre>
        </section>
      </div>
    </div>
  );
}
