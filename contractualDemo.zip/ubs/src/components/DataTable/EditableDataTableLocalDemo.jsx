import { useMemo, useState } from "react";
import DataTable from "./DataTable";
import "./EditableDataTableDemo.css";

const INITIAL_ROWS = [
  {
    employeeId: "EMP-1001",
    name: "Ava Miller",
    team: "Platform",
    role: "QA Lead",
    startDate: "2026-01-15",
    isActive: true,
    notes: "Owns release-readiness checks for payment workflows.",
  },
  {
    employeeId: "EMP-1002",
    name: "Rahul Bose",
    team: "Digital Banking",
    role: "Automation Engineer",
    startDate: "2025-11-04",
    isActive: true,
    notes: "Focuses on regression coverage for onboarding journeys.",
  },
  {
    employeeId: "EMP-1003",
    name: "Mina Park",
    team: "Risk",
    role: "Business Analyst",
    startDate: "2026-02-09",
    isActive: false,
    notes: "Captures validation gaps before approval sign-off.",
  },
];

export default function EditableDataTableLocalDemo() {
  const [rows, setRows] = useState(INITIAL_ROWS);

  const columns = useMemo(() => ([
    {
      key: "employeeId",
      label: "Employee Id",
      width: "16%",
      required: true,
      validate: (value, draft, current) => {
        if (!value) {
          return null;
        }

        const normalized = String(value).trim().toUpperCase();
        const duplicate = rows.some((row) => row.employeeId === normalized && row.employeeId !== current?.employeeId);
        return duplicate ? "Employee Id must be unique." : null;
      },
      parseEditValue: (value) => String(value || "").trim().toUpperCase(),
      editPlaceholder: "EMP-1004",
    },
    {
      key: "name",
      label: "Name",
      width: "20%",
      required: true,
      parseEditValue: (value) => String(value || "").trimStart(),
    },
    {
      key: "team",
      label: "Team",
      width: "16%",
      required: true,
      editType: "select",
      editOptions: ["Platform", "Digital Banking", "Risk", "Operations"],
    },
    {
      key: "role",
      label: "Role",
      width: "14%",
      required: true,
      editType: "select",
      editOptions: ["QA Lead", "Automation Engineer", "Business Analyst", "Release Manager"],
    },
    {
      key: "startDate",
      label: "Start Date",
      width: "14%",
      required: true,
      editType: "date",
      maxDate: "2032-12-31",
      validate: (value) => (!value ? null : value > "2032-12-31" ? "Start Date must be on or before 2032-12-31." : null),
    },
    {
      key: "isActive",
      label: "Active",
      width: "10%",
      editType: "checkbox",
      checkboxLabel: "Enabled",
      render: (value) => (value ? "Yes" : "No"),
    },
    {
      key: "notes",
      label: "Notes",
      editType: "textarea",
      truncate: 56,
      validate: (value) => (String(value || "").trim().length < 12 ? "Notes must be at least 12 characters." : null),
    },
  ]), [rows]);

  return (
    <div className="dt-demo">
      <section className="dt-demo__panel">
        <span className="dt-demo__eyebrow">Editable DataTable</span>
        <h1 className="dt-demo__title">Local editable table demo</h1>
        <p className="dt-demo__description">
          This demo uses the editable mode with validation only. Add, edit, save, and remove operate completely inside the component,
          while committed row updates are pushed back into the parent via the optional rows-change callback.
        </p>
      </section>

      <section className="dt-demo__meta">
        <div className="dt-demo__meta-item">
          Rows in dataset:
          <strong>{rows.length}</strong>
        </div>
        <div className="dt-demo__meta-item">
          Services:
          <strong>Not injected</strong>
        </div>
        <div className="dt-demo__meta-item">
          Validation:
          <strong>Required + custom</strong>
        </div>
      </section>

      <section className="dt-demo__panel">
        <DataTable
          columns={columns}
          data={rows}
          pageSize={5}
          pageSizeOptions={[5, 10, 25]}
          sortableColumns={["employeeId", "name", "team", "role", "startDate", "isActive"]}
          searchableColumns={["employeeId", "name", "team", "role", "startDate", "isActive", "notes"]}
          paginationPlacement="top"
          editable
          editableOptions={{
            rowKey: "employeeId",
            onRowsChange: setRows,
            createEmptyRow: () => ({
              employeeId: "",
              name: "",
              team: "",
              role: "",
              startDate: "",
              isActive: false,
              notes: "",
            }),
          }}
        />
      </section>

      <section className="dt-demo__panel">
        <h2 className="dt-demo__title">What this demonstrates</h2>
        <ul className="dt-demo__list">
          <li>The extra action column is added automatically when editable mode is enabled.</li>
          <li>The table-level add action inserts a new editable row at the top of the table.</li>
          <li>Required columns and custom validators block save until the row is valid.</li>
        </ul>
      </section>
    </div>
  );
}