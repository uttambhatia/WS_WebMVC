import { useMemo, useState } from "react";
import DataTable from "./DataTable";
import "./EditableDataTableDemo.css";

const INITIAL_ROWS = [
  {
    requestId: "REQ-501",
    summary: "ATM withdrawal flow",
    owner: "Nina Gomez",
    priority: "High",
    status: "Draft",
    dueDate: "2026-05-01",
    regulatorySignoff: true,
  },
  {
    requestId: "REQ-502",
    summary: "Credit card chargeback path",
    owner: "Samir Patel",
    priority: "Medium",
    status: "Review",
    dueDate: "2026-05-18",
    regulatorySignoff: false,
  },
  {
    requestId: "REQ-503",
    summary: "International transfer validation",
    owner: "Lea Fischer",
    priority: "Low",
    status: "Approved",
    dueDate: "2026-06-03",
    regulatorySignoff: true,
  },
];

function delay(value) {
  return new Promise((resolve) => {
    window.setTimeout(() => resolve(value), 350);
  });
}

export default function EditableDataTableServiceDemo() {
  const [rows, setRows] = useState(INITIAL_ROWS);
  const [logLines, setLogLines] = useState([
    "[ready] Service hooks are idle.",
  ]);

  const appendLog = (message) => {
    setLogLines((prev) => [`[${new Date().toLocaleTimeString()}] ${message}`, ...prev].slice(0, 10));
  };

  const columns = useMemo(() => ([
    {
      key: "requestId",
      label: "Request Id",
      width: "16%",
      required: true,
      parseEditValue: (value) => String(value || "").trim().toUpperCase(),
      validate: (value, draft, current) => {
        if (!value) {
          return null;
        }
        const duplicate = rows.some((row) => row.requestId === value && row.requestId !== current?.requestId);
        return duplicate ? "Request Id must be unique." : null;
      },
    },
    {
      key: "summary",
      label: "Summary",
      required: true,
      editType: "textarea",
      truncate: 54,
      validate: (value) => (String(value || "").trim().length < 15 ? "Summary must be at least 15 characters." : null),
    },
    {
      key: "owner",
      label: "Owner",
      width: "18%",
      required: true,
    },
    {
      key: "priority",
      label: "Priority",
      width: "14%",
      required: true,
      editType: "select",
      editOptions: ["Low", "Medium", "High"],
    },
    {
      key: "status",
      label: "Status",
      width: "12%",
      required: true,
      editType: "select",
      editOptions: ["Draft", "Review", "Approved"],
    },
    {
      key: "dueDate",
      label: "Due Date",
      width: "14%",
      required: true,
      editType: "date",
      minDate: "2025-01-01",
      validate: (value) => (!value ? null : value < "2025-01-01" ? "Due Date must be on or after 2025-01-01." : null),
    },
    {
      key: "regulatorySignoff",
      label: "Reg Signoff",
      width: "12%",
      required: true,
      editType: "checkbox",
      checkboxLabel: "Confirmed",
      render: (value) => (value ? "Confirmed" : "Pending"),
    },
  ]), [rows]);

  const editableOptions = useMemo(() => ({
    rowKey: "requestId",
    onRowsChange: setRows,
    createEmptyRow: () => ({
      requestId: "",
      summary: "",
      owner: "",
      priority: "",
      status: "Draft",
      dueDate: "",
      regulatorySignoff: false,
    }),
    onEditRow: async ({ row }) => {
      appendLog(`edit called for ${row.requestId || "new draft"}`);
      return delay(row);
    },
    onSaveRow: async ({ row, isNew, previousRow }) => {
      const persistedRow = await delay({
        ...row,
        requestId: row.requestId || `REQ-${600 + rows.length + 1}`,
      });
      appendLog(`save called for ${isNew ? "new row" : previousRow.requestId} -> ${persistedRow.requestId}`);
      return persistedRow;
    },
    onRemoveRow: async ({ row, isNew }) => {
      appendLog(`remove called for ${isNew ? "unsaved draft" : row.requestId}`);
      await delay(true);
    },
  }), [rows]);

  return (
    <div className="dt-demo">
      <section className="dt-demo__panel">
        <span className="dt-demo__eyebrow">Editable DataTable</span>
        <h1 className="dt-demo__title">Service-injected editable table demo</h1>
        <p className="dt-demo__description">
          This variant injects async edit, save, and remove handlers. The table still owns the edit state, but every action calls the provided service first,
          then commits the returned row data into the grid.
        </p>
      </section>

      <section className="dt-demo__meta">
        <div className="dt-demo__meta-item">
          Rows in dataset:
          <strong>{rows.length}</strong>
        </div>
        <div className="dt-demo__meta-item">
          Services:
          <strong>Edit + Save + Remove</strong>
        </div>
        <div className="dt-demo__meta-item">
          Request log:
          <strong>{logLines.length} entries</strong>
        </div>
      </section>

      <section className="dt-demo__panel">
        <DataTable
          columns={columns}
          data={rows}
          pageSize={5}
          pageSizeOptions={[5, 10, 25]}
          sortableColumns={["requestId", "owner", "priority", "status", "dueDate", "regulatorySignoff"]}
          searchableColumns={["requestId", "summary", "owner", "priority", "status", "dueDate", "regulatorySignoff"]}
          paginationPlacement="top"
          editable
          editableOptions={editableOptions}
        />
      </section>

      <section className="dt-demo__panel">
        <h2 className="dt-demo__title">Injected service log</h2>
        <pre className="dt-demo__log">
          {logLines.map((line, index) => (
            <div key={`${line}-${index}`} className="dt-demo__log-line">{line}</div>
          ))}
        </pre>
      </section>
    </div>
  );
}