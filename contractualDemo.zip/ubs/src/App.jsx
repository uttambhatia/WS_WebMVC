import { useMemo, useState } from "react";
import LeftNav from "./components/LeftNav";
import StageFlowPanelDemo from "./components/StageFlowPanel/StageFlowPanelDemo";
import CaseManagementPage from "./components/CaseManagement/CaseManagementPage";
import EditableDataTableLocalDemo from "./components/DataTable/EditableDataTableLocalDemo";
import EditableDataTableServiceDemo from "./components/DataTable/EditableDataTableServiceDemo";
import TreeHierarchyDemo from "./components/TreeHierarchy/TreeHierarchyDemo";
import ContractManagementPage from "./components/ContractManagement/ContractManagementPage";

function MenuIcon({ name }) {
  switch (name) {
    case "dashboard":
      return (
        <svg viewBox="0 0 24 24" aria-hidden="true">
          <rect x="3" y="3" width="7" height="8" rx="1.5" />
          <rect x="14" y="3" width="7" height="5" rx="1.5" />
          <rect x="14" y="11" width="7" height="10" rx="1.5" />
          <rect x="3" y="14" width="7" height="7" rx="1.5" />
        </svg>
      );
    case "users":
      return (
        <svg viewBox="0 0 24 24" aria-hidden="true">
          <circle cx="8" cy="8" r="3" />
          <circle cx="16" cy="9" r="2.5" />
          <path d="M3.5 19a4.5 4.5 0 0 1 9 0" fill="none" stroke="currentColor" strokeWidth="2" />
          <path d="M13 19a3.5 3.5 0 0 1 7 0" fill="none" stroke="currentColor" strokeWidth="2" />
        </svg>
      );
    case "list":
      return (
        <svg viewBox="0 0 24 24" aria-hidden="true">
          <circle cx="5" cy="7" r="1.5" />
          <circle cx="5" cy="12" r="1.5" />
          <circle cx="5" cy="17" r="1.5" />
          <rect x="9" y="6" width="11" height="2" rx="1" />
          <rect x="9" y="11" width="11" height="2" rx="1" />
          <rect x="9" y="16" width="11" height="2" rx="1" />
        </svg>
      );
    case "groups":
      return (
        <svg viewBox="0 0 24 24" aria-hidden="true">
          <rect x="3" y="4" width="8" height="6" rx="1.5" />
          <rect x="13" y="4" width="8" height="6" rx="1.5" />
          <rect x="8" y="14" width="8" height="6" rx="1.5" />
        </svg>
      );
    case "settings":
      return (
        <svg viewBox="0 0 24 24" aria-hidden="true">
          <circle cx="12" cy="12" r="3" />
          <path d="M12 2v3M12 19v3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M2 12h3M19 12h3M4.9 19.1L7 17M17 7l2.1-2.1" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
        </svg>
      );
    case "general":
      return (
        <svg viewBox="0 0 24 24" aria-hidden="true">
          <rect x="4" y="4" width="16" height="16" rx="2" fill="none" stroke="currentColor" strokeWidth="2" />
          <path d="M8 8h8M8 12h8M8 16h5" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
        </svg>
      );
    case "security":
      return (
        <svg viewBox="0 0 24 24" aria-hidden="true">
          <rect x="6" y="10" width="12" height="10" rx="2" fill="none" stroke="currentColor" strokeWidth="2" />
          <path d="M9 10V8a3 3 0 0 1 6 0v2" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
        </svg>
      );
    case "stages":
      return (
        <svg viewBox="0 0 24 24" aria-hidden="true">
          <circle cx="4" cy="12" r="2.5" fill="currentColor" />
          <circle cx="12" cy="12" r="2.5" fill="currentColor" />
          <circle cx="20" cy="12" r="2.5" fill="currentColor" />
          <line x1="6.5" y1="12" x2="9.5" y2="12" stroke="currentColor" strokeWidth="2" />
          <line x1="14.5" y1="12" x2="17.5" y2="12" stroke="currentColor" strokeWidth="2" />
        </svg>
      );
    case "case-management":
      return (
        <svg viewBox="0 0 24 24" aria-hidden="true">
          <rect x="4" y="3" width="16" height="18" rx="2" fill="none" stroke="currentColor" strokeWidth="2" />
          <path d="M8 3v2h8V3" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          <path d="M8 10h8M8 14h5" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          <polyline points="7 7 8.5 8.5 11 6" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );
    case "table-edit":
      return (
        <svg viewBox="0 0 24 24" aria-hidden="true">
          <rect x="3" y="4" width="18" height="14" rx="2" fill="none" stroke="currentColor" strokeWidth="2" />
          <path d="M3 9h18M9 4v14" fill="none" stroke="currentColor" strokeWidth="2" />
          <path d="M14 20l4.5-4.5 1.5 1.5L15.5 21.5H14z" fill="currentColor" />
        </svg>
      );
    case "tree-hierarchy":
      return (
        <svg viewBox="0 0 24 24" aria-hidden="true">
          <path d="M4 6h7v4H4z" fill="none" stroke="currentColor" strokeWidth="2" />
          <path d="M13 4h7v4h-7z" fill="none" stroke="currentColor" strokeWidth="2" />
          <path d="M13 14h7v6h-7z" fill="none" stroke="currentColor" strokeWidth="2" />
          <path d="M7.5 10v4h5.5" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          <path d="M16.5 8v6" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
        </svg>
      );
    case "contracts":
      return (
        <svg viewBox="0 0 24 24" aria-hidden="true">
          <rect x="4" y="3" width="16" height="18" rx="2" fill="none" stroke="currentColor" strokeWidth="2" />
          <path d="M8 8h8M8 12h8M8 16h8" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          <circle cx="18" cy="16" r="2" fill="currentColor" />
        </svg>
      );
    default:
      return (
        <svg viewBox="0 0 24 24" aria-hidden="true">
          <circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" strokeWidth="2" />
          <circle cx="12" cy="8" r="1.2" />
          <rect x="11" y="11" width="2" height="7" rx="1" />
        </svg>
      );
  }
}

const menuItems = [
  { id: "dashboard", label: "Dashboard", icon: <MenuIcon name="dashboard" /> },
  {
    id: "users",
    label: "Users",
    icon: <MenuIcon name="users" />,
    children: [
      { id: "users-list", label: "User List", icon: <MenuIcon name="list" /> },
      { id: "users-groups", label: "Groups", icon: <MenuIcon name="groups" /> },
    ],
  },
  {
    id: "settings",
    label: "Settings",
    icon: <MenuIcon name="settings" />,
    children: [
      { id: "general-settings", label: "General", icon: <MenuIcon name="general" /> },
      { id: "security-settings", label: "Security", icon: <MenuIcon name="security" /> },
    ],
  },
  { id: "help", label: "Help", icon: <MenuIcon name="help" /> },
  { id: "stage-flow", label: "AI Test Platform", icon: <MenuIcon name="stages" /> },
  { id: "case-management", label: "Case Management", icon: <MenuIcon name="case-management" /> },
  { id: "editable-datatable-local", label: "Editable DT Local", icon: <MenuIcon name="table-edit" /> },
  { id: "editable-datatable-service", label: "Editable DT Service", icon: <MenuIcon name="table-edit" /> },
  { id: "tree-hierarchy", label: "Tree Hierarchy", icon: <MenuIcon name="tree-hierarchy" /> },
  { id: "contract-management", label: "Contract Management", icon: <MenuIcon name="contracts" /> },
];

export default function App() {
  const [selectedItem, setSelectedItem] = useState(menuItems[0]);

  const contentTitle = useMemo(() => selectedItem?.label || "Home", [selectedItem]);

  return (
    <div className="app-shell">
      <LeftNav
        items={menuItems}
        onChange={setSelectedItem}
        enableMobileOverlay
        enableMainMenuCollapse
        expandMainMenusByDefault={false}
        enableCollapseTooltip
      />

      <main className="app-content">
        {selectedItem?.id === "stage-flow" ? (
          <StageFlowPanelDemo />
        ) : selectedItem?.id === "case-management" ? (
          <CaseManagementPage
            showComparisonCheckboxes
            maxComparisonCount={3}
            showEvaluationRating
          />
        ) : selectedItem?.id === "editable-datatable-local" ? (
          <EditableDataTableLocalDemo />
        ) : selectedItem?.id === "editable-datatable-service" ? (
          <EditableDataTableServiceDemo />
        ) : selectedItem?.id === "tree-hierarchy" ? (
          <TreeHierarchyDemo />
        ) : selectedItem?.id === "contract-management" ? (
          <ContractManagementPage />
        ) : (
          <>
            <h1>{contentTitle}</h1>
            <p>
              Select menu items from the left. The component supports hierarchy without item arrows,
              collapse/expand behavior, and a red selected menu label.
            </p>
          </>
        )}
      </main>
    </div>
  );
}
