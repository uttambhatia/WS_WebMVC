/// <reference types="vitest" />
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import path from 'path'

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  test: {
    environment: 'jsdom',
    globals: true,
    pool: 'vmThreads',
    setupFiles: ['src/__tests__/setup.ts'],
  },
  build: {
    // Keep declaration files emitted by `npm run build:types`.
    emptyOutDir: false,
    lib: {
      entry: path.resolve(__dirname, 'src/index.ts'),
      name: 'ReactJsFramework',
      formats: ['es', 'cjs'],
      fileName: (format) => `my-react-framework.${format}.js`,
    },
    rollupOptions: {
      // Do not bundle peer dependencies
      external: ['react', 'react-dom', 'react-router-dom'],
      output: {
        globals: {
          react: 'React',
          'react-dom': 'ReactDOM',
          'react-router-dom': 'ReactRouterDOM',
        },
      },
    },
  },
})
