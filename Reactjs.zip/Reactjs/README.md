# Reactjs Framework

Pluggable React framework shell for layout switching, theme switching, and route registration with deterministic bootstrap diagnostics.

## What This Framework Provides
- Registry-driven extension model for routes, themes, and layouts.
- Declarative startup via `FrameworkConfig` + `initializeFramework`.
- Runtime provider with persisted layout/theme preferences.
- Built-in layouts and themes via `corePlugin`.

## Quick Start
### Install
```bash
npm install reactjs-framework
```

### Minimum App Setup
```tsx
import { BrowserRouter } from 'react-router-dom'
import {
  LayoutProvider,
  LayoutRenderer,
  framework,
  corePlugin,
  initializeFramework,
  type FrameworkConfig,
} from 'reactjs-framework'
import { HomePage } from './pages/HomePage'

const config: FrameworkConfig = {
  appTitle: 'My App',
  defaultLayoutId: 'sidebar',
  defaultThemeId: 'ubs',
  plugins: [corePlugin],
  routes: [{ path: '/', element: <HomePage />, label: 'Home' }],
  themes: [],
}

const init = initializeFramework(framework, config)
if (!init.success) {
  console.error('[Framework] Initialization errors', init.errors)
}
if (init.warnings.length > 0) {
  console.warn('[Framework] Initialization warnings', init.warnings)
}

export default function App() {
  return (
    <BrowserRouter>
      <LayoutProvider
        framework={framework}
        appTitle={config.appTitle}
        defaultLayoutId={config.defaultLayoutId}
        defaultThemeId={config.defaultThemeId}
      >
        <LayoutRenderer />
      </LayoutProvider>
    </BrowserRouter>
  )
}
```

## Getting Started Notes
- Required fields: `plugins`, `routes`, `themes`.
- Optional fields: `appTitle`, `appLogo`, `defaultLayoutId`, `defaultThemeId`.
- Run initialization once at module level before rendering.

## Built-In Features
- `corePlugin` includes:
  - Layouts: `sidebar`, `topnav`, `focused-workspace`, `list-detail-responsive`, `adaptive-two-pane`, `card-grid-flow`, `step-journey`, `command-surface`
  - Themes: `ubs`, `classic`, `high-contrast`, `steel-ledger`, `executive-ivory`, `ops-command-green`, `regulatory-slate`, `carbon-commerce`, `azure-governance`, `boardroom-monochrome`, `industrial-teal`, `sovereign-burgundy`, `data-lab-cobalt`, `core-banking-blue`, `treasury-midnight`, `compliance-ledger`, `wealth-advisory-ivory`, `payments-velocity`, `credit-risk-slate`, `islamic-finance-emerald`, `corporate-cashflow-graphite`, `trade-finance-sepia`, `digital-onboarding-sky`, `ubs-signature-red`, `ubs-wealth-ivory`, `ubs-midnight-markets`, `ubs-alpine-trust`
- Hooks:
  - `useLayout()` for layout selection state.
  - `useTheme()` for theme selection state.
- Built-in component export:
  - `ThemeSwitcher`

## Governance Documentation
- `docs/governance/ARCHITECTURE.md`: architectural layers, module responsibilities, and flow diagram.
- `docs/governance/PLUGIN_GUIDE.md`: plugin contract, registration mechanics, and examples.
- `docs/governance/DESIGN_RULES.md`: spacing/typography/color system and cleanup roadmap.
- `docs/governance/COMPONENT_INVENTORY.md`: component behaviors, customization points, stability.
- `docs/governance/MIGRATION_GUIDE.md`: guard-check to bootstrap migration path.
- `docs/governance/A3_ACCEPTANCE_TRACEABILITY.md`: A3 acceptance criteria mapping.
- `docs/governance/ENTERPRISE_THEME_CATALOG.md`: enterprise theme portfolio, rollout plan, and implementation status.
- `docs/governance/BANKING_THEME_CATALOG.md`: banking-domain theme catalog and usage guidance.
- `docs/governance/THEME_STYLE_MATRIX.md`: Look and Feel vs Theme vs Component Styles governance matrix.
- `docs/governance/TOKEN_ENFORCEMENT_PLAN.md`: phased token-enforcement plan and CI guardrails.
- `VERSIONING.md`: API stability tiers and semantic versioning policy.

## Example References
- Plugin example: `src/plugins/example/index.tsx`
- Consumer integration example: `../ReactConsumer/src/App.tsx`

## API Stability
- Stable: core runtime APIs exported by `src/index.ts`.
- Alpha: `LayoutContextValue`.
- Internal APIs are intentionally excluded from package root exports.

For details, see `VERSIONING.md`.

## Contributing and Governance
- Keep docs aligned with source behavior and public exports.
- Record architecture and design decisions in governance docs.
- Avoid introducing dependencies on internal APIs.

## Support
- Open issues with:
  - framework version
  - minimal reproduction
  - initialization diagnostics (`errors`/`warnings`)
- Include expected vs actual behavior and affected docs section.
