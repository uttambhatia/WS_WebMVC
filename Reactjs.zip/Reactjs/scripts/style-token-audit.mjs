import { readFileSync } from 'node:fs'
import { resolve } from 'node:path'

const workspaceRoot = resolve(process.cwd())

const auditTargets = [
  {
    file: 'Reactjs/src/framework/framework.css',
    maxRawColorLiterals: 0,
    ignoreLine: (line) => /^\s*--/.test(line),
  },
  {
    file: 'Reactjs/src/components/core/core.css',
    maxRawColorLiterals: 0,
    ignoreLine: () => false,
  },
  {
    file: 'Reactjs/src/plugins/example/example.css',
    maxRawColorLiterals: 0,
    ignoreLine: () => false,
  },
  {
    file: 'Reactjs/src/App.css',
    maxRawColorLiterals: 0,
    ignoreLine: () => false,
  },
  {
    file: 'Reactjs/src/index.css',
    maxRawColorLiterals: 4,
    ignoreLine: (line) => line.trim().startsWith('--'),
  },
]

const colorLiteralRegex = /#(?:[0-9a-fA-F]{3,8})\b|rgba?\([^)]*\)|hsla?\([^)]*\)/g

function normalizeTokenFallbacks(line) {
  // Ignore fallback literals in var(--token, <literal>) because they are tokenized call sites.
  return line.replace(/var\((--[\w-]+)\s*,\s*[^)]+\)/g, 'var($1)')
}

function countRawColorLiterals(filePath, ignoreLine) {
  const content = readFileSync(resolve(workspaceRoot, filePath), 'utf8')
  const lines = content.split(/\r?\n/)
  let count = 0
  for (const line of lines) {
    if (ignoreLine(line)) {
      continue
    }
    const normalizedLine = normalizeTokenFallbacks(line)
    // Skip lines where all color literal matches are inside var() references
    if (/var\(--[\w-]+\)/.test(normalizedLine)) {
      continue
    }
    const matches = normalizedLine.match(colorLiteralRegex)
    if (matches) {
      count += matches.length
    }
  }
  return count
}

let failed = false

console.log('[Style Audit] Token usage baseline check')
for (const target of auditTargets) {
  const count = countRawColorLiterals(target.file, target.ignoreLine)
  const withinLimit = count <= target.maxRawColorLiterals

  console.log(`- ${target.file}: ${count} raw color literals (limit ${target.maxRawColorLiterals})`)

  if (!withinLimit) {
    failed = true
    console.error(
      `  > Regression detected in ${target.file}: raw color literal count exceeded baseline limit.`,
    )
  }
}

if (failed) {
  console.error(
    '\n[Style Audit] Failed. Reduce hard-coded color literals or update the governance plan and baseline intentionally.',
  )
  process.exit(1)
}

console.log('\n[Style Audit] Passed. No token-usage regressions detected against baseline.')
