# Versioning Policy

This package follows [Semantic Versioning](https://semver.org/) (semver).

---

## Stability Tiers

Exports in `src/index.ts` are classified into three tiers.

### Stable (default)

All exports without an `@alpha` tag are **stable**. Consumers can depend on them across releases.

- Breaking changes require a **major** version bump and a migration guide in `CHANGELOG.md`.
- A breaking change is any change that may require consumer code updates:
  - Removing or renaming an export
  - Adding required parameters to a function
  - Changing a return type in a non-additive way
  - Removing or narrowing a field from an exported type

### Alpha (`@alpha`)

Exports tagged `@alpha` in the `// PUBLIC ALPHA` section of `index.ts` are intentionally unstable.

- May change in **minor** or **patch** releases.
- Changes are still documented in `CHANGELOG.md`.
- Avoid depending on alpha exports in production-critical paths.

### Internal (`@internal`)

Items tagged `@internal` in source code are **not exported** from `index.ts`.

- They appear in source files but form no part of the public contract.
- May change freely between any releases.
- No changelog entry required for internal changes.

---

## Version Semantics

| Release type | When to use | Example trigger |
|---|---|---|
| **Major** (`X.0.0`) | Breaking change to a stable export | Removing `useLayout`, changing `LayoutProviderProps` |
| **Minor** (`0.X.0`) | Backward-compatible new feature | New stable hook, new plugin API |
| **Patch** (`0.0.X`) | Bug fix, internal refactor, docs | Fix theme fallback, update README |

---

## Pre-1.0 Policy

While the version is `0.x.x`:

- **Stable exports** are still protected — breaking them requires a **major** bump even before 1.0.
- **Minor bumps** (`0.X.0`) may include minor breaking changes to `@alpha` exports only.
- `1.0.0` will be published when Phase B (Extensibility Core) completes and the API has been validated across at least one real consumer application.

---

## Breaking Change Process

1. Add a `### Breaking Changes` section to `CHANGELOG.md` under the new version entry.
2. Describe what changed and why.
3. Provide a **before/after migration snippet** for each breaking item.
4. If migrating requires more than 5 lines of consumer code changes, create a dedicated migration guide at `docs/migration/vX.md` and link to it from the changelog.

---

## Peer Dependencies

| Dependency | Locked to | Reason |
|---|---|---|
| `react` | `^19.2.0` | Framework uses React 19 hooks API and concurrent-mode patterns |
| `react-dom` | `^19.2.0` | Must match the React major version |
| `react-router-dom` | `^7.13.1` | The `Routes`/`Route` JSX API changed significantly between v6 and v7 |

Consumer applications are expected to declare these packages as direct dependencies at the same major versions.
