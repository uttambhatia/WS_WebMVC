import type { FrameworkPlugin } from '../../framework/registry'
import { ExamplePage } from './ExamplePage'
import './example.css'

function ExampleSidebarFooter() {
  return (
    <div className="rf-state-panel rf-state-panel--info rf-example-sidebar-footer">
      <p className="rf-state-panel__title">Example Plugin</p>
      <p className="rf-state-panel__text">Injected via the sidebar footer slot.</p>
    </div>
  )
}

export const examplePlugin: FrameworkPlugin = (registry) => {
  registry.registerLayoutSlot({
    layoutId: 'sidebar',
    slotId: 'footerSlot',
    component: ExampleSidebarFooter,
    metadata: { source: 'example-plugin' },
  })

  registry.registerRoute({
    path: '/plugin-example',
    element: <ExamplePage />,
    label: 'Plugin Example',
    icon: 'spark',
    group: 'Examples',
    visibility: 'always',
    breadcrumb: ['Home', 'Plugin Example'],
    permissions: ['examples.read'],
    order: 30,
  })
}
