import { useState } from 'react'
import { Button } from '../../components/core/Button'
import { FormField } from '../../components/core/FormField'
import { Input } from '../../components/core/Input'
import { Select } from '../../components/core/Select'
import { Checkbox } from '../../components/core/Checkbox'
import { Radio } from '../../components/core/Radio'
import { Card } from '../../components/core/Card'
import { Panel } from '../../components/core/Panel'
import { Stack } from '../../components/core/Stack'
import { Grid } from '../../components/core/Grid'
import { Alert } from '../../components/core/Alert'
import { Spinner } from '../../components/core/Spinner'
import { EmptyState } from '../../components/core/EmptyState'
import { ErrorState } from '../../components/core/ErrorState'
import { Badge } from '../../components/core/Badge'

interface FormState {
  name: string
  email: string
  topic: string
  newsletter: boolean
  contactPref: 'email' | 'phone'
}

interface FormErrors {
  name?: string
  email?: string
  topic?: string
}

function validate(state: FormState): FormErrors {
  const errors: FormErrors = {}
  if (!state.name.trim()) errors.name = 'Name is required.'
  if (!state.email.trim()) errors.email = 'Email is required.'
  else if (!/^[^@]+@[^@]+\.[^@]+$/.test(state.email)) errors.email = 'Enter a valid email address.'
  if (!state.topic) errors.topic = 'Please select a topic.'
  return errors
}

export function ExamplePage() {
  const [form, setForm] = useState<FormState>({
    name: '',
    email: '',
    topic: '',
    newsletter: false,
    contactPref: 'email',
  })
  const [errors, setErrors] = useState<FormErrors>({})
  const [loading, setLoading] = useState(false)
  const [submitted, setSubmitted] = useState(false)
  const [showNotice, setShowNotice] = useState(true)
  const [simulateError, setSimulateError] = useState(false)
  const [recovering, setRecovering] = useState(false)

  function handleChange<K extends keyof FormState>(field: K, value: FormState[K]) {
    setForm((prev) => ({ ...prev, [field]: value }))
    if (errors[field as keyof FormErrors]) {
      setErrors((prev) => ({ ...prev, [field]: undefined }))
    }
  }

  async function handleSubmit(event: React.FormEvent) {
    event.preventDefault()
    const newErrors = validate(form)
    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors)
      return
    }
    setLoading(true)
    await new Promise((resolve) => setTimeout(resolve, 1000))
    setLoading(false)
    setSubmitted(true)
  }

  function handleReset() {
    setForm({ name: '', email: '', topic: '', newsletter: false, contactPref: 'email' })
    setErrors({})
    setSubmitted(false)
  }

  async function handleRetry() {
    setRecovering(true)
    await new Promise((resolve) => setTimeout(resolve, 900))
    setRecovering(false)
    setSimulateError(false)
  }

  if (submitted) {
    return (
      <Stack gap="xl" style={{ maxWidth: '40rem' }}>
        <h2>Plugin Example Page</h2>
        <Panel variant="success" title="Submission received">
          Your form has been submitted successfully.
        </Panel>
        <Button variant="outline" onClick={handleReset}>
          Submit another response
        </Button>
      </Stack>
    )
  }

  return (
    <Stack gap="xl">
      <Stack gap="sm">
        <h2>Plugin Example Page</h2>
        <p style={{ color: 'var(--muted)', margin: 0 }}>
          A demo page showcasing core form, surface, and layout components built with design tokens.
        </p>
      </Stack>

      {/* Dismissible Alert */}
      {showNotice && (
        <Alert
          variant="info"
          title="About this demo"
          dismissible
          onDismiss={() => setShowNotice(false)}
        >
          Interact with form, surface, layout, and feedback components in one place.
        </Alert>
      )}

      {!showNotice && (
        <Button variant="text" size="sm" onClick={() => setShowNotice(true)}>
          Show notice again
        </Button>
      )}

      {/* Form wrapped in a Card */}
      <Card padding="lg">
        <form
          onSubmit={handleSubmit}
          noValidate
          style={{ display: 'flex', flexDirection: 'column', gap: 'var(--spacing-lg)' }}
        >
          {/* Name */}
          <FormField id="name" label="Full name" required error={errors.name}>
            <Input
              id="name"
              type="text"
              value={form.name}
              onChange={(e) => handleChange('name', e.target.value)}
              placeholder="Jane Smith"
              error={!!errors.name}
              aria-describedby={errors.name ? 'name-error' : undefined}
            />
          </FormField>

          {/* Email */}
          <FormField
            id="email"
            label="Email address"
            required
            error={errors.email}
            helpText="We'll never share your email."
          >
            <Input
              id="email"
              type="email"
              value={form.email}
              onChange={(e) => handleChange('email', e.target.value)}
              placeholder="jane@example.com"
              error={!!errors.email}
              aria-describedby={errors.email ? 'email-error' : 'email-help'}
            />
          </FormField>

          {/* Topic */}
          <FormField id="topic" label="Topic" required error={errors.topic}>
            <Select
              id="topic"
              value={form.topic}
              onChange={(e) => handleChange('topic', e.target.value)}
              error={!!errors.topic}
              aria-describedby={errors.topic ? 'topic-error' : undefined}
            >
              <option value="">Select a topic…</option>
              <option value="general">General enquiry</option>
              <option value="billing">Billing</option>
              <option value="technical">Technical support</option>
              <option value="feedback">Feedback</option>
            </Select>
          </FormField>

          {/* Contact preference */}
          <fieldset
            style={{
              border: '1px solid var(--border)',
              borderRadius: 'var(--radius-md)',
              padding: 'var(--spacing-md) var(--spacing-lg)',
            }}
          >
            <legend
              style={{
                fontSize: 'var(--font-size-sm)',
                fontWeight: 'var(--font-weight-medium)',
                padding: '0 var(--spacing-xs)',
              }}
            >
              Preferred contact method
            </legend>
            <div style={{ display: 'flex', gap: 'var(--spacing-lg)', marginTop: 'var(--spacing-sm)' }}>
              <Radio
                id="pref-email"
                name="contactPref"
                value="email"
                label="Email"
                checked={form.contactPref === 'email'}
                onChange={(e) => handleChange('contactPref', e.target.value as 'email' | 'phone')}
              />
              <Radio
                id="pref-phone"
                name="contactPref"
                value="phone"
                label="Phone"
                checked={form.contactPref === 'phone'}
                onChange={(e) => handleChange('contactPref', e.target.value as 'email' | 'phone')}
              />
            </div>
          </fieldset>

          {/* Newsletter */}
          <Checkbox
            id="newsletter"
            label="Subscribe to the newsletter"
            checked={form.newsletter}
            onChange={(e) => handleChange('newsletter', e.target.checked)}
          />

          {/* Actions */}
          <Stack direction="row" gap="md">
            <Button type="submit" variant="primary" loading={loading}>
              {loading ? 'Submitting…' : 'Submit'}
            </Button>
            <Button type="reset" variant="secondary" onClick={handleReset} disabled={loading}>
              Reset
            </Button>
          </Stack>
        </form>
      </Card>

      {/* Surface & Layout demo */}
      <Stack gap="md">
        <h3 style={{ margin: 0 }}>Surface &amp; Layout Components</h3>
        <p style={{ color: 'var(--muted)', margin: 0 }}>
          Card, Panel, Stack and Grid composing a responsive three-column layout.
        </p>

        <Grid columns="auto-fit" minColWidth="14rem" gap="md">
          <Card padding="md" shadow="sm">
            <Stack gap="xs">
              <strong>Card — default</strong>
              <span style={{ color: 'var(--muted)', fontSize: '0.875rem' }}>
                padding=md · shadow=sm · radius=md
              </span>
            </Stack>
          </Card>

          <Card padding="lg" shadow="md" radius="lg">
            <Stack gap="xs">
              <strong>Card — elevated</strong>
              <span style={{ color: 'var(--muted)', fontSize: '0.875rem' }}>
                padding=lg · shadow=md · radius=lg
              </span>
            </Stack>
          </Card>

          <Card padding="sm" shadow="none" radius="sm">
            <Stack gap="xs">
              <strong>Card — flat</strong>
              <span style={{ color: 'var(--muted)', fontSize: '0.875rem' }}>
                padding=sm · shadow=none · radius=sm
              </span>
            </Stack>
          </Card>
        </Grid>

        <Stack gap="sm">
          <Panel variant="info" title="Info panel">
            Use info panels to surface neutral guidance or contextual help.
          </Panel>
          <Panel variant="success" title="Success panel">
            Operations completed without errors will surface a success panel.
          </Panel>
          <Panel variant="warning" title="Warning panel">
            Degraded or partial states can be communicated via a warning panel.
          </Panel>
          <Panel variant="error" title="Error panel">
            Critical failures that require immediate user action warrant an error panel.
          </Panel>
        </Stack>
      </Stack>

      {/* Feedback & Status demo */}
      <Stack gap="md">
        <h3 style={{ margin: 0 }}>Feedback &amp; Status Components</h3>
        <p style={{ color: 'var(--muted)', margin: 0 }}>
          Dismissible alerts, loading indicators, no-data placeholders, retry states, and semantic badges.
        </p>

        <Card>
          <Stack gap="sm">
            <strong>Status badges</strong>
            <Stack direction="row" gap="sm" wrap>
              <Badge variant="primary">New</Badge>
              <Badge variant="success">Completed</Badge>
              <Badge variant="warning">Needs review</Badge>
              <Badge variant="error">Failed</Badge>
              <Badge variant="primary" size="sm">Small</Badge>
            </Stack>
          </Stack>
        </Card>

        <Grid columns="auto-fit" minColWidth="18rem" gap="md">
          <Card>
            <Stack gap="sm">
              <strong>Spinner</strong>
              <Stack direction="row" gap="md" align="center">
                <Spinner size="sm" />
                <Spinner size="md" />
                <Spinner size="lg" />
              </Stack>
              {loading && (
                <Stack direction="row" gap="sm" align="center">
                  <Spinner inline label="Submitting form" />
                  <span style={{ color: 'var(--muted)' }}>Submitting in progress...</span>
                </Stack>
              )}
            </Stack>
          </Card>

          <EmptyState
            title="No reports yet"
            description="When users have no data, show a clear next step instead of a blank screen."
            action={<Button size="sm">Create first report</Button>}
          />
        </Grid>

        <Card>
          <Stack gap="sm">
            <strong>Error recovery</strong>
            {!simulateError && (
              <Stack direction="row" gap="sm" align="center">
                <Panel variant="success" title="API Health">
                  Service is operating normally.
                </Panel>
                <Button size="sm" variant="outline" onClick={() => setSimulateError(true)}>
                  Simulate failure
                </Button>
              </Stack>
            )}

            {simulateError && (
              <ErrorState
                message="The reports service is temporarily unavailable. Please retry."
                onRetry={handleRetry}
                retryLabel={recovering ? 'Retrying...' : 'Retry request'}
              />
            )}
          </Stack>
        </Card>
      </Stack>
    </Stack>
  )
}
