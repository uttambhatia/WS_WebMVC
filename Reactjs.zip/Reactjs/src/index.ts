// =============================================================================
// PUBLIC STABLE — safe to depend on; changes require a semver major bump
// =============================================================================

// Framework singleton
export { framework } from './framework/framework'

// Registry types & interfaces
export {
	isValidRoute,
	isValidRouteMetadata,
	REQUIRED_THEME_TOKENS,
	validateTheme,
} from './framework/registry'
export type {
	FrameworkRegistry,
	FrameworkPlugin,
	LayoutDefinition,
	LayoutSlotDefinition,
	LayoutSlotInjection,
	RouteDefinition,
	RoutePolicyContext,
	RouteVisibility,
	RouteVisibilityMode,
	RouteVisibilityPredicate,
	RequiredThemeToken,
	ThemeValidationResult,
	ThemeDefinition,
} from './framework/registry'

// Bootstrap
export { initializeFramework } from './framework/bootstrap'
export type { FrameworkConfig, InitializationResult } from './framework/bootstrap'

// Provider & renderer
export { LayoutProvider, LayoutRenderer } from './framework/provider'
export type { LayoutProviderProps } from './framework/provider'

// Hooks
export { useLayout, useLayoutSlot, useSetLayoutSlot, useTheme } from './framework/hooks'
export {
	applyChartDrilldown,
	nextChartDrilldownSelection,
	useChartDrilldown,
} from './framework/chartDrilldown'
export type { ChartDrilldownSelection, ChartDrilldownResolver } from './framework/chartDrilldown'

// Core plugin
export { corePlugin } from './framework/core'
export { enterpriseThemePresets, enterpriseThemeCatalog } from './framework/enterpriseThemes'
export type { EnterpriseThemeCatalogItem } from './framework/enterpriseThemes'
export { bankingThemePresets, bankingThemeCatalog } from './framework/bankingThemes'
export type { BankingThemeCatalogItem } from './framework/bankingThemes'

// UI components
export { ThemeSwitcher } from './components/ThemeSwitcher'

// =============================================================================
// PUBLIC ALPHA — exported but may change without a major bump
// =============================================================================

export type { LayoutContextValue } from './framework/provider'

// Generic schema-driven form engine
export { initializeFormEngine } from './forms/bootstrap'
export type {
	FormEngine,
	FormEngineConfig,
	FormEngineInitializationResult,
} from './forms/bootstrap'
export { FormEngineRegistry, registerDefaultValidators } from './forms/registry'
export type {
	FormWidget,
	FormWidgetProps,
	LookupProvider,
	LookupContext,
	ValidatorContext,
	ValidatorFn,
} from './forms/registry'
export { registerDefaultWidgets } from './forms/defaults'
export { SchemaFormProvider, useSchemaForm } from './forms/context'
export type {
	AsyncFieldStatus,
	SchemaFormContextValue,
	SchemaFormProviderProps,
} from './forms/context'
export { SchemaForm } from './forms/renderer'
export type { SchemaFormProps } from './forms/renderer'
export {
	evaluateCondition,
	isValueEmpty,
} from './forms/schema'
export type {
	ComputeRule,
	Condition,
	FieldRule,
	AsyncPolicy,
	FormFieldSchema,
	FormFieldType,
	FormOption,
	FormSchema,
	FormValues,
	HideRule,
	LookupSpec,
	RequireRule,
	RetryPolicy,
	RuleEvaluationPolicy,
	ShowRule,
	ValidatorSpec,
} from './forms/schema'

// Form components
export { Button } from './components/core/Button'
export type { ButtonProps } from './components/core/Button'
export { FormField } from './components/core/FormField'
export type { FormFieldProps } from './components/core/FormField'
export { Input } from './components/core/Input'
export type { InputProps } from './components/core/Input'
export { Select } from './components/core/Select'
export type { SelectProps } from './components/core/Select'
export { Checkbox } from './components/core/Checkbox'
export type { CheckboxProps } from './components/core/Checkbox'
export { Radio } from './components/core/Radio'
export type { RadioProps } from './components/core/Radio'
export { Textarea } from './components/core/Textarea'
export type { TextareaProps } from './components/core/Textarea'
export { Toggle } from './components/core/Toggle'
export type { ToggleProps } from './components/core/Toggle'
export { MultiSelect } from './components/core/MultiSelect'
export type { MultiSelectProps, MultiSelectOption } from './components/core/MultiSelect'
export { FileUpload } from './components/core/FileUpload'
export type { FileUploadProps } from './components/core/FileUpload'
export { DatePicker } from './components/core/DatePicker'
export type { DatePickerProps } from './components/core/DatePicker'
export { DateTimePicker } from './components/core/DateTimePicker'
export type { DateTimePickerProps } from './components/core/DateTimePicker'
export { DateRangePicker } from './components/core/DateRangePicker'
export type { DateRangePickerProps, DateRangeValue } from './components/core/DateRangePicker'
export { Combobox } from './components/core/Combobox'
export type { ComboboxOption, ComboboxProps } from './components/core/Combobox'
export { AsyncAutocomplete } from './components/core/AsyncAutocomplete'
export type { AsyncAutocompleteLoadContext, AsyncAutocompleteProps } from './components/core/AsyncAutocomplete'

// Surface & layout components
export { Card } from './components/core/Card'
export type { CardProps } from './components/core/Card'
export { Panel } from './components/core/Panel'
export type { PanelProps } from './components/core/Panel'
export { Stack } from './components/core/Stack'
export type { StackProps } from './components/core/Stack'
export { Grid } from './components/core/Grid'
export type { GridProps } from './components/core/Grid'
export { Breadcrumb } from './components/core/Breadcrumb'
export type { BreadcrumbItem, BreadcrumbProps } from './components/core/Breadcrumb'
export { Accordion } from './components/core/Accordion'
export type { AccordionItem, AccordionProps } from './components/core/Accordion'
export { Tabs } from './components/core/Tabs'
export type { TabDefinition, TabsProps } from './components/core/Tabs'
export { Stepper } from './components/core/Stepper'
export type { StepperProps, StepperStep } from './components/core/Stepper'
export { TreeView } from './components/core/TreeView'
export type { TreeNode, TreeViewProps } from './components/core/TreeView'
export { Drawer } from './components/core/Drawer'
export { DrawerHeader, DrawerBody, DrawerFooter } from './components/core/Drawer'
export type { DrawerProps, DrawerHeaderProps, DrawerBodyProps, DrawerFooterProps } from './components/core/Drawer'
export { ContextMenu } from './components/core/ContextMenu'
export type { ContextMenuItem, ContextMenuProps } from './components/core/ContextMenu'
export { FilterBuilder } from './components/core/FilterBuilder'
export type { FilterField, FilterOperator, FilterCondition, FilterBuilderProps } from './components/core/FilterBuilder'
export { FormWizard } from './components/core/FormWizard'
export type { FormWizardProps, FormWizardStep } from './components/core/FormWizard'
export { InlineEditable } from './components/core/InlineEditable'
export type { InlineEditableOption, InlineEditableProps } from './components/core/InlineEditable'
export { SplitLayout } from './components/core/SplitLayout'
export type { SplitPane, SplitLayoutProps } from './components/core/SplitLayout'
export { CalendarScheduler } from './components/core/CalendarScheduler'
export type {
	CalendarSchedulerEvent,
	CalendarSchedulerProps,
	CalendarSchedulerRange,
	CalendarSchedulerView,
} from './components/core/CalendarScheduler'
export { Table } from './components/core/Table'
export type { TableColumn, TableProps } from './components/core/Table'
export { DataGrid } from './components/core/DataGrid'
export type { DataGridProps, DataGridColumnVisibility, DataGridColumnWidths } from './components/core/DataGrid'
export { Pagination } from './components/core/Pagination'
export type { PaginationProps } from './components/core/Pagination'

// Feedback & status components
export { Alert } from './components/core/Alert'
export type { AlertProps } from './components/core/Alert'
export { Spinner } from './components/core/Spinner'
export type { SpinnerProps } from './components/core/Spinner'
export { EmptyState } from './components/core/EmptyState'
export type { EmptyStateProps } from './components/core/EmptyState'
export { ErrorState } from './components/core/ErrorState'
export type { ErrorStateProps } from './components/core/ErrorState'
export { Badge } from './components/core/Badge'
export type { BadgeProps } from './components/core/Badge'
export { ProgressBar } from './components/core/ProgressBar'
export type { ProgressBarProps } from './components/core/ProgressBar'
export { SkeletonLoader } from './components/core/SkeletonLoader'
export type { SkeletonLoaderProps } from './components/core/SkeletonLoader'
export { Tooltip } from './components/core/Tooltip'
export type { TooltipProps } from './components/core/Tooltip'
export { Modal } from './components/core/Modal'
export type { ModalProps } from './components/core/Modal'
export { Popover } from './components/core/Popover'
export type { PopoverProps } from './components/core/Popover'
export { DropdownMenu } from './components/core/DropdownMenu'
export type { DropdownMenuItem, DropdownMenuProps } from './components/core/DropdownMenu'
export { Toast } from './components/core/Toast'
export type { ToastMessage, ToastProps } from './components/core/Toast'
export { NotificationCenter } from './components/core/NotificationCenter'
export type { NotificationCenterProps } from './components/core/NotificationCenter'
export { CommandPalette } from './components/core/CommandPalette'
export type { CommandItem, CommandPaletteProps } from './components/core/CommandPalette'
export { CommandBar } from './components/core/CommandBar'
export type { CommandBarAction, CommandBarProps } from './components/core/CommandBar'
export { RichTextEditorField, defaultSanitizeRichText } from './components/core/RichTextEditorField'
export type {
	RichTextEditorChangeMeta,
	RichTextEditorFieldProps,
	RichTextEditorOutput,
} from './components/core/RichTextEditorField'
export { FileManager } from './components/core/FileManager'
export type { FileManagerItem, FileManagerProps } from './components/core/FileManager'
export { AuditTimeline } from './components/core/AuditTimeline'
export type { AuditTimelineEvent, AuditTimelineFilters, AuditTimelineProps } from './components/core/AuditTimeline'

// Sprint C7 — Advanced Data & Interaction Components
export { SliderInput } from './components/core/SliderInput'
export type { SliderInputProps } from './components/core/SliderInput'
export { TagsInput } from './components/core/TagsInput'
export type { TagsInputProps } from './components/core/TagsInput'
export { Sparkline } from './components/core/Sparkline'
export type { SparklineProps } from './components/core/Sparkline'
export { KPICard } from './components/core/KPICard'
export type { KPICardProps } from './components/core/KPICard'
export { VirtualList } from './components/core/VirtualList'
export type { VirtualListProps } from './components/core/VirtualList'
export { ConfirmationDialog } from './components/core/ConfirmationDialog'
export type { ConfirmationDialogProps } from './components/core/ConfirmationDialog'
export { KanbanBoard } from './components/core/KanbanBoard'
export type { KanbanBoardProps, KanbanCard, KanbanColumn } from './components/core/KanbanBoard'

// Sprint C8 Batch 1 — Enterprise Expansion Components
export { BarChart } from './components/core/BarChart'
export type { BarChartDatum, BarChartProps } from './components/core/BarChart'
export { LineChart } from './components/core/LineChart'
export type { LineChartDatum, LineChartProps } from './components/core/LineChart'
export { RatingInput } from './components/core/RatingInput'
export type { RatingInputProps } from './components/core/RatingInput'
export { PinInput } from './components/core/PinInput'
export type { PinInputProps } from './components/core/PinInput'
export { MaskedInput } from './components/core/MaskedInput'
export type { MaskedInputProps } from './components/core/MaskedInput'
export { Sticky } from './components/core/Sticky'
export type { StickyProps } from './components/core/Sticky'
export { DataExporter } from './components/core/DataExporter'
export type { DataExporterColumn, DataExporterFormat, DataExporterProps } from './components/core/DataExporter'
export { CodeBlock } from './components/core/CodeBlock'
export type { CodeBlockProps } from './components/core/CodeBlock'
export { JsonViewer } from './components/core/JsonViewer'
export type { JsonViewerProps } from './components/core/JsonViewer'
export { PermissionGate } from './components/core/PermissionGate'
export type { PermissionGateProps } from './components/core/PermissionGate'

// Sprint C8 Batch 2 — Enterprise Expansion Components
export { HeatMap } from './components/core/HeatMap'
export type { HeatMapProps } from './components/core/HeatMap'
export { ColorPicker } from './components/core/ColorPicker'
export type { ColorPickerProps } from './components/core/ColorPicker'
export { SignaturePad } from './components/core/SignaturePad'
export type { SignaturePadProps } from './components/core/SignaturePad'
export { AppShell } from './components/core/AppShell'
export type { AppShellProps, AppShellSectionProps } from './components/core/AppShell'
export { DragAndDropList } from './components/core/DragAndDropList'
export type { DragAndDropListProps } from './components/core/DragAndDropList'
export { MfaChallenge } from './components/core/MfaChallenge'
export type { MfaChallengeProps } from './components/core/MfaChallenge'

// Sprint C8 Batch 3 — Enterprise Expansion Components
export { TourSpotlight } from './components/core/TourSpotlight'
export type { TourSpotlightProps, TourStep } from './components/core/TourSpotlight'
export { LightBox } from './components/core/LightBox'
export type { LightBoxItem, LightBoxProps } from './components/core/LightBox'
export { BottomSheet } from './components/core/BottomSheet'
export type { BottomSheetProps } from './components/core/BottomSheet'
export { Carousel } from './components/core/Carousel'
export type { CarouselProps } from './components/core/Carousel'
export { ChatThread } from './components/core/ChatThread'
export type { ChatMessage, ChatThreadProps } from './components/core/ChatThread'
export { CommentBox } from './components/core/CommentBox'
export type { CommentBoxProps } from './components/core/CommentBox'
export { LogViewer } from './components/core/LogViewer'
export type { LogEntry, LogLevel, LogViewerProps } from './components/core/LogViewer'

// Sprint C8 Batch 4 — Enterprise Expansion Components
export { DockLayout } from './components/core/DockLayout'
export type { DockLayoutProps, DockPanel } from './components/core/DockLayout'
export { GanttChart } from './components/core/GanttChart'
export type { GanttChartProps, GanttTask } from './components/core/GanttChart'
export { PivotTable } from './components/core/PivotTable'
export type { PivotTableProps, PivotRow } from './components/core/PivotTable'

// Sprint C9 — Enterprise Workflow and Data Authoring Components
export { DataGridPro } from './components/core/DataGridPro'
export type { DataGridProColumn, DataGridProProps } from './components/core/DataGridPro'
export { QueryBuilder } from './components/core/QueryBuilder'
export type {
	QueryBuilderProps,
	QueryCondition,
	QueryField,
	QueryGroup,
	QueryOperator,
} from './components/core/QueryBuilder'
export { RuleBuilder } from './components/core/RuleBuilder'
export type { RuleAction, RuleBuilderProps, RuleDefinition } from './components/core/RuleBuilder'
export { WorkflowStepper } from './components/core/WorkflowStepper'
export type { WorkflowStep, WorkflowStepperProps } from './components/core/WorkflowStepper'
export { SchedulerTimeline } from './components/core/SchedulerTimeline'
export type {
	SchedulerTimelineItem,
	SchedulerTimelineProps,
	SchedulerTimelineResource,
} from './components/core/SchedulerTimeline'
export { RichTextEditor } from './components/core/RichTextEditor'
export type { RichTextEditorProps } from './components/core/RichTextEditor'
export { InlineCommentThreads } from './components/core/InlineCommentThreads'
export type { InlineComment, InlineCommentThreadsProps } from './components/core/InlineCommentThreads'
export { PresenceAvatars } from './components/core/PresenceAvatars'
export type { PresenceAvatarsProps, PresenceUser } from './components/core/PresenceAvatars'
export { ActivityFeed } from './components/core/ActivityFeed'
export type { ActivityFeedProps, ActivityItem } from './components/core/ActivityFeed'
export { DiffViewer } from './components/core/DiffViewer'
export type { DiffViewerProps } from './components/core/DiffViewer'
export { GlobalSearchPanel } from './components/core/GlobalSearchPanel'
export type { GlobalSearchPanelProps, GlobalSearchResult } from './components/core/GlobalSearchPanel'
export { SplitViewWorkbench } from './components/core/SplitViewWorkbench'
export type { SplitViewWorkbenchProps } from './components/core/SplitViewWorkbench'
export { InspectorPanel } from './components/core/InspectorPanel'
export type { InspectorPanelProps, InspectorPanelSection } from './components/core/InspectorPanel'
export { KeyboardShortcutManager } from './components/core/KeyboardShortcutManager'
export type {
	KeyboardShortcut,
	KeyboardShortcutManagerProps,
} from './components/core/KeyboardShortcutManager'
export { AuditTrailViewer } from './components/core/AuditTrailViewer'
export type { AuditTrailEvent, AuditTrailViewerProps } from './components/core/AuditTrailViewer'
export { PolicyEditor } from './components/core/PolicyEditor'
export type { PolicyEditorProps, PolicyRule } from './components/core/PolicyEditor'
export { FieldLevelPermissionMatrix } from './components/core/FieldLevelPermissionMatrix'
export type { FieldLevelPermissionMatrixProps } from './components/core/FieldLevelPermissionMatrix'
export { DataClassificationBadgeSet } from './components/core/DataClassificationBadgeSet'
export type {
	DataClassification,
	DataClassificationBadgeSetProps,
} from './components/core/DataClassificationBadgeSet'
export { ApprovalGate } from './components/core/ApprovalGate'
export type { ApprovalGateProps, ApprovalStep } from './components/core/ApprovalGate'

// Sprint C10 — Advanced Data Visualization Charts (PUBLIC ALPHA)
// These charts provide deterministic SVG rendering with token-first styling
// and comprehensive accessibility support. Subject to API changes in future releases.
export { PieChart } from './components/core/PieChart'
export type { PieChartDatum, PieChartProps, PieChartVariant } from './components/core/PieChart'
export { DonutChart } from './components/core/DonutChart'
export type { DonutChartDatum, DonutChartProps, RingConfig, Threshold } from './components/core/DonutChart'
export { AreaChart } from './components/core/AreaChart'
export type { AreaChartDatum, AreaChartProps, AreaChartVariant, AreaStackMode, AreaRangeDatum } from './components/core/AreaChart'
export { ScatterChart } from './components/core/ScatterChart'
export type { ScatterChartDatum, ScatterChartProps } from './components/core/ScatterChart'
export { StackedBarChart } from './components/core/StackedBarChart'
export type { StackedBarChartDatum, StackedBarChartProps, StackedBarVariant } from './components/core/StackedBarChart'
export { RadarChart } from './components/core/RadarChart'
export type { RadarChartDatum, RadarChartProps, RadarSeriesData } from './components/core/RadarChart'
export { BubbleChart } from './components/core/BubbleChart'
export type { BubbleChartDatum, BubbleChartProps, BubbleChartVariant, BubbleAnnotation } from './components/core/BubbleChart'

