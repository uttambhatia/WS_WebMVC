import { LayoutProvider, LayoutRenderer } from './framework/provider'
import { framework } from './framework/framework'

export default function App() {
  return (
    <LayoutProvider framework={framework}>
      <LayoutRenderer />
    </LayoutProvider>
  )
}
