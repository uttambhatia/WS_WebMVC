import { describe, it, expect, vi } from 'vitest'
import React from 'react'
import { createRoot } from 'react-dom/client'
import { act } from 'react'

import { BarChart } from '../components/core/BarChart'
import { LineChart } from '../components/core/LineChart'
import { RatingInput } from '../components/core/RatingInput'
import { PinInput } from '../components/core/PinInput'
import { MaskedInput } from '../components/core/MaskedInput'
import { Sticky } from '../components/core/Sticky'
import { DataExporter } from '../components/core/DataExporter'
import { CodeBlock } from '../components/core/CodeBlock'
import { JsonViewer } from '../components/core/JsonViewer'
import { PermissionGate } from '../components/core/PermissionGate'
import { HeatMap } from '../components/core/HeatMap'
import { ColorPicker } from '../components/core/ColorPicker'
import { SignaturePad } from '../components/core/SignaturePad'
import { AppShell } from '../components/core/AppShell'
import { DragAndDropList } from '../components/core/DragAndDropList'
import { MfaChallenge } from '../components/core/MfaChallenge'
import { TourSpotlight } from '../components/core/TourSpotlight'
import { LightBox } from '../components/core/LightBox'
import { BottomSheet } from '../components/core/BottomSheet'
import { Carousel } from '../components/core/Carousel'
import { ChatThread } from '../components/core/ChatThread'
import { CommentBox } from '../components/core/CommentBox'
import { LogViewer } from '../components/core/LogViewer'
import { DockLayout } from '../components/core/DockLayout'
import { GanttChart } from '../components/core/GanttChart'
import { PivotTable } from '../components/core/PivotTable'

const rootByContainer = new WeakMap<HTMLElement, ReturnType<typeof createRoot>>()

function render(element: React.ReactElement): HTMLElement {
  const container = document.createElement('div')
  document.body.appendChild(container)
  const root = createRoot(container)
  rootByContainer.set(container, root)
  act(() => {
    root.render(element)
  })
  return container
}

function cleanup(container: HTMLElement) {
  const root = rootByContainer.get(container)
  if (root) {
    act(() => {
      root.unmount()
    })
    rootByContainer.delete(container)
  }
  document.body.removeChild(container)
}

function setInputValue(input: HTMLInputElement, value: string) {
  const descriptor = Object.getOwnPropertyDescriptor(
    window.HTMLInputElement.prototype,
    'value',
  )
  descriptor?.set?.call(input, value)
}

function setTextareaValue(input: HTMLTextAreaElement, value: string) {
  const descriptor = Object.getOwnPropertyDescriptor(
    window.HTMLTextAreaElement.prototype,
    'value',
  )
  descriptor?.set?.call(input, value)
}

describe('BarChart', () => {
  it('renders bars for each datum', () => {
    const container = render(
      <BarChart data={[{ label: 'A', value: 10 }, { label: 'B', value: 20 }]} />,
    )
    expect(container.querySelectorAll('.rf-bar-chart__bar').length).toBe(2)
    cleanup(container)
  })
})

describe('LineChart', () => {
  it('renders polyline when at least two points are provided', () => {
    const container = render(
      <LineChart data={[{ label: 'Jan', value: 10 }, { label: 'Feb', value: 30 }]} />,
    )
    expect(container.querySelector('polyline')).toBeTruthy()
    cleanup(container)
  })
})

describe('RatingInput', () => {
  it('calls onChange when a star is clicked', () => {
    const onChange = vi.fn()
    const container = render(<RatingInput value={1} onChange={onChange} />)
    const stars = container.querySelectorAll<HTMLButtonElement>('.rf-rating-input__star')
    act(() => {
      stars[3].click()
    })
    expect(onChange).toHaveBeenCalledWith(4)
    cleanup(container)
  })
})

describe('PinInput', () => {
  it('calls onComplete when all digits are filled', () => {
    const onComplete = vi.fn()
    const container = render(<PinInput length={4} onComplete={onComplete} />)
    const cells = container.querySelectorAll<HTMLInputElement>('.rf-pin-input__cell')

    act(() => {
      setInputValue(cells[0], '1')
      cells[0].dispatchEvent(new Event('input', { bubbles: true }))
      setInputValue(cells[1], '2')
      cells[1].dispatchEvent(new Event('input', { bubbles: true }))
      setInputValue(cells[2], '3')
      cells[2].dispatchEvent(new Event('input', { bubbles: true }))
      setInputValue(cells[3], '4')
      cells[3].dispatchEvent(new Event('input', { bubbles: true }))
    })

    expect(onComplete).toHaveBeenCalledWith('1234')
    cleanup(container)
  })
})

describe('MaskedInput', () => {
  it('emits masked value on input', () => {
    const onChange = vi.fn()
    const container = render(
      <MaskedInput mask="###-##" defaultValue="" onChange={onChange} />,
    )
    const input = container.querySelector<HTMLInputElement>('input')!

    act(() => {
      setInputValue(input, '12345')
      input.dispatchEvent(new Event('input', { bubbles: true }))
    })

    expect(onChange).toHaveBeenCalledWith('123-45')
    cleanup(container)
  })
})

describe('Sticky', () => {
  it('renders children', () => {
    const container = render(<Sticky><span id="s">X</span></Sticky>)
    expect(container.querySelector('#s')).toBeTruthy()
    cleanup(container)
  })
})

describe('DataExporter', () => {
  it('calls onExport with selected format', () => {
    const onExport = vi.fn()
    const createObjectURL = vi.spyOn(URL, 'createObjectURL').mockReturnValue('blob:test')
    const revokeObjectURL = vi.spyOn(URL, 'revokeObjectURL').mockImplementation(() => {})

    const container = render(
      <DataExporter
        rows={[{ id: 1, name: 'A' }]}
        columns={[{ key: 'id', label: 'ID' }, { key: 'name', label: 'Name' }]}
        defaultFormat="json"
        onExport={onExport}
      />,
    )

    const button = container.querySelector<HTMLButtonElement>('.rf-data-exporter__button')!
    act(() => {
      button.click()
    })

    expect(onExport).toHaveBeenCalled()
    expect(onExport.mock.calls[0][0].format).toBe('json')

    createObjectURL.mockRestore()
    revokeObjectURL.mockRestore()
    cleanup(container)
  })
})

describe('CodeBlock', () => {
  it('calls onCopy callback when copy is clicked', () => {
    const onCopy = vi.fn()
    const container = render(
      <CodeBlock code={'const a = 1'} language="ts" onCopy={onCopy} />,
    )
    const button = container.querySelector<HTMLButtonElement>('.rf-code-block__copy')!
    act(() => {
      button.click()
    })
    expect(onCopy).toHaveBeenCalledWith('const a = 1')
    cleanup(container)
  })
})

describe('JsonViewer', () => {
  it('renders object node and can expand', () => {
    const container = render(
      <JsonViewer value={{ name: 'Framework', nested: { ok: true } }} expandedDepth={0} />,
    )
    const toggle = container.querySelector<HTMLButtonElement>('.rf-json-viewer__toggle')
    expect(toggle).toBeTruthy()
    act(() => {
      toggle!.click()
    })
    expect(container.textContent).toContain('nested')
    cleanup(container)
  })
})

describe('PermissionGate', () => {
  it('renders children when required role and permission are present', () => {
    const container = render(
      <PermissionGate
        roles={['admin']}
        permissions={['write']}
        userRoles={['admin']}
        userPermissions={['write', 'read']}
      >
        <span id="allowed">Allowed</span>
      </PermissionGate>,
    )
    expect(container.querySelector('#allowed')).toBeTruthy()
    cleanup(container)
  })

  it('renders fallback when policy check fails', () => {
    const container = render(
      <PermissionGate
        roles={['admin']}
        userRoles={['viewer']}
        fallback={<span id="blocked">Blocked</span>}
      >
        <span id="allowed">Allowed</span>
      </PermissionGate>,
    )
    expect(container.querySelector('#allowed')).toBeNull()
    expect(container.querySelector('#blocked')).toBeTruthy()
    cleanup(container)
  })
})

describe('HeatMap', () => {
  it('renders one cell per value', () => {
    const container = render(
      <HeatMap data={[[1, 2], [3, 4]]} />,
    )
    expect(container.querySelectorAll('.rf-heat-map__cell').length).toBe(4)
    cleanup(container)
  })
})

describe('ColorPicker', () => {
  it('calls onChange when a swatch is selected', () => {
    const onChange = vi.fn()
    const container = render(
      <ColorPicker value="#0b5fff" onChange={onChange} swatches={["#ff0000", "#00ff00"]} />,
    )
    const swatches = container.querySelectorAll<HTMLButtonElement>('.rf-color-picker__swatch')
    act(() => {
      swatches[1].click()
    })
    expect(onChange).toHaveBeenCalledWith('#00ff00')
    cleanup(container)
  })
})

describe('SignaturePad', () => {
  it('renders drawing canvas and clear button', () => {
    const container = render(<SignaturePad />)
    expect(container.querySelector('.rf-signature-pad__canvas')).toBeTruthy()
    expect(container.querySelector('.rf-signature-pad__clear')).toBeTruthy()
    cleanup(container)
  })
})

describe('AppShell', () => {
  it('renders all section slots', () => {
    const container = render(
      <AppShell>
        <AppShell.Header><span id="hdr">Header</span></AppShell.Header>
        <AppShell.Sidebar><span id="sdb">Sidebar</span></AppShell.Sidebar>
        <AppShell.Content><span id="cnt">Content</span></AppShell.Content>
        <AppShell.Footer><span id="ftr">Footer</span></AppShell.Footer>
      </AppShell>,
    )
    expect(container.querySelector('#hdr')).toBeTruthy()
    expect(container.querySelector('#sdb')).toBeTruthy()
    expect(container.querySelector('#cnt')).toBeTruthy()
    expect(container.querySelector('#ftr')).toBeTruthy()
    cleanup(container)
  })
})

describe('DragAndDropList', () => {
  it('calls onReorder when move-down control is clicked', () => {
    const onReorder = vi.fn()
    const items = [{ id: 'a', label: 'A' }, { id: 'b', label: 'B' }]
    const container = render(
      <DragAndDropList
        items={items}
        getItemId={(item) => item.id}
        renderItem={(item) => <span>{item.label}</span>}
        onReorder={onReorder}
      />,
    )

    const buttons = container.querySelectorAll<HTMLButtonElement>('.rf-dnd-list__move')
    act(() => {
      buttons[1].click()
    })

    expect(onReorder).toHaveBeenCalled()
    const reordered = onReorder.mock.calls[0][0] as Array<{ id: string }>
    expect(reordered[0].id).toBe('b')
    cleanup(container)
  })
})

describe('MfaChallenge', () => {
  it('submits code when verify is clicked after completion', () => {
    const onSubmit = vi.fn()
    const container = render(
      <MfaChallenge length={4} onSubmit={onSubmit} expiresInSeconds={0} />,
    )

    const cells = container.querySelectorAll<HTMLInputElement>('.rf-pin-input__cell')
    act(() => {
      setInputValue(cells[0], '1')
      cells[0].dispatchEvent(new Event('input', { bubbles: true }))
      setInputValue(cells[1], '2')
      cells[1].dispatchEvent(new Event('input', { bubbles: true }))
      setInputValue(cells[2], '3')
      cells[2].dispatchEvent(new Event('input', { bubbles: true }))
      setInputValue(cells[3], '4')
      cells[3].dispatchEvent(new Event('input', { bubbles: true }))
    })

    const verify = container.querySelector<HTMLButtonElement>('.rf-mfa-challenge__verify')
    act(() => {
      verify!.click()
    })

    expect(onSubmit).toHaveBeenCalledWith('1234')
    cleanup(container)
  })
})

describe('TourSpotlight', () => {
  it('renders current step when open', () => {
    const container = render(
      <TourSpotlight
        open
        steps={[{ title: 'Welcome', description: 'Intro' }]}
        onClose={vi.fn()}
      />,
    )
    expect(document.body.textContent).toContain('Welcome')
    cleanup(container)
  })
})

describe('LightBox', () => {
  it('renders image when open', () => {
    const container = render(
      <LightBox
        open
        items={[{ src: 'https://example.com/a.png', alt: 'A' }]}
        onClose={vi.fn()}
      />,
    )
    expect(document.body.querySelector('.rf-lightbox__image')).toBeTruthy()
    cleanup(container)
  })
})

describe('BottomSheet', () => {
  it('renders content when open', () => {
    const container = render(
      <BottomSheet open title="Sheet" onClose={vi.fn()}>
        <span id="sheet-content">Body</span>
      </BottomSheet>,
    )
    expect(document.body.querySelector('#sheet-content')).toBeTruthy()
    cleanup(container)
  })
})

describe('Carousel', () => {
  it('navigates to next slide', () => {
    const container = render(
      <Carousel>
        {[<span key="1">One</span>, <span key="2">Two</span>]}
      </Carousel>,
    )
    const next = container.querySelectorAll<HTMLButtonElement>('.rf-carousel__btn')[1]
    act(() => {
      next.click()
    })
    const activeDot = container.querySelector('.rf-carousel__dot--active')
    expect(activeDot).toBeTruthy()
    cleanup(container)
  })
})

describe('ChatThread', () => {
  it('renders messages with author and text', () => {
    const container = render(
      <ChatThread
        currentUser="me"
        messages={[
          { id: '1', author: 'me', text: 'Hello', timestamp: '10:00', read: true },
          { id: '2', author: 'you', text: 'Hi', timestamp: '10:01', read: false },
        ]}
      />,
    )
    expect(container.textContent).toContain('Hello')
    expect(container.textContent).toContain('Hi')
    cleanup(container)
  })
})

describe('CommentBox', () => {
  it('submits comment text', () => {
    const onSubmit = vi.fn()
    const container = render(
      <CommentBox onSubmit={onSubmit} mentionSuggestions={['alice']} />,
    )
    const input = container.querySelector<HTMLTextAreaElement>('.rf-comment-box__input')!
    act(() => {
      setTextareaValue(input, 'Hello team')
      input.dispatchEvent(new Event('input', { bubbles: true }))
    })
    const button = container.querySelector<HTMLButtonElement>('.rf-comment-box__submit')!
    act(() => {
      button.click()
    })
    expect(onSubmit).toHaveBeenCalledWith('Hello team')
    cleanup(container)
  })
})

describe('LogViewer', () => {
  it('renders filtered log entries', () => {
    const container = render(
      <LogViewer
        levelFilter="error"
        entries={[
          { id: '1', level: 'info', message: 'ok' },
          { id: '2', level: 'error', message: 'bad' },
        ]}
      />,
    )
    expect(container.textContent).toContain('bad')
    expect(container.textContent).not.toContain('ok')
    cleanup(container)
  })
})

describe('DockLayout', () => {
  it('renders docked panels', () => {
    const container = render(
      <DockLayout
        panels={[
          { id: 'left', title: 'Left', dock: 'left', content: <span id="left">L</span> },
          { id: 'center', title: 'Center', dock: 'center', content: <span id="center">C</span> },
        ]}
      />,
    )
    expect(container.querySelector('#left')).toBeTruthy()
    expect(container.querySelector('#center')).toBeTruthy()
    cleanup(container)
  })
})

describe('GanttChart', () => {
  it('renders one row per task', () => {
    const container = render(
      <GanttChart
        tasks={[
          { id: 't1', label: 'Task 1', start: 0, end: 3, progress: 50 },
          { id: 't2', label: 'Task 2', start: 2, end: 5, progress: 20 },
        ]}
      />,
    )
    expect(container.querySelectorAll('.rf-gantt__row').length).toBe(2)
    cleanup(container)
  })
})

describe('PivotTable', () => {
  it('aggregates values by row/column fields', () => {
    const container = render(
      <PivotTable
        data={[
          { team: 'A', month: 'Jan', amount: 10 },
          { team: 'A', month: 'Jan', amount: 5 },
          { team: 'B', month: 'Feb', amount: 7 },
        ]}
        rowField="team"
        columnField="month"
        valueField="amount"
        aggregator="sum"
      />,
    )
    expect(container.textContent).toContain('15')
    expect(container.textContent).toContain('7')
    cleanup(container)
  })
})
