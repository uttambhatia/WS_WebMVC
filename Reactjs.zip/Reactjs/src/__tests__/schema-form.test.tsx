import React, { act } from 'react'
import { afterEach, describe, expect, it } from 'vitest'
import { createRoot, type Root } from 'react-dom/client'
import { initializeFormEngine } from '../forms/bootstrap'
import { SchemaForm } from '../forms/renderer'
import type { FormSchema } from '../forms/schema'

;(globalThis as Record<string, unknown>).IS_REACT_ACT_ENVIRONMENT = true

let activeRoot: Root | null = null
let activeContainer: HTMLDivElement | null = null

async function render(ui: React.ReactNode): Promise<HTMLDivElement> {
  const container = document.createElement('div')
  document.body.appendChild(container)
  const root = createRoot(container)
  activeRoot = root
  activeContainer = container

  await act(async () => {
    root.render(ui)
    await Promise.resolve()
  })

  return container
}

afterEach(async () => {
  if (activeRoot && activeContainer) {
    await act(async () => {
      activeRoot?.unmount()
    })
    activeContainer.remove()
  }

  activeRoot = null
  activeContainer = null
  document.body.innerHTML = ''
})

describe('SchemaForm', () => {
  const schema: FormSchema = {
    id: 'sample-form',
    fields: [
      {
        key: 'name',
        label: 'Name',
        type: 'text',
        required: true,
      },
      {
        key: 'reason',
        label: 'Reason',
        type: 'textarea',
        rules: [
          {
            kind: 'show',
            when: { field: 'name', truthy: true },
          },
        ],
      },
    ],
  }

  it('blocks submit when required field is missing', async () => {
    const initialized = initializeFormEngine({ schema })
    expect(initialized.success).toBe(true)
    expect(initialized.engine).toBeDefined()

    let submitted = false

    const container = await render(
      <SchemaForm
        engine={initialized.engine!}
        onSubmit={() => {
          submitted = true
        }}
      />,
    )

    expect(container.querySelector('#sample-form-name')).not.toBeNull()
    expect(container.querySelector('#sample-form-reason')).toBeNull()

    await act(async () => {
      container.querySelector('form')?.dispatchEvent(
        new Event('submit', { bubbles: true, cancelable: true }),
      )
      await Promise.resolve()
    })

    expect(submitted).toBe(false)
    expect(container.querySelector('#sample-form-name-error')?.textContent).toContain('required')
  })

  it('applies show rules from initial values and submits valid data', async () => {
    const initialized = initializeFormEngine({ schema })
    expect(initialized.success).toBe(true)

    let submittedValues: Record<string, unknown> | undefined

    const container = await render(
      <SchemaForm
        engine={initialized.engine!}
        initialValues={{ name: 'Alice', reason: 'Because' }}
        onSubmit={(values) => {
          submittedValues = values
        }}
      />,
    )

    expect(container.querySelector('#sample-form-reason')).not.toBeNull()

    await act(async () => {
      container.querySelector('form')?.dispatchEvent(
        new Event('submit', { bubbles: true, cancelable: true }),
      )
      await Promise.resolve()
    })

    expect(submittedValues?.name).toBe('Alice')
    expect(submittedValues?.reason).toBe('Because')
  })
})
