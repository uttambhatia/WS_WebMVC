/**
 * Sprint C1 Batch 2 — Surface & Layout Component Tests
 * Tests for: Card, Panel, Stack, Grid
 * Pattern: createRoot + act + afterEach DOM cleanup (no @testing-library/react)
 */
 import React, { act } from 'react'
 import { describe, it, expect, afterEach } from 'vitest'
 import { createRoot, type Root } from 'react-dom/client'
 import { Card } from '../components/core/Card'
 import { Panel } from '../components/core/Panel'
 import { Stack } from '../components/core/Stack'
 import { Grid } from '../components/core/Grid'
 
 ;(globalThis as Record<string, unknown>).IS_REACT_ACT_ENVIRONMENT = true
 
 let activeRoot: Root | null = null
 let activeContainer: HTMLDivElement | null = null
 
 async function mount(ui: React.ReactElement): Promise<HTMLDivElement> {
   const container = document.createElement('div')
   document.body.appendChild(container)
   const root = createRoot(container)
   activeRoot = root
   activeContainer = container
   await act(async () => {
     root.render(ui)
     await Promise.resolve()
   })
   return container
 }
 
 afterEach(async () => {
   if (activeRoot && activeContainer) {
     await act(async () => {
       activeRoot?.unmount()
     })
     activeContainer.remove()
   }
   activeRoot = null
   activeContainer = null
 })

// =============================================================================
// Card
// =============================================================================
describe('Card', () => {
  it('renders children', async () => {
    const el = await mount(<Card>Hello Card</Card>)
    expect(el!.textContent).toContain('Hello Card')
  })

  it('applies rf-card base class', async () => {
    const el = await mount(<Card>x</Card>)
    const card = el!.firstElementChild as HTMLElement
    expect(card.classList.contains('rf-card')).toBe(true)
  })

  it('applies default padding md class', async () => {
    const el = await mount(<Card>x</Card>)
    const card = el!.firstElementChild as HTMLElement
    expect(card.classList.contains('rf-card--pad-md')).toBe(true)
  })

  it('applies default shadow sm class', async () => {
    const el = await mount(<Card>x</Card>)
    const card = el!.firstElementChild as HTMLElement
    expect(card.classList.contains('rf-card--shadow-sm')).toBe(true)
  })

  it('applies default radius md class', async () => {
    const el = await mount(<Card>x</Card>)
    const card = el!.firstElementChild as HTMLElement
    expect(card.classList.contains('rf-card--radius-md')).toBe(true)
  })

  it('applies padding none class', async () => {
    const el = await mount(<Card padding="none">x</Card>)
    const card = el!.firstElementChild as HTMLElement
    expect(card.classList.contains('rf-card--pad-none')).toBe(true)
  })

  it('applies padding lg class', async () => {
    const el = await mount(<Card padding="lg">x</Card>)
    const card = el!.firstElementChild as HTMLElement
    expect(card.classList.contains('rf-card--pad-lg')).toBe(true)
  })

  it('applies shadow md class', async () => {
    const el = await mount(<Card shadow="md">x</Card>)
    const card = el!.firstElementChild as HTMLElement
    expect(card.classList.contains('rf-card--shadow-md')).toBe(true)
  })

  it('applies shadow none class', async () => {
    const el = await mount(<Card shadow="none">x</Card>)
    const card = el!.firstElementChild as HTMLElement
    expect(card.classList.contains('rf-card--shadow-none')).toBe(true)
  })

  it('applies radius lg class', async () => {
    const el = await mount(<Card radius="lg">x</Card>)
    const card = el!.firstElementChild as HTMLElement
    expect(card.classList.contains('rf-card--radius-lg')).toBe(true)
  })

  it('applies radius none class', async () => {
    const el = await mount(<Card radius="none">x</Card>)
    const card = el!.firstElementChild as HTMLElement
    expect(card.classList.contains('rf-card--radius-none')).toBe(true)
  })

  it('renders as div by default', async () => {
    const el = await mount(<Card>x</Card>)
    expect(el!.firstElementChild!.tagName).toBe('DIV')
  })

  it('renders as a custom element when as prop is set', async () => {
    const el = await mount(<Card as="article">x</Card>)
    expect(el!.firstElementChild!.tagName).toBe('ARTICLE')
  })

  it('merges additional className', async () => {
    const el = await mount(<Card className="my-extra">x</Card>)
    const card = el!.firstElementChild as HTMLElement
    expect(card.classList.contains('my-extra')).toBe(true)
    expect(card.classList.contains('rf-card')).toBe(true)
  })
})

// =============================================================================
// Panel
// =============================================================================
describe('Panel', () => {
  it('renders children', async () => {
    const el = await mount(<Panel variant="info">Panel text</Panel>)
    expect(el!.textContent).toContain('Panel text')
  })

  it('applies rf-panel base class', async () => {
    const el = await mount(<Panel variant="info">x</Panel>)
    const panel = el!.querySelector('.rf-panel') as HTMLElement
    expect(panel).not.toBeNull()
  })

  it('applies variant class rf-panel--info', async () => {
    const el = await mount(<Panel variant="info">x</Panel>)
    const panel = el!.firstElementChild as HTMLElement
    expect(panel.classList.contains('rf-panel--info')).toBe(true)
  })

  it('applies variant class rf-panel--success', async () => {
    const el = await mount(<Panel variant="success">x</Panel>)
    const panel = el!.firstElementChild as HTMLElement
    expect(panel.classList.contains('rf-panel--success')).toBe(true)
  })

  it('applies variant class rf-panel--warning', async () => {
    const el = await mount(<Panel variant="warning">x</Panel>)
    const panel = el!.firstElementChild as HTMLElement
    expect(panel.classList.contains('rf-panel--warning')).toBe(true)
  })

  it('applies variant class rf-panel--error', async () => {
    const el = await mount(<Panel variant="error">x</Panel>)
    const panel = el!.firstElementChild as HTMLElement
    expect(panel.classList.contains('rf-panel--error')).toBe(true)
  })

  it('has role="status" for info variant', async () => {
    const el = await mount(<Panel variant="info">x</Panel>)
    const panel = el!.firstElementChild as HTMLElement
    expect(panel.getAttribute('role')).toBe('status')
  })

  it('has role="status" for success variant', async () => {
    const el = await mount(<Panel variant="success">x</Panel>)
    const panel = el!.firstElementChild as HTMLElement
    expect(panel.getAttribute('role')).toBe('status')
  })

  it('has role="alert" for warning variant', async () => {
    const el = await mount(<Panel variant="warning">x</Panel>)
    const panel = el!.firstElementChild as HTMLElement
    expect(panel.getAttribute('role')).toBe('alert')
  })

  it('has role="alert" for error variant', async () => {
    const el = await mount(<Panel variant="error">x</Panel>)
    const panel = el!.firstElementChild as HTMLElement
    expect(panel.getAttribute('role')).toBe('alert')
  })

  it('renders default icon for info', async () => {
    const el = await mount(<Panel variant="info">x</Panel>)
    const icon = el!.querySelector('.rf-panel__icon') as HTMLElement
    expect(icon.textContent).toContain('ℹ')
  })

  it('renders default icon for success', async () => {
    const el = await mount(<Panel variant="success">x</Panel>)
    const icon = el!.querySelector('.rf-panel__icon') as HTMLElement
    expect(icon.textContent).toContain('✓')
  })

  it('renders default icon for warning', async () => {
    const el = await mount(<Panel variant="warning">x</Panel>)
    const icon = el!.querySelector('.rf-panel__icon') as HTMLElement
    expect(icon.textContent).toContain('⚠')
  })

  it('renders default icon for error', async () => {
    const el = await mount(<Panel variant="error">x</Panel>)
    const icon = el!.querySelector('.rf-panel__icon') as HTMLElement
    expect(icon.textContent).toContain('✕')
  })

  it('renders custom icon', async () => {
    const el = await mount(<Panel variant="info" icon={<span data-testid="custom-icon">★</span>}>x</Panel>)
    const icon = el!.querySelector('.rf-panel__icon') as HTMLElement
    expect(icon.textContent).toContain('★')
  })

  it('renders title when provided', async () => {
    const el = await mount(<Panel variant="info" title="My Title">x</Panel>)
    const title = el!.querySelector('.rf-panel__title') as HTMLElement
    expect(title.textContent).toBe('My Title')
  })

  it('does not render title element when title is omitted', async () => {
    const el = await mount(<Panel variant="info">x</Panel>)
    expect(el!.querySelector('.rf-panel__title')).toBeNull()
  })

  it('renders content in rf-panel__content', async () => {
    const el = await mount(<Panel variant="success">Content here</Panel>)
    const content = el!.querySelector('.rf-panel__content') as HTMLElement
    expect(content.textContent).toContain('Content here')
  })
})

// =============================================================================
// Stack
// =============================================================================
describe('Stack', () => {
  it('renders children', async () => {
    const el = await mount(<Stack><span>item</span></Stack>)
    expect(el!.textContent).toContain('item')
  })

  it('sets display:flex', async () => {
    const el = await mount(<Stack>x</Stack>)
    const stack = el!.firstElementChild as HTMLElement
    expect(stack.style.display).toBe('flex')
  })

  it('defaults to column direction', async () => {
    const el = await mount(<Stack>x</Stack>)
    const stack = el!.firstElementChild as HTMLElement
    expect(stack.style.flexDirection).toBe('column')
  })

  it('sets row direction when specified', async () => {
    const el = await mount(<Stack direction="row">x</Stack>)
    const stack = el!.firstElementChild as HTMLElement
    expect(stack.style.flexDirection).toBe('row')
  })

  it('defaults to gap md (var(--spacing-md))', async () => {
    const el = await mount(<Stack>x</Stack>)
    const stack = el!.firstElementChild as HTMLElement
    expect(stack.style.gap).toBe('var(--spacing-md)')
  })

  it('applies gap none as 0', async () => {
    const el = await mount(<Stack gap="none">x</Stack>)
    const stack = el!.firstElementChild as HTMLElement
    expect(stack.style.gap).toBe('0px')
  })

  it('applies gap xl token', async () => {
    const el = await mount(<Stack gap="xl">x</Stack>)
    const stack = el!.firstElementChild as HTMLElement
    expect(stack.style.gap).toBe('var(--spacing-xl)')
  })

  it('sets alignItems when align is provided', async () => {
    const el = await mount(<Stack align="center">x</Stack>)
    const stack = el!.firstElementChild as HTMLElement
    expect(stack.style.alignItems).toBe('center')
  })

  it('sets justifyContent when justify is provided', async () => {
    const el = await mount(<Stack justify="space-between">x</Stack>)
    const stack = el!.firstElementChild as HTMLElement
    expect(stack.style.justifyContent).toBe('space-between')
  })

  it('sets flexWrap when wrap is true', async () => {
    const el = await mount(<Stack wrap>x</Stack>)
    const stack = el!.firstElementChild as HTMLElement
    expect(stack.style.flexWrap).toBe('wrap')
  })

  it('does not set flexWrap by default', async () => {
    const el = await mount(<Stack>x</Stack>)
    const stack = el!.firstElementChild as HTMLElement
    expect(stack.style.flexWrap).toBe('')
  })

  it('renders as div by default', async () => {
    const el = await mount(<Stack>x</Stack>)
    expect(el!.firstElementChild!.tagName).toBe('DIV')
  })

  it('supports as prop for custom element', async () => {
    const el = await mount(<Stack as="section">x</Stack>)
    expect(el!.firstElementChild!.tagName).toBe('SECTION')
  })
})

// =============================================================================
// Grid
// =============================================================================
describe('Grid', () => {
  it('renders children', async () => {
    const el = await mount(<Grid><span>cell</span></Grid>)
    expect(el!.textContent).toContain('cell')
  })

  it('sets display:grid', async () => {
    const el = await mount(<Grid>x</Grid>)
    const grid = el!.firstElementChild as HTMLElement
    expect(grid.style.display).toBe('grid')
  })

  it('defaults to auto-fit with minColWidth 16rem', async () => {
    const el = await mount(<Grid>x</Grid>)
    const grid = el!.firstElementChild as HTMLElement
    expect(grid.style.gridTemplateColumns).toBe('repeat(auto-fit, minmax(16rem, 1fr))')
  })

  it('sets numeric columns to repeat(n, 1fr)', async () => {
    const el = await mount(<Grid columns={3}>x</Grid>)
    const grid = el!.firstElementChild as HTMLElement
    expect(grid.style.gridTemplateColumns).toBe('repeat(3, 1fr)')
  })

  it('sets auto-fill with minColWidth', async () => {
    const el = await mount(<Grid columns="auto-fill" minColWidth="12rem">x</Grid>)
    const grid = el!.firstElementChild as HTMLElement
    expect(grid.style.gridTemplateColumns).toBe('repeat(auto-fill, minmax(12rem, 1fr))')
  })

  it('applies default gap md token', async () => {
    const el = await mount(<Grid>x</Grid>)
    const grid = el!.firstElementChild as HTMLElement
    expect(grid.style.gap).toBe('var(--spacing-md)')
  })

  it('applies gap none as 0', async () => {
    const el = await mount(<Grid gap="none">x</Grid>)
    const grid = el!.firstElementChild as HTMLElement
    expect(grid.style.gap).toBe('0px')
  })

  it('applies rowGap token when specified', async () => {
    const el = await mount(<Grid rowGap="lg">x</Grid>)
    const grid = el!.firstElementChild as HTMLElement
    expect(grid.style.rowGap).toBe('var(--spacing-lg)')
  })

  it('renders as div by default', async () => {
    const el = await mount(<Grid>x</Grid>)
    expect(el!.firstElementChild!.tagName).toBe('DIV')
  })

  it('supports as prop for custom element', async () => {
    const el = await mount(<Grid as="ul">x</Grid>)
    expect(el!.firstElementChild!.tagName).toBe('UL')
  })
})
