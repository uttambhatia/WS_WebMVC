import { describe, expect, it } from 'vitest'
import { applyChartDrilldown, nextChartDrilldownSelection } from '../framework/chartDrilldown'

describe('C12 drilldown orchestration', () => {
  it('creates new selection when no current selection exists', () => {
    const next = nextChartDrilldownSelection(null, 'status', 'Completed')
    expect(next).toEqual({ dimension: 'status', value: 'Completed' })
  })

  it('toggles selection off when selecting same value and dimension', () => {
    const next = nextChartDrilldownSelection({ dimension: 'status', value: 'Completed' }, 'status', 'Completed')
    expect(next).toBeNull()
  })

  it('filters items deterministically by selected dimension', () => {
    const rows = [
      { id: '1', status: 'Completed', team: 'A' },
      { id: '2', status: 'Pending', team: 'B' },
      { id: '3', status: 'Completed', team: 'C' },
    ]

    const filtered = applyChartDrilldown(rows, { dimension: 'status', value: 'Completed' }, (item, dimension) => item[dimension as keyof typeof item])

    expect(filtered.map((row) => row.id)).toEqual(['1', '3'])
  })
})
