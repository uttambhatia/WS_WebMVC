import React, { act } from 'react'
import { afterEach, describe, expect, it, vi } from 'vitest'
import { createRoot, type Root } from 'react-dom/client'
import { MemoryRouter } from 'react-router-dom'
import { Textarea } from '../components/core/Textarea'
import { Toggle } from '../components/core/Toggle'
import { Breadcrumb } from '../components/core/Breadcrumb'
import { Tabs } from '../components/core/Tabs'
import { Pagination } from '../components/core/Pagination'
import { Modal } from '../components/core/Modal'
import { Tooltip } from '../components/core/Tooltip'
import { Table } from '../components/core/Table'
import { DatePicker } from '../components/core/DatePicker'
import { DataGrid } from '../components/core/DataGrid'
import { CommandPalette } from '../components/core/CommandPalette'

;(globalThis as Record<string, unknown>).IS_REACT_ACT_ENVIRONMENT = true

let activeRoot: Root | null = null
let activeContainer: HTMLDivElement | null = null

async function render(ui: React.ReactNode): Promise<HTMLDivElement> {
  const container = document.createElement('div')
  document.body.appendChild(container)

  const root = createRoot(container)
  activeRoot = root
  activeContainer = container

  await act(async () => {
    root.render(ui)
    await Promise.resolve()
  })

  return container
}

afterEach(async () => {
  vi.restoreAllMocks()

  if (activeRoot && activeContainer) {
    await act(async () => {
      activeRoot?.unmount()
    })
    activeContainer.remove()
  }

  activeRoot = null
  activeContainer = null
  document.body.innerHTML = ''
})

describe('C4 Textarea and Toggle', () => {
  it('applies error state and aria-invalid on Textarea', async () => {
    const container = await render(<Textarea error rows={4} />)
    const textarea = container.querySelector('textarea')!

    expect(textarea.className).toContain('rf-textarea--error')
    expect(textarea.getAttribute('aria-invalid')).toBe('true')
  })

  it('renders Toggle as role switch and forwards checked state', async () => {
    const handleChange = vi.fn()
    const container = await render(
      <Toggle id="notifications" label="Notifications" checked onChange={handleChange} />,
    )

    const input = container.querySelector('input[type="checkbox"]') as HTMLInputElement
    expect(input.getAttribute('role')).toBe('switch')
    expect(input.checked).toBe(true)

    await act(async () => {
      input.click()
    })

    expect(handleChange).toHaveBeenCalledTimes(1)
  })
})

describe('C4 Breadcrumb and Tabs', () => {
  it('renders breadcrumb current page and links', async () => {
    await render(
      <MemoryRouter>
        <Breadcrumb
          items={[
            { label: 'Home', href: '/' },
            { label: 'Reports', href: '/reports' },
            { label: 'Current' },
          ]}
        />
      </MemoryRouter>,
    )

    const nav = document.querySelector('nav[aria-label="Breadcrumb"]')
    const links = document.querySelectorAll('.rf-breadcrumb__link')
    const current = document.querySelector('.rf-breadcrumb__current')

    expect(nav).not.toBeNull()
    expect(links).toHaveLength(2)
    expect(current?.getAttribute('aria-current')).toBe('page')
  })

  it('changes active tab on ArrowRight keyboard navigation', async () => {
    const handleTabChange = vi.fn()
    const container = await render(
      <Tabs
        tabs={[
          { id: 'a', label: 'Alpha', content: 'Alpha panel' },
          { id: 'b', label: 'Beta', content: 'Beta panel' },
        ]}
        onTabChange={handleTabChange}
      />,
    )

    const tablist = container.querySelector('[role="tablist"]') as HTMLDivElement

    await act(async () => {
      tablist.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowRight', bubbles: true }))
    })

    expect(handleTabChange).toHaveBeenCalledWith('b')
    expect(container.querySelector('#rf-tabpanel-b')).not.toBeNull()
  })
})

describe('C4 Pagination and Modal', () => {
  it('disables previous button on first page and next on last page', async () => {
    const first = await render(
      <Pagination currentPage={1} totalPages={3} onPageChange={() => {}} />,
    )

    const prevFirst = first.querySelectorAll('.rf-pagination__btn')[0] as HTMLButtonElement
    expect(prevFirst.disabled).toBe(true)

    await act(async () => {
      activeRoot?.render(<Pagination currentPage={3} totalPages={3} onPageChange={() => {}} />)
      await Promise.resolve()
    })

    const buttons = document.querySelectorAll('.rf-pagination__btn')
    const nextLast = buttons[buttons.length - 1] as HTMLButtonElement
    expect(nextLast.disabled).toBe(true)
  })

  it('calls onClose when Escape is pressed in Modal', async () => {
    const onClose = vi.fn()
    await render(
      <Modal open title="Test modal" onClose={onClose}>
        <button type="button">Focusable</button>
      </Modal>,
    )

    await act(async () => {
      document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }))
    })

    expect(onClose).toHaveBeenCalledTimes(1)
  })

  it('calls onClose when backdrop receives mouse down', async () => {
    const onClose = vi.fn()
    await render(
      <Modal open title="Backdrop" onClose={onClose}>
        <span>Body</span>
      </Modal>,
    )

    const backdrop = document.querySelector('.rf-modal__backdrop') as HTMLDivElement

    await act(async () => {
      backdrop.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }))
    })

    expect(onClose).toHaveBeenCalledTimes(1)
  })
})

describe('C4 Tooltip and Table', () => {
  it('shows tooltip on focus and hover classes', async () => {
    const container = await render(
      <Tooltip content="Helpful text">
        <button type="button">Target</button>
      </Tooltip>,
    )

    const wrapper = container.querySelector('.rf-tooltip') as HTMLSpanElement

    await act(async () => {
      wrapper.dispatchEvent(new MouseEvent('mouseover', { bubbles: true }))
    })

    const tooltip = container.querySelector('[role="tooltip"]') as HTMLSpanElement
    expect(tooltip.className).toContain('rf-tooltip__content--visible')
  })

  it('calls onSortChange when sortable table header is clicked', async () => {
    const onSortChange = vi.fn()
    const container = await render(
      <Table
        columns={[
          { key: 'name', header: 'Name', sortable: true },
          { key: 'role', header: 'Role' },
        ]}
        data={[
          { name: 'Alice', role: 'Owner' },
          { name: 'Bob', role: 'Editor' },
        ]}
        onSortChange={onSortChange}
      />,
    )

    const sortButton = container.querySelector('.rf-table__sort') as HTMLButtonElement

    await act(async () => {
      sortButton.click()
    })

    expect(onSortChange).toHaveBeenCalledWith('name', 'asc')
  })
})

describe('C4 DatePicker, DataGrid, CommandPalette', () => {
  it('renders date input type and error semantics in DatePicker', async () => {
    const container = await render(<DatePicker value="2026-03-14" error />)

    const input = container.querySelector('input[type="date"]') as HTMLInputElement

    expect(input).not.toBeNull()
    expect(input.value).toBe('2026-03-14')
    expect(input.className).toContain('rf-date-picker--error')
    expect(input.getAttribute('aria-invalid')).toBe('true')
  })

  it('renders paged rows in DataGrid based on page and pageSize', async () => {
    const container = await render(
      <DataGrid
        columns={[{ key: 'name', header: 'Name' }]}
        rows={[
          { id: '1', name: 'One' },
          { id: '2', name: 'Two' },
          { id: '3', name: 'Three' },
          { id: '4', name: 'Four' },
        ]}
        page={2}
        pageSize={2}
      />,
    )

    const text = container.textContent ?? ''
    expect(text).toContain('Three')
    expect(text).toContain('Four')
    expect(text).not.toContain('One')
  })

  it('renders commands and runs selected command callback in CommandPalette', async () => {
    const onClose = vi.fn()
    const runOpen = vi.fn()
    const runSave = vi.fn()

    await render(
      <CommandPalette
        open
        onClose={onClose}
        commands={[
          { id: 'open', label: 'Open file', keywords: ['file'], onSelect: runOpen },
          { id: 'save', label: 'Save all', keywords: ['write'], onSelect: runSave },
        ]}
      />,
    )

    const items = document.querySelectorAll('.rf-command__item')
    expect(items).toHaveLength(2)

    await act(async () => {
      (items[1] as HTMLButtonElement).click()
    })

    expect(runSave).toHaveBeenCalledTimes(1)
    expect(onClose).toHaveBeenCalledTimes(1)
    expect(runOpen).not.toHaveBeenCalled()
  })
})
