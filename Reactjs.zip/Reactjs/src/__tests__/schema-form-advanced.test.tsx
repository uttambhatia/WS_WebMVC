import React, { act } from 'react'
import { afterEach, describe, expect, it } from 'vitest'
import { createRoot, type Root } from 'react-dom/client'
import { initializeFormEngine } from '../forms/bootstrap'
import { SchemaFormProvider, useSchemaForm } from '../forms/context'
import { SchemaForm } from '../forms/renderer'
import { evaluateCondition, type FormSchema } from '../forms/schema'

;(globalThis as Record<string, unknown>).IS_REACT_ACT_ENVIRONMENT = true

let activeRoot: Root | null = null
let activeContainer: HTMLDivElement | null = null

async function render(ui: React.ReactNode): Promise<HTMLDivElement> {
  const container = document.createElement('div')
  document.body.appendChild(container)
  const root = createRoot(container)
  activeRoot = root
  activeContainer = container

  await act(async () => {
    root.render(ui)
    await Promise.resolve()
  })

  return container
}

afterEach(async () => {
  if (activeRoot && activeContainer) {
    await act(async () => {
      activeRoot?.unmount()
    })
    activeContainer.remove()
  }

  activeRoot = null
  activeContainer = null
  document.body.innerHTML = ''
})

describe('Form engine advanced behavior', () => {
  it('supports richer declarative condition operators', () => {
    const values = {
      text: 'alpha-beta',
      tags: ['core', 'forms'],
      size: 2,
      status: 'active',
    }

    expect(evaluateCondition({ field: 'text', contains: 'beta', startsWith: 'alpha' }, values)).toBe(true)
    expect(evaluateCondition({ field: 'text', endsWith: 'beta', matches: '^alpha-.*' }, values)).toBe(true)
    expect(evaluateCondition({ field: 'tags', includesAll: ['core'], includesAny: ['forms', 'grid'] }, values)).toBe(true)
    expect(evaluateCondition({ field: 'tags', includesNone: ['admin'] }, values)).toBe(true)
    expect(evaluateCondition({ field: 'text', lengthGte: 5, lengthLte: 20 }, values)).toBe(true)
    expect(evaluateCondition({ xor: [{ field: 'status', eq: 'active' }, { field: 'size', gt: 3 }] }, values)).toBe(true)
  })

  it('applies conflict-resolution policy for show/hide rule chains', async () => {
    const schema: FormSchema = {
      id: 'policy-form',
      rulePolicy: {
        visibility: 'hide-wins',
      },
      fields: [
        {
          key: 'enabled',
          label: 'Enabled',
          type: 'checkbox',
          defaultValue: true,
        },
        {
          key: 'details',
          label: 'Details',
          type: 'text',
          rules: [
            { kind: 'show', when: { field: 'enabled', eq: true } },
            { kind: 'hide', when: { field: 'enabled', eq: true } },
          ],
        },
      ],
    }

    const initialized = initializeFormEngine({ schema })
    expect(initialized.success).toBe(true)

    const container = await render(<SchemaForm engine={initialized.engine!} />)
    expect(container.querySelector('#policy-form-details')).toBeNull()
  })

  it('handles async validator cancellation and lookup retry policies', async () => {
    const attempts = {
      validator: 0,
      lookup: 0,
    }

    const schema: FormSchema = {
      id: 'async-form',
      fields: [
        {
          key: 'code',
          label: 'Code',
          type: 'text',
          validators: [
            {
              name: 'delayedCheck',
              stage: 'async',
              asyncPolicy: {
                timeoutMs: 200,
              },
            },
          ],
        },
        {
          key: 'dataset',
          label: 'Dataset',
          type: 'async-select',
          lookup: {
            provider: 'datasets',
            asyncPolicy: {
              retry: {
                maxAttempts: 2,
                backoffMs: 1,
              },
              timeoutMs: 200,
            },
          },
        },
      ],
    }

    const initialized = initializeFormEngine({
      schema,
      register: (registry) => {
        registry.registerValidator('delayedCheck', async (value, _args, context) => {
          attempts.validator += 1

          await new Promise<void>((resolve, reject) => {
            const timeoutId = window.setTimeout(resolve, value === 'bad' ? 200 : 5)

            function onAbort() {
              window.clearTimeout(timeoutId)
              reject(new DOMException('Aborted', 'AbortError'))
            }

            if (context.signal.aborted) {
              onAbort()
              return
            }

            context.signal.addEventListener('abort', onAbort, { once: true })
          })

          if (value === 'bad') {
            return 'Invalid code'
          }

          return undefined
        })

        registry.registerLookupProvider('datasets', async () => {
          attempts.lookup += 1
          if (attempts.lookup === 1) {
            throw new Error('Transient lookup failure')
          }

          return [{ label: 'Dataset A', value: 'dataset-a' }]
        })
      },
    })

    expect(initialized.success).toBe(true)

    type ProbeApi = {
      setValue: (fieldKey: string, value: unknown) => void
      validateField: (field: FormSchema['fields'][number]) => Promise<string | undefined>
      resolveLookupOptions: (field: FormSchema['fields'][number], query: string, signal: AbortSignal) => Promise<{ label: string; value: string }[]>
      errors: Record<string, string>
      asyncStatusByField: Record<string, { loading: boolean; attempts: number; error?: string }>
    }

    let probe: ProbeApi | undefined
    const captureProbe = (next: ProbeApi) => {
      probe = next
    }

    function Probe({ onReady }: { onReady: (api: ProbeApi) => void }) {
      const form = useSchemaForm()

      React.useEffect(() => {
        onReady({
          setValue: form.setValue,
          validateField: form.validateField,
          resolveLookupOptions: form.resolveLookupOptions,
          errors: form.errors,
          asyncStatusByField: form.asyncStatusByField,
        })
      }, [form, onReady])

      return null
    }

    await render(
      <SchemaFormProvider engine={initialized.engine!}>
        <Probe onReady={captureProbe} />
      </SchemaFormProvider>,
    )

    const codeField = schema.fields[0]
    const lookupField = schema.fields[1]

    let firstValidation: Promise<string | undefined> | undefined
    await act(async () => {
      probe?.setValue('code', 'bad')
      firstValidation = probe?.validateField(codeField)
      await Promise.resolve()
    })

    let secondValidation: Promise<string | undefined> | undefined
    await act(async () => {
      probe?.setValue('code', 'good')
      secondValidation = probe?.validateField(codeField)
      await Promise.resolve()
    })

    await act(async () => {
      await Promise.all([firstValidation, secondValidation])
      await Promise.resolve()
    })

    expect(probe?.errors.code).toBeUndefined()
    expect(attempts.validator).toBeGreaterThanOrEqual(2)

    let lookupResult: { label: string; value: string }[] | undefined
    await act(async () => {
      lookupResult = await probe?.resolveLookupOptions(lookupField, 'dat', new AbortController().signal)
      await Promise.resolve()
    })
    expect(lookupResult).toEqual([{ label: 'Dataset A', value: 'dataset-a' }])
    expect(attempts.lookup).toBe(2)
    expect(probe?.asyncStatusByField.dataset?.attempts).toBe(2)
  })
})
