import React, { act } from 'react'
import { afterEach, describe, expect, it, vi } from 'vitest'
import { createRoot, type Root } from 'react-dom/client'
import { AsyncAutocomplete } from '../components/core/AsyncAutocomplete'
import { DataGrid } from '../components/core/DataGrid'
import { FormWizard } from '../components/core/FormWizard'
import { InlineEditable } from '../components/core/InlineEditable'
import { SplitLayout } from '../components/core/SplitLayout'
import { CalendarScheduler } from '../components/core/CalendarScheduler'
import { CommandBar } from '../components/core/CommandBar'
import { RichTextEditorField } from '../components/core/RichTextEditorField'
import { FileManager } from '../components/core/FileManager'
import { AuditTimeline } from '../components/core/AuditTimeline'

;(globalThis as Record<string, unknown>).IS_REACT_ACT_ENVIRONMENT = true

let activeRoot: Root | null = null
let activeContainer: HTMLDivElement | null = null

async function render(ui: React.ReactNode): Promise<HTMLDivElement> {
  const container = document.createElement('div')
  document.body.appendChild(container)

  const root = createRoot(container)
  activeRoot = root
  activeContainer = container

  await act(async () => {
    root.render(ui)
    await Promise.resolve()
  })

  return container
}

afterEach(async () => {
  vi.restoreAllMocks()

  if (activeRoot && activeContainer) {
    await act(async () => {
      activeRoot?.unmount()
    })
    activeContainer.remove()
  }

  activeRoot = null
  activeContainer = null
  document.body.innerHTML = ''
})

describe('AsyncAutocomplete', () => {
  it('loads async options and selects item', async () => {
    vi.useFakeTimers()
    try {
      const onChange = vi.fn()
      const loadOptions = vi.fn(async () => {
        return [
          { id: 'alpha', label: 'Alpha Service' },
          { id: 'alpine', label: 'Alpine Data' },
        ]
      })

      const container = await render(
        <AsyncAutocomplete
          id="async-demo"
          value=""
          debounceMs={0}
          minQueryLength={0}
          loadOptions={loadOptions}
          getOptionLabel={(option) => option.label}
          getOptionValue={(option) => option.id}
          onChange={onChange}
        />,
      )

      const input = container.querySelector('#async-demo') as HTMLInputElement

      // Focus opens the dropdown and starts the debounce effect
      await act(async () => {
        input.focus()
      })

      // Flush the debounce setTimeout(fn, 0) then drain the async loadOptions promise
      await act(async () => {
        vi.runAllTimers()
        await Promise.resolve()
        await Promise.resolve()
      })

      expect(loadOptions).toHaveBeenCalled()

      const optionButton = container.querySelector('.rf-async-autocomplete__option') as HTMLButtonElement
      expect(optionButton).not.toBeNull()

      await act(async () => {
        optionButton.click()
      })

      expect(onChange).toHaveBeenCalledWith('alpha')
    } finally {
      vi.useRealTimers()
    }
  })
})

describe('DataGrid pro controls', () => {
  it('emits visibility, ordering, and resize callbacks', async () => {
    const onColumnVisibilityChange = vi.fn()
    const onColumnOrderChange = vi.fn()
    const onColumnResize = vi.fn()

    const container = await render(
      <DataGrid
        columns={[
          { key: 'name', header: 'Name', sortable: true },
          { key: 'status', header: 'Status' },
        ]}
        rows={[
          { id: '1', name: 'Alpha', status: 'Healthy' },
          { id: '2', name: 'Beta', status: 'Warning' },
        ]}
        page={1}
        pageSize={10}
        showColumnControls
        onColumnVisibilityChange={onColumnVisibilityChange}
        onColumnOrderChange={onColumnOrderChange}
        onColumnResize={onColumnResize}
      />,
    )

    const visibilityToggle = container.querySelector('.rf-data-grid__toggle input[type="checkbox"]') as HTMLInputElement
    await act(async () => {
      visibilityToggle.click()
    })

    expect(onColumnVisibilityChange).toHaveBeenCalled()

    const moveRight = container.querySelectorAll('.rf-data-grid__order-btn')[1] as HTMLButtonElement
    await act(async () => {
      moveRight.click()
    })

    expect(onColumnOrderChange).toHaveBeenCalled()

    const widthSlider = container.querySelector('.rf-data-grid__width input[type="range"]') as HTMLInputElement
    await act(async () => {
      widthSlider.value = '240'
      widthSlider.dispatchEvent(new Event('input', { bubbles: true }))
      widthSlider.dispatchEvent(new Event('change', { bubbles: true }))
    })

    expect(onColumnResize).toHaveBeenCalled()
  })
})

describe('FormWizard', () => {
  it('blocks next step on validation and submits on final step', async () => {
    const onSubmit = vi.fn()

    function Wrapper() {
      const [stepId, setStepId] = React.useState('details')
      const [valid, setValid] = React.useState(false)

      return (
        <>
          <button type="button" id="toggle-valid" onClick={() => setValid((prev) => !prev)}>toggle valid</button>
          <FormWizard
            currentStepId={stepId}
            onStepChange={setStepId}
            onSubmit={onSubmit}
            steps={[
              {
                id: 'details',
                title: 'Details',
                content: <p>Details step</p>,
                validateStep: () => (valid ? null : 'Details are required.'),
              },
              {
                id: 'review',
                title: 'Review',
                content: <p>Review step</p>,
              },
            ]}
          />
        </>
      )
    }

    const container = await render(<Wrapper />)

    const nextButton = container.querySelector('.rf-form-wizard__actions .rf-btn--primary') as HTMLButtonElement

    await act(async () => {
      nextButton.click()
    })

    expect(container.querySelector('.rf-form-wizard__error')?.textContent).toContain('Details are required.')

    const toggleValid = container.querySelector('#toggle-valid') as HTMLButtonElement
    await act(async () => {
      toggleValid.click()
    })

    await act(async () => {
      nextButton.click()
    })

    const submitButton = container.querySelector('.rf-form-wizard__actions .rf-btn--primary') as HTMLButtonElement
    expect(submitButton.textContent).toContain('Submit')

    await act(async () => {
      submitButton.click()
    })

    expect(onSubmit).toHaveBeenCalledTimes(1)
  })
})

describe('InlineEditable', () => {
  it('shows trigger in display mode and enters edit mode on click', async () => {
    const onSave = vi.fn()
    const container = await render(
      <InlineEditable value="Alice" onSave={onSave} />,
    )

    const trigger = container.querySelector('.rf-inline-editable__trigger') as HTMLButtonElement
    expect(trigger).not.toBeNull()
    expect(trigger.textContent).toContain('Alice')

    await act(async () => {
      trigger.click()
    })

    expect(container.querySelector('.rf-inline-editable__input')).not.toBeNull()
  })

  it('clicking cancel returns to display mode and fires onCancel', async () => {
    const onSave = vi.fn()
    const onCancel = vi.fn()
    const container = await render(
      <InlineEditable value="Original" onSave={onSave} onCancel={onCancel} />,
    )

    const trigger = container.querySelector('.rf-inline-editable__trigger') as HTMLButtonElement
    await act(async () => {
      trigger.click()
    })

    const cancelBtn = container.querySelector('.rf-inline-editable__cancel') as HTMLButtonElement
    await act(async () => {
      cancelBtn.click()
    })

    expect(onSave).not.toHaveBeenCalled()
    expect(onCancel).toHaveBeenCalledTimes(1)
    expect(container.querySelector('.rf-inline-editable__trigger')).not.toBeNull()
  })

  it('blocks save and shows validation error without calling onSave', async () => {
    const onSave = vi.fn()
    const validate = vi.fn(() => 'Name is required.')
    const container = await render(
      <InlineEditable value="" onSave={onSave} validate={validate} />,
    )

    const trigger = container.querySelector('.rf-inline-editable__trigger') as HTMLButtonElement
    await act(async () => {
      trigger.click()
    })

    const saveBtn = container.querySelector('.rf-inline-editable__save') as HTMLButtonElement
    await act(async () => {
      saveBtn.click()
    })

    expect(onSave).not.toHaveBeenCalled()
    expect(container.querySelector('.rf-inline-editable__error')?.textContent).toContain('Name is required.')
  })

  it('surfaces server-side error when onSave returns an error string', async () => {
    const onSave = vi.fn(async () => 'Server error: duplicate name' as string)
    const container = await render(
      <InlineEditable value="Test" onSave={onSave} saveOnBlur={false} />,
    )

    const trigger = container.querySelector('.rf-inline-editable__trigger') as HTMLButtonElement
    await act(async () => {
      trigger.click()
    })

    const saveBtn = container.querySelector('.rf-inline-editable__save') as HTMLButtonElement
    await act(async () => {
      saveBtn.click()
      await Promise.resolve()
    })

    expect(onSave).toHaveBeenCalledWith('Test')
    expect(container.querySelector('.rf-inline-editable__error')?.textContent).toContain('Server error: duplicate name')

  })
})

describe('SplitLayout', () => {
    it('renders all panes and handles are present', async () => {
      const container = await render(
        <SplitLayout
          panes={[
            { id: 'a', content: <div>Pane A</div>, label: 'Pane A' },
            { id: 'b', content: <div>Pane B</div>, label: 'Pane B' },
          ]}
        />,
      )

      expect(container.querySelector('[aria-label="Pane A"]')).not.toBeNull()
      expect(container.querySelector('[aria-label="Pane B"]')).not.toBeNull()
      expect(container.querySelector('.rf-split-layout__handle')).not.toBeNull()
      expect(container.querySelectorAll('.rf-split-layout__handle')).toHaveLength(1)
    })

    it('keyboard ArrowRight on handle grows left pane and calls onSizesChange', async () => {
      const onSizesChange = vi.fn()

      const container = await render(
        <SplitLayout
          panes={[
            { id: 'left', content: <div>Left</div>, label: 'Left' },
            { id: 'right', content: <div>Right</div>, label: 'Right' },
          ]}
          onSizesChange={onSizesChange}
        />,
      )

      const handle = container.querySelector('.rf-split-layout__handle') as HTMLElement
      await act(async () => {
        handle.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowRight', bubbles: true }))
      })

      expect(onSizesChange).toHaveBeenCalledTimes(1)
      const [newSizes] = onSizesChange.mock.calls[0]
      // Default sizes are [50, 50]; after +1 step: [51, 49]
      expect(newSizes[0]).toBeGreaterThan(50)
      expect(newSizes[1]).toBeLessThan(50)
    })

    it('collapses and expands a pane when collapsible is true', async () => {
      const onSizesChange = vi.fn()

      const container = await render(
        <SplitLayout
          panes={[
            { id: 'main', content: <div>Main</div>, label: 'Main' },
            { id: 'side', content: <div>Side</div>, label: 'Side' },
          ]}
          collapsible
          onSizesChange={onSizesChange}
        />,
      )

      const collapseBtn = container.querySelector('.rf-split-layout__collapse-btn') as HTMLButtonElement
      expect(collapseBtn).not.toBeNull()

      // Collapse the first pane.
      await act(async () => {
        collapseBtn.click()
      })

      expect(onSizesChange).toHaveBeenCalledTimes(1)
      const collapsedSizes = onSizesChange.mock.calls[0][0] as number[]
      expect(collapsedSizes[0]).toBe(0)
      expect(container.querySelector('.rf-split-layout__pane--collapsed')).not.toBeNull()

      // Expand the first pane.
      await act(async () => {
        collapseBtn.click()
      })

      expect(onSizesChange).toHaveBeenCalledTimes(2)
      const expandedSizes = onSizesChange.mock.calls[1][0] as number[]
      expect(expandedSizes[0]).toBeGreaterThan(0)
      expect(container.querySelector('.rf-split-layout__pane--collapsed')).toBeNull()
    })

    it('three-pane layout renders two handles', async () => {
      const container = await render(
        <SplitLayout
          panes={[
            { id: 'x', content: <span>X</span>, label: 'X' },
            { id: 'y', content: <span>Y</span>, label: 'Y' },
            { id: 'z', content: <span>Z</span>, label: 'Z' },
          ]}
        />,
      )

      expect(container.querySelectorAll('.rf-split-layout__handle')).toHaveLength(2)
    })
})

describe('CalendarScheduler', () => {
  it('emits range changes for month view and next navigation', async () => {
    const onRangeChange = vi.fn()

    const container = await render(
      <CalendarScheduler
        view="month"
        selectedDate="2026-03-14"
        events={[]}
        onRangeChange={onRangeChange}
      />,
    )

    expect(onRangeChange).toHaveBeenCalled()

    const nextButton = container.querySelectorAll('.rf-calendar-scheduler__nav-btn')[2] as HTMLButtonElement
    await act(async () => {
      nextButton.click()
    })

    expect(onRangeChange.mock.calls.length).toBeGreaterThanOrEqual(2)
  })

  it('calls onEventSelect when an event is clicked', async () => {
    const onEventSelect = vi.fn()

    const container = await render(
      <CalendarScheduler
        view="day"
        selectedDate="2026-03-14"
        timezone="UTC"
        onEventSelect={onEventSelect}
        events={[
          {
            id: 'event-1',
            title: 'Standup',
            start: '2026-03-14T09:00:00Z',
            end: '2026-03-14T09:30:00Z',
          },
        ]}
      />,
    )

    const eventButton = container.querySelector('.rf-calendar-scheduler__event') as HTMLButtonElement
    expect(eventButton).not.toBeNull()
    await act(async () => {
      eventButton.click()
    })

    expect(onEventSelect).toHaveBeenCalledTimes(1)
    expect(onEventSelect.mock.calls[0][0].id).toBe('event-1')
  })

  it('calls onCreateEvent from day view create button', async () => {
    const onCreateEvent = vi.fn()

    const container = await render(
      <CalendarScheduler
        view="day"
        selectedDate="2026-03-14"
        events={[]}
        onCreateEvent={onCreateEvent}
      />,
    )

    const createButton = container.querySelector('.rf-calendar-scheduler__create') as HTMLButtonElement
    await act(async () => {
      createButton.click()
    })

    expect(onCreateEvent).toHaveBeenCalledWith('2026-03-14', 'day')
  })

  it('renders seven columns in week view', async () => {
    const container = await render(
      <CalendarScheduler
        view="week"
        selectedDate="2026-03-14"
        events={[]}
      />,
    )

    expect(container.querySelectorAll('.rf-calendar-scheduler__week-day')).toHaveLength(7)
  })
})

describe('CommandBar', () => {
  it('shows overflow actions and triggers callbacks', async () => {
    const approve = vi.fn()
    const reject = vi.fn()
    const archive = vi.fn()
    const search = vi.fn()
    const openPalette = vi.fn()

    const container = await render(
      <CommandBar
        title="Ticket actions"
        maxVisibleActions={1}
        searchValue="pending"
        actions={[
          { id: 'approve', label: 'Approve', onSelect: approve },
          { id: 'reject', label: 'Reject', onSelect: reject },
        ]}
        overflowActions={[
          { id: 'archive', label: 'Archive', onSelect: archive },
        ]}
        onSearchSubmit={search}
        onOpenCommandPalette={openPalette}
      />,
    )

    const paletteButton = container.querySelector('.rf-command-bar__palette') as HTMLButtonElement
    await act(async () => {
      paletteButton.click()
    })
    expect(openPalette).toHaveBeenCalledTimes(1)

    const searchSubmit = container.querySelector('.rf-command-bar__search-submit') as HTMLButtonElement
    await act(async () => {
      searchSubmit.click()
    })
    expect(search).toHaveBeenCalledWith('pending')

    const overflowToggle = container.querySelector('.rf-command-bar__overflow-toggle') as HTMLButtonElement
    await act(async () => {
      overflowToggle.click()
    })

    const overflowItems = container.querySelectorAll('.rf-command-bar__overflow-item')
    expect(overflowItems.length).toBeGreaterThanOrEqual(2)

    await act(async () => {
      (overflowItems[0] as HTMLButtonElement).click()
    })
    expect(reject).toHaveBeenCalledTimes(1)

    await act(async () => {
      overflowToggle.click()
    })

    const secondOpenItems = container.querySelectorAll('.rf-command-bar__overflow-item')
    const archiveButton = Array.from(secondOpenItems).find((element) => {
      return (element.textContent ?? '').includes('Archive')
    }) as HTMLButtonElement | undefined
    expect(archiveButton).not.toBeUndefined()

    await act(async () => {
      archiveButton?.click()
    })

    expect(archive).toHaveBeenCalledTimes(1)
    expect(approve).not.toHaveBeenCalled()
  })
})

describe('RichTextEditorField', () => {
  it('sanitizes editor output and respects maxLength contract', async () => {
    const onChange = vi.fn()

    const container = await render(
      <RichTextEditorField
        value=""
        maxLength={5}
        onChange={onChange}
      />,
    )

    const editor = container.querySelector('.rf-rich-text__editor') as HTMLDivElement
    await act(async () => {
      editor.innerHTML = '<p>Hello<script>alert(1)</script>World</p>'
      editor.dispatchEvent(new Event('input', { bubbles: true }))
    })

    expect(onChange).toHaveBeenCalled()
    const latestCall = onChange.mock.calls[onChange.mock.calls.length - 1]
    const [value, meta] = latestCall as [string, { rawValue: string; output: string; textLength: number }]
    expect(value.includes('<script')).toBe(false)
    expect(meta.output).toBe('html')
    expect(meta.textLength).toBeLessThanOrEqual(5)
  })
})

describe('FileManager', () => {
  it('uploads, replaces, and removes files with callbacks', async () => {
    const onUpload = vi.fn()
    const onRemove = vi.fn()
    const onReplace = vi.fn()

    const container = await render(
      <FileManager
        maxFileSize={2000}
        onUpload={onUpload}
        onRemove={onRemove}
        onReplace={onReplace}
      />,
    )

    const inputs = container.querySelectorAll('input[type="file"]')
    const uploadInput = inputs[0] as HTMLInputElement
    const replaceInput = inputs[1] as HTMLInputElement

    await act(async () => {
      const uploaded = new File(['alpha'], 'alpha.txt', { type: 'text/plain' })
      Object.defineProperty(uploadInput, 'files', { value: [uploaded], configurable: true })
      uploadInput.dispatchEvent(new Event('change', { bubbles: true }))
    })

    expect(onUpload).toHaveBeenCalledTimes(1)
    expect(container.querySelector('.rf-file-manager__name')?.textContent).toContain('alpha.txt')

    const replaceButton = container.querySelector('.rf-file-manager__action') as HTMLButtonElement
    await act(async () => {
      replaceButton.click()
    })
    await act(async () => {
      const replacement = new File(['beta'], 'beta.txt', { type: 'text/plain' })
      Object.defineProperty(replaceInput, 'files', { value: [replacement], configurable: true })
      replaceInput.dispatchEvent(new Event('change', { bubbles: true }))
    })

    expect(onReplace).toHaveBeenCalledTimes(1)
    expect(container.querySelector('.rf-file-manager__name')?.textContent).toContain('beta.txt')

    const removeButton = container.querySelector('.rf-file-manager__action--danger') as HTMLButtonElement
    await act(async () => {
      removeButton.click()
    })

    expect(onRemove).toHaveBeenCalledTimes(1)
  })
})

describe('AuditTimeline', () => {
  it('groups chronologically and filters by category and query', async () => {
    const onFilterChange = vi.fn()

    const container = await render(
      <AuditTimeline
        onFilterChange={onFilterChange}
        events={[
          {
            id: 'event-1',
            timestamp: '2026-03-14T10:00:00Z',
            title: 'User created',
            actor: 'Alice',
            category: 'users',
            description: 'Created an account',
          },
          {
            id: 'event-2',
            timestamp: '2026-03-14T11:00:00Z',
            title: 'Policy updated',
            actor: 'Bob',
            category: 'security',
          },
        ]}
      />,
    )

    expect(container.querySelectorAll('.rf-audit-timeline__event-item')).toHaveLength(2)

    const categorySelect = container.querySelectorAll('.rf-audit-timeline__filter select')[0] as HTMLSelectElement
    await act(async () => {
      categorySelect.value = 'security'
      categorySelect.dispatchEvent(new Event('change', { bubbles: true }))
    })

    expect(container.querySelectorAll('.rf-audit-timeline__event-item')).toHaveLength(1)
    expect(container.querySelector('.rf-audit-timeline__event-title')?.textContent).toContain('Policy updated')

    expect(onFilterChange).toHaveBeenCalled()
  })
})
