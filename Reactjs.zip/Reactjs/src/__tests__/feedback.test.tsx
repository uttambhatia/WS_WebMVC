/**
 * Sprint C1 Batch 3 — Feedback & Status Component Tests
 * Tests for: Alert, Spinner, EmptyState, ErrorState, Badge
 */

import React, { act } from 'react'
import { afterEach, describe, expect, it, vi } from 'vitest'
import { createRoot, type Root } from 'react-dom/client'
import { Alert } from '../components/core/Alert'
import { Spinner } from '../components/core/Spinner'
import { EmptyState } from '../components/core/EmptyState'
import { ErrorState } from '../components/core/ErrorState'
import { Badge } from '../components/core/Badge'

;(globalThis as Record<string, unknown>).IS_REACT_ACT_ENVIRONMENT = true

let activeRoot: Root | null = null
let activeContainer: HTMLDivElement | null = null

async function render(ui: React.ReactNode): Promise<HTMLDivElement> {
  const container = document.createElement('div')
  document.body.appendChild(container)
  const root = createRoot(container)
  activeRoot = root
  activeContainer = container

  await act(async () => {
    root.render(ui)
    await Promise.resolve()
  })

  return container
}

afterEach(async () => {
  vi.restoreAllMocks()

  if (activeRoot && activeContainer) {
    await act(async () => {
      activeRoot?.unmount()
    })
    activeContainer.remove()
  }

  activeRoot = null
  activeContainer = null
  document.body.innerHTML = ''
})

describe('Alert', () => {
  it('renders info class by default', async () => {
    const container = await render(<Alert>Heads up</Alert>)
    expect(container.firstElementChild?.className).toContain('rf-alert--info')
  })

  it('applies variant class', async () => {
    const container = await render(<Alert variant="error">Failure</Alert>)
    expect(container.firstElementChild?.className).toContain('rf-alert--error')
  })

  it('uses role status for success', async () => {
    const container = await render(<Alert variant="success">Done</Alert>)
    expect(container.firstElementChild?.getAttribute('role')).toBe('status')
  })

  it('uses role alert for warning', async () => {
    const container = await render(<Alert variant="warning">Warning</Alert>)
    expect(container.firstElementChild?.getAttribute('role')).toBe('alert')
  })

  it('renders default icon', async () => {
    const container = await render(<Alert variant="success">Done</Alert>)
    expect(container.querySelector('.rf-alert__icon')?.textContent).toContain('✓')
  })

  it('renders custom icon when provided', async () => {
    const container = await render(<Alert icon={<span>!</span>}>Custom</Alert>)
    expect(container.querySelector('.rf-alert__icon')?.textContent).toContain('!')
  })

  it('renders dismiss button when dismissible', async () => {
    const container = await render(<Alert dismissible>Can close</Alert>)
    expect(container.querySelector('.rf-alert__dismiss')).not.toBeNull()
  })

  it('does not render dismiss button when not dismissible', async () => {
    const container = await render(<Alert>Fixed</Alert>)
    expect(container.querySelector('.rf-alert__dismiss')).toBeNull()
  })

  it('dismisses itself when dismiss button clicked and no onDismiss provided', async () => {
    const container = await render(<Alert dismissible>Closable</Alert>)
    const dismiss = container.querySelector('.rf-alert__dismiss') as HTMLButtonElement

    await act(async () => {
      dismiss.click()
    })

    expect(container.firstElementChild).toBeNull()
  })

  it('calls onDismiss when provided', async () => {
    const onDismiss = vi.fn()
    const container = await render(
      <Alert dismissible onDismiss={onDismiss}>
        Controlled
      </Alert>
    )

    await act(async () => {
      (container.querySelector('.rf-alert__dismiss') as HTMLButtonElement).click()
    })

    expect(onDismiss).toHaveBeenCalledTimes(1)
    expect(container.firstElementChild).not.toBeNull()
  })
})

describe('Spinner', () => {
  it('renders with md size class by default', async () => {
    const container = await render(<Spinner />)
    expect(container.firstElementChild?.className).toContain('rf-spinner--md')
  })

  it('applies sm size class', async () => {
    const container = await render(<Spinner size="sm" />)
    expect(container.firstElementChild?.className).toContain('rf-spinner--sm')
  })

  it('applies lg size class', async () => {
    const container = await render(<Spinner size="lg" />)
    expect(container.firstElementChild?.className).toContain('rf-spinner--lg')
  })

  it('uses status role and aria-live polite', async () => {
    const container = await render(<Spinner />)
    const spinner = container.firstElementChild as HTMLElement
    expect(spinner.getAttribute('role')).toBe('status')
    expect(spinner.getAttribute('aria-live')).toBe('polite')
  })

  it('renders accessibility label', async () => {
    const container = await render(<Spinner label="Loading dashboard" />)
    expect(container.querySelector('.rf-visually-hidden')?.textContent).toBe('Loading dashboard')
  })

  it('applies inline class when inline is true', async () => {
    const container = await render(<Spinner inline />)
    expect(container.firstElementChild?.className).toContain('rf-spinner--inline')
  })
})

describe('EmptyState', () => {
  it('renders title', async () => {
    const container = await render(<EmptyState title="No data" />)
    expect(container.querySelector('.rf-empty-state__title')?.textContent).toBe('No data')
  })

  it('renders description when provided', async () => {
    const container = await render(<EmptyState title="No data" description="Try changing filters" />)
    expect(container.querySelector('.rf-empty-state__description')?.textContent).toContain('Try changing')
  })

  it('does not render description when omitted', async () => {
    const container = await render(<EmptyState title="No data" />)
    expect(container.querySelector('.rf-empty-state__description')).toBeNull()
  })

  it('renders default icon when no custom icon is provided', async () => {
    const container = await render(<EmptyState title="No data" />)
    expect(container.querySelector('.rf-empty-state__icon')?.textContent).toContain('📭')
  })

  it('renders custom icon', async () => {
    const container = await render(<EmptyState title="No data" icon={<span>*</span>} />)
    expect(container.querySelector('.rf-empty-state__icon')?.textContent).toContain('*')
  })

  it('renders optional action slot', async () => {
    const container = await render(
      <EmptyState title="No data" action={<button type="button">Create</button>} />
    )
    expect(container.querySelector('.rf-empty-state__action button')?.textContent).toBe('Create')
  })

  it('applies left alignment class', async () => {
    const container = await render(<EmptyState title="No data" align="left" />)
    expect(container.firstElementChild?.className).toContain('rf-empty-state--left')
  })
})

describe('ErrorState', () => {
  it('renders message', async () => {
    const container = await render(<ErrorState message="Could not load" onRetry={() => undefined} />)
    expect(container.querySelector('.rf-error-state__message')?.textContent).toContain('Could not load')
  })

  it('uses default title when title is omitted', async () => {
    const container = await render(<ErrorState message="Could not load" onRetry={() => undefined} />)
    expect(container.querySelector('.rf-error-state__title')?.textContent).toBe('Something went wrong')
  })

  it('uses alert role', async () => {
    const container = await render(<ErrorState message="Could not load" onRetry={() => undefined} />)
    expect(container.firstElementChild?.getAttribute('role')).toBe('alert')
  })

  it('calls onRetry when retry button clicked', async () => {
    const onRetry = vi.fn()
    const container = await render(<ErrorState message="Could not load" onRetry={onRetry} />)

    await act(async () => {
      (container.querySelector('button') as HTMLButtonElement).click()
    })

    expect(onRetry).toHaveBeenCalledTimes(1)
  })

  it('renders custom retry label', async () => {
    const container = await render(
      <ErrorState message="Could not load" retryLabel="Retry request" onRetry={() => undefined} />
    )
    expect(container.querySelector('button')?.textContent).toContain('Retry request')
  })
})

describe('Badge', () => {
  it('renders primary and md classes by default', async () => {
    const container = await render(<Badge>Default</Badge>)
    expect(container.firstElementChild?.className).toContain('rf-badge--primary')
    expect(container.firstElementChild?.className).toContain('rf-badge--md')
  })

  it('applies success variant class', async () => {
    const container = await render(<Badge variant="success">Done</Badge>)
    expect(container.firstElementChild?.className).toContain('rf-badge--success')
  })

  it('applies warning variant class', async () => {
    const container = await render(<Badge variant="warning">Warn</Badge>)
    expect(container.firstElementChild?.className).toContain('rf-badge--warning')
  })

  it('applies error variant class', async () => {
    const container = await render(<Badge variant="error">Fail</Badge>)
    expect(container.firstElementChild?.className).toContain('rf-badge--error')
  })

  it('applies sm size class', async () => {
    const container = await render(<Badge size="sm">Small</Badge>)
    expect(container.firstElementChild?.className).toContain('rf-badge--sm')
  })

  it('renders children content', async () => {
    const container = await render(<Badge>Pending</Badge>)
    expect(container.firstElementChild?.textContent).toBe('Pending')
  })
})
