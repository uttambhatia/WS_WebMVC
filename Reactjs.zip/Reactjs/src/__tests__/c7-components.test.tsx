/**
 * Sprint C7 Component Tests
 * Covers: SliderInput, TagsInput, Sparkline, KPICard, VirtualList, ConfirmationDialog, KanbanBoard
 */

import { describe, it, expect, vi } from 'vitest'
import React from 'react'
import { createRoot } from 'react-dom/client'
import { act } from 'react'

const rootByContainer = new WeakMap<HTMLElement, ReturnType<typeof createRoot>>()

function render(element: React.ReactElement): HTMLElement {
  const container = document.createElement('div')
  document.body.appendChild(container)
  const root = createRoot(container)
  rootByContainer.set(container, root)
  act(() => {
    root.render(element)
  })
  return container
}

function cleanup(container: HTMLElement) {
  const root = rootByContainer.get(container)
  if (root) {
    act(() => {
      root.unmount()
    })
    rootByContainer.delete(container)
  }
  document.body.removeChild(container)
}

function setInputValue(input: HTMLInputElement, value: string) {
  const descriptor = Object.getOwnPropertyDescriptor(
    window.HTMLInputElement.prototype,
    'value',
  )
  descriptor?.set?.call(input, value)
}

// ─────────────────────────────────────────────────────────────────────────────
// SliderInput
// ─────────────────────────────────────────────────────────────────────────────

import { SliderInput } from '../components/core/SliderInput'

describe('SliderInput', () => {
  it('renders single mode with correct range input attributes', () => {
    const container = render(
      <SliderInput value={40} min={0} max={100} step={1} />,
    )
    const input = container.querySelector<HTMLInputElement>('input[type="range"]')
    expect(input).toBeTruthy()
    expect(input!.min).toBe('0')
    expect(input!.max).toBe('100')
    expect(input!.value).toBe('40')
    cleanup(container)
  })

  it('renders dual mode with two range inputs', () => {
    const container = render(
      <SliderInput dual value={[20, 80]} min={0} max={100} />,
    )
    const inputs = container.querySelectorAll<HTMLInputElement>('input[type="range"]')
    expect(inputs.length).toBe(2)
    expect(inputs[0].value).toBe('20')
    expect(inputs[1].value).toBe('80')
    cleanup(container)
  })

  it('calls onChange with numeric value in single mode', () => {
    const onChange = vi.fn()
    const container = render(
      <SliderInput value={10} onChange={onChange} min={0} max={100} />,
    )
    const input = container.querySelector<HTMLInputElement>('input[type="range"]')!
    act(() => {
      setInputValue(input, '55')
      input.dispatchEvent(new Event('input', { bubbles: true }))
    })
    expect(onChange).toHaveBeenCalledWith(55)
    cleanup(container)
  })

  it('applies disabled class and attribute when disabled', () => {
    const container = render(<SliderInput disabled value={50} />)
    const wrapper = container.querySelector('.rf-slider--disabled')
    expect(wrapper).toBeTruthy()
    const input = container.querySelector<HTMLInputElement>('input[type="range"]')!
    expect(input.disabled).toBe(true)
    cleanup(container)
  })

  it('applies error class when error prop is truthy', () => {
    const container = render(<SliderInput value={30} error="Required" />)
    expect(container.querySelector('.rf-slider--error')).toBeTruthy()
    const input = container.querySelector<HTMLInputElement>('input[type="range"]')!
    expect(input.getAttribute('aria-invalid')).toBe('true')
    cleanup(container)
  })

  it('renders value display when showValue is true', () => {
    const container = render(<SliderInput value={42} showValue />)
    const valueEl = container.querySelector('.rf-slider__value')
    expect(valueEl).toBeTruthy()
    expect(valueEl!.textContent).toContain('42')
    cleanup(container)
  })
})

// ─────────────────────────────────────────────────────────────────────────────
// TagsInput
// ─────────────────────────────────────────────────────────────────────────────

import { TagsInput } from '../components/core/TagsInput'

describe('TagsInput', () => {
  it('renders existing tags as chips', () => {
    const container = render(
      <TagsInput value={['react', 'typescript']} onChange={vi.fn()} />,
    )
    const chips = container.querySelectorAll('.rf-tags-input__chip')
    expect(chips.length).toBe(2)
    expect(chips[0].textContent).toContain('react')
    expect(chips[1].textContent).toContain('typescript')
    cleanup(container)
  })

  it('calls onChange with new tag when Enter is pressed', () => {
    const onChange = vi.fn()
    const container = render(<TagsInput value={[]} onChange={onChange} />)
    const input = container.querySelector<HTMLInputElement>('.rf-tags-input__field')!

    act(() => {
      setInputValue(input, 'newTag')
      input.dispatchEvent(new Event('input', { bubbles: true }))
      input.dispatchEvent(
        new KeyboardEvent('keydown', { key: 'Enter', bubbles: true }),
      )
    })
    expect(onChange).toHaveBeenCalledWith(['newTag'])
    cleanup(container)
  })

  it('calls onChange with last tag removed on Backspace when input is empty', () => {
    const onChange = vi.fn()
    const container = render(
      <TagsInput value={['alpha', 'beta']} onChange={onChange} />,
    )
    const input = container.querySelector<HTMLInputElement>('.rf-tags-input__field')!

    act(() => {
      setInputValue(input, '')
      input.dispatchEvent(new Event('input', { bubbles: true }))
      input.dispatchEvent(
        new KeyboardEvent('keydown', { key: 'Backspace', bubbles: true }),
      )
    })
    expect(onChange).toHaveBeenCalledWith(['alpha'])
    cleanup(container)
  })

  it('calls onChange with tag removed when chip remove button is clicked', () => {
    const onChange = vi.fn()
    const container = render(
      <TagsInput value={['one', 'two']} onChange={onChange} />,
    )
    const removeButtons = container.querySelectorAll<HTMLButtonElement>(
      '.rf-tags-input__chip-remove',
    )
    act(() => {
      removeButtons[0].click()
    })
    expect(onChange).toHaveBeenCalledWith(['two'])
    cleanup(container)
  })

  it('does not add duplicate when allowDuplicates is false', () => {
    const onChange = vi.fn()
    const container = render(
      <TagsInput value={['react']} onChange={onChange} allowDuplicates={false} />,
    )
    const input = container.querySelector<HTMLInputElement>('.rf-tags-input__field')!

    act(() => {
      setInputValue(input, 'react')
      input.dispatchEvent(new Event('input', { bubbles: true }))
      input.dispatchEvent(
        new KeyboardEvent('keydown', { key: 'Enter', bubbles: true }),
      )
    })
    expect(onChange).not.toHaveBeenCalled()
    cleanup(container)
  })

  it('hides input and applies full class when maxTags is reached', () => {
    const container = render(
      <TagsInput value={['a', 'b', 'c']} onChange={vi.fn()} maxTags={3} />,
    )
    expect(container.querySelector('.rf-tags-input--full')).toBeTruthy()
    expect(container.querySelector('.rf-tags-input__field')).toBeNull()
    cleanup(container)
  })

  it('applies error class when error prop is truthy', () => {
    const container = render(
      <TagsInput value={[]} onChange={vi.fn()} error="Required" />,
    )
    expect(container.querySelector('.rf-tags-input--error')).toBeTruthy()
    cleanup(container)
  })
})

// ─────────────────────────────────────────────────────────────────────────────
// Sparkline
// ─────────────────────────────────────────────────────────────────────────────

import { Sparkline } from '../components/core/Sparkline'

describe('Sparkline', () => {
  it('renders an SVG element', () => {
    const container = render(<Sparkline data={[10, 20, 15, 30, 25]} />)
    const svg = container.querySelector('svg')
    expect(svg).toBeTruthy()
    cleanup(container)
  })

  it('is aria-hidden by default', () => {
    const container = render(<Sparkline data={[1, 2, 3]} />)
    const svg = container.querySelector('svg')!
    expect(svg.getAttribute('aria-hidden')).toBe('true')
    cleanup(container)
  })

  it('renders a polyline with points', () => {
    const container = render(<Sparkline data={[0, 50, 100]} />)
    const polyline = container.querySelector('polyline')
    expect(polyline).toBeTruthy()
    const pts = polyline!.getAttribute('points')
    expect(pts).toBeTruthy()
    expect(pts!.split(' ').length).toBe(3)
    cleanup(container)
  })

  it('renders a fill path when fillColor is provided', () => {
    const container = render(
      <Sparkline data={[10, 40, 20]} fillColor="rgba(0,0,255,0.1)" />,
    )
    const path = container.querySelector('path')
    expect(path).toBeTruthy()
    cleanup(container)
  })

  it('renders empty SVG for fewer than 2 data points', () => {
    const container = render(<Sparkline data={[42]} />)
    const svg = container.querySelector('svg')
    expect(svg).toBeTruthy()
    expect(svg!.querySelector('polyline')).toBeNull()
    cleanup(container)
  })
})

// ─────────────────────────────────────────────────────────────────────────────
// KPICard
// ─────────────────────────────────────────────────────────────────────────────

import { KPICard } from '../components/core/KPICard'

describe('KPICard', () => {
  it('renders title and value', () => {
    const container = render(<KPICard title="Revenue" value="$42,000" />)
    expect(container.querySelector('.rf-kpi-card__title')!.textContent).toBe('Revenue')
    expect(container.querySelector('.rf-kpi-card__value')!.textContent).toBe('$42,000')
    cleanup(container)
  })

  it('applies up trend class for positive delta', () => {
    const container = render(
      <KPICard title="Sales" value={100} delta={12} trend="up" />,
    )
    expect(container.querySelector('.rf-kpi-card__delta--up')).toBeTruthy()
    cleanup(container)
  })

  it('applies down trend class for negative delta', () => {
    const container = render(
      <KPICard title="Churn" value={5} delta={-3} trend="down" />,
    )
    expect(container.querySelector('.rf-kpi-card__delta--down')).toBeTruthy()
    cleanup(container)
  })

  it('renders skeleton loaders when loading is true', () => {
    const container = render(<KPICard title="MRR" value="$0" loading />)
    expect(container.querySelector('.rf-skeleton')).toBeTruthy()
    expect(container.querySelector('.rf-kpi-card__value')).toBeNull()
    cleanup(container)
  })

  it('renders footer slot when footer prop is provided', () => {
    const container = render(
      <KPICard title="Orders" value={42} footer={<span id="footer-test">Last 30 days</span>} />,
    )
    expect(container.querySelector('#footer-test')).toBeTruthy()
    cleanup(container)
  })

  it('renders sparkline slot', () => {
    const container = render(
      <KPICard title="Visits" value={1000} sparkline={<span id="spark-slot" />} />,
    )
    expect(container.querySelector('#spark-slot')).toBeTruthy()
    cleanup(container)
  })
})

// ─────────────────────────────────────────────────────────────────────────────
// VirtualList
// ─────────────────────────────────────────────────────────────────────────────

import { VirtualList } from '../components/core/VirtualList'

describe('VirtualList', () => {
  it('renders the container with role="list"', () => {
    const items = Array.from({ length: 10 }, (_, i) => `Item ${i}`)
    const container = render(
      <VirtualList
        items={items}
        itemHeight={40}
        height={200}
        renderItem={(item) => <span>{item}</span>}
      />,
    )
    const list = container.querySelector('[role="list"]')
    expect(list).toBeTruthy()
    cleanup(container)
  })

  it('does not render all items when list is longer than viewport', () => {
    const items = Array.from({ length: 1000 }, (_, i) => `Item ${i}`)
    const container = render(
      <VirtualList
        items={items}
        itemHeight={40}
        height={200}
        renderItem={(item) => <span className="test-item">{item}</span>}
      />,
    )
    const renderedItems = container.querySelectorAll('.test-item')
    // 200px / 40px = 5 visible + 3 overscan * 2 = max ~11; definitely < 1000
    expect(renderedItems.length).toBeLessThan(50)
    cleanup(container)
  })

  it('renders items starting from index 0 initially', () => {
    const items = Array.from({ length: 20 }, (_, i) => `Row-${i}`)
    const container = render(
      <VirtualList
        items={items}
        itemHeight={40}
        height={200}
        renderItem={(item) => <span className="row">{item}</span>}
      />,
    )
    const first = container.querySelector('.row')!
    expect(first.textContent).toBe('Row-0')
    cleanup(container)
  })

  it('uses getItemKey for stable keys', () => {
    const items = [{ id: 'a' }, { id: 'b' }, { id: 'c' }]
    const container = render(
      <VirtualList
        items={items}
        itemHeight={50}
        height={200}
        renderItem={(item) => <span>{item.id}</span>}
        getItemKey={(item) => item.id}
      />,
    )
    expect(container.querySelector('[role="listitem"]')).toBeTruthy()
    cleanup(container)
  })
})

// ─────────────────────────────────────────────────────────────────────────────
// ConfirmationDialog
// ─────────────────────────────────────────────────────────────────────────────

import { ConfirmationDialog } from '../components/core/ConfirmationDialog'

describe('ConfirmationDialog', () => {
  it('renders message when open', () => {
    const container = render(
      <ConfirmationDialog
        open
        message={<span id="msg-test">Delete this record?</span>}
        onConfirm={vi.fn()}
        onCancel={vi.fn()}
      />,
    )
    expect(document.body.querySelector('#msg-test')).toBeTruthy()
    cleanup(container)
  })

  it('does not render when closed', () => {
    const container = render(
      <ConfirmationDialog
        open={false}
        message="Delete?"
        onConfirm={vi.fn()}
        onCancel={vi.fn()}
      />,
    )
    expect(document.body.querySelector('.rf-confirm-dialog__message')).toBeNull()
    cleanup(container)
  })

  it('calls onConfirm when confirm button is clicked', () => {
    const onConfirm = vi.fn()
    const container = render(
      <ConfirmationDialog
        open
        message="Confirm action?"
        confirmLabel="Yes"
        onConfirm={onConfirm}
        onCancel={vi.fn()}
      />,
    )
    const buttons = document.body.querySelectorAll<HTMLButtonElement>('button')
    const confirmBtn = Array.from(buttons).find((b) => b.textContent?.includes('Yes'))
    act(() => { confirmBtn!.click() })
    expect(onConfirm).toHaveBeenCalledOnce()
    cleanup(container)
  })

  it('calls onCancel when cancel button is clicked', () => {
    const onCancel = vi.fn()
    const container = render(
      <ConfirmationDialog
        open
        message="Cancel action?"
        cancelLabel="No"
        onConfirm={vi.fn()}
        onCancel={onCancel}
      />,
    )
    const buttons = document.body.querySelectorAll<HTMLButtonElement>('button')
    const cancelBtn = Array.from(buttons).find((b) => b.textContent?.includes('No'))
    act(() => { cancelBtn!.click() })
    expect(onCancel).toHaveBeenCalledOnce()
    cleanup(container)
  })

  it('applies danger class to confirm button when variant is danger', () => {
    const container = render(
      <ConfirmationDialog
        open
        variant="danger"
        message="Delete forever?"
        onConfirm={vi.fn()}
        onCancel={vi.fn()}
      />,
    )
    const dangerBtn = document.body.querySelector('.rf-btn--danger')
    expect(dangerBtn).toBeTruthy()
    cleanup(container)
  })

  it('renders title text', () => {
    const container = render(
      <ConfirmationDialog
        open
        title="Confirm deletion"
        message="This cannot be undone."
        onConfirm={vi.fn()}
        onCancel={vi.fn()}
      />,
    )
    expect(document.body.textContent).toContain('Confirm deletion')
    cleanup(container)
  })
})

// ─────────────────────────────────────────────────────────────────────────────
// KanbanBoard
// ─────────────────────────────────────────────────────────────────────────────

import { KanbanBoard } from '../components/core/KanbanBoard'
import type { KanbanColumn } from '../components/core/KanbanBoard'

const TEST_COLUMNS: KanbanColumn[] = [
  {
    id: 'todo',
    title: 'To Do',
    cards: [
      { id: 'c1', title: 'Card One' },
      { id: 'c2', title: 'Card Two', description: 'Desc' },
    ],
  },
  {
    id: 'in-progress',
    title: 'In Progress',
    cards: [{ id: 'c3', title: 'Card Three' }],
  },
  {
    id: 'done',
    title: 'Done',
    cards: [],
  },
]

describe('KanbanBoard', () => {
  it('renders all columns', () => {
    const container = render(<KanbanBoard columns={TEST_COLUMNS} />)
    const columns = container.querySelectorAll('.rf-kanban__column')
    expect(columns.length).toBe(3)
    cleanup(container)
  })

  it('renders column titles', () => {
    const container = render(<KanbanBoard columns={TEST_COLUMNS} />)
    const titles = Array.from(container.querySelectorAll('.rf-kanban__column-title')).map(
      (el) => el.textContent,
    )
    expect(titles).toContain('To Do')
    expect(titles).toContain('In Progress')
    expect(titles).toContain('Done')
    cleanup(container)
  })

  it('renders cards in correct columns', () => {
    const container = render(<KanbanBoard columns={TEST_COLUMNS} />)
    const cardTitles = Array.from(container.querySelectorAll('.rf-kanban__card-title')).map(
      (el) => el.textContent,
    )
    expect(cardTitles).toContain('Card One')
    expect(cardTitles).toContain('Card Two')
    expect(cardTitles).toContain('Card Three')
    cleanup(container)
  })

  it('calls onCardClick with correct card and columnId', () => {
    const onCardClick = vi.fn()
    const container = render(
      <KanbanBoard columns={TEST_COLUMNS} onCardClick={onCardClick} />,
    )
    const cards = container.querySelectorAll<HTMLElement>('.rf-kanban__card')
    act(() => { cards[0].click() })
    expect(onCardClick).toHaveBeenCalledWith(TEST_COLUMNS[0].cards[0], 'todo')
    cleanup(container)
  })

  it('shows WIP warning class when cards exceed wipLimit', () => {
    const columns: KanbanColumn[] = [
      { id: 'backlog', title: 'Backlog', cards: [{ id: 'x1', title: 'X1' }, { id: 'x2', title: 'X2' }, { id: 'x3', title: 'X3' }], wipLimit: 2 },
    ]
    const container = render(<KanbanBoard columns={columns} />)
    expect(container.querySelector('.rf-kanban__column--over-limit')).toBeTruthy()
    cleanup(container)
  })

  it('renders add-card button when onAddCard is provided', () => {
    const onAddCard = vi.fn()
    const container = render(
      <KanbanBoard columns={TEST_COLUMNS} onAddCard={onAddCard} />,
    )
    const addBtns = container.querySelectorAll('.rf-kanban__add-card')
    expect(addBtns.length).toBe(TEST_COLUMNS.length)
    act(() => { (addBtns[0] as HTMLButtonElement).click() })
    expect(onAddCard).toHaveBeenCalledWith('todo')
    cleanup(container)
  })

  it('renders custom card content via renderCard override', () => {
    const container = render(
      <KanbanBoard
        columns={TEST_COLUMNS}
        renderCard={(card) => <div className="custom-card">{card.title}</div>}
      />,
    )
    expect(container.querySelector('.custom-card')).toBeTruthy()
    cleanup(container)
  })
})
