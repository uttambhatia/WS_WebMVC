import React, { act } from 'react'
import { afterEach, describe, expect, it, vi } from 'vitest'
import { createRoot, type Root } from 'react-dom/client'
import {
  PieChart,
  DonutChart,
  AreaChart,
  ScatterChart,
  StackedBarChart,
  RadarChart,
  BubbleChart,
} from '../index'

describe('C11: Chart Variant Contracts', () => {
  let root: Root | null = null
  let container: HTMLDivElement | null = null

  afterEach(() => {
    if (root) {
      act(() => {
        root?.unmount()
      })
      root = null
    }
    if (container && container.parentNode) {
      container.parentNode.removeChild(container)
      container = null
    }
  })

  const renderChart = (element: React.ReactElement) => {
    if (!container) {
      container = document.createElement('div')
      document.body.appendChild(container)
    }
    root = createRoot(container)
    act(() => {
      root?.render(element)
    })
    return container
  }

  it('PieChart drilldown variant supports deterministic selection callbacks', () => {
    const onSliceSelect = vi.fn()
    const view = renderChart(
      <PieChart
        data={[{ label: 'A', value: 60 }, { label: 'B', value: 40 }]}
        variant="drilldown"
        onSliceSelect={onSliceSelect}
      />,
    )

    const firstSlice = view.querySelector('path')
    expect(firstSlice).toBeTruthy()
    firstSlice?.dispatchEvent(new MouseEvent('click', { bubbles: true }))
    expect(onSliceSelect).toHaveBeenCalledTimes(1)
  })

  it('DonutChart multi-ring variant renders ring slices for each ring dataset', () => {
    const view = renderChart(
      <DonutChart
        variant="multi-ring"
        data={[{ label: 'Outer', value: 100 }]}
        rings={[
          { data: [{ label: 'Outer', value: 100 }], innerRadius: 48 },
          { data: [{ label: 'Inner A', value: 70 }, { label: 'Inner B', value: 30 }], innerRadius: 30 },
        ]}
      />,
    )

    const slices = view.querySelectorAll('.rf-donut-chart__slice')
    expect(slices.length).toBeGreaterThanOrEqual(3)
  })

  it('AreaChart range variant renders bounded range polygon', () => {
    const view = renderChart(
      <AreaChart
        variant="range"
        data={[{ x: 1, y: 10 }, { x: 2, y: 20 }]}
        rangeSeries={[
          { x: 1, min: 8, max: 14 },
          { x: 2, min: 12, max: 22 },
          { x: 3, min: 10, max: 20 },
        ]}
      />,
    )

    const areaPolygons = view.querySelectorAll('.rf-area-chart__area')
    expect(areaPolygons.length).toBeGreaterThan(0)
  })

  it('ScatterChart regression variant renders trendline', () => {
    const view = renderChart(
      <ScatterChart
        variant="regression"
        data={[{ x: 10, y: 20 }, { x: 20, y: 30 }, { x: 30, y: 45 }]}
      />,
    )

    const trendline = view.querySelector('.rf-scatter-chart__trendline')
    expect(trendline).toBeTruthy()
  })

  it('StackedBarChart percent variant normalizes through percent class', () => {
    const view = renderChart(
      <StackedBarChart
        variant="percent"
        data={[{ label: 'Q1', a: 30, b: 70 }]}
        series={['a', 'b']}
      />,
    )

    const wrapper = view.querySelector('.rf-stacked-bar-chart--percent')
    expect(wrapper).toBeTruthy()
  })

  it('RadarChart threshold variant renders threshold overlay polygon', () => {
    const view = renderChart(
      <RadarChart
        variant="threshold"
        axes={['A', 'B', 'C']}
        data={[{ label: 'Current', values: [6, 7, 8] }]}
        benchmarkSeries={[7, 7, 7]}
      />,
    )

    const threshold = view.querySelector('.rf-radar-chart__threshold')
    expect(threshold).toBeTruthy()
  })

  it('BubbleChart annotated variant renders annotation labels', () => {
    const view = renderChart(
      <BubbleChart
        variant="annotated"
        data={[{ x: 10, y: 20, r: 5, label: 'A' }]}
        annotations={[{ label: 'Hotspot', x: 10, y: 20 }]}
      />,
    )

    const annotation = view.querySelector('.rf-bubble-chart__annotation')
    expect(annotation?.textContent).toBe('Hotspot')
  })
})
