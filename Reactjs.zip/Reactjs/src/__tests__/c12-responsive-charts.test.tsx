import React, { act } from 'react'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { createRoot, type Root } from 'react-dom/client'
import {
  AreaChart,
  BubbleChart,
  DonutChart,
  PieChart,
  RadarChart,
  ScatterChart,
  StackedBarChart,
} from '../index'

describe('C12: Responsive Chart Sizing', () => {
  let root: Root | null = null
  let container: HTMLDivElement | null = null
  const measuredWidth = 560

  beforeEach(() => {
    vi.spyOn(HTMLElement.prototype, 'getBoundingClientRect').mockImplementation(() => {
      return {
        x: 0,
        y: 0,
        top: 0,
        left: 0,
        right: measuredWidth,
        bottom: 360,
        width: measuredWidth,
        height: 360,
        toJSON: () => ({}),
      } as DOMRect
    })
  })

  afterEach(() => {
    if (root) {
      act(() => {
        root?.unmount()
      })
      root = null
    }

    if (container && container.parentNode) {
      container.parentNode.removeChild(container)
      container = null
    }

    vi.restoreAllMocks()
  })

  const renderChart = (element: React.ReactElement) => {
    if (!container) {
      container = document.createElement('div')
      document.body.appendChild(container)
      root = createRoot(container)
    }

    act(() => {
      root?.render(element)
    })

    const svg = container.querySelector('svg')
    expect(svg).toBeTruthy()
    return svg as SVGSVGElement
  }

  it('keeps explicit width when responsive is false', () => {
    const charts: React.ReactElement[] = [
      <PieChart key="pie" data={[{ label: 'A', value: 1 }]} width={400} responsive={false} />,
      <DonutChart key="donut" data={[{ label: 'A', value: 1 }]} width={400} responsive={false} />,
      <AreaChart key="area" data={[{ x: 1, y: 10 }, { x: 2, y: 12 }]} width={400} responsive={false} />,
      <ScatterChart key="scatter" data={[{ x: 1, y: 2 }]} width={400} responsive={false} />,
      <StackedBarChart key="stacked" data={[{ label: 'Q1', a: 3, b: 4 }]} series={['a', 'b']} width={400} responsive={false} />,
      <RadarChart key="radar" axes={['A', 'B', 'C']} data={[{ label: 'Current', values: [2, 3, 4] }]} width={400} responsive={false} />,
      <BubbleChart key="bubble" data={[{ x: 1, y: 2, r: 3 }]} width={400} responsive={false} />,
    ]

    for (const chart of charts) {
      const svg = renderChart(chart)
      expect(svg.getAttribute('width')).toBe('400')
    }
  })

  it('uses measured container width when responsive is true', () => {
    const charts: React.ReactElement[] = [
      <PieChart key="pie" data={[{ label: 'A', value: 1 }]} width={320} responsive />,
      <DonutChart key="donut" data={[{ label: 'A', value: 1 }]} width={320} responsive />,
      <AreaChart key="area" data={[{ x: 1, y: 10 }, { x: 2, y: 12 }]} width={320} responsive />,
      <ScatterChart key="scatter" data={[{ x: 1, y: 2 }]} width={320} responsive />,
      <StackedBarChart key="stacked" data={[{ label: 'Q1', a: 3, b: 4 }]} series={['a', 'b']} width={320} responsive />,
      <RadarChart key="radar" axes={['A', 'B', 'C']} data={[{ label: 'Current', values: [2, 3, 4] }]} width={320} responsive />,
      <BubbleChart key="bubble" data={[{ x: 1, y: 2, r: 3 }]} width={320} responsive />,
    ]

    for (const chart of charts) {
      const svg = renderChart(chart)
      expect(svg.getAttribute('width')).toBe(String(measuredWidth))
    }
  })

  it('uses measured container height for PieChart when responsive is true', () => {
    const svg = renderChart(<PieChart data={[{ label: 'A', value: 1 }]} height={220} responsive />)
    expect(svg.getAttribute('height')).toBe('360')
  })
})
