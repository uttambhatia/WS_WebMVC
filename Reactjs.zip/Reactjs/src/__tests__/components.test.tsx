/**
 * C1.7 — Unit tests for core form & input components
 *
 * Pattern: createRoot + act (consistent with layouts.test.tsx)
 * Environment: jsdom (configured in vite.config.ts)
 */

import React, { act } from 'react'
import { afterEach, describe, expect, it, vi } from 'vitest'
import { createRoot, type Root } from 'react-dom/client'
import { Button } from '../components/core/Button'
import { FormField } from '../components/core/FormField'
import { Input } from '../components/core/Input'
import { Select } from '../components/core/Select'
import { Checkbox } from '../components/core/Checkbox'
import { Radio } from '../components/core/Radio'

;(globalThis as Record<string, unknown>).IS_REACT_ACT_ENVIRONMENT = true

// ─── Helpers ─────────────────────────────────────────────────────────────────

let activeRoot: Root | null = null
let activeContainer: HTMLDivElement | null = null

async function render(ui: React.ReactNode): Promise<HTMLDivElement> {
  const container = document.createElement('div')
  document.body.appendChild(container)
  const root = createRoot(container)
  activeRoot = root
  activeContainer = container

  await act(async () => {
    root.render(ui)
    await Promise.resolve()
  })

  return container
}

afterEach(async () => {
  vi.restoreAllMocks()

  if (activeRoot && activeContainer) {
    await act(async () => {
      activeRoot?.unmount()
    })
    activeContainer.remove()
  }

  activeRoot = null
  activeContainer = null
  document.body.innerHTML = ''
})

// ─── Button ───────────────────────────────────────────────────────────────────

describe('Button', () => {
  it('renders primary variant class by default', async () => {
    const container = await render(<Button>Click me</Button>)
    const btn = container.querySelector('button')!
    expect(btn.className).toContain('rf-btn--primary')
  })

  it('applies secondary variant class', async () => {
    const container = await render(<Button variant="secondary">Click</Button>)
    expect(container.querySelector('button')!.className).toContain('rf-btn--secondary')
  })

  it('applies outline variant class', async () => {
    const container = await render(<Button variant="outline">Click</Button>)
    expect(container.querySelector('button')!.className).toContain('rf-btn--outline')
  })

  it('applies text variant class', async () => {
    const container = await render(<Button variant="text">Click</Button>)
    expect(container.querySelector('button')!.className).toContain('rf-btn--text')
  })

  it('applies sm size class', async () => {
    const container = await render(<Button size="sm">Click</Button>)
    expect(container.querySelector('button')!.className).toContain('rf-btn--sm')
  })

  it('applies lg size class', async () => {
    const container = await render(<Button size="lg">Click</Button>)
    expect(container.querySelector('button')!.className).toContain('rf-btn--lg')
  })

  it('calls onClick when clicked', async () => {
    const handler = vi.fn()
    const container = await render(<Button onClick={handler}>Click</Button>)
    await act(async () => {
      container.querySelector('button')!.click()
    })
    expect(handler).toHaveBeenCalledTimes(1)
  })

  it('does not call onClick when disabled', async () => {
    const handler = vi.fn()
    const container = await render(<Button disabled onClick={handler}>Click</Button>)
    await act(async () => {
      container.querySelector('button')!.click()
    })
    expect(handler).not.toHaveBeenCalled()
  })

  it('sets aria-busy="true" when loading', async () => {
    const container = await render(<Button loading>Loading</Button>)
    expect(container.querySelector('button')!.getAttribute('aria-busy')).toBe('true')
  })

  it('does not set aria-busy when not loading', async () => {
    const container = await render(<Button>Click</Button>)
    expect(container.querySelector('button')!.getAttribute('aria-busy')).toBeNull()
  })

  it('renders spinner element when loading', async () => {
    const container = await render(<Button loading>Loading</Button>)
    expect(container.querySelector('.rf-btn__spinner')).not.toBeNull()
  })

  it('does not render spinner when not loading', async () => {
    const container = await render(<Button>Click</Button>)
    expect(container.querySelector('.rf-btn__spinner')).toBeNull()
  })

  it('applies rf-btn--loading class when loading', async () => {
    const container = await render(<Button loading>Loading</Button>)
    expect(container.querySelector('button')!.className).toContain('rf-btn--loading')
  })

  it('native disabled attribute is set when disabled', async () => {
    const container = await render(<Button disabled>Disabled</Button>)
    expect(container.querySelector('button')!.disabled).toBe(true)
  })

  it('spinner element is aria-hidden', async () => {
    const container = await render(<Button loading>Loading</Button>)
    const spinner = container.querySelector('.rf-btn__spinner')!
    expect(spinner.getAttribute('aria-hidden')).toBe('true')
  })

  it('renders children text', async () => {
    const container = await render(<Button>Submit</Button>)
    expect(container.querySelector('button')!.textContent).toContain('Submit')
  })
})

// ─── FormField ────────────────────────────────────────────────────────────────

describe('FormField', () => {
  it('renders a label with correct htmlFor', async () => {
    const container = await render(
      <FormField id="email" label="Email">
        <input id="email" />
      </FormField>,
    )
    const label = container.querySelector('label')!
    expect(label.getAttribute('for')).toBe('email')
  })

  it('renders the label text', async () => {
    const container = await render(
      <FormField id="name" label="Full name">
        <input id="name" />
      </FormField>,
    )
    expect(container.querySelector('label')!.textContent).toContain('Full name')
  })

  it('renders required indicator when required=true', async () => {
    const container = await render(
      <FormField id="name" label="Name" required>
        <input id="name" />
      </FormField>,
    )
    expect(container.querySelector('.rf-form-field__required')).not.toBeNull()
  })

  it('does not render required indicator when required=false', async () => {
    const container = await render(
      <FormField id="name" label="Name">
        <input id="name" />
      </FormField>,
    )
    expect(container.querySelector('.rf-form-field__required')).toBeNull()
  })

  it('renders error span with correct id when error is provided', async () => {
    const container = await render(
      <FormField id="email" label="Email" error="Required">
        <input id="email" />
      </FormField>,
    )
    const errorSpan = container.querySelector('#email-error')!
    expect(errorSpan).not.toBeNull()
    expect(errorSpan.textContent).toBe('Required')
  })

  it('sets role="alert" on the error span', async () => {
    const container = await render(
      <FormField id="email" label="Email" error="Required">
        <input id="email" />
      </FormField>,
    )
    expect(container.querySelector('#email-error')!.getAttribute('role')).toBe('alert')
  })

  it('renders help text span with correct id when helpText is provided', async () => {
    const container = await render(
      <FormField id="email" label="Email" helpText="We never share your email">
        <input id="email" />
      </FormField>,
    )
    const helpSpan = container.querySelector('#email-help')!
    expect(helpSpan).not.toBeNull()
    expect(helpSpan.textContent).toContain("We never share")
  })

  it('does not render help text when error is present (error takes priority)', async () => {
    const container = await render(
      <FormField id="email" label="Email" error="Required" helpText="Hint">
        <input id="email" />
      </FormField>,
    )
    expect(container.querySelector('#email-help')).toBeNull()
    expect(container.querySelector('#email-error')).not.toBeNull()
  })

  it('renders children inside the field', async () => {
    const container = await render(
      <FormField id="x" label="X">
        <input id="x" data-testid="child-input" />
      </FormField>,
    )
    expect(container.querySelector('[data-testid="child-input"]')).not.toBeNull()
  })
})

// ─── Input ────────────────────────────────────────────────────────────────────

describe('Input', () => {
  it('renders an input element', async () => {
    const container = await render(<Input id="name" />)
    expect(container.querySelector('input')).not.toBeNull()
  })

  it('applies default md size class', async () => {
    const container = await render(<Input id="x" />)
    expect(container.querySelector('input')!.className).toContain('rf-input--md')
  })

  it('applies sm size class', async () => {
    const container = await render(<Input id="x" size="sm" />)
    expect(container.querySelector('input')!.className).toContain('rf-input--sm')
  })

  it('applies lg size class', async () => {
    const container = await render(<Input id="x" size="lg" />)
    expect(container.querySelector('input')!.className).toContain('rf-input--lg')
  })

  it('sets aria-invalid="true" when error is truthy', async () => {
    const container = await render(<Input id="x" error="Required" />)
    expect(container.querySelector('input')!.getAttribute('aria-invalid')).toBe('true')
  })

  it('does not set aria-invalid when error is falsy', async () => {
    const container = await render(<Input id="x" />)
    expect(container.querySelector('input')!.getAttribute('aria-invalid')).toBeNull()
  })

  it('applies rf-input--error class when error is truthy', async () => {
    const container = await render(<Input id="x" error />)
    expect(container.querySelector('input')!.className).toContain('rf-input--error')
  })

  it('forwards aria-describedby to the input', async () => {
    const container = await render(<Input id="x" aria-describedby="x-error" />)
    expect(container.querySelector('input')!.getAttribute('aria-describedby')).toBe('x-error')
  })

  it('sets the correct type attribute', async () => {
    const container = await render(<Input id="x" type="email" />)
    expect(container.querySelector('input')!.getAttribute('type')).toBe('email')
  })
})

// ─── Select ───────────────────────────────────────────────────────────────────

describe('Select', () => {
  it('renders a select element', async () => {
    const container = await render(
      <Select id="topic">
        <option value="a">A</option>
      </Select>,
    )
    expect(container.querySelector('select')).not.toBeNull()
  })

  it('applies default md size class', async () => {
    const container = await render(
      <Select id="x"><option value="a">A</option></Select>,
    )
    expect(container.querySelector('select')!.className).toContain('rf-select--md')
  })

  it('sets aria-invalid="true" when error is truthy', async () => {
    const container = await render(
      <Select id="x" error="Required"><option value="">Select</option></Select>,
    )
    expect(container.querySelector('select')!.getAttribute('aria-invalid')).toBe('true')
  })

  it('does not set aria-invalid when error is falsy', async () => {
    const container = await render(
      <Select id="x"><option value="">Select</option></Select>,
    )
    expect(container.querySelector('select')!.getAttribute('aria-invalid')).toBeNull()
  })

  it('applies rf-select--error class when error is truthy', async () => {
    const container = await render(
      <Select id="x" error><option value="">Select</option></Select>,
    )
    expect(container.querySelector('select')!.className).toContain('rf-select--error')
  })

  it('forwards aria-label to the select element', async () => {
    const container = await render(
      <Select id="x" aria-label="Choose topic"><option value="">Select</option></Select>,
    )
    expect(container.querySelector('select')!.getAttribute('aria-label')).toBe('Choose topic')
  })

  it('renders option children', async () => {
    const container = await render(
      <Select id="x">
        <option value="a">Alpha</option>
        <option value="b">Beta</option>
      </Select>,
    )
    expect(container.querySelectorAll('option')).toHaveLength(2)
  })
})

// ─── Checkbox ─────────────────────────────────────────────────────────────────

describe('Checkbox', () => {
  it('renders an input of type checkbox', async () => {
    const container = await render(
      <Checkbox id="cb" label="Accept" checked={false} onChange={() => {}} />,
    )
    expect(container.querySelector('input[type="checkbox"]')).not.toBeNull()
  })

  it('reflects checked prop on the input', async () => {
    const container = await render(
      <Checkbox id="cb" label="Accept" checked={true} onChange={() => {}} />,
    )
    expect((container.querySelector('input') as HTMLInputElement).checked).toBe(true)
  })

  it('calls onChange when label is clicked', async () => {
    const handler = vi.fn()
    const container = await render(
      <Checkbox id="cb" label="Accept" checked={false} onChange={handler} />,
    )
    await act(async () => {
      container.querySelector('label')!.click()
    })
    expect(handler).toHaveBeenCalledTimes(1)
  })

  it('does not fire onChange when disabled', async () => {
    const handler = vi.fn()
    const container = await render(
      <Checkbox id="cb" label="Accept" checked={false} onChange={handler} disabled />,
    )
    await act(async () => {
      container.querySelector('label')!.click()
    })
    expect(handler).not.toHaveBeenCalled()
  })

  it('renders label text', async () => {
    const container = await render(
      <Checkbox id="cb" label="Subscribe" checked={false} onChange={() => {}} />,
    )
    expect(container.querySelector('.rf-checkbox__label')!.textContent).toBe('Subscribe')
  })

  it('applies rf-checkbox--disabled class when disabled', async () => {
    const container = await render(
      <Checkbox id="cb" label="Accept" checked={false} onChange={() => {}} disabled />,
    )
    expect(container.querySelector('label')!.className).toContain('rf-checkbox--disabled')
  })
})

// ─── Radio ────────────────────────────────────────────────────────────────────

describe('Radio', () => {
  it('renders an input of type radio', async () => {
    const container = await render(
      <Radio id="r1" name="pref" value="email" label="Email" checked={false} onChange={() => {}} />,
    )
    expect(container.querySelector('input[type="radio"]')).not.toBeNull()
  })

  it('sets the name attribute', async () => {
    const container = await render(
      <Radio id="r1" name="pref" value="email" label="Email" checked={false} onChange={() => {}} />,
    )
    expect(container.querySelector('input')!.getAttribute('name')).toBe('pref')
  })

  it('sets the value attribute', async () => {
    const container = await render(
      <Radio id="r1" name="pref" value="email" label="Email" checked={false} onChange={() => {}} />,
    )
    expect(container.querySelector('input')!.getAttribute('value')).toBe('email')
  })

  it('reflects checked prop on the input', async () => {
    const container = await render(
      <Radio id="r1" name="pref" value="email" label="Email" checked={true} onChange={() => {}} />,
    )
    expect((container.querySelector('input') as HTMLInputElement).checked).toBe(true)
  })

  it('calls onChange when label is clicked', async () => {
    const handler = vi.fn()
    const container = await render(
      <Radio id="r1" name="pref" value="email" label="Email" checked={false} onChange={handler} />,
    )
    await act(async () => {
      container.querySelector('label')!.click()
    })
    expect(handler).toHaveBeenCalledTimes(1)
  })

  it('does not fire onChange when disabled', async () => {
    const handler = vi.fn()
    const container = await render(
      <Radio id="r1" name="pref" value="email" label="Email" checked={false} onChange={handler} disabled />,
    )
    await act(async () => {
      container.querySelector('label')!.click()
    })
    expect(handler).not.toHaveBeenCalled()
  })

  it('renders label text', async () => {
    const container = await render(
      <Radio id="r1" name="pref" value="email" label="By email" checked={false} onChange={() => {}} />,
    )
    expect(container.querySelector('.rf-radio__label')!.textContent).toBe('By email')
  })

  it('applies rf-radio--disabled class when disabled', async () => {
    const container = await render(
      <Radio id="r1" name="pref" value="email" label="Email" checked={false} onChange={() => {}} disabled />,
    )
    expect(container.querySelector('label')!.className).toContain('rf-radio--disabled')
  })
})
