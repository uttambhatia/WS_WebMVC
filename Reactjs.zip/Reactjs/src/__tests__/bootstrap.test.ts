import { describe, it, expect, beforeEach } from 'vitest'
import React from 'react'
import { createFrameworkRegistry } from '../framework/registry'
import { initializeFramework } from '../framework/bootstrap'
import { corePlugin } from '../framework/core'
import type { FrameworkRegistry, FrameworkPlugin } from '../framework/registry'
import type { FrameworkConfig } from '../framework/bootstrap'

// ─── Helpers ─────────────────────────────────────────────────────────────────

/** Minimal valid route element */
const el = React.createElement('div', null, 'test')

/** Build a config with sensible defaults so individual tests only override what they care about */
function makeConfig(overrides: Partial<FrameworkConfig> = {}): FrameworkConfig {
  return {
    plugins: [corePlugin],
    routes: [{ path: '/', element: el, label: 'Home' }],
    themes: [],
    ...overrides,
  }
}

// ─── Tests ────────────────────────────────────────────────────────────────────

describe('initializeFramework()', () => {
  let registry: FrameworkRegistry

  beforeEach(() => {
    registry = createFrameworkRegistry()
  })

  // ── Plugin execution ────────────────────────────────────────────────────────

  describe('plugin execution', () => {
    it('runs corePlugin and registers built-in layouts and themes', () => {
      initializeFramework(registry, makeConfig({ plugins: [corePlugin] }))

      expect(registry.getLayouts().length).toBeGreaterThan(0)
      expect(registry.getThemes().length).toBeGreaterThan(0)
    })

    it('runs plugins in provided order', () => {
      const order: number[] = []
      const p1: FrameworkPlugin = () => { order.push(1) }
      const p2: FrameworkPlugin = () => { order.push(2) }
      const p3: FrameworkPlugin = () => { order.push(3) }

      initializeFramework(registry, makeConfig({ plugins: [p1, p2, p3] }))

      expect(order).toEqual([1, 2, 3])
    })

    it('catches plugin errors and reports them without throwing', () => {
      const badPlugin: FrameworkPlugin = () => { throw new Error('Plugin crashed') }

      const result = initializeFramework(registry, makeConfig({ plugins: [badPlugin] }))

      expect(result.errors.some(e => e.includes('Plugin failed'))).toBe(true)
      expect(result.errors.some(e => e.includes('Plugin crashed'))).toBe(true)
    })

    it('continues running remaining plugins after one fails', () => {
      const ran: boolean[] = []
      const badPlugin: FrameworkPlugin = () => { throw new Error('oops') }
      const goodPlugin: FrameworkPlugin = () => { ran.push(true) }

      initializeFramework(registry, makeConfig({ plugins: [badPlugin, goodPlugin] }))

      expect(ran).toHaveLength(1)
    })
  })

  // ── Route registration ──────────────────────────────────────────────────────

  describe('route registration', () => {
    it('registers all routes from config', () => {
      initializeFramework(registry, makeConfig({
        routes: [
          { path: '/', element: el, label: 'Home' },
          { path: '/about', element: el, label: 'About' },
          { path: '/reports', element: el, label: 'Reports' },
        ],
      }))

      const paths = registry.getRoutes().map(r => r.path)
      expect(paths).toContain('/')
      expect(paths).toContain('/about')
      expect(paths).toContain('/reports')
    })

    it('returns error for route with empty path', () => {
      const result = initializeFramework(registry, makeConfig({
        routes: [{ path: '', element: el }],
      }))

      expect(result.errors.some(e => e.includes('invalid'))).toBe(true)
    })

    it('returns warning for duplicate route paths', () => {
      const result = initializeFramework(registry, makeConfig({
        routes: [
          { path: '/', element: el },
          { path: '/', element: el },
        ],
      }))

      expect(result.warnings.some(w => w.includes('Duplicate route path'))).toBe(true)
    })
  })

  // ── Theme registration ──────────────────────────────────────────────────────

  describe('theme registration', () => {
    it('registers all themes from config', () => {
      initializeFramework(registry, makeConfig({
        themes: [
          { id: 'dark', label: 'Dark', variables: { '--bg': '#000' } },
          { id: 'light', label: 'Light', variables: { '--bg': '#fff' } },
        ],
      }))

      const ids = registry.getThemes().map(t => t.id)
      expect(ids).toContain('dark')
      expect(ids).toContain('light')
    })

    it('returns warning for theme with no CSS variables', () => {
      const result = initializeFramework(registry, makeConfig({
        themes: [{ id: 'bare', label: 'Bare', variables: {} }],
      }))

      expect(result.warnings.some(w => w.includes('no CSS variables'))).toBe(true)
    })
  })

  // ── Validation ──────────────────────────────────────────────────────────────

  describe('validation', () => {
    it('errors when no layouts are registered', () => {
      const result = initializeFramework(registry, makeConfig({
        plugins: [], // skip corePlugin so no layouts are registered
        routes: [],
        themes: [],
      }))

      expect(result.success).toBe(false)
      expect(result.errors.some(e => e.includes('No layouts registered'))).toBe(true)
    })

    it('warns but does not error when no routes are registered', () => {
      const result = initializeFramework(registry, makeConfig({ routes: [] }))

      expect(result.success).toBe(true)
      expect(result.warnings.some(w => w.includes('No routes registered'))).toBe(true)
    })

    it('warns but does not error when no themes are registered', () => {
      const result = initializeFramework(registry, makeConfig({
        // corePlugin registers themes; use an empty plugin list to get the warning
        plugins: [
          (r) => {
            r.registerLayout({
              id: 'test-layout',
              label: 'Test',
              Component: ({ children }) => children as React.ReactElement,
            })
          },
        ],
        themes: [],
      }))

      expect(result.success).toBe(true)
      expect(result.warnings.some(w => w.includes('No themes registered'))).toBe(true)
    })

    it('all error messages start with [Framework] prefix', () => {
      const result = initializeFramework(registry, makeConfig({
        plugins: [],
        routes: [{ path: '', element: el }],
        themes: [],
      }))

      expect(result.errors.length).toBeGreaterThan(0)
      expect(result.errors.every(e => e.startsWith('[Framework]'))).toBe(true)
    })

    it('all warning messages start with [Framework] prefix', () => {
      const result = initializeFramework(registry, makeConfig({ routes: [] }))

      expect(result.warnings.length).toBeGreaterThan(0)
      expect(result.warnings.every(w => w.startsWith('[Framework]'))).toBe(true)
    })
  })

  // ── Return value ────────────────────────────────────────────────────────────

  describe('return value', () => {
    it('returns success: true for a valid config', () => {
      const result = initializeFramework(registry, makeConfig())

      expect(result.success).toBe(true)
      expect(result.errors).toHaveLength(0)
    })

    it('returns success: false when blocking errors are present', () => {
      const result = initializeFramework(registry, makeConfig({
        plugins: [],
        routes: [],
        themes: [],
      }))

      expect(result.success).toBe(false)
      expect(result.errors.length).toBeGreaterThan(0)
    })

    it('always returns errors and warnings arrays (never undefined)', () => {
      const result = initializeFramework(registry, makeConfig())

      expect(Array.isArray(result.errors)).toBe(true)
      expect(Array.isArray(result.warnings)).toBe(true)
    })
  })

  // ── Integration ─────────────────────────────────────────────────────────────

  describe('integration: full initialization flow', () => {
    it('replicates consumer-app bootstrap pattern successfully', () => {
      const consumerTheme = {
        id: 'consumer-ocean',
        label: 'Ocean',
        description: 'Consumer theme',
        variables: {
          '--spacing-xs': '0.25rem',
          '--spacing-sm': '0.5rem',
          '--spacing-md': '0.75rem',
          '--spacing-lg': '1rem',
          '--spacing-xl': '1.5rem',
          '--font-size-xs': '0.75rem',
          '--font-size-sm': '0.875rem',
          '--font-size-md': '1rem',
          '--font-size-lg': '1.2rem',
          '--font-size-xl': '2rem',
          '--font-weight-regular': '400',
          '--font-weight-medium': '500',
          '--font-weight-semibold': '600',
          '--font-weight-bold': '700',
          '--surface': '#f0f8ff',
          '--border': '#c4dff6',
          '--text': '#0f3554',
          '--muted': '#436a88',
          '--primary-hover': '#d8ecfb',
          '--bg': '#eaf4fb',
          '--brand': '#0b5fa5',
          '--link': '#0b5fa5',
          '--link-hover': '#084a80',
          '--color-primary': '#0b5fa5',
          '--color-secondary': '#0f3554',
          '--color-success': '#117a65',
          '--color-warning': '#9c6b00',
          '--color-error': '#c44536',
          '--radius-sm': '0.25rem',
          '--radius-md': '0.5rem',
          '--radius-lg': '0.9rem',
          '--radius-pill': '999px',
          '--elevation-sm': '0 8px 20px rgba(11, 95, 165, 0.12)',
          '--elevation-md': '0 16px 40px rgba(11, 95, 165, 0.18)',
        },
      }

      const result = initializeFramework(registry, {
        appTitle: 'AI Agent Evals',
        defaultLayoutId: 'sidebar',
        defaultThemeId: 'consumer-ocean',
        plugins: [corePlugin],
        routes: [
          { path: '/', element: el, label: 'Home' },
          { path: '/about', element: el, label: 'About' },
          { path: '/reports', element: el, label: 'Reports' },
        ],
        themes: [consumerTheme],
      })

      expect(result.success).toBe(true)
      expect(result.errors).toHaveLength(0)
      expect(registry.getLayout('sidebar')).toBeDefined()
      expect(registry.getTheme('consumer-ocean')).toBeDefined()
      expect(registry.getRoutes()).toHaveLength(3)
    })
  })
})
