import React from 'react'
import { describe, expect, it, vi, afterEach } from 'vitest'
import {
  buildNavGroups,
  isRouteVisible,
  prepareNavRoutes,
} from '../components/MainNav'
import {
  isValidRoute,
  isValidRouteMetadata,
  type RouteDefinition,
  type RoutePolicyContext,
} from '../framework/registry'

const el = React.createElement('div', null, 'x')

function makeRoute(overrides: Partial<RouteDefinition> = {}): RouteDefinition {
  return {
    path: '/',
    element: el,
    label: 'Home',
    ...overrides,
  }
}

afterEach(() => {
  vi.restoreAllMocks()
})

describe('route metadata guards', () => {
  it('accepts valid metadata', () => {
    expect(
      isValidRouteMetadata({
        icon: 'home',
        group: 'Main',
        visibility: 'authenticated',
        breadcrumb: ['Root', 'Home'],
        permissions: ['route.read'],
        order: 10,
      }),
    ).toBe(true)
  })

  it('rejects invalid metadata with diagnostic', () => {
    const warnSpy = vi.spyOn(console, 'warn').mockImplementation(() => {})

    const valid = isValidRouteMetadata({
      order: Number.POSITIVE_INFINITY,
    })

    expect(valid).toBe(false)
    expect(warnSpy).toHaveBeenCalled()
  })

  it('validates full route shape', () => {
    expect(isValidRoute(makeRoute())).toBe(true)
  })

  it('rejects invalid route path', () => {
    const warnSpy = vi.spyOn(console, 'warn').mockImplementation(() => {})

    const valid = isValidRoute({
      path: '',
      element: el,
      label: 'Bad',
    })

    expect(valid).toBe(false)
    expect(warnSpy).toHaveBeenCalled()
  })
})

describe('route visibility', () => {
  const authContext: RoutePolicyContext = { isAuthenticated: true, roles: ['user'] }
  const adminContext: RoutePolicyContext = { isAuthenticated: true, roles: ['admin'] }

  it('keeps old behavior for routes without metadata', () => {
    expect(isRouteVisible(makeRoute())).toBe(true)
  })

  it('supports authenticated and admin visibility modes', () => {
    expect(isRouteVisible(makeRoute({ visibility: 'authenticated' }), undefined, authContext)).toBe(true)
    expect(isRouteVisible(makeRoute({ visibility: 'authenticated' }), undefined, {})).toBe(false)

    expect(isRouteVisible(makeRoute({ visibility: 'admin' }), undefined, adminContext)).toBe(true)
    expect(isRouteVisible(makeRoute({ visibility: 'admin' }), undefined, authContext)).toBe(false)
  })

  it('supports predicate visibility', () => {
    const route = makeRoute({
      visibility: (ctx) => Boolean(ctx.featureFlags?.betaNav),
    })

    expect(isRouteVisible(route, undefined, { featureFlags: { betaNav: true } })).toBe(true)
    expect(isRouteVisible(route, undefined, { featureFlags: { betaNav: false } })).toBe(false)
  })

  it('uses routePolicy as authoritative when provided', () => {
    const route = makeRoute({ visibility: 'always' })
    const routePolicy = vi.fn(() => false)

    expect(isRouteVisible(route, routePolicy, authContext)).toBe(false)
    expect(routePolicy).toHaveBeenCalledTimes(1)
  })
})

describe('navigation ordering and grouping', () => {
  it('orders ranked routes first and leaves unranked routes last', () => {
    const prepared = prepareNavRoutes([
      makeRoute({ path: '/zeta', label: 'Zeta' }),
      makeRoute({ path: '/alpha', label: 'Alpha', order: 20 }),
      makeRoute({ path: '/beta', label: 'Beta', order: 10 }),
      makeRoute({ path: '/gamma', label: 'Gamma' }),
    ])

    expect(prepared.map((route) => route.path)).toEqual(['/beta', '/alpha', '/gamma', '/zeta'])
  })

  it('filters hidden routes and keeps labeled routes only', () => {
    const prepared = prepareNavRoutes([
      makeRoute({ path: '/public', label: 'Public', visibility: 'always' }),
      makeRoute({ path: '/auth', label: 'Auth', visibility: 'authenticated' }),
      makeRoute({ path: '/nolabel', label: undefined }),
    ])

    expect(prepared.map((route) => route.path)).toEqual(['/public'])
  })

  it('builds groups with stable order', () => {
    const groups = buildNavGroups([
      makeRoute({ path: '/a', label: 'A', group: 'General' }),
      makeRoute({ path: '/b', label: 'B' }),
      makeRoute({ path: '/c', label: 'C', group: 'Admin' }),
    ])

    expect(groups.map((group) => group.key)).toEqual(['General', '__ungrouped__', 'Admin'])
    expect(groups[0].routes[0].path).toBe('/a')
    expect(groups[1].routes[0].path).toBe('/b')
    expect(groups[2].routes[0].path).toBe('/c')
  })

  it('retains icon metadata for rendering', () => {
    const prepared = prepareNavRoutes([
      makeRoute({ path: '/ops', label: 'Ops', icon: 'shield' }),
    ])

    expect(prepared[0].icon).toBe('shield')
  })
})
