import React, { act } from 'react'
import { afterEach, describe, expect, it, vi } from 'vitest'
import { createRoot, type Root } from 'react-dom/client'
import { Combobox } from '../components/core/Combobox'
import { DateRangePicker } from '../components/core/DateRangePicker'
import { DateTimePicker } from '../components/core/DateTimePicker'
import { Drawer, DrawerBody, DrawerFooter, DrawerHeader } from '../components/core/Drawer'
import { ContextMenu } from '../components/core/ContextMenu'
import { FilterBuilder, type FilterCondition } from '../components/core/FilterBuilder'
import { DataGrid } from '../components/core/DataGrid'

;(globalThis as Record<string, unknown>).IS_REACT_ACT_ENVIRONMENT = true

let activeRoot: Root | null = null
let activeContainer: HTMLDivElement | null = null

async function render(ui: React.ReactNode): Promise<HTMLDivElement> {
  const container = document.createElement('div')
  document.body.appendChild(container)

  const root = createRoot(container)
  activeRoot = root
  activeContainer = container

  await act(async () => {
    root.render(ui)
    await Promise.resolve()
  })

  return container
}

afterEach(async () => {
  vi.restoreAllMocks()

  if (activeRoot && activeContainer) {
    await act(async () => {
      activeRoot?.unmount()
    })
    activeContainer.remove()
  }

  activeRoot = null
  activeContainer = null
  document.body.innerHTML = ''
})

describe('Combobox', () => {
  it('opens options and selects value', async () => {
    const onChange = vi.fn()

    const container = await render(
      <Combobox
        options={[
          { value: 'alpha', label: 'Alpha' },
          { value: 'beta', label: 'Beta' },
        ]}
        onChange={onChange}
      />,
    )

    const input = container.querySelector('.rf-combobox__input') as HTMLInputElement

    await act(async () => {
      input.focus()
    })

    const options = container.querySelectorAll('.rf-combobox__option')
    expect(options).toHaveLength(2)

    await act(async () => {
      (options[1] as HTMLButtonElement).click()
    })

    expect(onChange).toHaveBeenCalledWith('beta')
  })
})

describe('DateRangePicker', () => {
  it('renders start and end date inputs with labels', async () => {
    const onChange = vi.fn()

    const container = await render(
      <DateRangePicker
        value={{ startDate: '2026-03-01', endDate: '2026-03-31' }}
        onChange={onChange}
        id="range"
      />,
    )

    const start = container.querySelector('#range-start') as HTMLInputElement
    const end = container.querySelector('#range-end') as HTMLInputElement

    expect(start.value).toBe('2026-03-01')
    expect(end.value).toBe('2026-03-31')
    expect(container.querySelector('.rf-date-range__legend')?.textContent).toContain('Date range')
  })
})

describe('DateTimePicker', () => {
  it('renders datetime-local input and error semantics', async () => {
    const container = await render(
      <DateTimePicker value="2026-03-14T10:30" error />,
    )

    const input = container.querySelector('input[type="datetime-local"]') as HTMLInputElement
    expect(input).not.toBeNull()
    expect(input.className).toContain('rf-datetime-picker--error')
    expect(input.getAttribute('aria-invalid')).toBe('true')
  })
})

describe('Drawer', () => {
  it('renders open drawer and closes on escape', async () => {
    const onClose = vi.fn()

    await render(
      <Drawer open title="Filters" onClose={onClose}>
        <p>Drawer body</p>
      </Drawer>,
    )

    const dialog = document.querySelector('[role="dialog"]')
    expect(dialog).not.toBeNull()

    await act(async () => {
      document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }))
    })

    expect(onClose).toHaveBeenCalledTimes(1)
  })

  it('supports composable sections via DrawerHeader/Body/Footer', async () => {
    const onClose = vi.fn()

    await render(
      <Drawer open onClose={onClose} composable>
        <DrawerHeader title="Composable" actions={<button type="button">A</button>} />
        <DrawerBody>
          <p>Custom body</p>
        </DrawerBody>
        <DrawerFooter>
          <button type="button">Done</button>
        </DrawerFooter>
      </Drawer>,
    )

    expect(document.querySelector('.rf-drawer__header')).not.toBeNull()
    expect(document.querySelector('.rf-drawer__body')?.textContent).toContain('Custom body')
    expect(document.querySelector('.rf-drawer__footer')).not.toBeNull()
  })
})

describe('DataGrid advanced', () => {
  it('applies global filtering and renders empty-state when no matches', async () => {
    const container = await render(
      <DataGrid
        columns={[
          { key: 'name', header: 'Name', sortable: true },
          { key: 'status', header: 'Status' },
        ]}
        rows={[
          { id: '1', name: 'Alpha', status: 'Healthy' },
          { id: '2', name: 'Beta', status: 'Warning' },
        ]}
        page={1}
        pageSize={10}
        globalFilter="zzz"
        emptyState="No rows in filter"
      />,
    )

    expect(container.querySelector('.rf-data-grid__empty')?.textContent).toContain('No rows in filter')
  })

  it('pins requested columns and emits visible rows callback', async () => {
    const onVisibleRowsChange = vi.fn()

    const container = await render(
      <DataGrid
        columns={[
          { key: 'name', header: 'Name', sortable: true },
          { key: 'status', header: 'Status' },
        ]}
        rows={[
          { id: '1', name: 'Alpha', status: 'Healthy' },
          { id: '2', name: 'Beta', status: 'Warning' },
          { id: '3', name: 'Gamma', status: 'Healthy' },
        ]}
        page={1}
        pageSize={2}
        pinnedColumnKeys={['name']}
        onVisibleRowsChange={onVisibleRowsChange}
      />,
    )

    const firstHeader = container.querySelector('th.rf-table__cell--pinned-left')
    expect(firstHeader).not.toBeNull()
    expect(onVisibleRowsChange).toHaveBeenCalled()
  })
})

describe('ContextMenu', () => {
  it('opens on right click and triggers selection', async () => {
    const onSelect = vi.fn()

    const container = await render(
      <ContextMenu
        items={[{ id: 'open', label: 'Open', onSelect }]}
      >
        <div data-testid="target">Target</div>
      </ContextMenu>,
    )

    const target = container.querySelector('[data-testid="target"]') as HTMLDivElement

    await act(async () => {
      target.dispatchEvent(new MouseEvent('contextmenu', { bubbles: true, clientX: 40, clientY: 40 }))
    })

    const item = document.querySelector('.rf-context-menu__item') as HTMLButtonElement
    expect(item).not.toBeNull()

    await act(async () => {
      item.click()
    })

    expect(onSelect).toHaveBeenCalledTimes(1)
  })
})

describe('FilterBuilder', () => {
  it('adds and removes filter conditions', async () => {
    function Wrapper() {
      const [conditions, setConditions] = React.useState<FilterCondition[]>([])

      return (
        <FilterBuilder
          fields={[
            { id: 'name', label: 'Name', type: 'text' },
            { id: 'score', label: 'Score', type: 'number' },
          ]}
          value={conditions}
          onChange={setConditions}
        />
      )
    }

    const container = await render(<Wrapper />)

    const addButton = container.querySelector('.rf-filter-builder__add') as HTMLButtonElement

    await act(async () => {
      addButton.click()
    })

    expect(container.querySelectorAll('.rf-filter-builder__row')).toHaveLength(1)

    const removeButton = container.querySelector('.rf-filter-builder__remove') as HTMLButtonElement

    await act(async () => {
      removeButton.click()
    })

    expect(container.querySelectorAll('.rf-filter-builder__row')).toHaveLength(0)
  })
})
