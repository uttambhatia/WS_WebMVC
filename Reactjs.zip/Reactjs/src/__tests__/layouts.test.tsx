import React, { act, useEffect } from 'react'
import { afterEach, describe, expect, it, vi } from 'vitest'
import { createRoot, type Root } from 'react-dom/client'
import { MemoryRouter } from 'react-router-dom'
import { corePlugin } from '../framework/core'
import { LayoutProvider, LayoutRenderer } from '../framework/provider'
import { createFrameworkRegistry } from '../framework/registry'
import { useLayoutSlot, useSetLayoutSlot } from '../framework/hooks'
import type { FrameworkRegistry, LayoutSlotInjection } from '../framework/registry'

;(globalThis as Record<string, unknown>).IS_REACT_ACT_ENVIRONMENT = true

let activeRoot: Root | null = null
let activeContainer: HTMLDivElement | null = null

function makeRegistry(): FrameworkRegistry {
  const registry = createFrameworkRegistry()
  corePlugin(registry)
  registry.registerRoute({
    path: '/',
    element: <div>Home content</div>,
    label: 'Home',
  })
  return registry
}

function InitialSlotProbe() {
  const slot = useLayoutSlot('footerSlot')
  const SlotComponent = slot?.component

  return SlotComponent ? <SlotComponent /> : <span>missing</span>
}

function RuntimeSlotProbe() {
  const setLayoutSlot = useSetLayoutSlot()
  const slot = useLayoutSlot('footerSlot')
  const SlotComponent = slot?.component

  useEffect(() => {
    function RuntimeFooter() {
      return <div>Runtime footer slot</div>
    }

    setLayoutSlot('footerSlot', RuntimeFooter)
  }, [setLayoutSlot])

  return SlotComponent ? <SlotComponent /> : <span>missing</span>
}

async function renderWithProvider(
  ui: React.ReactNode,
  options?: {
    defaultLayoutId?: string
    initialSlotInjections?: LayoutSlotInjection[]
  },
) {
  const registry = makeRegistry()
  const layoutId = options?.defaultLayoutId ?? 'sidebar'

  window.localStorage.setItem('framework.layoutId', layoutId)
  window.localStorage.removeItem('framework.themeId')

  const container = document.createElement('div')
  document.body.appendChild(container)
  const root = createRoot(container)
  activeRoot = root
  activeContainer = container

  await act(async () => {
    root.render(
      <MemoryRouter initialEntries={['/']}>
        <LayoutProvider
          framework={registry}
          defaultLayoutId={layoutId}
          initialSlotInjections={options?.initialSlotInjections}
        >
          {ui}
        </LayoutProvider>
      </MemoryRouter>,
    )
    await Promise.resolve()
  })

  return { container, registry }
}

afterEach(async () => {
  vi.restoreAllMocks()

  if (activeRoot && activeContainer) {
    await act(async () => {
      activeRoot?.unmount()
    })
    activeContainer.remove()
  }

  activeRoot = null
  activeContainer = null
  document.body.innerHTML = ''
})

describe('layout slot registry', () => {
  it('registers and retrieves layout slot injections', () => {
    const registry = makeRegistry()

    function FooterSlot() {
      return <div>Footer</div>
    }

    registry.registerLayoutSlot({
      layoutId: 'sidebar',
      slotId: 'footerSlot',
      component: FooterSlot,
    })

    expect(registry.getLayoutSlot('sidebar', 'footerSlot')?.component).toBe(FooterSlot)
    expect(registry.getLayoutSlots('sidebar')).toHaveLength(1)
  })

  it('overwrites duplicate slot injections with warning', () => {
    const registry = makeRegistry()
    const warnSpy = vi.spyOn(console, 'warn').mockImplementation(() => {})

    function FirstSlot() {
      return <div>First</div>
    }

    function SecondSlot() {
      return <div>Second</div>
    }

    registry.registerLayoutSlot({ layoutId: 'sidebar', slotId: 'footerSlot', component: FirstSlot })
    registry.registerLayoutSlot({ layoutId: 'sidebar', slotId: 'footerSlot', component: SecondSlot })

    expect(registry.getLayoutSlot('sidebar', 'footerSlot')?.component).toBe(SecondSlot)
    expect(warnSpy).toHaveBeenCalled()
  })
})

describe('layout slot hooks and rendering', () => {
  it('resolves initial slot injections through useLayoutSlot', async () => {
    function InitialFooter() {
      return <div>Initial footer slot</div>
    }

    const { container } = await renderWithProvider(<InitialSlotProbe />, {
      initialSlotInjections: [
        {
          layoutId: 'sidebar',
          slotId: 'footerSlot',
          component: InitialFooter,
        },
      ],
    })

    expect(container.textContent).toContain('Initial footer slot')
  })

  it('supports runtime slot registration via useSetLayoutSlot', async () => {
    const { container } = await renderWithProvider(<RuntimeSlotProbe />)

    expect(container.textContent).toContain('Runtime footer slot')
  })

  it('renders contentBeforeSlot inside SidebarLayout via LayoutRenderer', async () => {
    function ContentBefore() {
      return <div>Injected before content</div>
    }

    const { container } = await renderWithProvider(<LayoutRenderer />, {
      initialSlotInjections: [
        {
          layoutId: 'sidebar',
          slotId: 'contentBeforeSlot',
          component: ContentBefore,
        },
      ],
    })

    expect(container.textContent).toContain('Injected before content')
    expect(container.textContent).toContain('Home content')
  })

  it('falls back gracefully when no slot injection exists', async () => {
    const { container } = await renderWithProvider(<InitialSlotProbe />)

    expect(container.textContent).toContain('missing')
  })

  it('renders focused workspace inspector slot and toggles visibility', async () => {
    function InspectorSlot() {
      return <div>Focused inspector panel</div>
    }

    const { container } = await renderWithProvider(<LayoutRenderer />, {
      defaultLayoutId: 'focused-workspace',
      initialSlotInjections: [
        {
          layoutId: 'focused-workspace',
          slotId: 'inspectorSlot',
          component: InspectorSlot,
        },
      ],
    })

    expect(container.textContent).toContain('Focused inspector panel')

    const toggle = container.querySelector('.rf-focused-layout__inspector-toggle') as HTMLButtonElement | null
    expect(toggle).not.toBeNull()

    await act(async () => {
      toggle?.click()
      await Promise.resolve()
    })

    const inspector = container.querySelector('.rf-focused-layout__inspector') as HTMLElement | null
    expect(inspector?.getAttribute('aria-hidden')).toBe('true')
  })

  it('renders list detail responsive layout and supports pane toggle state', async () => {
    function ListSlot() {
      return <div>List pane content</div>
    }

    const { container } = await renderWithProvider(<LayoutRenderer />, {
      defaultLayoutId: 'list-detail-responsive',
      initialSlotInjections: [
        {
          layoutId: 'list-detail-responsive',
          slotId: 'listSlot',
          component: ListSlot,
        },
      ],
    })

    expect(container.textContent).toContain('List pane content')
    expect(container.textContent).toContain('Home content')

    const buttons = container.querySelectorAll('.rf-list-detail-layout__mobile-toggle button')
    const detailButton = buttons[1] as HTMLButtonElement | undefined

    await act(async () => {
      detailButton?.click()
      await Promise.resolve()
    })

    const body = container.querySelector('.rf-list-detail-layout__body') as HTMLElement | null
    expect(body?.getAttribute('data-mobile-pane')).toBe('detail')
  })

  it('renders adaptive two-pane layout and toggles compact rail mode', async () => {
    function RailSlot() {
      return <div>Rail top content</div>
    }

    const { container } = await renderWithProvider(<LayoutRenderer />, {
      defaultLayoutId: 'adaptive-two-pane',
      initialSlotInjections: [
        {
          layoutId: 'adaptive-two-pane',
          slotId: 'railTopSlot',
          component: RailSlot,
        },
      ],
    })

    expect(container.textContent).toContain('Rail top content')

    const root = container.querySelector('.rf-adaptive-layout') as HTMLElement | null
    expect(root?.classList.contains('is-rail-compact')).toBe(false)

    const toggle = container.querySelector('.rf-adaptive-layout__rail-toggle') as HTMLButtonElement | null
    await act(async () => {
      toggle?.click()
      await Promise.resolve()
    })

    expect(root?.classList.contains('is-rail-compact')).toBe(true)
  })

  it('renders card grid flow layout and toggles density state', async () => {
    const { container } = await renderWithProvider(<LayoutRenderer />, {
      defaultLayoutId: 'card-grid-flow',
    })

    const root = container.querySelector('.rf-card-grid-layout') as HTMLElement | null
    expect(root?.classList.contains('is-comfortable')).toBe(true)

    const toggle = container.querySelector('.rf-card-grid-layout__density-toggle') as HTMLButtonElement | null
    await act(async () => {
      toggle?.click()
      await Promise.resolve()
    })

    expect(root?.classList.contains('is-compact')).toBe(true)
  })

  it('renders step journey layout with progress and actions slots', async () => {
    function ProgressSlot() {
      return <div>Journey progress slot</div>
    }

    function ActionsSlot() {
      return <button type="button">Continue</button>
    }

    const { container } = await renderWithProvider(<LayoutRenderer />, {
      defaultLayoutId: 'step-journey',
      initialSlotInjections: [
        {
          layoutId: 'step-journey',
          slotId: 'progressSlot',
          component: ProgressSlot,
        },
        {
          layoutId: 'step-journey',
          slotId: 'actionsSlot',
          component: ActionsSlot,
        },
      ],
    })

    expect(container.textContent).toContain('Journey progress slot')
    expect(container.textContent).toContain('Continue')
    expect(container.textContent).toContain('Home content')
  })

  it('renders command surface layout and toggles side panel visibility', async () => {
    function CommandSlot() {
      return <div>Command bar slot</div>
    }

    function ResultsSlot() {
      return <div>Results slot content</div>
    }

    function SideSlot() {
      return <div>Side panel content</div>
    }

    const { container } = await renderWithProvider(<LayoutRenderer />, {
      defaultLayoutId: 'command-surface',
      initialSlotInjections: [
        {
          layoutId: 'command-surface',
          slotId: 'commandBarSlot',
          component: CommandSlot,
        },
        {
          layoutId: 'command-surface',
          slotId: 'resultsSlot',
          component: ResultsSlot,
        },
        {
          layoutId: 'command-surface',
          slotId: 'sidePanelSlot',
          component: SideSlot,
        },
      ],
    })

    expect(container.textContent).toContain('Command bar slot')
    expect(container.textContent).toContain('Results slot content')
    expect(container.textContent).toContain('Side panel content')

    const toggle = container.querySelector('.rf-command-layout__side-toggle') as HTMLButtonElement | null
    await act(async () => {
      toggle?.click()
      await Promise.resolve()
    })

    const side = container.querySelector('.rf-command-layout__side') as HTMLElement | null
    expect(side?.getAttribute('aria-hidden')).toBe('true')
  })
})
