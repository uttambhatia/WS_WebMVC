import { describe, expect, it, vi, afterEach } from 'vitest'
import {
  REQUIRED_THEME_TOKENS,
  createFrameworkRegistry,
  validateTheme,
  type ThemeDefinition,
} from '../framework/registry'
import { corePlugin } from '../framework/core'

afterEach(() => {
  vi.restoreAllMocks()
})

describe('theme token validation', () => {
  it('validates a complete theme', () => {
    const theme: ThemeDefinition = {
      id: 'full',
      label: 'Full',
      variables: Object.fromEntries(REQUIRED_THEME_TOKENS.map((token) => [token, 'x'])) as Record<string, string>,
    }

    const result = validateTheme(theme)
    expect(result.valid).toBe(true)
    expect(result.missingTokens).toEqual([])
    expect(result.invalidTokens).toEqual([])
  })

  it('reports missing required tokens', () => {
    const theme: ThemeDefinition = {
      id: 'incomplete',
      label: 'Incomplete',
      variables: {
        '--surface': '#fff',
      },
    }

    const result = validateTheme(theme)
    expect(result.valid).toBe(false)
    expect(result.missingTokens.length).toBeGreaterThan(0)
  })

  it('warns and still registers invalid themes for backward compatibility', () => {
    const warnSpy = vi.spyOn(console, 'warn').mockImplementation(() => {})
    const registry = createFrameworkRegistry()

    registry.registerTheme({
      id: 'legacy',
      label: 'Legacy',
      variables: {
        '--surface': '#fff',
      },
    })

    expect(registry.getTheme('legacy')).toBeTruthy()
    expect(warnSpy).toHaveBeenCalled()
  })

  it('core plugin themes satisfy token contract', () => {
    const registry = createFrameworkRegistry()
    corePlugin(registry)

    for (const theme of registry.getThemes()) {
      const result = validateTheme(theme)
      expect(result.valid).toBe(true)
    }
  })
})
