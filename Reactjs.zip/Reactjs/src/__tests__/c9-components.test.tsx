import { describe, it, expect, vi } from 'vitest'
import React from 'react'
import { createRoot } from 'react-dom/client'
import { act } from 'react'

import { DataGridPro } from '../components/core/DataGridPro'
import { QueryBuilder } from '../components/core/QueryBuilder'
import { RuleBuilder } from '../components/core/RuleBuilder'
import { WorkflowStepper } from '../components/core/WorkflowStepper'
import { SchedulerTimeline } from '../components/core/SchedulerTimeline'
import { RichTextEditor } from '../components/core/RichTextEditor'
import { InlineCommentThreads } from '../components/core/InlineCommentThreads'
import { PresenceAvatars } from '../components/core/PresenceAvatars'
import { ActivityFeed } from '../components/core/ActivityFeed'
import { DiffViewer } from '../components/core/DiffViewer'
import { GlobalSearchPanel } from '../components/core/GlobalSearchPanel'
import { SplitViewWorkbench } from '../components/core/SplitViewWorkbench'
import { InspectorPanel } from '../components/core/InspectorPanel'
import { KeyboardShortcutManager } from '../components/core/KeyboardShortcutManager'
import { AuditTrailViewer } from '../components/core/AuditTrailViewer'
import { PolicyEditor } from '../components/core/PolicyEditor'
import { FieldLevelPermissionMatrix } from '../components/core/FieldLevelPermissionMatrix'
import { DataClassificationBadgeSet } from '../components/core/DataClassificationBadgeSet'
import { ApprovalGate } from '../components/core/ApprovalGate'

const rootByContainer = new WeakMap<HTMLElement, ReturnType<typeof createRoot>>()

function render(element: React.ReactElement): HTMLElement {
  const container = document.createElement('div')
  document.body.appendChild(container)
  const root = createRoot(container)
  rootByContainer.set(container, root)
  act(() => {
    root.render(element)
  })
  return container
}

function cleanup(container: HTMLElement) {
  const root = rootByContainer.get(container)
  if (root) {
    act(() => {
      root.unmount()
    })
    rootByContainer.delete(container)
  }
  document.body.removeChild(container)
}

function setInputValue(input: HTMLInputElement, value: string) {
  const descriptor = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')
  descriptor?.set?.call(input, value)
}

function setTextareaValue(input: HTMLTextAreaElement, value: string) {
  const descriptor = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value')
  descriptor?.set?.call(input, value)
}

describe('DataGridPro', () => {
  it('supports inline edit and emits row updates', () => {
    const onRowsChange = vi.fn()
    const rows = [{ id: '1', name: 'A' }]
    const container = render(
      <DataGridPro
        columns={[{ key: 'name', header: 'Name', editable: true }]}
        rows={rows}
        onRowsChange={onRowsChange}
      />,
    )

    const cell = container.querySelector('tbody td') as HTMLTableCellElement
    act(() => {
      cell.dispatchEvent(new MouseEvent('dblclick', { bubbles: true }))
    })

    const editor = container.querySelector('.rf-data-grid-pro__inline-edit') as HTMLInputElement
    act(() => {
      setInputValue(editor, 'B')
      editor.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true }))
    })

    expect(onRowsChange).toHaveBeenCalled()
    cleanup(container)
  })
})

describe('QueryBuilder', () => {
  it('renders condition editor controls', () => {
    const onChange = vi.fn()
    const container = render(
      <QueryBuilder
        fields={[{ id: 'status', label: 'Status', type: 'text' }]}
        value={{
          id: 'root',
          combinator: 'and',
          conditions: [{ id: 'c1', fieldId: 'status', operator: 'equals', value: 'Open' }],
          groups: [],
        }}
        onChange={onChange}
      />,
    )

    expect(container.querySelectorAll('.rf-query-builder__condition').length).toBe(1)
    cleanup(container)
  })
})

describe('RuleBuilder', () => {
  it('adds action rows', () => {
    const onChange = vi.fn()
    const container = render(
      <RuleBuilder
        fields={[{ id: 'status', label: 'Status', type: 'text' }]}
        value={{
          id: 'r1',
          name: 'Rule A',
          enabled: true,
          when: {
            id: 'root',
            combinator: 'and',
            conditions: [{ id: 'c1', fieldId: 'status', operator: 'equals', value: 'Open' }],
            groups: [],
          },
          then: [],
        }}
        onChange={onChange}
      />,
    )

    const button = container.querySelector('.rf-rule-builder__btn') as HTMLButtonElement
    act(() => button.click())
    expect(onChange).toHaveBeenCalled()
    cleanup(container)
  })
})

describe('WorkflowStepper', () => {
  it('moves to next step via action button', () => {
    const onStepChange = vi.fn()
    const container = render(
      <WorkflowStepper
        steps={[{ id: 'a', label: 'A' }, { id: 'b', label: 'B' }]}
        currentStepId="a"
        onStepChange={onStepChange}
      />,
    )

    const next = container.querySelector('.rf-workflow-stepper__btn--primary') as HTMLButtonElement
    act(() => next.click())
    expect(onStepChange).toHaveBeenCalledWith('b')
    cleanup(container)
  })
})

describe('SchedulerTimeline', () => {
  it('supports keyboard nudging', () => {
    const onItemsChange = vi.fn()
    const container = render(
      <SchedulerTimeline
        resources={[{ id: 'r1', label: 'Room 1' }]}
        items={[{ id: 'i1', resourceId: 'r1', label: 'Task', start: 9, end: 11 }]}
        onItemsChange={onItemsChange}
      />,
    )

    const item = container.querySelector('.rf-scheduler-timeline__item') as HTMLButtonElement
    act(() => {
      item.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowRight', bubbles: true }))
    })

    expect(onItemsChange).toHaveBeenCalled()
    cleanup(container)
  })
})

describe('RichTextEditor', () => {
  it('renders toolbar and editor', () => {
    const onChange = vi.fn()
    const container = render(<RichTextEditor value="" onChange={onChange} />)
    expect(container.querySelector('.rf-rich-text__toolbar')).toBeTruthy()
    cleanup(container)
  })
})

describe('InlineCommentThreads', () => {
  it('adds anchored comments', () => {
    const onAddComment = vi.fn()
    const container = render(
      <InlineCommentThreads
        anchors={[{ id: 'field-a', label: 'Field A' }]}
        comments={[]}
        onAddComment={onAddComment}
      />,
    )

    const textarea = container.querySelector('.rf-inline-threads__textarea') as HTMLTextAreaElement
    const form = container.querySelector('.rf-inline-threads__composer') as HTMLFormElement
    act(() => {
      setTextareaValue(textarea, 'Looks good')
      textarea.dispatchEvent(new Event('input', { bubbles: true }))
      form.dispatchEvent(new Event('submit', { bubbles: true, cancelable: true }))
    })

    expect(onAddComment).toHaveBeenCalled()
    cleanup(container)
  })
})

describe('PresenceAvatars', () => {
  it('renders overflow badge when users exceed maxVisible', () => {
    const container = render(
      <PresenceAvatars
        users={[
          { id: '1', name: 'A One' },
          { id: '2', name: 'B Two' },
          { id: '3', name: 'C Three' },
        ]}
        maxVisible={2}
      />,
    )
    expect(container.textContent).toContain('+1')
    cleanup(container)
  })
})

describe('ActivityFeed', () => {
  it('filters items by actor', () => {
    const container = render(
      <ActivityFeed
        actorFilter="alice"
        items={[
          { id: '1', actor: 'Alice', type: 'update', message: 'Changed policy', createdAt: '2026-03-15T10:00:00.000Z' },
          { id: '2', actor: 'Bob', type: 'create', message: 'Created rule', createdAt: '2026-03-15T10:05:00.000Z' },
        ]}
      />,
    )
    expect(container.textContent).toContain('Changed policy')
    expect(container.textContent).not.toContain('Created rule')
    cleanup(container)
  })
})

describe('DiffViewer', () => {
  it('renders modified rows', () => {
    const container = render(<DiffViewer before={'a\nb'} after={'a\nc'} />)
    expect(container.querySelector('.rf-diff-viewer__row--modified')).toBeTruthy()
    cleanup(container)
  })
})

describe('GlobalSearchPanel', () => {
  it('groups and renders results', () => {
    const onQueryChange = vi.fn()
    const container = render(
      <GlobalSearchPanel
        query=""
        onQueryChange={onQueryChange}
        results={[{ id: '1', title: 'Home', group: 'Routes' }]}
      />,
    )
    expect(container.textContent).toContain('Routes')
    cleanup(container)
  })
})

describe('SplitViewWorkbench', () => {
  it('renders both panes', () => {
    const container = render(<SplitViewWorkbench left={<span id="l">L</span>} right={<span id="r">R</span>} />)
    expect(container.querySelector('#l')).toBeTruthy()
    expect(container.querySelector('#r')).toBeTruthy()
    cleanup(container)
  })
})

describe('InspectorPanel', () => {
  it('renders sections when open', () => {
    const container = render(
      <InspectorPanel
        title="Inspector"
        open
        sections={[{ id: 's1', title: 'Meta', content: <span id="meta">M</span> }]}
      />,
    )
    expect(container.querySelector('#meta')).toBeTruthy()
    cleanup(container)
  })
})

describe('KeyboardShortcutManager', () => {
  it('fires handler for matching key combo', () => {
    const handler = vi.fn()
    const container = render(
      <KeyboardShortcutManager
        shortcuts={[{ id: 'save', keys: 'ctrl+s', description: 'Save', handler }]}
      />,
    )

    act(() => {
      window.dispatchEvent(new KeyboardEvent('keydown', { key: 's', ctrlKey: true, bubbles: true }))
    })

    expect(handler).toHaveBeenCalledTimes(1)
    cleanup(container)
  })
})

describe('AuditTrailViewer', () => {
  it('renders immutable indicator', () => {
    const container = render(
      <AuditTrailViewer
        events={[
          {
            id: 'e1',
            actor: 'Admin',
            action: 'Updated policy',
            entity: 'Policy A',
            timestamp: '2026-03-15T10:00:00.000Z',
            immutable: true,
          },
        ]}
      />,
    )

    expect(container.textContent).toContain('Immutable')
    cleanup(container)
  })
})

describe('PolicyEditor', () => {
  it('adds rules', () => {
    const onChange = vi.fn()
    const container = render(
      <PolicyEditor
        value={[]}
        onChange={onChange}
        availableRoles={['admin']}
        availablePermissions={['read']}
      />,
    )

    const button = container.querySelector('.rf-policy-editor__add') as HTMLButtonElement
    act(() => button.click())
    expect(onChange).toHaveBeenCalled()
    cleanup(container)
  })
})

describe('FieldLevelPermissionMatrix', () => {
  it('toggles a permission cell', () => {
    const onChange = vi.fn()
    const container = render(
      <FieldLevelPermissionMatrix
        roles={['admin']}
        fields={['salary']}
        value={{ admin: { salary: false } }}
        onChange={onChange}
      />,
    )

    const checkbox = container.querySelector('input[type="checkbox"]') as HTMLInputElement
    act(() => checkbox.click())
    expect(onChange).toHaveBeenCalled()
    cleanup(container)
  })
})

describe('DataClassificationBadgeSet', () => {
  it('renders all provided classifications', () => {
    const container = render(<DataClassificationBadgeSet values={['pii', 'confidential']} />)
    expect(container.textContent).toContain('PII')
    expect(container.textContent).toContain('CONFIDENTIAL')
    cleanup(container)
  })
})

describe('ApprovalGate', () => {
  it('approves next pending step', () => {
    const onApprove = vi.fn()
    const container = render(
      <ApprovalGate
        steps={[
          { id: 's1', approver: 'Lead', approvedAt: '2026-03-15T09:00:00.000Z' },
          { id: 's2', approver: 'Director' },
        ]}
        onApprove={onApprove}
      />,
    )

    const button = container.querySelector('.rf-approval-gate__approve') as HTMLButtonElement
    act(() => button.click())
    expect(onApprove).toHaveBeenCalledWith('s2', undefined)
    cleanup(container)
  })
})
