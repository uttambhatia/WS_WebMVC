import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom'
import './index.css'
import App from './App'
import { framework } from './framework/framework'
import { corePlugin } from './framework/core'
import { examplePlugin } from './plugins/example'

// Register core and optional plugins before rendering
corePlugin(framework)
examplePlugin(framework)

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <BrowserRouter>
      <App />
    </BrowserRouter>
  </StrictMode>,
)
