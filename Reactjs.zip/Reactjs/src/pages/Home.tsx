export function Home() {
  return (
    <section>
      <h2>Welcome</h2>
      <p>
        This is the pluggable layout demo. Use the layout switcher to change the main page structure, and open
        <code>/about</code> to see routing supported by the framework.
      </p>
      <p>
        To add a new layout or feature, create a plugin module that registers routes or layouts via the framework
        registry.
      </p>
    </section>
  )
}
