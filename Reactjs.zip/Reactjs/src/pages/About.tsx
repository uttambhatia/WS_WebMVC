export function About() {
  return (
    <section>
      <h2>About</h2>
      <p>
        This is a minimal example of a pluggable React framework. The layout can be swapped at runtime and the choice is
        saved in localStorage.
      </p>
      <p>
        To extend the framework, add a plugin which registers layouts, routes, or UI components. See <code>src/plugins</code>.
      </p>
    </section>
  )
}
