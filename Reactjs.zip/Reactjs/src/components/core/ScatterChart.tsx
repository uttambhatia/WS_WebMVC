import './core.css'
import { useResponsiveChartWidth } from './useResponsiveChartWidth'

export interface ScatterChartDatum {
  x: number
  y: number
  label?: string
  group?: string
}

export interface Quadrant {
  label: string
  color: string
}

export interface ScatterChartProps {
  data: ScatterChartDatum[]
  width?: number
  height?: number
  responsive?: boolean
  variant?: 'basic' | 'categorized' | 'regression' | 'quadrant' | 'density'
  pointColor?: string
  pointRadius?: number
  showLabels?: boolean
  showTrendline?: boolean
  trendline?: boolean
  groups?: string[]
  quadrants?: Quadrant[]
  densityMode?: boolean
  opacityScale?: boolean
  ariaLabel?: string
  className?: string
}

/**
 * ScatterChart renders x/y point data with optional categorical coloring and trend analysis.
 * 
 * @example
 * <ScatterChart
 *   data={[
 *     { x: 10, y: 20, label: 'A' },
 *     { x: 15, y: 25, label: 'B' },
 *   ]}
 *   showLabels
 *   showTrendline
 * />
 */
export function ScatterChart({
  data,
  width = 320,
  height = 240,
  responsive = false,
  variant = 'basic',
  pointColor = 'var(--color-primary)',
  pointRadius = 4,
  showLabels = false,
  showTrendline = false,
  trendline = false,
  groups,
  quadrants = [],
  densityMode = false,
  opacityScale = false,
  ariaLabel = 'Scatter chart',
  className,
}: ScatterChartProps) {
  const { containerRef, width: chartWidth } = useResponsiveChartWidth<HTMLElement>(width, responsive)

  const shouldShowTrendline = showTrendline || trendline || variant === 'regression'
  const shouldShowQuadrants = quadrants.length >= 2 || variant === 'quadrant'
  const shouldUseDensity = densityMode || opacityScale || variant === 'density'
  const shouldUseCategorized = variant === 'categorized' || groups != null

  if (data.length === 0) {
    return (
      <figure className={['rf-scatter-chart', className ?? ''].filter(Boolean).join(' ')} ref={containerRef}>
        <svg role="img" aria-label={ariaLabel} viewBox={`0 0 ${chartWidth} ${height}`} width={chartWidth} height={height} />
      </figure>
    )
  }

  // Find min/max for normalization
  const minX = Math.min(...data.map((d) => d.x), 0)
  const maxX = Math.max(...data.map((d) => d.x), 1)
  const minY = Math.min(...data.map((d) => d.y), 0)
  const maxY = Math.max(...data.map((d) => d.y), 1)
  const rangeX = maxX - minX || 1
  const rangeY = maxY - minY || 1

  const padding = 30
  const innerWidth = chartWidth - padding * 2
  const innerHeight = height - padding * 2

  // Normalize points
  const points = data.map((datum) => {
    const normX = (datum.x - minX) / rangeX
    const normY = (datum.y - minY) / rangeY
    return {
      ...datum,
      px: padding + normX * innerWidth,
      py: padding + (1 - normY) * innerHeight,
    }
  })

  // Calculate trendline if requested
  let trendlinePoints: [number, number] | null = null
  if (shouldShowTrendline && points.length > 1) {
    const n = points.length
    const sumX = points.reduce((sum, p) => sum + (p.x - minX) / rangeX, 0)
    const sumY = points.reduce((sum, p) => sum + (p.y - minY) / rangeY, 0)
    const sumXY = points.reduce((sum, p) => sum + ((p.x - minX) / rangeX) * ((p.y - minY) / rangeY), 0)
    const sumX2 = points.reduce((sum, p) => sum + Math.pow((p.x - minX) / rangeX, 2), 0)

    const slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX)
    const intercept = (sumY - slope * sumX) / n

    const y1 = intercept
    const y2 = slope + intercept
    trendlinePoints = [y1, y2]
  }

  const classes = ['rf-scatter-chart', className ?? ''].filter(Boolean).join(' ')

  // Group colors
  const uniqueGroups = shouldUseCategorized
    ? groups || Array.from(new Set(data.map((d) => d.group || 'default')))
    : ['default']
  const groupColors = uniqueGroups.reduce(
    (acc, group, idx) => {
      acc[group] = `hsl(${(idx / Math.max(uniqueGroups.length, 1)) * 360}, 70%, 60%)`
      return acc
    },
    {} as Record<string, string>
  )

  return (
    <figure className={classes} ref={containerRef}>
      <svg
        role="img"
        aria-label={ariaLabel}
        viewBox={`0 0 ${chartWidth} ${height}`}
        width={chartWidth}
        height={height}
        className="rf-scatter-chart__svg"
      >
        {/* Quadrants */}
        {shouldShowQuadrants && (
          <>
            <line x1={padding + innerWidth / 2} y1={padding} x2={padding + innerWidth / 2} y2={height - padding} stroke="var(--border, #ddd)" strokeWidth="1" strokeDasharray="2,2" />
            <line x1={padding} y1={padding + innerHeight / 2} x2={chartWidth - padding} y2={padding + innerHeight / 2} stroke="var(--border, #ddd)" strokeWidth="1" strokeDasharray="2,2" />
          </>
        )}

        {/* Trendline */}
        {trendlinePoints && (
          <line
            x1={padding}
            y1={padding + trendlinePoints[0] * innerHeight}
            x2={chartWidth - padding}
            y2={padding + trendlinePoints[1] * innerHeight}
            stroke="var(--muted, #999)"
            strokeWidth="2"
            strokeDasharray="4,4"
            className="rf-scatter-chart__trendline"
          />
        )}

        {/* Points */}
        {points.map((point, idx) => {
          const groupKey = point.group || 'default'
          const color = shouldUseCategorized ? groupColors[groupKey] || pointColor : pointColor
          const clusterCount = data.filter(
            (d) => Math.abs(d.x - point.x) <= rangeX * 0.08 && Math.abs(d.y - point.y) <= rangeY * 0.08,
          ).length
          const opacity = shouldUseDensity ? Math.max(0.35, 1 - clusterCount * 0.08) : 1

          return (
            <g key={`point-${idx}`}>
              <circle
                cx={point.px}
                cy={point.py}
                r={pointRadius}
                fill={color}
                opacity={opacity}
                className="rf-scatter-chart__point"
                role="button"
                tabIndex={0}
                aria-label={point.label || `Point (${point.x}, ${point.y})`}
              />
              {showLabels && point.label && (
                <text
                  x={point.px}
                  y={point.py - pointRadius - 4}
                  textAnchor="middle"
                  fontSize="12"
                  fill="var(--text, #000)"
                  className="rf-scatter-chart__label"
                  pointerEvents="none"
                >
                  {point.label}
                </text>
              )}
            </g>
          )
        })}
      </svg>
    </figure>
  )
}
