import './core.css'

export interface TableColumn<T> {
  key: keyof T
  header: React.ReactNode
  sortable?: boolean
  pinned?: 'left' | 'right'
  headerClassName?: string
  cellClassName?: string
  headerStyle?: React.CSSProperties
  cellStyle?: React.CSSProperties
  render?: (value: T[keyof T], row: T, rowIndex: number) => React.ReactNode
}

export interface TableProps<T extends Record<string, unknown>> {
  columns: TableColumn<T>[]
  data: T[]
  rowKey?: (row: T, rowIndex: number) => string
  sortBy?: keyof T
  sortDirection?: 'asc' | 'desc'
  onSortChange?: (key: keyof T, direction: 'asc' | 'desc') => void
  className?: string
}

export function Table<T extends Record<string, unknown>>({
  columns,
  data,
  rowKey,
  sortBy,
  sortDirection = 'asc',
  onSortChange,
  className,
}: TableProps<T>) {
  function toggleSort(key: keyof T) {
    if (!onSortChange) return
    if (sortBy !== key) {
      onSortChange(key, 'asc')
      return
    }
    onSortChange(key, sortDirection === 'asc' ? 'desc' : 'asc')
  }

  return (
    <div className={['rf-table-wrapper', className ?? ''].filter(Boolean).join(' ')}>
      <table className="rf-table">
        <thead>
          <tr>
            {columns.map((column) => {
              const isSorted = sortBy === column.key
              const ariaSort = isSorted
                ? (sortDirection === 'asc' ? 'ascending' : 'descending')
                : 'none'
              return (
                <th
                  key={String(column.key)}
                  className={[
                    column.headerClassName ?? '',
                    column.pinned ? `rf-table__cell--pinned-${column.pinned}` : '',
                  ].filter(Boolean).join(' ')}
                  style={column.headerStyle}
                >
                  {column.sortable ? (
                    <button
                      type="button"
                      className="rf-table__sort"
                      onClick={() => toggleSort(column.key)}
                      aria-sort={ariaSort}
                    >
                      {column.header}
                    </button>
                  ) : (
                    column.header
                  )}
                </th>
              )
            })}
          </tr>
        </thead>
        <tbody>
          {data.map((row, rowIndex) => (
            <tr key={rowKey ? rowKey(row, rowIndex) : String(rowIndex)}>
              {columns.map((column) => {
                const value = row[column.key]
                return (
                    <td
                      key={String(column.key)}
                      className={[
                        column.cellClassName ?? '',
                        column.pinned ? `rf-table__cell--pinned-${column.pinned}` : '',
                      ].filter(Boolean).join(' ')}
                      style={column.cellStyle}
                    >
                    {column.render ? column.render(value, row, rowIndex) : String(value ?? '')}
                  </td>
                )
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
