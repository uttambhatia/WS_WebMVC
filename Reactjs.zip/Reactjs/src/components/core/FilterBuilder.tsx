import './core.css'

export type FilterOperator = 'equals' | 'contains' | 'gt' | 'lt'

export interface FilterField {
  id: string
  label: string
  type?: 'text' | 'number' | 'date'
}

export interface FilterCondition {
  id: string
  fieldId: string
  operator: FilterOperator
  value: string
}

export interface FilterBuilderProps {
  fields: FilterField[]
  value: FilterCondition[]
  onChange: (conditions: FilterCondition[]) => void
  className?: string
}

const OPERATORS: Array<{ value: FilterOperator; label: string }> = [
  { value: 'equals', label: 'Equals' },
  { value: 'contains', label: 'Contains' },
  { value: 'gt', label: 'Greater than' },
  { value: 'lt', label: 'Less than' },
]

function createCondition(defaultFieldId: string): FilterCondition {
  return {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    fieldId: defaultFieldId,
    operator: 'equals',
    value: '',
  }
}

export function FilterBuilder({
  fields,
  value,
  onChange,
  className,
}: FilterBuilderProps) {
  const firstFieldId = fields[0]?.id ?? ''

  function updateCondition(id: string, patch: Partial<FilterCondition>) {
    onChange(value.map((condition) => (condition.id === id ? { ...condition, ...patch } : condition)))
  }

  function removeCondition(id: string) {
    onChange(value.filter((condition) => condition.id !== id))
  }

  return (
    <div className={['rf-filter-builder', className ?? ''].filter(Boolean).join(' ')}>
      <div className="rf-filter-builder__header">
        <p className="rf-filter-builder__title">Filters</p>
        <button
          type="button"
          className="rf-filter-builder__add"
          onClick={() => onChange([...value, createCondition(firstFieldId)])}
          disabled={!firstFieldId}
        >
          Add filter
        </button>
      </div>

      <div className="rf-filter-builder__rows">
        {value.length === 0 && <p className="rf-filter-builder__empty">No filters configured.</p>}

        {value.map((condition) => {
          const field = fields.find((item) => item.id === condition.fieldId)
          const inputType = field?.type === 'number' || field?.type === 'date' ? field.type : 'text'

          return (
            <div key={condition.id} className="rf-filter-builder__row">
              <select
                className="rf-filter-builder__select"
                value={condition.fieldId}
                onChange={(event) => updateCondition(condition.id, { fieldId: event.currentTarget.value })}
              >
                {fields.map((item) => (
                  <option key={item.id} value={item.id}>{item.label}</option>
                ))}
              </select>

              <select
                className="rf-filter-builder__select"
                value={condition.operator}
                onChange={(event) => updateCondition(condition.id, { operator: event.currentTarget.value as FilterOperator })}
              >
                {OPERATORS.map((operator) => (
                  <option key={operator.value} value={operator.value}>{operator.label}</option>
                ))}
              </select>

              <input
                type={inputType}
                className="rf-filter-builder__input"
                value={condition.value}
                onChange={(event) => updateCondition(condition.id, { value: event.currentTarget.value })}
              />

              <button
                type="button"
                className="rf-filter-builder__remove"
                onClick={() => removeCondition(condition.id)}
              >
                Remove
              </button>
            </div>
          )
        })}
      </div>
    </div>
  )
}
