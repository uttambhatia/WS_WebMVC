import './core.css'
import {
  RichTextEditorField,
  defaultSanitizeRichText,
  type RichTextEditorOutput,
  type RichTextEditorFieldProps,
} from './RichTextEditorField'

export interface RichTextEditorProps {
  value: string
  onChange: (value: string) => void
  output?: RichTextEditorOutput
  disabled?: boolean
  placeholder?: string
  maxLength?: number
  sanitize?: RichTextEditorFieldProps['sanitize']
  className?: string
}

export function RichTextEditor({
  value,
  onChange,
  output = 'html',
  disabled,
  placeholder,
  maxLength,
  sanitize = defaultSanitizeRichText,
  className,
}: RichTextEditorProps) {
  return (
    <RichTextEditorField
      value={value}
      onChange={(next) => onChange(next)}
      output={output}
      disabled={disabled}
      placeholder={placeholder}
      maxLength={maxLength}
      sanitize={sanitize}
      className={['rf-rich-text-editor', className ?? ''].filter(Boolean).join(' ')}
      toolbarPreset="basic"
    />
  )
}
