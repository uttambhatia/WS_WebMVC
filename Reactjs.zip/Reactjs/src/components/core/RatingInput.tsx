import './core.css'
import React from 'react'

export interface RatingInputProps {
  value?: number
  defaultValue?: number
  max?: number
  allowClear?: boolean
  disabled?: boolean
  readOnly?: boolean
  label?: string
  onChange?: (value: number) => void
  className?: string
}

export function RatingInput({
  value,
  defaultValue = 0,
  max = 5,
  allowClear = true,
  disabled = false,
  readOnly = false,
  label = 'Rating',
  onChange,
  className,
}: RatingInputProps) {
  const [internalValue, setInternalValue] = React.useState(defaultValue)
  const selected = value ?? internalValue

  const update = (next: number) => {
    if (disabled || readOnly) {
      return
    }

    const resolved = allowClear && next === selected ? 0 : next
    if (value === undefined) {
      setInternalValue(resolved)
    }
    onChange?.(resolved)
  }

  const onKeyDown = (event: React.KeyboardEvent<HTMLDivElement>) => {
    if (disabled || readOnly) {
      return
    }

    if (event.key === 'ArrowRight' || event.key === 'ArrowUp') {
      event.preventDefault()
      update(Math.min(max, selected + 1))
      return
    }

    if (event.key === 'ArrowLeft' || event.key === 'ArrowDown') {
      event.preventDefault()
      update(Math.max(0, selected - 1))
      return
    }

    if (event.key === 'Home') {
      event.preventDefault()
      update(0)
      return
    }

    if (event.key === 'End') {
      event.preventDefault()
      update(max)
    }
  }

  const classes = [
    'rf-rating-input',
    disabled ? 'rf-rating-input--disabled' : '',
    readOnly ? 'rf-rating-input--readonly' : '',
    className ?? '',
  ].filter(Boolean).join(' ')

  return (
    <div
      className={classes}
      role="slider"
      aria-label={label}
      aria-valuemin={0}
      aria-valuemax={max}
      aria-valuenow={selected}
      tabIndex={disabled ? -1 : 0}
      onKeyDown={onKeyDown}
    >
      {Array.from({ length: max }, (_, index) => {
        const starValue = index + 1
        return (
          <button
            key={starValue}
            type="button"
            className={[
              'rf-rating-input__star',
              starValue <= selected ? 'rf-rating-input__star--active' : '',
            ].filter(Boolean).join(' ')}
            disabled={disabled || readOnly}
            aria-label={`Rate ${starValue} out of ${max}`}
            onClick={() => update(starValue)}
          >
            *
          </button>
        )
      })}
    </div>
  )
}
