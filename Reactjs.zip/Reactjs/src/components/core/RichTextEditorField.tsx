import './core.css'
import React from 'react'

export type RichTextEditorOutput = 'html' | 'text'

export interface RichTextEditorChangeMeta {
  rawValue: string
  output: RichTextEditorOutput
  textLength: number
}

export interface RichTextEditorFieldProps {
  value: string
  onChange: (value: string, meta: RichTextEditorChangeMeta) => void
  sanitize?: (value: string) => string
  output?: RichTextEditorOutput
  disabled?: boolean
  error?: string
  maxLength?: number
  placeholder?: string
  toolbarPreset?: 'basic' | 'none'
  className?: string
  id?: string
  'aria-label'?: string
  'aria-labelledby'?: string
  'aria-describedby'?: string
}

function escapeHtml(value: string): string {
  return value
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;')
}

function extractPlainText(value: string): string {
  if (typeof document === 'undefined') {
    return value.replace(/<[^>]*>/g, '')
  }

  const container = document.createElement('div')
  container.innerHTML = value
  return (container.textContent ?? '').replace(/\s+/g, ' ').trim()
}

function truncateHtmlByTextLength(value: string, maxLength: number): string {
  if (maxLength < 0) return ''

  if (typeof DOMParser === 'undefined' || typeof document === 'undefined') {
    return escapeHtml(extractPlainText(value).slice(0, maxLength))
  }

  const parser = new DOMParser()
  const doc = parser.parseFromString(value, 'text/html')
  const { body } = doc
  let remaining = maxLength

  function truncateNode(node: Node) {
    const children = Array.from(node.childNodes)

    for (const child of children) {
      if (remaining <= 0) {
        child.remove()
        continue
      }

      if (child.nodeType === Node.TEXT_NODE) {
        const text = child.textContent ?? ''
        if (text.length > remaining) {
          child.textContent = text.slice(0, remaining)
          remaining = 0
          continue
        }

        remaining -= text.length
        continue
      }

      truncateNode(child)
    }
  }

  truncateNode(body)
  return body.innerHTML
}

export function defaultSanitizeRichText(value: string): string {
  if (typeof DOMParser === 'undefined' || typeof document === 'undefined') {
    return value
      .replace(/<script[\s\S]*?>[\s\S]*?<\/script>/gi, '')
      .replace(/<style[\s\S]*?>[\s\S]*?<\/style>/gi, '')
      .replace(/ on[a-z]+="[^"]*"/gi, '')
      .replace(/javascript:/gi, '')
  }

  const parser = new DOMParser()
  const doc = parser.parseFromString(value, 'text/html')

  doc.querySelectorAll('script, style, iframe, object, embed').forEach((element) => {
    element.remove()
  })

  doc.querySelectorAll<HTMLElement>('*').forEach((element) => {
    Array.from(element.attributes).forEach((attribute) => {
      const name = attribute.name.toLowerCase()
      const valueText = attribute.value.toLowerCase()

      if (name.startsWith('on')) {
        element.removeAttribute(attribute.name)
        return
      }

      if ((name === 'href' || name === 'src') && valueText.startsWith('javascript:')) {
        element.removeAttribute(attribute.name)
      }
    })
  })

  return doc.body.innerHTML
}

function toEditorMarkup(value: string, output: RichTextEditorOutput): string {
  return output === 'text' ? escapeHtml(value) : value
}

function fromEditorMarkup(value: string, output: RichTextEditorOutput): string {
  if (output === 'text') {
    return extractPlainText(value)
  }

  return value
}

export function RichTextEditorField({
  value,
  onChange,
  sanitize = defaultSanitizeRichText,
  output = 'html',
  disabled = false,
  error,
  maxLength,
  placeholder = 'Enter rich text content',
  toolbarPreset = 'basic',
  className,
  id,
  ...ariaProps
}: RichTextEditorFieldProps) {
  const editorRef = React.useRef<HTMLDivElement | null>(null)
  const [editorValue, setEditorValue] = React.useState(() => toEditorMarkup(value, output))
  const [focused, setFocused] = React.useState(false)

  const textLength = React.useMemo(() => extractPlainText(editorValue).length, [editorValue])
  const limitExceeded = maxLength !== undefined && textLength > maxLength

  React.useEffect(() => {
    const nextMarkup = toEditorMarkup(value, output)
    setEditorValue(nextMarkup)
    if (editorRef.current && document.activeElement !== editorRef.current) {
      editorRef.current.innerHTML = nextMarkup
    }
  }, [output, value])

  function emitChange(rawMarkup: string) {
    const sanitizedMarkup = sanitize(rawMarkup)
    const nextMarkup = maxLength === undefined
      ? sanitizedMarkup
      : truncateHtmlByTextLength(sanitizedMarkup, maxLength)
    const nextValue = fromEditorMarkup(nextMarkup, output)
    const nextTextLength = extractPlainText(nextMarkup).length

    setEditorValue(nextMarkup)

    if (editorRef.current && editorRef.current.innerHTML !== nextMarkup) {
      editorRef.current.innerHTML = nextMarkup
    }

    onChange(nextValue, {
      rawValue: rawMarkup,
      output,
      textLength: nextTextLength,
    })
  }

  function applyFormat(command: 'bold' | 'italic' | 'underline') {
    if (disabled || toolbarPreset === 'none') return

    editorRef.current?.focus()
    if (typeof document !== 'undefined' && typeof document.execCommand === 'function') {
      document.execCommand(command)
    }

    emitChange(editorRef.current?.innerHTML ?? '')
  }

  function handleEditorInput(event: React.FormEvent<HTMLDivElement>) {
    emitChange(event.currentTarget.innerHTML)
  }

  return (
    <div
      className={[
        'rf-rich-text',
        error ? 'rf-rich-text--error' : '',
        disabled ? 'rf-rich-text--disabled' : '',
        focused ? 'rf-rich-text--focused' : '',
        className ?? '',
      ].filter(Boolean).join(' ')}
    >
      {toolbarPreset === 'basic' && (
        <div className="rf-rich-text__toolbar" role="toolbar" aria-label="Rich text formatting">
          <button
            type="button"
            className="rf-rich-text__tool"
            onClick={() => applyFormat('bold')}
            disabled={disabled}
            aria-label="Bold"
          >
            <strong>B</strong>
          </button>
          <button
            type="button"
            className="rf-rich-text__tool"
            onClick={() => applyFormat('italic')}
            disabled={disabled}
            aria-label="Italic"
          >
            <em>I</em>
          </button>
          <button
            type="button"
            className="rf-rich-text__tool"
            onClick={() => applyFormat('underline')}
            disabled={disabled}
            aria-label="Underline"
          >
            <span className="rf-rich-text__underline">U</span>
          </button>
        </div>
      )}

      <div
        id={id}
        ref={editorRef}
        className="rf-rich-text__editor"
        contentEditable={!disabled}
        role="textbox"
        aria-multiline="true"
        aria-invalid={error || limitExceeded ? 'true' : undefined}
        aria-label={ariaProps['aria-label']}
        aria-labelledby={ariaProps['aria-labelledby']}
        aria-describedby={ariaProps['aria-describedby']}
        data-placeholder={placeholder}
        suppressContentEditableWarning
        dangerouslySetInnerHTML={{ __html: editorValue }}
        onInput={handleEditorInput}
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
      />

      <div className="rf-rich-text__meta">
        {maxLength !== undefined && (
          <p className="rf-rich-text__counter" aria-live="polite">
            {textLength} / {maxLength}
          </p>
        )}
        {limitExceeded && (
          <p className="rf-rich-text__limit" role="alert">
            Maximum length reached. Extra content is truncated.
          </p>
        )}
        {error && (
          <p className="rf-rich-text__error" role="alert">
            {error}
          </p>
        )}
      </div>
    </div>
  )
}
