import './core.css'

export interface FieldLevelPermissionMatrixProps {
  roles: string[]
  fields: string[]
  value: Record<string, Record<string, boolean>>
  onChange: (value: Record<string, Record<string, boolean>>) => void
  inheritedFromRole?: Record<string, string>
}

export function FieldLevelPermissionMatrix({
  roles,
  fields,
  value,
  onChange,
  inheritedFromRole,
}: FieldLevelPermissionMatrixProps) {
  return (
    <div className="rf-permission-matrix" role="region" aria-label="Field permissions">
      <table>
        <thead>
          <tr>
            <th>Field</th>
            {roles.map((role) => (
              <th key={role}>
                {role}
                {inheritedFromRole?.[role] ? <small> inherits {inheritedFromRole[role]}</small> : null}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {fields.map((field) => (
            <tr key={field}>
              <th scope="row">{field}</th>
              {roles.map((role) => {
                const checked = Boolean(value[role]?.[field])
                return (
                  <td key={`${field}-${role}`}>
                    <input
                      type="checkbox"
                      checked={checked}
                      onChange={(event) => {
                        const next = {
                          ...value,
                          [role]: {
                            ...(value[role] ?? {}),
                            [field]: event.currentTarget.checked,
                          },
                        }
                        onChange(next)
                      }}
                    />
                  </td>
                )
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
