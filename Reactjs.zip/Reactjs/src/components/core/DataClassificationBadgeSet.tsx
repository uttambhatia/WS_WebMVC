import './core.css'

export type DataClassification = 'public' | 'internal' | 'confidential' | 'pii'

export interface DataClassificationBadgeSetProps {
  values: DataClassification[]
}

export function DataClassificationBadgeSet({ values }: DataClassificationBadgeSetProps) {
  return (
    <div className="rf-classification" aria-label="Data classification badges">
      {values.map((value) => (
        <span key={value} className={`rf-classification__badge rf-classification__badge--${value}`}>
          {value.toUpperCase()}
        </span>
      ))}
    </div>
  )
}
