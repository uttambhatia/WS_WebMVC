import './core.css'
import React from 'react'

export interface AlertProps {
  variant?: 'info' | 'success' | 'warning' | 'error'
  title?: string
  children: React.ReactNode
  dismissible?: boolean
  onDismiss?: () => void
  icon?: React.ReactNode
  className?: string
}

const DEFAULT_ICONS: Record<NonNullable<AlertProps['variant']>, string> = {
  info: 'ℹ',
  success: '✓',
  warning: '⚠',
  error: '✕',
}

export function Alert({
  variant = 'info',
  title,
  children,
  dismissible = false,
  onDismiss,
  icon,
  className,
  ...rest
}: AlertProps & React.HTMLAttributes<HTMLDivElement>) {
  const [dismissed, setDismissed] = React.useState(false)

  if (dismissed) {
    return null
  }

  const role = variant === 'warning' || variant === 'error' ? 'alert' : 'status'
  const resolvedIcon = icon !== undefined ? icon : DEFAULT_ICONS[variant]

  const classes = ['rf-alert', `rf-alert--${variant}`, className].filter(Boolean).join(' ')

  function handleDismiss() {
    onDismiss?.()
    if (!onDismiss) {
      setDismissed(true)
    }
  }

  return (
    <div className={classes} role={role} {...rest}>
      <span className="rf-alert__icon" aria-hidden="true">
        {resolvedIcon}
      </span>
      <div className="rf-alert__content">
        {title && <p className="rf-alert__title">{title}</p>}
        <p className="rf-alert__message">{children}</p>
      </div>
      {dismissible && (
        <button
          type="button"
          className="rf-alert__dismiss"
          aria-label="Dismiss alert"
          onClick={handleDismiss}
        >
          ×
        </button>
      )}
    </div>
  )
}
