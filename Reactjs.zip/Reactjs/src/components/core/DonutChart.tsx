import './core.css'
import { useResponsiveChartWidth } from './useResponsiveChartWidth'

export interface DonutChartDatum {
  label: string
  value: number
}

export interface RingConfig {
  data: DonutChartDatum[]
  innerRadius?: number
}

export interface Threshold {
  value: number
  color: string
  label: string
}

export interface DonutChartProps {
  data: DonutChartDatum[]
  width?: number
  height?: number
  responsive?: boolean
  innerRadius?: number
  variant?: 'basic' | 'kpi' | 'multi-ring' | 'threshold' | 'interactive'
  centerLabel?: React.ReactNode
  centerValue?: string | number
  showLegend?: boolean
  rings?: RingConfig[]
  thresholds?: Threshold[]
  activeSliceId?: string
  onSliceFocus?: (label: string) => void
  ariaLabel?: string
  className?: string
}

/**
 * DonutChart renders a donut/ring chart with optional center content.
 * Supports multi-ring stacked donuts and threshold indicators.
 * 
 * @example
 * <DonutChart
 *   data={[{ label: 'Q1', value: 65 }]}
 *   centerValue="65%"
 *   centerLabel="Complete"
 *   showLegend
 * />
 */
export function DonutChart({
  data,
  width = 320,
  height = 240,
  responsive = false,
  innerRadius,
  variant = 'basic',
  centerLabel,
  centerValue,
  showLegend = true,
  rings,
  thresholds,
  activeSliceId,
  onSliceFocus,
  ariaLabel = 'Donut chart',
  className,
}: DonutChartProps) {
  const { containerRef, width: chartWidth } = useResponsiveChartWidth<HTMLDivElement>(width, responsive)
  const resolvedInnerRadius = innerRadius ?? chartWidth * 0.25
  const total = Math.max(data.reduce((sum, item) => sum + item.value, 0), 1)
  const centerX = chartWidth / 2
  const centerY = height / 2
  const radius = Math.min(chartWidth, height) / 2 - 20

  const makeSliceData = (ringData: DonutChartDatum[]) => {
    const ringTotal = Math.max(ringData.reduce((sum, item) => sum + item.value, 0), 1)
    let currentAngle = -Math.PI / 2
    return ringData.map((item) => {
      const sliceValue = item.value
      const sliceAngle = (sliceValue / ringTotal) * 2 * Math.PI
      const startAngle = currentAngle
      const endAngle = currentAngle + sliceAngle
      currentAngle = endAngle
      return { ...item, startAngle, endAngle, ringTotal }
    })
  }

  const ringConfigs =
    variant === 'multi-ring' && Array.isArray(rings) && rings.length > 0
      ? rings
      : [{ data, innerRadius: resolvedInnerRadius }]

  const classes = ['rf-donut-chart', `rf-donut-chart--${variant}`, className ?? ''].filter(Boolean).join(' ')
  const interactiveMode = variant === 'interactive' || onSliceFocus != null
  const showCenterContent = variant === 'kpi' || centerLabel != null || centerValue != null

  return (
    <div className={classes} ref={containerRef}>
      <svg
        role="img"
        aria-label={ariaLabel}
        viewBox={`0 0 ${chartWidth} ${height}`}
        width={chartWidth}
        height={height}
        className="rf-donut-chart__svg"
      >
        {(variant === 'threshold' || (thresholds && thresholds.length > 0)) && thresholds && thresholds.length > 0 && (
          <circle
            cx={centerX}
            cy={centerY}
            r={radius}
            fill="none"
            stroke={thresholds[0].color}
            strokeWidth="8"
            opacity="0.1"
            className="rf-donut-chart__threshold-bg"
          />
        )}

        {ringConfigs.map((ring, ringIdx) => {
          const sliceData = makeSliceData(ring.data)
          const ringOuterRadius = radius - ringIdx * 18
          const ringInnerRadius = Math.max(
            ring.innerRadius ?? ringOuterRadius - 14,
            Math.max(resolvedInnerRadius - ringIdx * 18, 10),
          )

          return sliceData.map((slice, idx) => {
            const x1 = centerX + ringOuterRadius * Math.cos(slice.startAngle)
            const y1 = centerY + ringOuterRadius * Math.sin(slice.startAngle)
            const x2 = centerX + ringOuterRadius * Math.cos(slice.endAngle)
            const y2 = centerY + ringOuterRadius * Math.sin(slice.endAngle)
            const largeArcFlag = slice.endAngle - slice.startAngle > Math.PI ? 1 : 0

            const innerX1 = centerX + ringInnerRadius * Math.cos(slice.startAngle)
            const innerY1 = centerY + ringInnerRadius * Math.sin(slice.startAngle)
            const innerX2 = centerX + ringInnerRadius * Math.cos(slice.endAngle)
            const innerY2 = centerY + ringInnerRadius * Math.sin(slice.endAngle)

            const pathData = `M ${x1} ${y1} A ${ringOuterRadius} ${ringOuterRadius} 0 ${largeArcFlag} 1 ${x2} ${y2} L ${innerX2} ${innerY2} A ${ringInnerRadius} ${ringInnerRadius} 0 ${largeArcFlag} 0 ${innerX1} ${innerY1} Z`
            const hueStep = ((idx + ringIdx * 2) / Math.max(sliceData.length + ringIdx * 2, 1)) * 360
            const isActive = activeSliceId === slice.label

            return (
              <path
                key={`slice-${ringIdx}-${idx}`}
                className={`rf-donut-chart__slice ${isActive ? 'rf-donut-chart__slice--active' : ''}`}
                d={pathData}
                fill={`hsl(${hueStep}, 70%, 60%)`}
                stroke="var(--surface, #ffffff)"
                strokeWidth="2"
                onMouseEnter={interactiveMode ? () => onSliceFocus?.(slice.label) : undefined}
                onKeyDown={interactiveMode ? (e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    onSliceFocus?.(slice.label)
                  }
                } : undefined}
                role={interactiveMode ? 'button' : undefined}
                tabIndex={interactiveMode ? 0 : undefined}
                aria-label={`${slice.label}: ${slice.value}`}
                style={{ cursor: interactiveMode ? 'pointer' : 'default', opacity: isActive ? 1 : 0.85 }}
              />
            )
          })
        })}

        {showCenterContent && (
          <g className="rf-donut-chart__center">
            {typeof centerValue === 'number' || typeof centerValue === 'string' ? (
              <text
                x={centerX}
                y={centerY - 12}
                textAnchor="middle"
                className="rf-donut-chart__center-value"
                fontSize="24"
                fontWeight="bold"
                fill="var(--text, #000000)"
              >
                {centerValue}
              </text>
            ) : null}
            <text
              x={centerX}
              y={centerY + 12}
              textAnchor="middle"
              className="rf-donut-chart__center-label"
              fontSize="14"
              fill="var(--muted, #666666)"
            >
              {centerLabel}
            </text>
          </g>
        )}
      </svg>

      {showLegend && (
        <div className="rf-donut-chart__legend">
          {data.map((slice, idx) => {
            const percentage = ((slice.value / total) * 100).toFixed(1)
            const hueStep = (idx / Math.max(data.length, 1)) * 360
            return (
              <div key={`legend-${idx}`} className="rf-donut-chart__legend-item">
                <span
                  className="rf-donut-chart__legend-color"
                  style={{ backgroundColor: `hsl(${hueStep}, 70%, 60%)` }}
                />
                <span className="rf-donut-chart__legend-label" title={slice.label}>
                  {slice.label} ({percentage}%)
                </span>
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}
