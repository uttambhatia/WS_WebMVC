import './core.css'
import React from 'react'

export interface CardProps {
  padding?: 'none' | 'sm' | 'md' | 'lg'
  shadow?: 'none' | 'sm' | 'md'
  radius?: 'none' | 'sm' | 'md' | 'lg'
  as?: React.ElementType
  children?: React.ReactNode
  className?: string
}

export function Card({
  padding = 'md',
  shadow = 'sm',
  radius = 'md',
  as: Tag = 'div',
  children,
  className,
  ...rest
}: CardProps & React.HTMLAttributes<HTMLElement>) {
  const classes = [
    'rf-card',
    `rf-card--pad-${padding}`,
    `rf-card--shadow-${shadow}`,
    `rf-card--radius-${radius}`,
    className,
  ]
    .filter(Boolean)
    .join(' ')

  return (
    <Tag className={classes} {...rest}>
      {children}
    </Tag>
  )
}
