import './core.css'
import React from 'react'

export interface TreeNode {
  id: string
  label: React.ReactNode
  children?: TreeNode[]
}

export interface TreeViewProps {
  nodes: TreeNode[]
  defaultExpandedIds?: string[]
  className?: string
}

function TreeItem({
  node,
  expandedIds,
  onToggle,
}: {
  node: TreeNode
  expandedIds: Set<string>
  onToggle: (id: string) => void
}) {
  const hasChildren = Boolean(node.children?.length)
  const expanded = expandedIds.has(node.id)

  return (
    <li role="treeitem" aria-expanded={hasChildren ? (expanded ? 'true' : 'false') : undefined} className="rf-tree__item">
      <div className="rf-tree__row">
        {hasChildren && (
          <button
            type="button"
            className="rf-tree__toggle"
            aria-label={expanded ? 'Collapse node' : 'Expand node'}
            onClick={() => onToggle(node.id)}
          >
            {expanded ? '▾' : '▸'}
          </button>
        )}
        {!hasChildren && <span className="rf-tree__spacer" aria-hidden="true" />}
        <span className="rf-tree__label">{node.label}</span>
      </div>
      {hasChildren && expanded && (
        <ul role="group" className="rf-tree__group">
          {node.children?.map((child) => (
            <TreeItem key={child.id} node={child} expandedIds={expandedIds} onToggle={onToggle} />
          ))}
        </ul>
      )}
    </li>
  )
}

export function TreeView({ nodes, defaultExpandedIds = [], className }: TreeViewProps) {
  const [expandedIds, setExpandedIds] = React.useState<Set<string>>(() => new Set(defaultExpandedIds))

  function onToggle(id: string) {
    setExpandedIds((current) => {
      const next = new Set(current)
      if (next.has(id)) {
        next.delete(id)
      } else {
        next.add(id)
      }
      return next
    })
  }

  return (
    <ul role="tree" className={['rf-tree', className ?? ''].filter(Boolean).join(' ')}>
      {nodes.map((node) => (
        <TreeItem key={node.id} node={node} expandedIds={expandedIds} onToggle={onToggle} />
      ))}
    </ul>
  )
}
