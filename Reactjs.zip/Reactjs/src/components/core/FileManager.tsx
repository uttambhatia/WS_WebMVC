import './core.css'
import React from 'react'

export interface FileManagerItem {
  id: string
  name: string
  size: number
  type?: string
  lastModified?: number
  versionLabel?: string
  metadata?: Record<string, string>
  previewUrl?: string
  file?: File
}

export interface FileManagerProps {
  files?: FileManagerItem[]
  defaultFiles?: FileManagerItem[]
  accept?: string
  multiple?: boolean
  maxFiles?: number
  maxFileSize?: number
  disabled?: boolean
  emptyText?: string
  className?: string
  onUpload?: (files: File[], nextItems: FileManagerItem[]) => void
  onRemove?: (item: FileManagerItem, nextItems: FileManagerItem[]) => void
  onReplace?: (item: FileManagerItem, file: File, nextItems: FileManagerItem[]) => void
  onPreview?: (item: FileManagerItem) => void
  onFilesChange?: (nextItems: FileManagerItem[]) => void
}

function toFileItem(file: File, index: number): FileManagerItem {
  return {
    id: `${file.name}-${file.lastModified}-${index}`,
    name: file.name,
    size: file.size,
    type: file.type,
    lastModified: file.lastModified,
    file,
  }
}

function formatBytes(size: number): string {
  if (size < 1024) return `${size} B`
  if (size < 1024 * 1024) return `${(size / 1024).toFixed(1)} KB`
  return `${(size / (1024 * 1024)).toFixed(1)} MB`
}

function isAcceptedFile(file: File, accept?: string): boolean {
  if (!accept || accept.trim() === '') return true

  const rules = accept
    .split(',')
    .map((item) => item.trim().toLowerCase())
    .filter(Boolean)

  if (rules.length === 0) return true

  const fileName = file.name.toLowerCase()
  const fileType = (file.type || '').toLowerCase()

  return rules.some((rule) => {
    if (rule.startsWith('.')) {
      return fileName.endsWith(rule)
    }

    if (rule.endsWith('/*')) {
      const prefix = rule.slice(0, -1)
      return fileType.startsWith(prefix)
    }

    return fileType === rule
  })
}

export function FileManager({
  files,
  defaultFiles,
  accept,
  multiple = true,
  maxFiles,
  maxFileSize,
  disabled = false,
  emptyText = 'No files uploaded yet.',
  className,
  onUpload,
  onRemove,
  onReplace,
  onPreview,
  onFilesChange,
}: FileManagerProps) {
  const isControlled = files !== undefined
  const [localItems, setLocalItems] = React.useState<FileManagerItem[]>(defaultFiles ?? [])
  const [errors, setErrors] = React.useState<string[]>([])
  const [replaceTargetId, setReplaceTargetId] = React.useState<string | null>(null)

  const uploadInputRef = React.useRef<HTMLInputElement | null>(null)
  const replaceInputRef = React.useRef<HTMLInputElement | null>(null)
  const uploadInputId = React.useId()
  const replaceInputId = React.useId()

  const resolvedItems = isControlled ? files : localItems

  function commitItems(nextItems: FileManagerItem[]) {
    if (!isControlled) {
      setLocalItems(nextItems)
    }
    onFilesChange?.(nextItems)
  }

  function collectValidationErrors(candidates: File[]): { accepted: File[]; messages: string[] } {
    const accepted: File[] = []
    const messages: string[] = []

    candidates.forEach((file) => {
      if (!isAcceptedFile(file, accept)) {
        messages.push(`Unsupported file type: ${file.name}`)
        return
      }

      if (maxFileSize !== undefined && file.size > maxFileSize) {
        messages.push(`File too large: ${file.name}`)
        return
      }

      accepted.push(file)
    })

    return { accepted, messages }
  }

  function handleUploadSelection(fileList: FileList | null) {
    if (!fileList) return

    const selected = Array.from(fileList)
    const { accepted, messages } = collectValidationErrors(selected)
    if (accepted.length === 0) {
      setErrors(messages)
      return
    }

    const incomingItems = accepted.map((file, index) => toFileItem(file, index))

    let nextItems: FileManagerItem[]
    if (multiple) {
      nextItems = [...resolvedItems, ...incomingItems]
    } else {
      nextItems = incomingItems.slice(0, 1)
    }

    if (maxFiles !== undefined && nextItems.length > maxFiles) {
      const dropped = nextItems.length - maxFiles
      messages.push(`${dropped} file(s) were skipped because maxFiles is ${maxFiles}.`)
      nextItems = nextItems.slice(0, maxFiles)
    }

    setErrors(messages)
    commitItems(nextItems)
    onUpload?.(accepted, nextItems)
  }

  function handleRemove(item: FileManagerItem) {
    const nextItems = resolvedItems.filter((candidate) => candidate.id !== item.id)
    commitItems(nextItems)
    onRemove?.(item, nextItems)
  }

  function handleReplaceSelection(fileList: FileList | null) {
    if (!fileList || !replaceTargetId) return

    const target = resolvedItems.find((item) => item.id === replaceTargetId)
    setReplaceTargetId(null)

    if (!target) return

    const nextFile = fileList[0]
    if (!nextFile) return

    const { accepted, messages } = collectValidationErrors([nextFile])
    if (accepted.length === 0) {
      setErrors(messages)
      return
    }

    const replacement = {
      ...toFileItem(accepted[0], 0),
      id: target.id,
      versionLabel: target.versionLabel,
      metadata: target.metadata,
    }

    const nextItems = resolvedItems.map((item) => (item.id === target.id ? replacement : item))

    setErrors(messages)
    commitItems(nextItems)
    onReplace?.(target, accepted[0], nextItems)
  }

  function handlePreview(item: FileManagerItem) {
    if (onPreview) {
      onPreview(item)
      return
    }

    if (item.previewUrl) {
      window.open(item.previewUrl, '_blank', 'noopener')
    }
  }

  return (
    <section className={['rf-file-manager', className ?? ''].filter(Boolean).join(' ')} aria-label="File manager">
      <div className="rf-file-manager__header">
        <button
          type="button"
          className="rf-file-manager__upload"
          disabled={disabled}
          onClick={() => uploadInputRef.current?.click()}
        >
          Upload files
        </button>

        <input
          id={uploadInputId}
          ref={uploadInputRef}
          type="file"
          className="rf-file-manager__input"
          accept={accept}
          multiple={multiple}
          disabled={disabled}
          onChange={(event) => {
            handleUploadSelection(event.currentTarget.files)
            event.currentTarget.value = ''
          }}
        />

        <input
          id={replaceInputId}
          ref={replaceInputRef}
          type="file"
          className="rf-file-manager__input"
          accept={accept}
          disabled={disabled}
          onChange={(event) => {
            handleReplaceSelection(event.currentTarget.files)
            event.currentTarget.value = ''
          }}
        />
      </div>

      {errors.length > 0 && (
        <ul className="rf-file-manager__errors" role="alert" aria-live="polite">
          {errors.map((message, index) => (
            <li key={`${message}-${index}`}>{message}</li>
          ))}
        </ul>
      )}

      {resolvedItems.length === 0 ? (
        <p className="rf-file-manager__empty" role="status">{emptyText}</p>
      ) : (
        <ul className="rf-file-manager__list" aria-label="Uploaded files">
          {resolvedItems.map((item) => (
            <li key={item.id} className="rf-file-manager__item">
              <div className="rf-file-manager__file">
                <p className="rf-file-manager__name">{item.name}</p>
                <p className="rf-file-manager__meta">
                  <span>{formatBytes(item.size)}</span>
                  {item.versionLabel && <span>Version {item.versionLabel}</span>}
                  {item.type && <span>{item.type}</span>}
                </p>

                {item.metadata && Object.keys(item.metadata).length > 0 && (
                  <dl className="rf-file-manager__metadata">
                    {Object.entries(item.metadata).map(([key, value]) => (
                      <div key={key} className="rf-file-manager__metadata-item">
                        <dt>{key}</dt>
                        <dd>{value}</dd>
                      </div>
                    ))}
                  </dl>
                )}
              </div>

              <div className="rf-file-manager__actions">
                {(item.previewUrl || onPreview) && (
                  <button
                    type="button"
                    className="rf-file-manager__action"
                    onClick={() => handlePreview(item)}
                    disabled={disabled}
                  >
                    Preview
                  </button>
                )}
                <button
                  type="button"
                  className="rf-file-manager__action"
                  onClick={() => {
                    setReplaceTargetId(item.id)
                    replaceInputRef.current?.click()
                  }}
                  disabled={disabled}
                >
                  Replace
                </button>
                <button
                  type="button"
                  className="rf-file-manager__action rf-file-manager__action--danger"
                  onClick={() => handleRemove(item)}
                  disabled={disabled}
                >
                  Remove
                </button>
              </div>
            </li>
          ))}
        </ul>
      )}
    </section>
  )
}
