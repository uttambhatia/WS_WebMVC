import './core.css'
import React from 'react'

export interface FormWizardStep {
  id: string
  title: string
  description?: string
  content: React.ReactNode
  validateStep?: () => string | null | undefined
}

export interface FormWizardProps {
  steps: FormWizardStep[]
  currentStepId: string
  onStepChange: (stepId: string) => void
  onSubmit: () => void
  canNavigateToStep?: (targetStepId: string, sourceStepId: string) => boolean
  className?: string
  backLabel?: string
  nextLabel?: string
  submitLabel?: string
}

export function FormWizard({
  steps,
  currentStepId,
  onStepChange,
  onSubmit,
  canNavigateToStep,
  className,
  backLabel = 'Back',
  nextLabel = 'Next',
  submitLabel = 'Submit',
}: FormWizardProps) {
  const currentIndex = steps.findIndex((step) => step.id === currentStepId)
  const safeIndex = currentIndex >= 0 ? currentIndex : 0
  const currentStep = steps[safeIndex]
  const isFirst = safeIndex === 0
  const isLast = safeIndex === steps.length - 1
  const [validationMessage, setValidationMessage] = React.useState<string | null>(null)

  function canNavigate(targetStepId: string): boolean {
    if (!canNavigateToStep || !currentStep) return true
    return canNavigateToStep(targetStepId, currentStep.id)
  }

  function requestStepChange(targetStepId: string) {
    if (!canNavigate(targetStepId)) return
    setValidationMessage(null)
    onStepChange(targetStepId)
  }

  function handleNext() {
    if (!currentStep) return

    const issue = currentStep.validateStep?.()
    if (issue) {
      setValidationMessage(issue)
      return
    }

    const next = steps[safeIndex + 1]
    if (next) {
      requestStepChange(next.id)
    }
  }

  function handleSubmit() {
    if (!currentStep) return

    const issue = currentStep.validateStep?.()
    if (issue) {
      setValidationMessage(issue)
      return
    }

    setValidationMessage(null)
    onSubmit()
  }

  return (
    <section className={['rf-form-wizard', className ?? ''].filter(Boolean).join(' ')}>
      <ol className="rf-form-wizard__steps" aria-label="Form steps">
        {steps.map((step, index) => {
          const active = step.id === currentStep?.id
          const complete = index < safeIndex
          const blocked = !canNavigate(step.id)

          return (
            <li key={step.id} className="rf-form-wizard__step">
              <button
                type="button"
                className={[
                  'rf-form-wizard__step-button',
                  active ? 'rf-form-wizard__step-button--active' : '',
                  complete ? 'rf-form-wizard__step-button--complete' : '',
                ].filter(Boolean).join(' ')}
                aria-current={active ? 'step' : undefined}
                disabled={blocked}
                onClick={() => requestStepChange(step.id)}
              >
                <span className="rf-form-wizard__step-index">{index + 1}</span>
                <span className="rf-form-wizard__step-text">
                  <span className="rf-form-wizard__step-title">{step.title}</span>
                  {step.description && <span className="rf-form-wizard__step-description">{step.description}</span>}
                </span>
              </button>
            </li>
          )
        })}
      </ol>

      <div className="rf-form-wizard__panel">
        <h3 className="rf-form-wizard__panel-title">{currentStep?.title}</h3>
        {currentStep?.description && <p className="rf-form-wizard__panel-description">{currentStep.description}</p>}
        <div className="rf-form-wizard__content">{currentStep?.content}</div>

        {validationMessage && (
          <p className="rf-form-wizard__error" role="alert">
            {validationMessage}
          </p>
        )}

        <div className="rf-form-wizard__actions">
          <button
            type="button"
            className="rf-btn rf-btn--outline rf-btn--md"
            onClick={() => {
              const previous = steps[safeIndex - 1]
              if (previous) {
                requestStepChange(previous.id)
              }
            }}
            disabled={isFirst}
          >
            {backLabel}
          </button>

          {!isLast ? (
            <button type="button" className="rf-btn rf-btn--primary rf-btn--md" onClick={handleNext}>
              {nextLabel}
            </button>
          ) : (
            <button type="button" className="rf-btn rf-btn--primary rf-btn--md" onClick={handleSubmit}>
              {submitLabel}
            </button>
          )}
        </div>
      </div>
    </section>
  )
}
