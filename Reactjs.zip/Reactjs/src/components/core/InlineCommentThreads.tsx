import './core.css'
import React from 'react'

export interface InlineComment {
  id: string
  anchorId: string
  author: string
  message: string
  createdAt: string
}

export interface InlineCommentThreadsProps {
  comments: InlineComment[]
  anchors: Array<{ id: string, label: string }>
  onAddComment?: (comment: InlineComment) => void
}

export function InlineCommentThreads({ comments, anchors, onAddComment }: InlineCommentThreadsProps) {
  const [selectedAnchor, setSelectedAnchor] = React.useState(anchors[0]?.id ?? '')
  const [draft, setDraft] = React.useState('')

  const grouped = React.useMemo(() => {
    const map = new Map<string, InlineComment[]>()
    comments.forEach((comment) => {
      const bucket = map.get(comment.anchorId) ?? []
      bucket.push(comment)
      map.set(comment.anchorId, bucket)
    })
    return map
  }, [comments])

  return (
    <section className="rf-inline-threads">
      <header className="rf-inline-threads__head">
        <select
          className="rf-inline-threads__select"
          value={selectedAnchor}
          onChange={(event) => setSelectedAnchor(event.currentTarget.value)}
          aria-label="Comment anchor"
        >
          {anchors.map((anchor) => <option key={anchor.id} value={anchor.id}>{anchor.label}</option>)}
        </select>
      </header>

      <ul className="rf-inline-threads__list">
        {(grouped.get(selectedAnchor) ?? []).map((comment) => (
          <li key={comment.id} className="rf-inline-threads__item">
            <div className="rf-inline-threads__meta">
              <strong>{comment.author}</strong>
              <time dateTime={comment.createdAt}>{new Date(comment.createdAt).toLocaleString()}</time>
            </div>
            <p>{comment.message}</p>
          </li>
        ))}
      </ul>

      <form
        className="rf-inline-threads__composer"
        onSubmit={(event) => {
          event.preventDefault()
          if (!draft.trim() || !selectedAnchor) return
          onAddComment?.({
            id: crypto.randomUUID(),
            anchorId: selectedAnchor,
            author: 'You',
            message: draft.trim(),
            createdAt: new Date().toISOString(),
          })
          setDraft('')
        }}
      >
        <textarea
          className="rf-inline-threads__textarea"
          value={draft}
          onChange={(event) => setDraft(event.currentTarget.value)}
          placeholder="Add comment"
        />
        <button type="submit" className="rf-inline-threads__submit">Post</button>
      </form>
    </section>
  )
}
