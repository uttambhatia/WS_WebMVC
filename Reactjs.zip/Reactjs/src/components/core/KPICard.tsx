import './core.css'
import React from 'react'
import { SkeletonLoader } from './SkeletonLoader'

export interface KPICardProps {
  title: string
  value: React.ReactNode
  delta?: number
  deltaLabel?: string
  trend?: 'up' | 'down' | 'neutral'
  sparkline?: React.ReactNode
  footer?: React.ReactNode
  loading?: boolean
  className?: string
}

const TREND_ARROWS: Record<NonNullable<KPICardProps['trend']>, string> = {
  up: '↑',
  down: '↓',
  neutral: '→',
}

export function KPICard({
  title,
  value,
  delta,
  deltaLabel,
  trend = 'neutral',
  sparkline,
  footer,
  loading = false,
  className,
}: KPICardProps) {
  const classes = ['rf-kpi-card', className ?? ''].filter(Boolean).join(' ')

  const deltaClasses = [
    'rf-kpi-card__delta',
    `rf-kpi-card__delta--${trend}`,
  ].join(' ')

  return (
    <div className={classes}>
      <p className="rf-kpi-card__title">{title}</p>

      <div className="rf-kpi-card__body">
        <div className="rf-kpi-card__value-row">
          {loading ? (
            <SkeletonLoader variant="text" width="6rem" height="2rem" />
          ) : (
            <span className="rf-kpi-card__value">{value}</span>
          )}

          {(delta !== undefined || deltaLabel) && !loading && (
            <span className={deltaClasses}>
              <span className="rf-kpi-card__trend-arrow" aria-hidden="true">
                {TREND_ARROWS[trend]}
              </span>
              {delta !== undefined && (
                <span className="rf-kpi-card__delta-value">
                  {delta > 0 ? '+' : ''}
                  {delta}%
                </span>
              )}
              {deltaLabel && (
                <span className="rf-kpi-card__delta-label">{deltaLabel}</span>
              )}
            </span>
          )}
          {delta !== undefined && loading && (
            <SkeletonLoader variant="text" width="4rem" height="1rem" />
          )}
        </div>

        {sparkline && (
          <div className="rf-kpi-card__sparkline">
            {sparkline}
          </div>
        )}
      </div>

      {footer && (
        <div className="rf-kpi-card__footer">
          {footer}
        </div>
      )}
    </div>
  )
}
