import './core.css'
import React from 'react'

export interface DockPanel {
  id: string
  title: string
  content: React.ReactNode
  dock?: 'left' | 'right' | 'bottom' | 'center'
  size?: number
  collapsible?: boolean
}

export interface DockLayoutProps {
  panels: DockPanel[]
  className?: string
}

export function DockLayout({ panels, className }: DockLayoutProps) {
  const [collapsed, setCollapsed] = React.useState<Record<string, boolean>>({})

  const left = panels.filter((panel) => panel.dock === 'left')
  const right = panels.filter((panel) => panel.dock === 'right')
  const center = panels.filter((panel) => !panel.dock || panel.dock === 'center')
  const bottom = panels.filter((panel) => panel.dock === 'bottom')

  function renderPanels(items: DockPanel[], region: string) {
    return items.map((panel) => {
      const isCollapsed = Boolean(collapsed[panel.id])
      return (
        <section
          key={panel.id}
          className={[
            'rf-dock-layout__panel',
            isCollapsed ? 'rf-dock-layout__panel--collapsed' : '',
          ].filter(Boolean).join(' ')}
          style={panel.size ? { flexBasis: `${panel.size}px` } : undefined}
        >
          <header className="rf-dock-layout__header">
            <h3 className="rf-dock-layout__title">{panel.title}</h3>
            {panel.collapsible && (
              <button
                type="button"
                className="rf-dock-layout__toggle"
                onClick={() => {
                  setCollapsed((current) => ({
                    ...current,
                    [panel.id]: !current[panel.id],
                  }))
                }}
                aria-label={isCollapsed ? `Expand ${panel.title}` : `Collapse ${panel.title}`}
              >
                {isCollapsed ? 'Expand' : 'Collapse'}
              </button>
            )}
          </header>
          {!isCollapsed && (
            <div className="rf-dock-layout__content" role="region" aria-label={`${panel.title} ${region} panel`}>
              {panel.content}
            </div>
          )}
        </section>
      )
    })
  }

  return (
    <div className={['rf-dock-layout', className ?? ''].filter(Boolean).join(' ')}>
      <div className="rf-dock-layout__main">
        <aside className="rf-dock-layout__rail rf-dock-layout__rail--left">
          {renderPanels(left, 'left')}
        </aside>

        <main className="rf-dock-layout__center">
          {renderPanels(center, 'center')}
        </main>

        <aside className="rf-dock-layout__rail rf-dock-layout__rail--right">
          {renderPanels(right, 'right')}
        </aside>
      </div>

      <footer className="rf-dock-layout__bottom">
        {renderPanels(bottom, 'bottom')}
      </footer>
    </div>
  )
}
