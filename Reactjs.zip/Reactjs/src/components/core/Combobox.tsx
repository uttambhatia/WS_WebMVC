import './core.css'
import React from 'react'

export interface ComboboxOption {
  value: string
  label: string
  keywords?: string[]
  disabled?: boolean
}

export interface ComboboxProps {
  options: ComboboxOption[]
  value?: string
  onChange?: (value: string) => void
  placeholder?: string
  className?: string
  id?: string
  ariaLabel?: string
}

export function Combobox({
  options,
  value,
  onChange,
  placeholder = 'Search...',
  className,
  id,
  ariaLabel,
}: ComboboxProps) {
  const [open, setOpen] = React.useState(false)
  const [query, setQuery] = React.useState('')
  const [activeIndex, setActiveIndex] = React.useState(0)
  const rootRef = React.useRef<HTMLDivElement | null>(null)

  const selectedOption = React.useMemo(
    () => options.find((option) => option.value === value),
    [options, value],
  )

  const filteredOptions = React.useMemo(() => {
    const normalized = query.trim().toLowerCase()
    if (!normalized) return options
    return options.filter((option) => {
      const haystack = [option.label, ...(option.keywords ?? [])].join(' ').toLowerCase()
      return haystack.includes(normalized)
    })
  }, [options, query])

  React.useEffect(() => {
    if (!open) return

    function onPointerDown(event: MouseEvent) {
      const target = event.target as Node
      if (rootRef.current?.contains(target)) return
      setOpen(false)
    }

    function onKeyDown(event: KeyboardEvent) {
      if (event.key === 'Escape') {
        event.preventDefault()
        setOpen(false)
      }
    }

    document.addEventListener('mousedown', onPointerDown)
    document.addEventListener('keydown', onKeyDown)

    return () => {
      document.removeEventListener('mousedown', onPointerDown)
      document.removeEventListener('keydown', onKeyDown)
    }
  }, [open])

  function handleListKeyDown(event: React.KeyboardEvent<HTMLInputElement>) {
    if (!open && (event.key === 'ArrowDown' || event.key === 'ArrowUp')) {
      setOpen(true)
      return
    }

    if (!open || filteredOptions.length === 0) return

    if (event.key === 'ArrowDown') {
      event.preventDefault()
      setActiveIndex((index) => (index + 1) % filteredOptions.length)
    }

    if (event.key === 'ArrowUp') {
      event.preventDefault()
      setActiveIndex((index) => (index - 1 + filteredOptions.length) % filteredOptions.length)
    }

    if (event.key === 'Enter') {
      event.preventDefault()
      const option = filteredOptions[activeIndex]
      if (!option || option.disabled) return
      onChange?.(option.value)
      setQuery('')
      setOpen(false)
    }
  }

  return (
    <div ref={rootRef} className={['rf-combobox', className ?? ''].filter(Boolean).join(' ')}>
      <input
        id={id}
        type="text"
        role="combobox"
        aria-label={ariaLabel}
        aria-expanded={open ? 'true' : 'false'}
        aria-autocomplete="list"
        aria-controls={id ? `${id}-listbox` : undefined}
        className="rf-combobox__input"
        value={open ? query : selectedOption?.label ?? query}
        placeholder={placeholder}
        onFocus={() => {
          setOpen(true)
          setQuery('')
          setActiveIndex(0)
        }}
        onChange={(event) => {
          setOpen(true)
          setQuery(event.currentTarget.value)
          setActiveIndex(0)
        }}
        onKeyDown={handleListKeyDown}
      />
      {open && (
        <ul
          id={id ? `${id}-listbox` : undefined}
          className="rf-combobox__list"
          role="listbox"
        >
          {filteredOptions.length === 0 && (
            <li className="rf-combobox__empty">No options</li>
          )}
          {filteredOptions.map((option, index) => {
            const active = index === activeIndex
            return (
              <li key={option.value} role="option" aria-selected={active ? 'true' : 'false'}>
                <button
                  type="button"
                  className={[
                    'rf-combobox__option',
                    active ? 'rf-combobox__option--active' : '',
                  ].filter(Boolean).join(' ')}
                  disabled={option.disabled}
                  onMouseEnter={() => setActiveIndex(index)}
                  onClick={() => {
                    onChange?.(option.value)
                    setQuery('')
                    setOpen(false)
                  }}
                >
                  {option.label}
                </button>
              </li>
            )
          })}
        </ul>
      )}
    </div>
  )
}
