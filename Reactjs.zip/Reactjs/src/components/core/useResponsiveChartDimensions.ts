import { useEffect, useRef, useState } from 'react'

/**
 * Tracks both width and height from an observed container when responsive mode is enabled.
 * Falls back to provided base dimensions when measurements are unavailable.
 */
export function useResponsiveChartDimensions<T extends HTMLElement>(
  baseWidth: number,
  baseHeight: number,
  responsive: boolean,
) {
  const containerRef = useRef<T | null>(null)
  const [measuredWidth, setMeasuredWidth] = useState(baseWidth)
  const [measuredHeight, setMeasuredHeight] = useState(baseHeight)

  useEffect(() => {
    if (!responsive) {
      setMeasuredWidth(baseWidth)
      setMeasuredHeight(baseHeight)
      return
    }

    const element = containerRef.current
    if (!element) {
      return
    }

    const applySize = (nextWidth: number, nextHeight: number) => {
      if (Number.isFinite(nextWidth) && nextWidth > 0) {
        const roundedWidth = Math.round(nextWidth)
        setMeasuredWidth((current) => (current === roundedWidth ? current : roundedWidth))
      }

      if (Number.isFinite(nextHeight) && nextHeight > 0) {
        const roundedHeight = Math.round(nextHeight)
        setMeasuredHeight((current) => (current === roundedHeight ? current : roundedHeight))
      }
    }

    const initialRect = element.getBoundingClientRect()
    applySize(initialRect.width, initialRect.height)

    if (typeof ResizeObserver === 'undefined') {
      return
    }

    const observer = new ResizeObserver((entries) => {
      for (const entry of entries) {
        applySize(entry.contentRect.width, entry.contentRect.height)
      }
    })

    observer.observe(element)
    return () => observer.disconnect()
  }, [baseHeight, baseWidth, responsive])

  return {
    containerRef,
    width: responsive ? measuredWidth : baseWidth,
    height: responsive ? measuredHeight : baseHeight,
  }
}