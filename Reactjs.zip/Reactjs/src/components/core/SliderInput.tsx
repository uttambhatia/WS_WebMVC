import './core.css'
import React from 'react'

export interface SliderInputProps {
  value?: number | [number, number]
  defaultValue?: number | [number, number]
  min?: number
  max?: number
  step?: number
  dual?: boolean
  showValue?: boolean
  showTicks?: boolean
  disabled?: boolean
  onChange?: (value: number | [number, number]) => void
  error?: boolean | string
  className?: string
  'aria-label'?: string
  'aria-labelledby'?: string
}

function clamp(val: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, val))
}

export function SliderInput({
  value,
  defaultValue,
  min = 0,
  max = 100,
  step = 1,
  dual = false,
  showValue = false,
  showTicks = false,
  disabled = false,
  onChange,
  error,
  className,
  'aria-label': ariaLabel,
  'aria-labelledby': ariaLabelledBy,
}: SliderInputProps) {
  const hasError = Boolean(error)

  // Single mode default
  const singleDefault = typeof defaultValue === 'number' ? defaultValue : min
  const dualDefault: [number, number] = Array.isArray(defaultValue)
    ? defaultValue
    : [min, max]

  const [internalSingle, setInternalSingle] = React.useState<number>(singleDefault)
  const [internalDual, setInternalDual] = React.useState<[number, number]>(dualDefault)

  const singleValue = typeof value === 'number' ? value : internalSingle
  const dualValue: [number, number] = Array.isArray(value) ? value : internalDual

  const wrapperClasses = [
    'rf-slider',
    dual ? 'rf-slider--dual' : '',
    disabled ? 'rf-slider--disabled' : '',
    hasError ? 'rf-slider--error' : '',
    className ?? '',
  ]
    .filter(Boolean)
    .join(' ')

  const fillPct = dual
    ? null
    : ((singleValue - min) / (max - min)) * 100

  const dualFillLeft = dual ? ((dualValue[0] - min) / (max - min)) * 100 : 0
  const dualFillRight = dual ? ((dualValue[1] - min) / (max - min)) * 100 : 100

  function handleSingleChange(event: React.ChangeEvent<HTMLInputElement>) {
    const next = Number(event.currentTarget.value)
    if (value === undefined) setInternalSingle(next)
    onChange?.(next)
  }

  function handleDualStartChange(event: React.ChangeEvent<HTMLInputElement>) {
    const next = clamp(Number(event.currentTarget.value), min, dualValue[1])
    const newPair: [number, number] = [next, dualValue[1]]
    if (!Array.isArray(value)) setInternalDual(newPair)
    onChange?.(newPair)
  }

  function handleDualEndChange(event: React.ChangeEvent<HTMLInputElement>) {
    const next = clamp(Number(event.currentTarget.value), dualValue[0], max)
    const newPair: [number, number] = [dualValue[0], next]
    if (!Array.isArray(value)) setInternalDual(newPair)
    onChange?.(newPair)
  }

  const tickCount = (max - min) / step
  const showTickMarks = showTicks && tickCount <= 20

  return (
    <div className={wrapperClasses}>
      <div className="rf-slider__track-wrapper">
        <div className="rf-slider__track">
          {dual ? (
            <span
              className="rf-slider__fill"
              style={{ left: `${dualFillLeft}%`, right: `${100 - dualFillRight}%` }}
            />
          ) : (
            <span className="rf-slider__fill" style={{ width: `${fillPct}%` }} />
          )}
        </div>
        {dual ? (
          <>
            <input
              type="range"
              className="rf-slider__input rf-slider__input--start"
              min={min}
              max={max}
              step={step}
              value={dualValue[0]}
              disabled={disabled}
              aria-label={ariaLabel ? `${ariaLabel} start` : undefined}
              aria-labelledby={ariaLabelledBy}
              aria-invalid={hasError ? 'true' : undefined}
              onChange={handleDualStartChange}
            />
            <input
              type="range"
              className="rf-slider__input rf-slider__input--end"
              min={min}
              max={max}
              step={step}
              value={dualValue[1]}
              disabled={disabled}
              aria-label={ariaLabel ? `${ariaLabel} end` : undefined}
              aria-labelledby={ariaLabelledBy}
              aria-invalid={hasError ? 'true' : undefined}
              onChange={handleDualEndChange}
            />
          </>
        ) : (
          <input
            type="range"
            className="rf-slider__input"
            min={min}
            max={max}
            step={step}
            value={singleValue}
            disabled={disabled}
            aria-label={ariaLabel}
            aria-labelledby={ariaLabelledBy}
            aria-invalid={hasError ? 'true' : undefined}
            onChange={handleSingleChange}
          />
        )}
      </div>

      {showTickMarks && (
        <div className="rf-slider__ticks" aria-hidden="true">
          {Array.from({ length: tickCount + 1 }, (_, i) => (
            <span key={i} className="rf-slider__tick" />
          ))}
        </div>
      )}

      {showValue && (
        <div className="rf-slider__value" aria-live="polite">
          {dual
            ? `${dualValue[0]} – ${dualValue[1]}`
            : String(singleValue)}
        </div>
      )}
    </div>
  )
}
