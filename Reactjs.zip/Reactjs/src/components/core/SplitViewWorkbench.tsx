import './core.css'
import React from 'react'

export interface SplitViewWorkbenchProps {
  left: React.ReactNode
  right: React.ReactNode
  storageKey?: string
  minLeftPercent?: number
  maxLeftPercent?: number
}

export function SplitViewWorkbench({
  left,
  right,
  storageKey = 'rf.splitViewWorkbench',
  minLeftPercent = 20,
  maxLeftPercent = 80,
}: SplitViewWorkbenchProps) {
  const [leftPercent, setLeftPercent] = React.useState(() => {
    const saved = Number(window.localStorage.getItem(storageKey) ?? '40')
    if (Number.isNaN(saved)) return 40
    return Math.max(minLeftPercent, Math.min(maxLeftPercent, saved))
  })

  React.useEffect(() => {
    window.localStorage.setItem(storageKey, String(leftPercent))
  }, [leftPercent, storageKey])

  return (
    <section className="rf-split-workbench" style={{ gridTemplateColumns: `${leftPercent}% 1fr` }}>
      <div className="rf-split-workbench__pane">{left}</div>
      <div className="rf-split-workbench__divider">
        <input
          type="range"
          min={minLeftPercent}
          max={maxLeftPercent}
          value={leftPercent}
          onChange={(event) => setLeftPercent(Number(event.currentTarget.value))}
          aria-label="Resize split view"
        />
      </div>
      <div className="rf-split-workbench__pane">{right}</div>
    </section>
  )
}
