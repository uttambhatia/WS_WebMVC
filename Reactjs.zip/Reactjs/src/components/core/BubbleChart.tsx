import './core.css'
import { useResponsiveChartWidth } from './useResponsiveChartWidth'

export interface BubbleChartDatum {
  x: number
  y: number
  r: number
  label?: string
  group?: string
  timeStep?: number
}

export interface BubbleAnnotation {
  label: string
  x: number
  y: number
}

export type BubbleChartVariant = 'basic' | 'categorized' | 'timeline' | 'packed' | 'annotated'

export interface BubbleChartProps {
  data: BubbleChartDatum[]
  width?: number
  height?: number
  responsive?: boolean
  bubbleOpacity?: number
  showLabels?: boolean
  groups?: string[]
  variant?: BubbleChartVariant
  timeStep?: number
  packingMode?: boolean
  annotations?: BubbleAnnotation[]
  labelStrategy?: 'all' | 'top-n'
  topN?: number
  ariaLabel?: string
  className?: string
}

/**
 * BubbleChart renders bubbles with x, y position and r (radius) representing a third dimension.
 * 
 * @example
 * <BubbleChart
 *   data={[
 *     { x: 10, y: 20, r: 5, label: 'Item A' },
 *     { x: 15, y: 25, r: 8, label: 'Item B' },
 *   ]}
 *   showLabels
 *   labelStrategy="top-n"
 *   topN={5}
 * />
 */
export function BubbleChart({
  data,
  width = 320,
  height = 240,
  responsive = false,
  bubbleOpacity = 0.7,
  showLabels = false,
  groups,
  variant = 'basic',
  packingMode = false,
  labelStrategy = 'all',
  topN = 5,
  ariaLabel = 'Bubble chart',
  className,
  timeStep,
  annotations,
}: BubbleChartProps) {
  const { containerRef, width: chartWidth } = useResponsiveChartWidth<HTMLElement>(width, responsive)

  if (data.length === 0) {
    return (
      <figure className={['rf-bubble-chart', className ?? ''].filter(Boolean).join(' ')} ref={containerRef}>
        <svg role="img" aria-label={ariaLabel} viewBox={`0 0 ${chartWidth} ${height}`} width={chartWidth} height={height} />
      </figure>
    )
  }

  // Find min/max for normalization
  const timelineData =
    variant === 'timeline' && typeof timeStep === 'number'
      ? data.filter((datum) => datum.timeStep === timeStep)
      : data

  const minX = Math.min(...timelineData.map((d) => d.x), 0)
  const maxX = Math.max(...timelineData.map((d) => d.x), 1)
  const minY = Math.min(...timelineData.map((d) => d.y), 0)
  const maxY = Math.max(...timelineData.map((d) => d.y), 1)
  const minR = Math.min(...timelineData.map((d) => d.r), 1)
  const maxR = Math.max(...timelineData.map((d) => d.r), 1)

  const rangeX = maxX - minX || 1
  const rangeY = maxY - minY || 1
  const rangeR = maxR - minR || 1

  const padding = 40
  const innerWidth = chartWidth - padding * 2
  const innerHeight = height - padding * 2

  // Normalize points
  const points = timelineData.map((datum) => {
    const normX = (datum.x - minX) / rangeX
    const normY = (datum.y - minY) / rangeY
    const normR = ((datum.r - minR) / rangeR) * 20 + 3

    return {
      ...datum,
      px: padding + normX * innerWidth,
      py: padding + (1 - normY) * innerHeight,
      pr: normR,
    }
  })

  // Sort by radius descending for layering
  const sortedPoints = [...points].sort((a, b) => b.pr - a.pr)

  // Determine which labels to show
  const labelsToShow =
    showLabels && labelStrategy === 'top-n'
      ? new Set(sortedPoints.slice(0, topN).map((p) => p.label || ''))
      : showLabels
        ? new Set(sortedPoints.map((p) => p.label || ''))
        : new Set<string>()

  const classes = [
    'rf-bubble-chart',
    `rf-bubble-chart--${variant}`,
    packingMode || variant === 'packed' ? 'rf-bubble-chart--packed' : '',
    className ?? '',
  ]
    .filter(Boolean)
    .join(' ')

  // Group colors
  const uniqueGroups = groups || Array.from(new Set(timelineData.map((d) => d.group || 'default')))
  const groupColors = uniqueGroups.reduce(
    (acc, group, idx) => {
      acc[group] = `hsl(${(idx / Math.max(uniqueGroups.length, 1)) * 360}, 70%, 60%)`
      return acc
    },
    {} as Record<string, string>
  )

  return (
    <figure className={classes} ref={containerRef}>
      <svg
        role="img"
        aria-label={ariaLabel}
        viewBox={`0 0 ${chartWidth} ${height}`}
        width={chartWidth}
        height={height}
        className="rf-bubble-chart__svg"
      >
        {/* Axes */}
        <line
          x1={padding}
          y1={height - padding}
          x2={chartWidth - padding}
          y2={height - padding}
          stroke="var(--border, #ddd)"
          strokeWidth="1"
        />
        <line
          x1={padding}
          y1={padding}
          x2={padding}
          y2={height - padding}
          stroke="var(--border, #ddd)"
          strokeWidth="1"
        />

        {/* Bubbles - render from largest to smallest for proper layering */}
        {sortedPoints.map((point, idx) => {
          const groupKey = point.group || 'default'
          const color = groupColors[groupKey] || 'var(--color-primary)'
          const shouldLabel = labelsToShow.has(point.label || '')

          return (
            <g key={`bubble-${idx}`}>
              <circle
                cx={point.px}
                cy={point.py}
                r={point.pr}
                fill={color}
                opacity={bubbleOpacity}
                stroke="var(--surface, #fff)"
                strokeWidth="1"
                className="rf-bubble-chart__bubble"
                role="button"
                tabIndex={0}
                aria-label={point.label || `Bubble (${point.x}, ${point.y}, ${point.r})`}
              />
              {shouldLabel && point.label && (
                <text
                  x={point.px}
                  y={point.py}
                  textAnchor="middle"
                  dy="0.3em"
                  fontSize="11"
                  fontWeight="500"
                  fill="var(--surface, #fff)"
                  className="rf-bubble-chart__label"
                  pointerEvents="none"
                  style={{
                    textShadow: '0 1px 2px rgba(0,0,0,0.3)',
                  }}
                >
                  {point.label}
                </text>
              )}
            </g>
          )
        })}

        {/* Axis labels */}
        <text x={chartWidth - padding + 10} y={height - padding} fontSize="12" fill="var(--text, #000)" className="rf-bubble-chart__axis-label">
          X: {maxX.toFixed(1)}
        </text>
        <text x={padding - 10} y={padding - 10} fontSize="12" fill="var(--text, #000)" textAnchor="end" className="rf-bubble-chart__axis-label">
          Y: {maxY.toFixed(1)}
        </text>

        {variant === 'annotated' &&
          (annotations ?? []).map((annotation, idx) => {
            const x = padding + ((annotation.x - minX) / rangeX) * innerWidth
            const y = padding + (1 - (annotation.y - minY) / rangeY) * innerHeight
            return (
              <text
                key={`annotation-${idx}`}
                x={x}
                y={y - 8}
                textAnchor="middle"
                fontSize="11"
                fill="var(--text, #000)"
                className="rf-bubble-chart__annotation"
              >
                {annotation.label}
              </text>
            )
          })}
      </svg>

      {variant !== 'basic' && uniqueGroups.length > 1 && (
        <div className="rf-bubble-chart__legend">
          {uniqueGroups.map((group, idx) => (
            <div key={`legend-${idx}`} className="rf-bubble-chart__legend-item">
              <span
                className="rf-bubble-chart__legend-color"
                style={{ backgroundColor: groupColors[group] }}
              />
              <span className="rf-bubble-chart__legend-label">{group}</span>
            </div>
          ))}
        </div>
      )}
    </figure>
  )
}
