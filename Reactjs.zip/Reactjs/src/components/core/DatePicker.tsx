import './core.css'

export interface DatePickerProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'type' | 'value' | 'onChange'> {
  value?: string
  onChange?: (value: string) => void
  error?: boolean | string
  className?: string
}

export function DatePicker({
  value,
  onChange,
  error,
  className,
  ...rest
}: DatePickerProps) {
  const hasError = Boolean(error)

  return (
    <input
      type="date"
      value={value}
      className={['rf-date-picker', hasError ? 'rf-date-picker--error' : '', className ?? ''].filter(Boolean).join(' ')}
      aria-invalid={hasError ? 'true' : undefined}
      onChange={(event) => onChange?.(event.currentTarget.value)}
      {...rest}
    />
  )
}
