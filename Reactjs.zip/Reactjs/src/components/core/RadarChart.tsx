import './core.css'
import { useResponsiveChartWidth } from './useResponsiveChartWidth'

export interface RadarChartDatum {
  label: string
  value: number
}

export interface RadarSeriesData {
  label?: string
  series?: string
  data?: RadarChartDatum[]
  values?: number[] | RadarChartDatum[]
}

type RadarPointValue = number | RadarChartDatum

export interface RadarChartProps {
  data: RadarSeriesData[]
  axes: string[]
  width?: number
  height?: number
  responsive?: boolean
  levels?: number
  showLegend?: boolean
  variant?: 'basic' | 'filled' | 'threshold' | 'delta'
  benchmarkSeries?: number[]
  deltaBaseline?: number[]
  seriesOpacity?: number
  fillMode?: boolean
  ariaLabel?: string
  className?: string
}

/**
 * RadarChart renders multi-dimensional profile data as a radar/spider chart.
 * 
 * @example
 * <RadarChart
 *   axes={['Speed', 'Range', 'Efficiency']}
 *   data={[{
 *     label: 'Model A',
 *     data: [
 *       { label: 'Speed', value: 8 },
 *       { label: 'Range', value: 7 },
 *       { label: 'Efficiency', value: 9 },
 *     ]
 *   }]}
 *   levels={5}
 * />
 */
export function RadarChart({
  data,
  axes,
  width = 320,
  height = 320,
  responsive = false,
  levels = 5,
  showLegend = true,
  variant = 'basic',
  benchmarkSeries,
  deltaBaseline,
  seriesOpacity = 0.7,
  fillMode = true,
  ariaLabel = 'Radar chart',
  className,
}: RadarChartProps) {
  const { containerRef, width: chartWidth } = useResponsiveChartWidth<HTMLElement>(width, responsive)

  const centerX = chartWidth / 2
  const centerY = height / 2
  const maxRadius = Math.min(chartWidth, height) / 2 - 40
  const numAxes = axes.length

  // Find max value for normalization
  let maxValue = 0
  for (const seriesItem of data) {
    // Handle both { series, values } and { series, data: [...] } formats
    const values: RadarPointValue[] = seriesItem.values || (Array.isArray(seriesItem.data) ? seriesItem.data.map((d) => d.value) : [])
    for (const val of values) {
      const numVal = typeof val === 'number' ? val : val.value
      if (numVal > maxValue) maxValue = numVal
    }
  }
  maxValue = Math.max(maxValue, 1)

  // Calculate angle for each axis
  const angleSlice = (Math.PI * 2) / numAxes

  // Helper function to calculate point coordinates
  const getCoordinates = (value: number, axisIndex: number) => {
    const angle = angleSlice * axisIndex - Math.PI / 2
    const normalized = (value / maxValue) * maxRadius
    return {
      x: centerX + normalized * Math.cos(angle),
      y: centerY + normalized * Math.sin(angle),
    }
  }

  const classes = ['rf-radar-chart', `rf-radar-chart--${variant}`, className ?? ''].filter(Boolean).join(' ')
  const shouldFill = variant === 'filled' || fillMode

  const resolveSeriesValues = (seriesItem: RadarSeriesData): RadarPointValue[] =>
    seriesItem.values || (Array.isArray(seriesItem.data) ? seriesItem.data : [])

  const thresholdPoints =
    variant === 'threshold' && benchmarkSeries && benchmarkSeries.length > 0
      ? benchmarkSeries
          .map((value, axisIdx) => {
            const coords = getCoordinates(value / maxValue, axisIdx)
            return `${coords.x},${coords.y}`
          })
          .join(' ')
      : ''

  const baselineValues =
    variant === 'delta' && deltaBaseline && deltaBaseline.length > 0 ? deltaBaseline : null

  return (
    <figure className={classes} ref={containerRef}>
      <svg
        role="img"
        aria-label={ariaLabel}
        viewBox={`0 0 ${chartWidth} ${height}`}
        width={chartWidth}
        height={height}
        className="rf-radar-chart__svg"
      >
        {/* Background levels */}
        {Array.from({ length: levels }).map((_, levelIdx) => {
          const levelValue = ((levelIdx + 1) / levels) * maxRadius
          const points = Array.from({ length: numAxes })
            .map((_, axisIdx) => {
              const angle = angleSlice * axisIdx - Math.PI / 2
              const x = centerX + levelValue * Math.cos(angle)
              const y = centerY + levelValue * Math.sin(angle)
              return `${x},${y}`
            })
            .join(' ')

          return (
            <polygon
              key={`level-${levelIdx}`}
              points={points}
              fill="none"
              stroke="var(--border, #ddd)"
              strokeWidth="1"
              className="rf-radar-chart__level"
              opacity="0.3"
            />
          )
        })}

        {thresholdPoints && (
          <polygon
            points={thresholdPoints}
            fill="none"
            stroke="var(--color-warning)"
            strokeWidth="2"
            strokeDasharray="4,4"
            className="rf-radar-chart__threshold"
          />
        )}

        {/* Axes */}
        {Array.from({ length: numAxes }).map((_, axisIdx) => {
          const angle = angleSlice * axisIdx - Math.PI / 2
          const x = centerX + maxRadius * Math.cos(angle)
          const y = centerY + maxRadius * Math.sin(angle)

          return (
            <g key={`axis-${axisIdx}`}>
              <line x1={centerX} y1={centerY} x2={x} y2={y} stroke="var(--border, #ddd)" strokeWidth="1" />
              <text
                x={centerX + (maxRadius + 20) * Math.cos(angle)}
                y={centerY + (maxRadius + 20) * Math.sin(angle)}
                textAnchor="middle"
                dy="0.3em"
                fontSize="12"
                fill="var(--text, #000000)"
                className="rf-radar-chart__axis-label"
              >
                {axes[axisIdx]}
              </text>
            </g>
          )
        })}

        {/* Data series */}
        {data.map((seriesItem, seriesIdx) => {
          // Handle both { series, values } and { series, data: [...] } formats
          const seriesValues = resolveSeriesValues(seriesItem)
          const points = seriesValues
            .map((datum, axisIdx: number) => {
              const numVal = typeof datum === 'number' ? datum : datum.value
              const coords = getCoordinates(numVal / maxValue, axisIdx)
              return `${coords.x},${coords.y}`
            })
            .filter(Boolean)
            .join(' ')

          if (!points) return null

          const hueStep = (seriesIdx / Math.max(data.length, 1)) * 360
          const color = `hsl(${hueStep}, 70%, 60%)`

          return (
            <g key={`series-${seriesIdx}`}>
              {shouldFill && (
                <polygon
                  points={points}
                  fill={color}
                  opacity={seriesOpacity * 0.3}
                  stroke="none"
                  className="rf-radar-chart__fill"
                />
              )}
              <polyline
                points={points}
                fill="none"
                stroke={color}
                strokeWidth="2"
                className="rf-radar-chart__series"
                opacity={seriesOpacity}
              />

              {baselineValues && baselineValues.length > 0 && (
                <polyline
                  points={seriesValues
                    .map((datum, datumIdx) => {
                      const value = typeof datum === 'number' ? datum : datum.value
                      const baseline = baselineValues[datumIdx] ?? 0
                      const deltaValue = Math.max(value - baseline, 0)
                      const coords = getCoordinates(deltaValue / maxValue, datumIdx)
                      return `${coords.x},${coords.y}`
                    })
                    .join(' ')}
                  fill="none"
                  stroke="var(--color-success)"
                  strokeWidth="1.5"
                  strokeDasharray="3,3"
                  className="rf-radar-chart__delta"
                />
              )}

              {/* Data points */}
              {seriesValues.map((datum, datumIdx: number) => {
                const coords = getCoordinates((typeof datum === 'number' ? datum : datum.value) / maxValue, datumIdx)
                return (
                  <circle
                    key={`point-${seriesIdx}-${datumIdx}`}
                    cx={coords.x}
                    cy={coords.y}
                    r="3"
                    fill={color}
                    className="rf-radar-chart__point"
                  />
                )
              })}
            </g>
          )
        })}
      </svg>

      {showLegend && data.length > 0 && (
        <div className="rf-radar-chart__legend">
          {data.map((series, idx) => {
            const hueStep = (idx / Math.max(data.length, 1)) * 360
            return (
              <div key={`legend-${idx}`} className="rf-radar-chart__legend-item">
                <span
                  className="rf-radar-chart__legend-color"
                  style={{ backgroundColor: `hsl(${hueStep}, 70%, 60%)` }}
                />
                <span className="rf-radar-chart__legend-label">{series.label}</span>
              </div>
            )
          })}
        </div>
      )}
    </figure>
  )
}
