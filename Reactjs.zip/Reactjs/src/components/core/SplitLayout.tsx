import './core.css'
import React from 'react'

export interface SplitPane {
  id: string
  content: React.ReactNode
  /** Accessible label for the pane region. */
  label?: string
  /** Opt a specific pane out of the collapse button when `collapsible` is true on the layout. Defaults to true. */
  collapsible?: boolean
}

export interface SplitLayoutProps {
  /** Exactly 2 or 3 panes. */
  panes: [SplitPane, SplitPane] | [SplitPane, SplitPane, SplitPane]
  /** Controlled percentage sizes — must match the number of panes and sum near 100. */
  sizes?: number[]
  /** Minimum percentage per pane. Defaults to 10 for each pane. */
  minSizes?: number[]
  /** Split axis. Defaults to `'horizontal'` (panes are side-by-side). */
  direction?: 'horizontal' | 'vertical'
  /** Whether drag handles are rendered between panes. Defaults to `true`. */
  resizable?: boolean
  /** When true, adds a collapse toggle button to each pane. Defaults to `false`. */
  collapsible?: boolean
  /** Fired after every resize or collapse/expand with the new size array. */
  onSizesChange?: (sizes: number[]) => void
  className?: string
}

const STEP_PCT = 1 // percentage points per arrow-key press

function clamp(v: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, v))
}

function evenSizes(count: number): number[] {
  const base = parseFloat((100 / count).toFixed(6))
  const sizes = Array.from({ length: count }, () => base)
  // Assign any floating-point remainder to the last pane.
  sizes[sizes.length - 1] += 100 - sizes.reduce((a, b) => a + b, 0)
  return sizes
}

function applyDelta(
  sizes: number[],
  handleIndex: number,
  delta: number,
  minSizes: number[],
): number[] {
  const next = [...sizes]
  const li = handleIndex
  const ri = handleIndex + 1
  const lMin = minSizes[li] ?? 0
  const rMin = minSizes[ri] ?? 0

  const actual =
    delta > 0
      ? Math.min(delta, next[ri] - rMin)
      : Math.max(delta, -(next[li] - lMin))

  next[li] = clamp(next[li] + actual, lMin, 100)
  next[ri] = clamp(next[ri] - actual, rMin, 100)
  return next
}

export function SplitLayout({
  panes,
  sizes: sizesProp,
  minSizes,
  direction = 'horizontal',
  resizable = true,
  collapsible = false,
  onSizesChange,
  className,
}: SplitLayoutProps) {
  const count = panes.length

  const effectiveMin = React.useMemo(
    () => Array.from({ length: count }, (_, i) => minSizes?.[i] ?? 10),
    [count, minSizes],
  )

  const [localSizes, setLocalSizes] = React.useState<number[]>(
    () => sizesProp ?? evenSizes(count),
  )

  // Sync controlled prop changes into local state.
  const prevPropRef = React.useRef(sizesProp)
  React.useEffect(() => {
    if (sizesProp && sizesProp !== prevPropRef.current) {
      prevPropRef.current = sizesProp
      setLocalSizes(sizesProp)
    }
  }, [sizesProp])

  // Collapsed panes: key = pane id, value = size before collapse.
  const [collapsedSizes, setCollapsedSizes] = React.useState<Record<string, number>>({})

  const containerRef = React.useRef<HTMLDivElement | null>(null)
  const dragRef = React.useRef<{
    handleIndex: number
    startPos: number
    startSizes: number[]
  } | null>(null)

  function emitSizes(next: number[]) {
    setLocalSizes(next)
    onSizesChange?.(next)
  }

  // ── Drag (pointer capture) ───────────────────────────────────────────────

  function handlePointerDown(e: React.PointerEvent<HTMLDivElement>, hi: number) {
    if (!resizable) return
    e.preventDefault()
    ;(e.currentTarget as HTMLElement).setPointerCapture(e.pointerId)
    dragRef.current = {
      handleIndex: hi,
      startPos: direction === 'horizontal' ? e.clientX : e.clientY,
      startSizes: [...localSizes],
    }
  }

  function handlePointerMove(e: React.PointerEvent<HTMLDivElement>, hi: number) {
    if (!dragRef.current || dragRef.current.handleIndex !== hi) return
    const container = containerRef.current
    if (!container) return
    const containerSize =
      direction === 'horizontal' ? container.clientWidth : container.clientHeight
    if (containerSize === 0) return

    const pos = direction === 'horizontal' ? e.clientX : e.clientY
    const deltaPct = ((pos - dragRef.current.startPos) / containerSize) * 100
    emitSizes(applyDelta(dragRef.current.startSizes, hi, deltaPct, effectiveMin))
  }

  function handlePointerUp() {
    dragRef.current = null
  }

  // ── Keyboard resize ──────────────────────────────────────────────────────

  function handleKeyDown(e: React.KeyboardEvent<HTMLDivElement>, hi: number) {
    const growKey = direction === 'horizontal' ? 'ArrowRight' : 'ArrowDown'
    const shrinkKey = direction === 'horizontal' ? 'ArrowLeft' : 'ArrowUp'
    if (e.key !== growKey && e.key !== shrinkKey) return
    e.preventDefault()
    const delta = e.key === growKey ? STEP_PCT : -STEP_PCT
    emitSizes(applyDelta(localSizes, hi, delta, effectiveMin))
  }

  // ── Collapse / expand ────────────────────────────────────────────────────

  function toggleCollapse(paneIndex: number) {
    const pane = panes[paneIndex]
    const isCollapsed = pane.id in collapsedSizes

    if (isCollapsed) {
      // Restore: reclaim saved size from the adjacent pane.
      const savedSize = collapsedSizes[pane.id]
      const adjIdx = paneIndex === 0 ? 1 : paneIndex - 1
      const newSizes = [...localSizes]
      const toReclaim = Math.min(savedSize, newSizes[adjIdx] - (effectiveMin[adjIdx] ?? 0))
      newSizes[paneIndex] = toReclaim
      newSizes[adjIdx] = newSizes[adjIdx] - toReclaim

      const next = { ...collapsedSizes }
      delete next[pane.id]
      setCollapsedSizes(next)
      emitSizes(newSizes)
    } else {
      // Collapse: give space to the adjacent pane.
      const adjIdx = paneIndex === 0 ? 1 : paneIndex - 1
      const newSizes = [...localSizes]
      newSizes[adjIdx] = newSizes[adjIdx] + newSizes[paneIndex]
      newSizes[paneIndex] = 0
      setCollapsedSizes({ ...collapsedSizes, [pane.id]: localSizes[paneIndex] })
      emitSizes(newSizes)
    }
  }

  // ── Render ───────────────────────────────────────────────────────────────

  const containerClass = [
    'rf-split-layout',
    `rf-split-layout--${direction}`,
    className ?? '',
  ]
    .filter(Boolean)
    .join(' ')

  return (
    <div ref={containerRef} className={containerClass}>
      {(panes as SplitPane[]).map((pane, paneIndex) => {
        const isLast = paneIndex === count - 1
        const isCollapsed = pane.id in collapsedSizes
        const size = localSizes[paneIndex] ?? 0
        const showCollapseBtn = collapsible && pane.collapsible !== false

        const paneStyle: React.CSSProperties =
          direction === 'horizontal'
            ? { flexBasis: `${size}%`, flexShrink: 0, flexGrow: 0, minWidth: 0, overflow: 'auto' }
            : { flexBasis: `${size}%`, flexShrink: 0, flexGrow: 0, minHeight: 0, overflow: 'auto' }

        return (
          <React.Fragment key={pane.id}>
            <div
              className={[
                'rf-split-layout__pane',
                isCollapsed ? 'rf-split-layout__pane--collapsed' : '',
              ]
                .filter(Boolean)
                .join(' ')}
              style={paneStyle}
              role="region"
              aria-label={pane.label}
            >
              {showCollapseBtn && (
                <button
                  type="button"
                  className="rf-split-layout__collapse-btn"
                  aria-label={
                    isCollapsed
                      ? `Expand ${pane.label ?? 'pane'}`
                      : `Collapse ${pane.label ?? 'pane'}`
                  }
                  aria-expanded={!isCollapsed}
                  onClick={() => toggleCollapse(paneIndex)}
                >
                  {isCollapsed
                    ? direction === 'horizontal'
                      ? '›'
                      : '∨'
                    : direction === 'horizontal'
                      ? '‹'
                      : '∧'}
                </button>
              )}
              <div className="rf-split-layout__pane-content">{pane.content}</div>
            </div>

            {!isLast && resizable && (
              <div
                role="separator"
                aria-orientation={direction === 'horizontal' ? 'vertical' : 'horizontal'}
                aria-label={`Resize between pane ${paneIndex + 1} and pane ${paneIndex + 2}`}
                aria-valuenow={Math.round(size)}
                aria-valuemin={Math.round(effectiveMin[paneIndex] ?? 0)}
                aria-valuemax={100 - Math.round(effectiveMin[paneIndex + 1] ?? 0)}
                tabIndex={0}
                className="rf-split-layout__handle"
                onPointerDown={(e) => handlePointerDown(e, paneIndex)}
                onPointerMove={(e) => handlePointerMove(e, paneIndex)}
                onPointerUp={handlePointerUp}
                onKeyDown={(e) => handleKeyDown(e, paneIndex)}
              />
            )}
          </React.Fragment>
        )
      })}
    </div>
  )
}
