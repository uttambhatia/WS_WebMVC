export interface CheckboxProps {
  /** Unique id for the input element. Must match a FormField `id` if used inside one. */
  id: string
  /** Visible label text displayed next to the checkbox. */
  label: string
  /** Controlled checked state. */
  checked: boolean
  /** Called when the checked state changes. */
  onChange: React.ChangeEventHandler<HTMLInputElement>
  /** When true the checkbox is not interactive. */
  disabled?: boolean
  /** Additional class names for the wrapper label element. */
  className?: string
}

/**
 * Checkbox component with a visible label.
 *
 * Clicking anywhere on the label (including the text) toggles the checkbox.
 * Pass matching `id` and `htmlFor` values when used inside a `FormField`.
 *
 * @example
 * ```tsx
 * <Checkbox
 *   id="newsletter"
 *   label="Subscribe to newsletter"
 *   checked={newsletter}
 *   onChange={(e) => setNewsletter(e.target.checked)}
 * />
 * ```
 */
export function Checkbox({
  id,
  label,
  checked,
  onChange,
  disabled = false,
  className,
}: CheckboxProps) {
  const classes = [
    'rf-checkbox',
    disabled ? 'rf-checkbox--disabled' : '',
    className ?? '',
  ]
    .filter(Boolean)
    .join(' ')

  return (
    <label className={classes}>
      <input
        type="checkbox"
        id={id}
        className="rf-checkbox__input"
        checked={checked}
        onChange={onChange}
        disabled={disabled}
      />
      <span className="rf-checkbox__label">{label}</span>
    </label>
  )
}
