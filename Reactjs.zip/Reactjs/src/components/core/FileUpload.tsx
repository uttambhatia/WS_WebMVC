import './core.css'
import React from 'react'

export interface FileUploadProps {
  id?: string
  label?: React.ReactNode
  accept?: string
  multiple?: boolean
  disabled?: boolean
  onFilesChange?: (files: File[]) => void
  className?: string
}

export function FileUpload({
  id,
  label = 'Select files',
  accept,
  multiple = false,
  disabled = false,
  onFilesChange,
  className,
}: FileUploadProps) {
  const [files, setFiles] = React.useState<File[]>([])

  return (
    <div className={['rf-file-upload', className ?? ''].filter(Boolean).join(' ')}>
      <label className="rf-file-upload__label" htmlFor={id}>{label}</label>
      <input
        id={id}
        type="file"
        className="rf-file-upload__input"
        accept={accept}
        multiple={multiple}
        disabled={disabled}
        onChange={(event) => {
          const nextFiles = Array.from(event.currentTarget.files ?? [])
          setFiles(nextFiles)
          onFilesChange?.(nextFiles)
        }}
      />
      {files.length > 0 && (
        <ul className="rf-file-upload__list" aria-live="polite">
          {files.map((file) => (
            <li key={`${file.name}-${file.size}`} className="rf-file-upload__item">
              {file.name}
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}
