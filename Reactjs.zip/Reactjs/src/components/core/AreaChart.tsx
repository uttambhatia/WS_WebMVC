import './core.css'
import { useResponsiveChartWidth } from './useResponsiveChartWidth'

export interface AreaChartDatum {
  x: number
  y: number
  label?: string
}

export interface AreaRangeDatum {
  x: number
  min: number
  max: number
  label?: string
}

export type AreaChartVariant = 'single' | 'multi' | 'stacked' | 'percent' | 'range'
export type AreaStackMode = 'absolute' | 'percent'

export interface AreaChartProps {
  data: AreaChartDatum[] | AreaChartDatum[][]
  series?: AreaChartDatum[][]
  width?: number
  height?: number
  responsive?: boolean
  lineColor?: string
  fillColor?: string
  fillOpacity?: number
  showPoints?: boolean
  stackMode?: AreaStackMode
  rangeSeries?: AreaRangeDatum[]
  showMedianLine?: boolean
  variant?: AreaChartVariant
  ariaLabel?: string
  className?: string
}

/**
 * AreaChart renders an area chart with optional multi-series stacking.
 * 
 * @example
 * <AreaChart
 *   data={[
 *     { label: 'Month 1', value: 100 },
 *     { label: 'Month 2', value: 120 },
 *   ]}
 *   showPoints
 *   fillOpacity={0.3}
 * />
 */
export function AreaChart({
  data,
  series,
  width = 320,
  height = 180,
  responsive = false,
  lineColor = 'var(--color-primary)',
  fillColor = 'var(--color-primary)',
  fillOpacity = 0.1,
  showPoints = true,
  stackMode = 'absolute',
  rangeSeries,
  showMedianLine = false,
  variant = 'single',
  ariaLabel = 'Area chart',
  className,
}: AreaChartProps) {
  const { containerRef, width: chartWidth } = useResponsiveChartWidth<HTMLElement>(width, responsive)

  // lineColor and fillColor reserved for C11 variant expansion
  void lineColor
  void fillColor
  // Normalize data format
  const normalizedData = Array.isArray(data[0]) ? (data as AreaChartDatum[][]) : [data as AreaChartDatum[]]
  const seriesData = series && series.length > 0 ? series : normalizedData
  const isSingleSeries = seriesData.length === 1
  const itemCount = seriesData[0].length

  if (itemCount < 2 && variant !== 'range') {
    return (
      <figure className={['rf-area-chart', className ?? ''].filter(Boolean).join(' ')} ref={containerRef}>
        <svg role="img" aria-label={ariaLabel} viewBox={`0 0 ${chartWidth} ${height}`} width={chartWidth} height={height} />
      </figure>
    )
  }

  const padding = 12
  const innerWidth = chartWidth - padding * 2
  const innerHeight = height - padding * 2

  const xValues = seriesData.flatMap((seriesRow) => seriesRow.map((datum, idx) => (Number.isFinite(datum.x) ? datum.x : idx)))
  const minX = Math.min(...xValues, 0)
  const maxX = Math.max(...xValues, 1)
  const xRange = maxX - minX || 1

  const stackedValuesBySeries = seriesData.map((seriesRow, seriesIdx) =>
    seriesRow.map((datum, idx) => {
      if (variant !== 'stacked' && variant !== 'percent') {
        return datum.y
      }

      const runningTotal = seriesData
        .slice(0, seriesIdx + 1)
        .reduce((sum, currentSeries) => sum + (currentSeries[idx]?.y ?? 0), 0)

      if (variant === 'percent' || stackMode === 'percent') {
        const columnTotal = seriesData.reduce((sum, currentSeries) => sum + (currentSeries[idx]?.y ?? 0), 0)
        return columnTotal > 0 ? (runningTotal / columnTotal) * 100 : 0
      }

      return runningTotal
    }),
  )

  const allYValues =
    variant === 'range' && rangeSeries && rangeSeries.length > 0
      ? rangeSeries.flatMap((entry) => [entry.min, entry.max])
      : stackedValuesBySeries.flat()
  const maxValue = Math.max(...allYValues, 1)

  const points = seriesData.map((seriesRow, seriesIdx) =>
    seriesRow.map((datum, index) => {
      const sourceX = Number.isFinite(datum.x) ? datum.x : index
      const x = padding + ((sourceX - minX) / xRange) * innerWidth
      const normalized = stackedValuesBySeries[seriesIdx][index] / maxValue
      const plotY = padding + (1 - normalized) * innerHeight
      return { x, y: plotY, datum }
    }),
  )

  const classes = ['rf-area-chart', `rf-area-chart--${variant}`, className ?? ''].filter(Boolean).join(' ')

  return (
    <figure className={classes} ref={containerRef}>
      <svg
        role="img"
        aria-label={ariaLabel}
        viewBox={`0 0 ${chartWidth} ${height}`}
        width={chartWidth}
        height={height}
        className="rf-area-chart__svg"
      >
        {/* Range band variant */}
        {variant === 'range' && rangeSeries && rangeSeries.length > 1 ? (() => {
          const upper = rangeSeries.map((datum, idx) => {
            const sourceX = Number.isFinite(datum.x) ? datum.x : idx
            const x = padding + ((sourceX - minX) / xRange) * innerWidth
            const y = padding + (1 - datum.max / maxValue) * innerHeight
            return { x, y }
          })
          const lower = [...rangeSeries].reverse().map((datum, idx) => {
            const sourceX = Number.isFinite(datum.x) ? datum.x : rangeSeries.length - 1 - idx
            const x = padding + ((sourceX - minX) / xRange) * innerWidth
            const y = padding + (1 - datum.min / maxValue) * innerHeight
            return { x, y }
          })
          const band = [...upper, ...lower].map((p) => `${p.x},${p.y}`).join(' ')
          const median = rangeSeries
            .map((datum, idx) => {
              const sourceX = Number.isFinite(datum.x) ? datum.x : idx
              const x = padding + ((sourceX - minX) / xRange) * innerWidth
              const y = padding + (1 - ((datum.min + datum.max) / 2) / maxValue) * innerHeight
              return `${x},${y}`
            })
            .join(' ')

          return (
            <g>
              <polygon className="rf-area-chart__area" points={band} fill="var(--color-primary)" opacity={fillOpacity} />
              <polyline className="rf-area-chart__line" points={median} stroke="var(--color-primary)" strokeWidth="2" fill="none" />
            </g>
          )
        })() : (
          points.map((seriesRow, seriesIdx) => {
            const polyline = seriesRow.map((point) => `${point.x},${point.y}`).join(' ')
            const closePath = `${seriesRow[seriesRow.length - 1].x},${height - padding} ${seriesRow[0].x},${height - padding}`
            const fullPath = polyline + ' ' + closePath

            const hueStep = (seriesIdx / Math.max(seriesData.length, 1)) * 360

            return (
              <g key={`area-${seriesIdx}`}>
                <polygon
                  className="rf-area-chart__area"
                  points={fullPath}
                  fill={`hsl(${hueStep}, 70%, 60%)`}
                  opacity={fillOpacity}
                />
                <polyline
                  className="rf-area-chart__line"
                  points={polyline}
                  stroke={`hsl(${hueStep}, 70%, 50%)`}
                  strokeWidth="2"
                  fill="none"
                />
                {showPoints &&
                  seriesRow.map((point, idx) => (
                    <circle
                      key={`point-${seriesIdx}-${idx}`}
                      cx={point.x}
                      cy={point.y}
                      r="3"
                      fill={`hsl(${hueStep}, 70%, 50%)`}
                      className="rf-area-chart__point"
                    />
                  ))}
              </g>
            )
          })
        )}

        {showMedianLine && isSingleSeries && (
          <line
            x1={padding}
            y1={padding + innerHeight / 2}
            x2={chartWidth - padding}
            y2={padding + innerHeight / 2}
            stroke="var(--border, #ccc)"
            strokeWidth="1"
            strokeDasharray="4,4"
            className="rf-area-chart__median"
          />
        )}
      </svg>
    </figure>
  )
}
