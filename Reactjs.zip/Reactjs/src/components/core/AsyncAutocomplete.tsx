import './core.css'
import React from 'react'

export interface AsyncAutocompleteLoadContext {
  signal: AbortSignal
}

export interface AsyncAutocompleteProps<T> {
  value?: string
  loadOptions: (query: string, context: AsyncAutocompleteLoadContext) => Promise<T[]>
  getOptionLabel: (option: T) => string
  getOptionValue: (option: T) => string
  onChange?: (value: string) => void
  onSelect?: (option: T) => void
  placeholder?: string
  className?: string
  id?: string
  ariaLabel?: string
  minQueryLength?: number
  debounceMs?: number
  loadingText?: string
  emptyText?: string
}

export function AsyncAutocomplete<T>({
  value,
  loadOptions,
  getOptionLabel,
  getOptionValue,
  onChange,
  onSelect,
  placeholder = 'Search...',
  className,
  id,
  ariaLabel,
  minQueryLength = 2,
  debounceMs = 220,
  loadingText = 'Loading options...',
  emptyText = 'No options found.',
}: AsyncAutocompleteProps<T>) {
  const rootRef = React.useRef<HTMLDivElement | null>(null)
  const requestVersionRef = React.useRef(0)
  const abortRef = React.useRef<AbortController | null>(null)

  const [open, setOpen] = React.useState(false)
  const [query, setQuery] = React.useState('')
  const [activeIndex, setActiveIndex] = React.useState(0)
  const [options, setOptions] = React.useState<T[]>([])
  const [loading, setLoading] = React.useState(false)

  const selectedOption = React.useMemo(
    () => options.find((option) => getOptionValue(option) === value),
    [getOptionValue, options, value],
  )

  React.useEffect(() => {
    if (!open) return

    function onDocumentPointerDown(event: MouseEvent) {
      const target = event.target as Node
      if (rootRef.current?.contains(target)) return
      setOpen(false)
    }

    function onDocumentKeyDown(event: KeyboardEvent) {
      if (event.key === 'Escape') {
        event.preventDefault()
        setOpen(false)
      }
    }

    document.addEventListener('mousedown', onDocumentPointerDown)
    document.addEventListener('keydown', onDocumentKeyDown)

    return () => {
      document.removeEventListener('mousedown', onDocumentPointerDown)
      document.removeEventListener('keydown', onDocumentKeyDown)
    }
  }, [open])

  React.useEffect(() => {
    if (!open) return

    const normalizedQuery = query.trim()
    if (normalizedQuery.length < minQueryLength) {
      setOptions([])
      setLoading(false)
      return
    }

    const timer = window.setTimeout(async () => {
      requestVersionRef.current += 1
      const requestVersion = requestVersionRef.current

      abortRef.current?.abort()
      const abortController = new AbortController()
      abortRef.current = abortController

      setLoading(true)

      try {
        const loaded = await loadOptions(normalizedQuery, { signal: abortController.signal })
        if (requestVersion !== requestVersionRef.current) return
        setOptions(loaded)
        setActiveIndex(0)
      } catch (error) {
        if ((error as { name?: string })?.name !== 'AbortError') {
          setOptions([])
        }
      } finally {
        if (requestVersion === requestVersionRef.current) {
          setLoading(false)
        }
      }
    }, debounceMs)

    return () => {
      window.clearTimeout(timer)
    }
  }, [debounceMs, loadOptions, minQueryLength, open, query])

  React.useEffect(() => {
    return () => {
      abortRef.current?.abort()
    }
  }, [])

  function commitSelection(option: T) {
    const optionValue = getOptionValue(option)
    onChange?.(optionValue)
    onSelect?.(option)
    setQuery('')
    setOpen(false)
  }

  function onInputKeyDown(event: React.KeyboardEvent<HTMLInputElement>) {
    if (!open && (event.key === 'ArrowDown' || event.key === 'ArrowUp')) {
      setOpen(true)
      return
    }

    if (!open || options.length === 0) return

    if (event.key === 'ArrowDown') {
      event.preventDefault()
      setActiveIndex((index) => (index + 1) % options.length)
      return
    }

    if (event.key === 'ArrowUp') {
      event.preventDefault()
      setActiveIndex((index) => (index - 1 + options.length) % options.length)
      return
    }

    if (event.key === 'Enter') {
      event.preventDefault()
      const option = options[activeIndex]
      if (!option) return
      commitSelection(option)
    }
  }

  const displayValue = open
    ? query
    : selectedOption
      ? getOptionLabel(selectedOption)
      : query

  const listboxId = id ? `${id}-listbox` : undefined

  return (
    <div ref={rootRef} className={['rf-async-autocomplete', className ?? ''].filter(Boolean).join(' ')}>
      <input
        id={id}
        type="text"
        role="combobox"
        aria-label={ariaLabel}
        aria-expanded={open ? 'true' : 'false'}
        aria-autocomplete="list"
        aria-controls={listboxId}
        aria-activedescendant={listboxId && options[activeIndex] ? `${listboxId}-${activeIndex}` : undefined}
        className="rf-async-autocomplete__input"
        value={displayValue}
        placeholder={placeholder}
        onFocus={() => {
          setOpen(true)
          setActiveIndex(0)
        }}
        onChange={(event) => {
          setQuery(event.currentTarget.value)
          setOpen(true)
        }}
        onKeyDown={onInputKeyDown}
      />

      {open && (
        <ul id={listboxId} className="rf-async-autocomplete__list" role="listbox">
          {query.trim().length < minQueryLength && (
            <li className="rf-async-autocomplete__empty" role="status">
              Type at least {minQueryLength} characters.
            </li>
          )}

          {query.trim().length >= minQueryLength && loading && (
            <li className="rf-async-autocomplete__loading" role="status">
              {loadingText}
            </li>
          )}

          {query.trim().length >= minQueryLength && !loading && options.length === 0 && (
            <li className="rf-async-autocomplete__empty" role="status">
              {emptyText}
            </li>
          )}

          {query.trim().length >= minQueryLength && !loading && options.map((option, index) => {
            const active = index === activeIndex
            return (
              <li
                id={listboxId ? `${listboxId}-${index}` : undefined}
                key={getOptionValue(option)}
                role="option"
                aria-selected={active ? 'true' : 'false'}
              >
                <button
                  type="button"
                  className={[
                    'rf-async-autocomplete__option',
                    active ? 'rf-async-autocomplete__option--active' : '',
                  ].filter(Boolean).join(' ')}
                  onMouseEnter={() => setActiveIndex(index)}
                  onClick={() => commitSelection(option)}
                >
                  {getOptionLabel(option)}
                </button>
              </li>
            )
          })}
        </ul>
      )}
    </div>
  )
}
