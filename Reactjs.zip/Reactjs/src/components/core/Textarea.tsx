import './core.css'

export interface TextareaProps extends Omit<React.TextareaHTMLAttributes<HTMLTextAreaElement>, 'size'> {
  size?: 'sm' | 'md' | 'lg'
  error?: boolean | string
  className?: string
}

export function Textarea({
  size = 'md',
  error,
  className,
  ...rest
}: TextareaProps) {
  const hasError = Boolean(error)

  const classes = [
    'rf-textarea',
    `rf-textarea--${size}`,
    hasError ? 'rf-textarea--error' : '',
    className ?? '',
  ]
    .filter(Boolean)
    .join(' ')

  return (
    <textarea
      className={classes}
      aria-invalid={hasError ? 'true' : undefined}
      {...rest}
    />
  )
}
