import './core.css'

export interface MultiSelectOption {
  value: string
  label: React.ReactNode
  disabled?: boolean
}

export interface MultiSelectProps {
  id?: string
  options: MultiSelectOption[]
  values: string[]
  onChange: (values: string[]) => void
  size?: 'sm' | 'md' | 'lg'
  className?: string
  ariaLabel?: string
}

export function MultiSelect({
  id,
  options,
  values,
  onChange,
  size = 'md',
  className,
  ariaLabel,
}: MultiSelectProps) {
  return (
    <select
      id={id}
      multiple
      value={values}
      aria-label={ariaLabel}
      className={['rf-multi-select', `rf-multi-select--${size}`, className ?? ''].filter(Boolean).join(' ')}
      onChange={(event) => {
        const nextValues = Array.from(event.currentTarget.selectedOptions).map((option) => option.value)
        onChange(nextValues)
      }}
    >
      {options.map((option) => (
        <option key={option.value} value={option.value} disabled={option.disabled}>
          {option.label}
        </option>
      ))}
    </select>
  )
}
