import './core.css'
import React from 'react'
import { createPortal } from 'react-dom'

export interface DrawerHeaderProps {
  title?: React.ReactNode
  actions?: React.ReactNode
  className?: string
}

export function DrawerHeader({ title, actions, className }: DrawerHeaderProps) {
  return (
    <header className={['rf-drawer__header', className ?? ''].filter(Boolean).join(' ')}>
      <h3 className="rf-drawer__title">{title}</h3>
      {actions}
    </header>
  )
}

export interface DrawerBodyProps {
  children: React.ReactNode
  className?: string
}

export function DrawerBody({ children, className }: DrawerBodyProps) {
  return <div className={['rf-drawer__body', className ?? ''].filter(Boolean).join(' ')}>{children}</div>
}

export interface DrawerFooterProps {
  children: React.ReactNode
  className?: string
}

export function DrawerFooter({ children, className }: DrawerFooterProps) {
  return <footer className={['rf-drawer__footer', className ?? ''].filter(Boolean).join(' ')}>{children}</footer>
}

export interface DrawerProps {
  open: boolean
  title?: React.ReactNode
  children: React.ReactNode
  onClose: () => void
  side?: 'left' | 'right'
  closeOnBackdropClick?: boolean
  closeOnEscape?: boolean
  footer?: React.ReactNode
  composable?: boolean
  showCloseButton?: boolean
  className?: string
}

export function Drawer({
  open,
  title,
  children,
  onClose,
  side = 'right',
  closeOnBackdropClick = true,
  closeOnEscape = true,
  footer,
  composable = false,
  showCloseButton = true,
  className,
}: DrawerProps) {
  React.useEffect(() => {
    if (!open || !closeOnEscape) return

    function onKeyDown(event: KeyboardEvent) {
      if (event.key === 'Escape') {
        event.preventDefault()
        onClose()
      }
    }

    document.addEventListener('keydown', onKeyDown)
    return () => document.removeEventListener('keydown', onKeyDown)
  }, [closeOnEscape, onClose, open])

  if (!open || typeof document === 'undefined') {
    return null
  }

  function onBackdropMouseDown(event: React.MouseEvent<HTMLDivElement>) {
    if (event.target !== event.currentTarget) return
    if (closeOnBackdropClick) {
      onClose()
    }
  }

  return createPortal(
    <div className="rf-drawer__backdrop" onMouseDown={onBackdropMouseDown}>
      <aside
        className={[
          'rf-drawer',
          `rf-drawer--${side}`,
          className ?? '',
        ].filter(Boolean).join(' ')}
        role="dialog"
        aria-modal="true"
        aria-label={typeof title === 'string' ? title : undefined}
      >
        {composable ? (
          children
        ) : (
          <>
            <DrawerHeader
              title={title}
              actions={showCloseButton ? (
                <button type="button" className="rf-drawer__close" onClick={onClose} aria-label="Close drawer">
                  ×
                </button>
              ) : null}
            />
            <DrawerBody>{children}</DrawerBody>
            {footer && <DrawerFooter>{footer}</DrawerFooter>}
          </>
        )}
      </aside>
    </div>,
    document.body,
  )
}
