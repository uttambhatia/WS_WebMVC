import './core.css'
import React from 'react'

export interface TabDefinition {
  id: string
  label: React.ReactNode
  content: React.ReactNode
  disabled?: boolean
}

export interface TabsProps {
  tabs: TabDefinition[]
  activeTabId?: string
  defaultTabId?: string
  onTabChange?: (tabId: string) => void
  className?: string
}

export function Tabs({
  tabs,
  activeTabId,
  defaultTabId,
  onTabChange,
  className,
}: TabsProps) {
  const resolvedDefault = defaultTabId ?? tabs.find((tab) => !tab.disabled)?.id
  const [internalTab, setInternalTab] = React.useState<string | undefined>(resolvedDefault)
  const currentId = activeTabId ?? internalTab

  const currentTab = tabs.find((tab) => tab.id === currentId) ?? tabs.find((tab) => !tab.disabled)

  function setTab(id: string) {
    if (activeTabId === undefined) {
      setInternalTab(id)
    }
    onTabChange?.(id)
  }

  function onKeyDown(event: React.KeyboardEvent<HTMLDivElement>) {
    const enabledTabs = tabs.filter((tab) => !tab.disabled)
    if (enabledTabs.length === 0 || !currentTab) return

    const currentIndex = enabledTabs.findIndex((tab) => tab.id === currentTab.id)
    if (currentIndex === -1) return

    if (event.key === 'ArrowRight') {
      event.preventDefault()
      setTab(enabledTabs[(currentIndex + 1) % enabledTabs.length].id)
    } else if (event.key === 'ArrowLeft') {
      event.preventDefault()
      setTab(enabledTabs[(currentIndex - 1 + enabledTabs.length) % enabledTabs.length].id)
    } else if (event.key === 'Home') {
      event.preventDefault()
      setTab(enabledTabs[0].id)
    } else if (event.key === 'End') {
      event.preventDefault()
      setTab(enabledTabs[enabledTabs.length - 1].id)
    }
  }

  return (
    <div className={['rf-tabs', className ?? ''].filter(Boolean).join(' ')}>
      <div className="rf-tabs__list" role="tablist" onKeyDown={onKeyDown}>
        {tabs.map((tab) => {
          const selected = currentTab?.id === tab.id
          return (
            <button
              key={tab.id}
              type="button"
              role="tab"
              id={`rf-tab-${tab.id}`}
              aria-selected={selected ? 'true' : 'false'}
              aria-controls={`rf-tabpanel-${tab.id}`}
              tabIndex={selected ? 0 : -1}
              className={[
                'rf-tabs__tab',
                selected ? 'rf-tabs__tab--active' : '',
                tab.disabled ? 'rf-tabs__tab--disabled' : '',
              ].filter(Boolean).join(' ')}
              disabled={tab.disabled}
              onClick={() => setTab(tab.id)}
            >
              {tab.label}
            </button>
          )
        })}
      </div>
      {currentTab && (
        <div
          id={`rf-tabpanel-${currentTab.id}`}
          role="tabpanel"
          aria-labelledby={`rf-tab-${currentTab.id}`}
          className="rf-tabs__panel"
        >
          {currentTab.content}
        </div>
      )}
    </div>
  )
}
