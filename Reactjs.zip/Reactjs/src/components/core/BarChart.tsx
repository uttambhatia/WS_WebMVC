import './core.css'

export interface BarChartDatum {
  label: string
  value: number
}

export interface BarChartProps {
  data: BarChartDatum[]
  width?: number
  height?: number
  barColor?: string
  showValues?: boolean
  ariaLabel?: string
  className?: string
}

export function BarChart({
  data,
  width = 320,
  height = 180,
  barColor = 'var(--color-primary)',
  showValues = true,
  ariaLabel = 'Bar chart',
  className,
}: BarChartProps) {
  const max = Math.max(...data.map((item) => item.value), 1)
  const classes = ['rf-bar-chart', className ?? ''].filter(Boolean).join(' ')

  return (
    <figure className={classes}>
      <svg
        role="img"
        aria-label={ariaLabel}
        viewBox={`0 0 ${width} ${height}`}
        width={width}
        height={height}
      >
        {data.map((item, index) => {
          const barWidth = width / Math.max(data.length, 1)
          const x = index * barWidth + barWidth * 0.15
          const innerWidth = barWidth * 0.7
          const innerHeight = (item.value / max) * (height - 24)
          const y = height - 20 - innerHeight

          return (
            <g key={`${item.label}-${index}`}>
              <rect
                className="rf-bar-chart__bar"
                x={x}
                y={y}
                width={innerWidth}
                height={innerHeight}
                fill={barColor}
                rx={4}
              />
              <text
                className="rf-bar-chart__label"
                x={x + innerWidth / 2}
                y={height - 6}
                textAnchor="middle"
              >
                {item.label}
              </text>
              {showValues && (
                <text
                  className="rf-bar-chart__value"
                  x={x + innerWidth / 2}
                  y={Math.max(y - 4, 10)}
                  textAnchor="middle"
                >
                  {item.value}
                </text>
              )}
            </g>
          )
        })}
      </svg>
    </figure>
  )
}
