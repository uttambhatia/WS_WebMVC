import './core.css'
import React from 'react'

export interface DropdownMenuItem {
  id: string
  label: React.ReactNode
  onSelect: () => void
  disabled?: boolean
}

export interface DropdownMenuProps {
  triggerLabel: React.ReactNode
  items: DropdownMenuItem[]
  className?: string
}

export function DropdownMenu({ triggerLabel, items, className }: DropdownMenuProps) {
  const [open, setOpen] = React.useState(false)
  const [activeIndex, setActiveIndex] = React.useState(0)
  const rootRef = React.useRef<HTMLDivElement | null>(null)

  React.useEffect(() => {
    if (!open) return

    function onPointerDown(event: MouseEvent) {
      const target = event.target as Node
      if (rootRef.current?.contains(target)) return
      setOpen(false)
    }

    function onKeyDown(event: KeyboardEvent) {
      if (event.key === 'Escape') {
        event.preventDefault()
        setOpen(false)
      }
    }

    document.addEventListener('mousedown', onPointerDown)
    document.addEventListener('keydown', onKeyDown)

    return () => {
      document.removeEventListener('mousedown', onPointerDown)
      document.removeEventListener('keydown', onKeyDown)
    }
  }, [open])

  function onMenuKeyDown(event: React.KeyboardEvent<HTMLUListElement>) {
    const enabledIndexes = items
      .map((item, index) => ({ item, index }))
      .filter((entry) => !entry.item.disabled)
      .map((entry) => entry.index)

    if (enabledIndexes.length === 0) return

    if (event.key === 'ArrowDown') {
      event.preventDefault()
      const current = enabledIndexes.indexOf(activeIndex)
      setActiveIndex(enabledIndexes[(current + 1) % enabledIndexes.length])
    }

    if (event.key === 'ArrowUp') {
      event.preventDefault()
      const current = enabledIndexes.indexOf(activeIndex)
      setActiveIndex(enabledIndexes[(current - 1 + enabledIndexes.length) % enabledIndexes.length])
    }

    if (event.key === 'Home') {
      event.preventDefault()
      setActiveIndex(enabledIndexes[0])
    }

    if (event.key === 'End') {
      event.preventDefault()
      setActiveIndex(enabledIndexes[enabledIndexes.length - 1])
    }
  }

  return (
    <div ref={rootRef} className={['rf-dropdown', className ?? ''].filter(Boolean).join(' ')}>
      <button
        type="button"
        className="rf-dropdown__trigger"
        aria-haspopup="menu"
        aria-expanded={open ? 'true' : 'false'}
        onClick={() => setOpen((value) => !value)}
      >
        {triggerLabel}
      </button>
      {open && (
        <ul className="rf-dropdown__menu" role="menu" onKeyDown={onMenuKeyDown}>
          {items.map((item, index) => (
            <li key={item.id} role="none">
              <button
                type="button"
                role="menuitem"
                className={[
                  'rf-dropdown__item',
                  index === activeIndex ? 'rf-dropdown__item--active' : '',
                ].filter(Boolean).join(' ')}
                disabled={item.disabled}
                onMouseEnter={() => setActiveIndex(index)}
                onClick={() => {
                  item.onSelect()
                  setOpen(false)
                }}
              >
                {item.label}
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}
