import './core.css'
import React from 'react'

export interface SpinnerProps {
  size?: 'sm' | 'md' | 'lg'
  label?: string
  inline?: boolean
  className?: string
}

export function Spinner({
  size = 'md',
  label = 'Loading',
  inline = false,
  className,
  ...rest
}: SpinnerProps & React.HTMLAttributes<HTMLSpanElement>) {
  const classes = ['rf-spinner', `rf-spinner--${size}`, inline ? 'rf-spinner--inline' : '', className]
    .filter(Boolean)
    .join(' ')

  return (
    <span className={classes} role="status" aria-live="polite" {...rest}>
      <span className="rf-spinner__glyph" aria-hidden="true" />
      <span className="rf-visually-hidden">{label}</span>
    </span>
  )
}
