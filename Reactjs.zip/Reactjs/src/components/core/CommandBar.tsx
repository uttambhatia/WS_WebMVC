import './core.css'
import React from 'react'

export interface CommandBarAction {
  id: string
  label: string
  onSelect: () => void
  icon?: React.ReactNode
  shortcutHint?: string
  disabled?: boolean
  ariaLabel?: string
}

export interface CommandBarProps {
  title?: React.ReactNode
  actions: CommandBarAction[]
  overflowActions?: CommandBarAction[]
  maxVisibleActions?: number
  searchValue?: string
  onSearchChange?: (value: string) => void
  onSearchSubmit?: (query: string) => void
  searchPlaceholder?: string
  searchAriaLabel?: string
  onOpenCommandPalette?: () => void
  commandPaletteLabel?: string
  className?: string
}

function getResponsiveVisibleCount(width: number, fallback: number): number {
  if (width < 420) return Math.min(1, fallback)
  if (width < 720) return Math.min(2, fallback)
  return fallback
}

export function CommandBar({
  title,
  actions,
  overflowActions,
  maxVisibleActions = 3,
  searchValue,
  onSearchChange,
  onSearchSubmit,
  searchPlaceholder = 'Search actions',
  searchAriaLabel = 'Search command bar actions',
  onOpenCommandPalette,
  commandPaletteLabel = 'Open command palette',
  className,
}: CommandBarProps) {
  const rootRef = React.useRef<HTMLDivElement | null>(null)
  const overflowButtonRef = React.useRef<HTMLButtonElement | null>(null)
  const overflowMenuRef = React.useRef<HTMLUListElement | null>(null)

  const [localSearchValue, setLocalSearchValue] = React.useState('')
  const [overflowOpen, setOverflowOpen] = React.useState(false)
  const [responsiveVisibleCount, setResponsiveVisibleCount] = React.useState(maxVisibleActions)

  const isControlledSearch = searchValue !== undefined
  const resolvedSearchValue = isControlledSearch ? searchValue : localSearchValue

  React.useEffect(() => {
    const root = rootRef.current
    if (!root || typeof ResizeObserver === 'undefined') {
      setResponsiveVisibleCount(maxVisibleActions)
      return
    }

    const resizeObserver = new ResizeObserver((entries) => {
      const entry = entries[0]
      if (!entry) return
      const width = entry.contentRect.width
      setResponsiveVisibleCount(getResponsiveVisibleCount(width, maxVisibleActions))
    })

    resizeObserver.observe(root)
    return () => resizeObserver.disconnect()
  }, [maxVisibleActions])

  React.useEffect(() => {
    if (!overflowOpen) return

    function onDocumentMouseDown(event: MouseEvent) {
      if (!(event.target instanceof Node)) return
      if (rootRef.current?.contains(event.target)) return
      setOverflowOpen(false)
    }

    function onDocumentKeyDown(event: KeyboardEvent) {
      if (event.key !== 'Escape') return
      event.preventDefault()
      setOverflowOpen(false)
      overflowButtonRef.current?.focus()
    }

    document.addEventListener('mousedown', onDocumentMouseDown)
    document.addEventListener('keydown', onDocumentKeyDown)

    return () => {
      document.removeEventListener('mousedown', onDocumentMouseDown)
      document.removeEventListener('keydown', onDocumentKeyDown)
    }
  }, [overflowOpen])

  const effectiveVisibleCount = Math.max(0, Math.min(maxVisibleActions, responsiveVisibleCount))

  const visibleActions = actions.slice(0, effectiveVisibleCount)
  const computedOverflowActions = React.useMemo(() => {
    return [...actions.slice(effectiveVisibleCount), ...(overflowActions ?? [])]
  }, [actions, effectiveVisibleCount, overflowActions])

  function updateSearchValue(nextValue: string) {
    if (!isControlledSearch) {
      setLocalSearchValue(nextValue)
    }
    onSearchChange?.(nextValue)
  }

  function activateAction(action: CommandBarAction) {
    if (action.disabled) return
    action.onSelect()
    setOverflowOpen(false)
  }

  function handleToolbarKeyDown(event: React.KeyboardEvent<HTMLDivElement>) {
    const focusable = Array.from(
      event.currentTarget.querySelectorAll<HTMLElement>('button:not(:disabled)')
    )

    const activeElement = document.activeElement as HTMLElement | null
    const currentIndex = activeElement ? focusable.indexOf(activeElement) : -1
    if (currentIndex < 0) return

    if (event.key === 'ArrowRight') {
      event.preventDefault()
      const next = focusable[(currentIndex + 1) % focusable.length]
      next?.focus()
      return
    }

    if (event.key === 'ArrowLeft') {
      event.preventDefault()
      const previous = focusable[(currentIndex - 1 + focusable.length) % focusable.length]
      previous?.focus()
      return
    }

    if (event.key === 'Home') {
      event.preventDefault()
      focusable[0]?.focus()
      return
    }

    if (event.key === 'End') {
      event.preventDefault()
      focusable[focusable.length - 1]?.focus()
    }
  }

  function focusOverflowItem(index: number) {
    const items = overflowMenuRef.current?.querySelectorAll<HTMLButtonElement>('[role="menuitem"]')
    if (!items || items.length === 0) return

    const safeIndex = Math.max(0, Math.min(index, items.length - 1))
    items[safeIndex]?.focus()
  }

  function handleOverflowButtonKeyDown(event: React.KeyboardEvent<HTMLButtonElement>) {
    if (event.key === 'ArrowDown') {
      event.preventDefault()
      setOverflowOpen(true)
      requestAnimationFrame(() => focusOverflowItem(0))
      return
    }

    if (event.key === 'ArrowUp') {
      event.preventDefault()
      setOverflowOpen(true)
      requestAnimationFrame(() => {
        const items = overflowMenuRef.current?.querySelectorAll<HTMLButtonElement>('[role="menuitem"]')
        const lastIndex = items ? items.length - 1 : 0
        focusOverflowItem(lastIndex)
      })
    }
  }

  function handleOverflowMenuKeyDown(event: React.KeyboardEvent<HTMLUListElement>) {
    const items = Array.from(
      event.currentTarget.querySelectorAll<HTMLButtonElement>('[role="menuitem"]')
    )
    const activeElement = document.activeElement as HTMLButtonElement | null
    const currentIndex = activeElement ? items.indexOf(activeElement) : -1

    if (event.key === 'Escape') {
      event.preventDefault()
      setOverflowOpen(false)
      overflowButtonRef.current?.focus()
      return
    }

    if (items.length === 0 || currentIndex < 0) {
      return
    }

    if (event.key === 'ArrowDown') {
      event.preventDefault()
      const next = items[(currentIndex + 1) % items.length]
      next?.focus()
      return
    }

    if (event.key === 'ArrowUp') {
      event.preventDefault()
      const previous = items[(currentIndex - 1 + items.length) % items.length]
      previous?.focus()
      return
    }

    if (event.key === 'Home') {
      event.preventDefault()
      items[0]?.focus()
      return
    }

    if (event.key === 'End') {
      event.preventDefault()
      items[items.length - 1]?.focus()
    }
  }

  return (
    <section
      ref={rootRef}
      className={[
        'rf-command-bar',
        className ?? '',
      ].filter(Boolean).join(' ')}
      aria-label="Command bar"
    >
      <header className="rf-command-bar__header">
        {title && <h3 className="rf-command-bar__title">{title}</h3>}

        <form
          className="rf-command-bar__search"
          role="search"
          onSubmit={(event) => {
            event.preventDefault()
            onSearchSubmit?.(resolvedSearchValue)
          }}
        >
          <input
            type="search"
            value={resolvedSearchValue}
            onChange={(event) => updateSearchValue(event.currentTarget.value)}
            className="rf-command-bar__search-input"
            placeholder={searchPlaceholder}
            aria-label={searchAriaLabel}
          />

          <button type="submit" className="rf-command-bar__search-submit">
            Search
          </button>

          {onOpenCommandPalette && (
            <button
              type="button"
              className="rf-command-bar__palette"
              onClick={onOpenCommandPalette}
            >
              {commandPaletteLabel}
            </button>
          )}
        </form>
      </header>

      <div
        className="rf-command-bar__actions"
        role="toolbar"
        aria-label="Contextual actions"
        onKeyDown={handleToolbarKeyDown}
      >
        {visibleActions.map((action) => (
          <button
            key={action.id}
            type="button"
            className="rf-command-bar__action"
            disabled={action.disabled}
            onClick={() => activateAction(action)}
            aria-label={action.ariaLabel}
          >
            {action.icon && <span className="rf-command-bar__action-icon" aria-hidden="true">{action.icon}</span>}
            <span>{action.label}</span>
            {action.shortcutHint && <kbd className="rf-command-bar__shortcut">{action.shortcutHint}</kbd>}
          </button>
        ))}

        {computedOverflowActions.length > 0 && (
          <div className="rf-command-bar__overflow">
            <button
              ref={overflowButtonRef}
              type="button"
              className="rf-command-bar__overflow-toggle"
              aria-haspopup="menu"
              aria-expanded={overflowOpen ? 'true' : 'false'}
              aria-controls="rf-command-bar-overflow-menu"
              onClick={() => setOverflowOpen((previous) => !previous)}
              onKeyDown={handleOverflowButtonKeyDown}
            >
              More
            </button>

            {overflowOpen && (
              <ul
                id="rf-command-bar-overflow-menu"
                ref={overflowMenuRef}
                className="rf-command-bar__overflow-menu"
                role="menu"
                aria-label="Additional actions"
                onKeyDown={handleOverflowMenuKeyDown}
              >
                {computedOverflowActions.map((action) => (
                  <li key={action.id} role="none">
                    <button
                      type="button"
                      role="menuitem"
                      className="rf-command-bar__overflow-item"
                      disabled={action.disabled}
                      onClick={() => activateAction(action)}
                    >
                      <span>{action.label}</span>
                      {action.shortcutHint && <kbd className="rf-command-bar__shortcut">{action.shortcutHint}</kbd>}
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </div>
        )}
      </div>
    </section>
  )
}
