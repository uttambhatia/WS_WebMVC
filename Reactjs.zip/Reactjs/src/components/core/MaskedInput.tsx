import './core.css'
import React from 'react'

export interface MaskedInputProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'value' | 'onChange'> {
  mask: string
  value?: string
  defaultValue?: string
  placeholderChar?: string
  onChange?: (value: string) => void
}

const TOKEN_REGEX: Record<string, RegExp> = {
  '#': /[0-9]/,
  A: /[a-zA-Z]/,
  '*': /[a-zA-Z0-9]/,
}

function applyMask(raw: string, mask: string, placeholderChar: string): string {
  const chars = raw.split('')
  let sourceIndex = 0
  let output = ''

  for (const token of mask) {
    const matcher = TOKEN_REGEX[token]
    if (!matcher) {
      output += token
      continue
    }

    let accepted = placeholderChar
    while (sourceIndex < chars.length) {
      const candidate = chars[sourceIndex]
      sourceIndex += 1
      if (matcher.test(candidate)) {
        accepted = candidate
        break
      }
    }

    output += accepted
  }

  return output
}

export function MaskedInput({
  mask,
  value,
  defaultValue = '',
  placeholderChar = '_',
  onChange,
  className,
  ...rest
}: MaskedInputProps) {
  const [internalValue, setInternalValue] = React.useState(() => applyMask(defaultValue, mask, placeholderChar))
  const current = value ?? internalValue

  return (
    <input
      {...rest}
      className={['rf-masked-input', className ?? ''].filter(Boolean).join(' ')}
      value={current}
      onChange={(event) => {
        const masked = applyMask(event.currentTarget.value, mask, placeholderChar)
        if (value === undefined) {
          setInternalValue(masked)
        }
        onChange?.(masked)
      }}
    />
  )
}
