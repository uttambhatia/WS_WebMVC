import React from 'react'
import type { CSSProperties } from 'react'

export interface GridProps {
  columns?: number | 'auto-fit' | 'auto-fill'
  minColWidth?: string
  gap?: 'none' | 'xs' | 'sm' | 'md' | 'lg' | 'xl'
  rowGap?: 'none' | 'xs' | 'sm' | 'md' | 'lg' | 'xl'
  as?: React.ElementType
  children?: React.ReactNode
  className?: string
}

const GAP_MAP: Record<NonNullable<GridProps['gap']>, string> = {
  none: '0',
  xs: 'var(--spacing-xs)',
  sm: 'var(--spacing-sm)',
  md: 'var(--spacing-md)',
  lg: 'var(--spacing-lg)',
  xl: 'var(--spacing-xl)',
}

function resolveColumns(
  columns: NonNullable<GridProps['columns']>,
  minColWidth: string
): string {
  if (typeof columns === 'number') {
    return `repeat(${columns}, 1fr)`
  }
  return `repeat(${columns}, minmax(${minColWidth}, 1fr))`
}

export function Grid({
  columns = 'auto-fit',
  minColWidth = '16rem',
  gap = 'md',
  rowGap,
  as: Tag = 'div',
  children,
  className,
  style,
  ...rest
}: GridProps & React.HTMLAttributes<HTMLElement>) {
  const inlineStyle: CSSProperties = {
    display: 'grid',
    gridTemplateColumns: resolveColumns(columns, minColWidth),
    gap: GAP_MAP[gap],
    ...(rowGap !== undefined ? { rowGap: GAP_MAP[rowGap] } : {}),
    ...style,
  }

  return (
    <Tag className={className} style={inlineStyle} {...rest}>
      {children}
    </Tag>
  )
}
