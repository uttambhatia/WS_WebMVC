import './core.css'
import React from 'react'

export interface DragAndDropListProps<T> {
  items: T[]
  renderItem: (item: T, index: number) => React.ReactNode
  getItemId: (item: T, index: number) => string
  onReorder?: (items: T[]) => void
  className?: string
}

function reorderItems<T>(items: T[], from: number, to: number): T[] {
  const next = items.slice()
  const [moved] = next.splice(from, 1)
  next.splice(to, 0, moved)
  return next
}

export function DragAndDropList<T>({
  items,
  renderItem,
  getItemId,
  onReorder,
  className,
}: DragAndDropListProps<T>) {
  const [dragId, setDragId] = React.useState<string | null>(null)

  const getIndexById = (id: string) => items.findIndex((item, index) => getItemId(item, index) === id)

  const move = (from: number, to: number) => {
    if (from < 0 || to < 0 || from === to || to >= items.length) {
      return
    }
    onReorder?.(reorderItems(items, from, to))
  }

  return (
    <ul className={['rf-dnd-list', className ?? ''].filter(Boolean).join(' ')} role="list">
      {items.map((item, index) => {
        const id = getItemId(item, index)
        return (
          <li
            key={id}
            className={[
              'rf-dnd-list__item',
              dragId === id ? 'rf-dnd-list__item--dragging' : '',
            ].filter(Boolean).join(' ')}
            role="listitem"
            draggable
            onDragStart={() => setDragId(id)}
            onDragEnd={() => setDragId(null)}
            onDragOver={(event) => event.preventDefault()}
            onDrop={() => {
              if (!dragId) {
                return
              }
              move(getIndexById(dragId), index)
              setDragId(null)
            }}
          >
            <div className="rf-dnd-list__content">{renderItem(item, index)}</div>
            <div className="rf-dnd-list__controls">
              <button
                type="button"
                className="rf-dnd-list__move"
                aria-label="Move item up"
                disabled={index === 0}
                onClick={() => move(index, index - 1)}
              >
                Up
              </button>
              <button
                type="button"
                className="rf-dnd-list__move"
                aria-label="Move item down"
                disabled={index === items.length - 1}
                onClick={() => move(index, index + 1)}
              >
                Down
              </button>
            </div>
          </li>
        )
      })}
    </ul>
  )
}
