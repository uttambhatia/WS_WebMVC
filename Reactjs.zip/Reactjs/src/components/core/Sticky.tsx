import './core.css'
import React from 'react'

type StickyTag = 'div' | 'section' | 'aside' | 'header' | 'footer' | 'nav' | 'main' | 'article'

export interface StickyProps extends React.HTMLAttributes<HTMLElement> {
  as?: StickyTag
  top?: string
  zIndex?: number
}

export function Sticky({
  as = 'div',
  top = 'var(--header-height, 0px)',
  zIndex = 10,
  className,
  style,
  children,
  ...rest
}: StickyProps) {
  const Component = as

  return (
    <Component
      {...rest}
      className={['rf-sticky', className ?? ''].filter(Boolean).join(' ')}
      style={{
        position: 'sticky',
        top,
        zIndex,
        ...style,
      }}
    >
      {children}
    </Component>
  )
}
