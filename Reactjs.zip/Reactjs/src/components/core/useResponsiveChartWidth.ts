import { useEffect, useRef, useState } from 'react'

/**
 * Tracks parent container width when responsive mode is enabled.
 * Falls back to the provided base width when measurement is unavailable.
 */
export function useResponsiveChartWidth<T extends HTMLElement>(baseWidth: number, responsive: boolean) {
  const containerRef = useRef<T | null>(null)
  const [measuredWidth, setMeasuredWidth] = useState(baseWidth)

  useEffect(() => {
    if (!responsive) {
      return
    }

    const element = containerRef.current
    if (!element) {
      return
    }

    const applyWidth = (nextWidth: number) => {
      if (!Number.isFinite(nextWidth) || nextWidth <= 0) {
        return
      }

      const rounded = Math.round(nextWidth)
      setMeasuredWidth((current) => (current === rounded ? current : rounded))
    }

    applyWidth(element.getBoundingClientRect().width)

    if (typeof ResizeObserver === 'undefined') {
      return
    }

    const observer = new ResizeObserver((entries) => {
      for (const entry of entries) {
        applyWidth(entry.contentRect.width)
      }
    })

    observer.observe(element)
    return () => observer.disconnect()
  }, [responsive])

  return {
    containerRef,
    width: responsive ? measuredWidth : baseWidth,
  }
}
