import './core.css'

export interface WorkflowStep {
  id: string
  label: string
  description?: string
  canEnter?: (currentStepId: string, nextStepId: string) => boolean
}

export interface WorkflowStepperProps {
  steps: WorkflowStep[]
  currentStepId: string
  onStepChange: (nextStepId: string) => void
  onComplete?: () => void
  className?: string
}

export function WorkflowStepper({
  steps,
  currentStepId,
  onStepChange,
  onComplete,
  className,
}: WorkflowStepperProps) {
  const currentIndex = Math.max(0, steps.findIndex((step) => step.id === currentStepId))
  const currentStep = steps[currentIndex]

  function goToStep(nextIndex: number) {
    const bounded = Math.min(steps.length - 1, Math.max(0, nextIndex))
    const nextStep = steps[bounded]
    if (!nextStep || !currentStep) return

    if (nextStep.canEnter && !nextStep.canEnter(currentStep.id, nextStep.id)) {
      return
    }

    onStepChange(nextStep.id)
  }

  return (
    <section className={['rf-workflow-stepper', className ?? ''].filter(Boolean).join(' ')}>
      <ol className="rf-workflow-stepper__list">
        {steps.map((step, index) => {
          const state = index < currentIndex ? 'complete' : index === currentIndex ? 'active' : 'pending'
          return (
            <li key={step.id} className={`rf-workflow-stepper__item rf-workflow-stepper__item--${state}`}>
              <button
                type="button"
                className="rf-workflow-stepper__jump"
                disabled={index > currentIndex + 1}
                onClick={() => goToStep(index)}
              >
                <span className="rf-workflow-stepper__index">{index + 1}</span>
                <span>
                  <strong>{step.label}</strong>
                  {step.description ? <small>{step.description}</small> : null}
                </span>
              </button>
            </li>
          )
        })}
      </ol>

      <footer className="rf-workflow-stepper__actions">
        <button type="button" className="rf-workflow-stepper__btn" onClick={() => goToStep(currentIndex - 1)} disabled={currentIndex === 0}>
          Back
        </button>
        {currentIndex < steps.length - 1 ? (
          <button type="button" className="rf-workflow-stepper__btn rf-workflow-stepper__btn--primary" onClick={() => goToStep(currentIndex + 1)}>
            Next
          </button>
        ) : (
          <button type="button" className="rf-workflow-stepper__btn rf-workflow-stepper__btn--primary" onClick={onComplete}>
            Complete
          </button>
        )}
      </footer>
    </section>
  )
}
