import './core.css'
import React from 'react'

export interface ColorPickerProps {
  value?: string
  defaultValue?: string
  swatches?: string[]
  disabled?: boolean
  onChange?: (value: string) => void
  className?: string
}

const HEX_COLOR = /^#[0-9a-fA-F]{6}$/

const DEFAULT_SWATCHES = [
  '#0b5fff',
  '#16a34a',
  '#f59e0b',
  '#ef4444',
  '#7c3aed',
  '#0f172a',
]

function normalizeColor(input: string): string {
  if (!input.startsWith('#')) {
    return `#${input}`
  }
  return input
}

export function ColorPicker({
  value,
  defaultValue = '#0b5fff',
  swatches = DEFAULT_SWATCHES,
  disabled = false,
  onChange,
  className,
}: ColorPickerProps) {
  const [internalValue, setInternalValue] = React.useState(defaultValue)
  const current = value ?? internalValue

  const update = (next: string) => {
    const normalized = normalizeColor(next)
    if (!HEX_COLOR.test(normalized)) {
      return
    }

    if (value === undefined) {
      setInternalValue(normalized)
    }
    onChange?.(normalized)
  }

  return (
    <div className={['rf-color-picker', className ?? ''].filter(Boolean).join(' ')}>
      <div className="rf-color-picker__swatches" role="list" aria-label="Color swatches">
        {swatches.map((swatch) => (
          <button
            key={swatch}
            type="button"
            role="listitem"
            className={[
              'rf-color-picker__swatch',
              swatch.toLowerCase() === current.toLowerCase() ? 'rf-color-picker__swatch--active' : '',
            ].filter(Boolean).join(' ')}
            style={{ backgroundColor: swatch }}
            aria-label={`Select ${swatch}`}
            disabled={disabled}
            onClick={() => update(swatch)}
          />
        ))}
      </div>

      <div className="rf-color-picker__inputs">
        <input
          type="color"
          value={current}
          disabled={disabled}
          className="rf-color-picker__native"
          aria-label="Color wheel picker"
          onChange={(event) => update(event.currentTarget.value)}
        />
        <input
          type="text"
          value={current}
          disabled={disabled}
          className="rf-color-picker__hex"
          aria-label="Hex color"
          onChange={(event) => {
            const next = normalizeColor(event.currentTarget.value)
            if (value === undefined) {
              setInternalValue(next)
            }
            if (HEX_COLOR.test(next)) {
              onChange?.(next)
            }
          }}
        />
      </div>
    </div>
  )
}
