export interface InputProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'size'> {
  /** HTML input type. Defaults to `'text'`. */
  type?: 'text' | 'email' | 'password' | 'number'
  /** Size variant matching the design token scale. Defaults to `'md'`. */
  size?: 'sm' | 'md' | 'lg'
  /**
   * When truthy, applies error styling and sets `aria-invalid="true"`.
   * Pass a string to provide a message (used by FormField's error span);
   * pass `true` to apply only visual error state without a message here.
   */
  error?: boolean | string
  /** Additional class names merged on top of the base classes. */
  className?: string
}

/**
 * Text input component with size variants and validation state styling.
 *
 * @example
 * ```tsx
 * <FormField id="name" label="Full name" error={errors.name}>
 *   <Input
 *     id="name"
 *     value={name}
 *     onChange={(e) => setName(e.target.value)}
 *     aria-describedby={errors.name ? 'name-error' : undefined}
 *     error={!!errors.name}
 *   />
 * </FormField>
 * ```
 *
 * @remarks
 * Pass `aria-describedby="{id}-error"` or `"{id}-help"` (from the parent
 * FormField) to wire screen reader descriptions. This is explicit by design.
 */
export function Input({
  type = 'text',
  size = 'md',
  error,
  className,
  ...rest
}: InputProps) {
  const hasError = Boolean(error)

  const classes = [
    'rf-input',
    `rf-input--${size}`,
    hasError ? 'rf-input--error' : '',
    className ?? '',
  ]
    .filter(Boolean)
    .join(' ')

  return (
    <input
      type={type}
      className={classes}
      aria-invalid={hasError ? 'true' : undefined}
      {...rest}
    />
  )
}
