import './core.css'

export interface ProgressBarProps {
  value?: number
  max?: number
  label?: string
  className?: string
}

export function ProgressBar({
  value,
  max = 100,
  label,
  className,
}: ProgressBarProps) {
  const isIndeterminate = value === undefined
  const clamped = isIndeterminate ? 0 : Math.max(0, Math.min(max, value))
  const width = isIndeterminate ? undefined : `${(clamped / max) * 100}%`

  return (
    <div className={['rf-progress', className ?? ''].filter(Boolean).join(' ')}>
      {label && <span className="rf-progress__label">{label}</span>}
      <div
        className={['rf-progress__track', isIndeterminate ? 'rf-progress__track--indeterminate' : ''].filter(Boolean).join(' ')}
        role="progressbar"
        aria-valuemin={isIndeterminate ? undefined : 0}
        aria-valuemax={isIndeterminate ? undefined : max}
        aria-valuenow={isIndeterminate ? undefined : clamped}
      >
        <span className="rf-progress__fill" style={width ? { width } : undefined} />
      </div>
    </div>
  )
}
