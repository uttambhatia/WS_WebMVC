import './core.css'
import React from 'react'

export interface SignaturePadProps {
  width?: number
  height?: number
  disabled?: boolean
  onChange?: (dataUrl: string) => void
  clearLabel?: string
  className?: string
}

export function SignaturePad({
  width = 360,
  height = 160,
  disabled = false,
  onChange,
  clearLabel = 'Clear',
  className,
}: SignaturePadProps) {
  const canvasRef = React.useRef<HTMLCanvasElement | null>(null)
  const drawingRef = React.useRef(false)
  const lastPointRef = React.useRef<{ x: number; y: number } | null>(null)

  const emit = () => {
    const canvas = canvasRef.current
    if (!canvas || typeof canvas.toDataURL !== 'function') {
      onChange?.('')
      return
    }
    onChange?.(canvas.toDataURL('image/png'))
  }

  const getPoint = (event: React.PointerEvent<HTMLCanvasElement>) => {
    const rect = event.currentTarget.getBoundingClientRect()
    return {
      x: event.clientX - rect.left,
      y: event.clientY - rect.top,
    }
  }

  const drawSegment = (from: { x: number; y: number }, to: { x: number; y: number }) => {
    const canvas = canvasRef.current
    const context = canvas?.getContext('2d')
    if (!canvas || !context) {
      return
    }

    context.strokeStyle = 'var(--text)'
    context.lineWidth = 2
    context.lineCap = 'round'
    context.beginPath()
    context.moveTo(from.x, from.y)
    context.lineTo(to.x, to.y)
    context.stroke()
  }

  return (
    <div className={['rf-signature-pad', className ?? ''].filter(Boolean).join(' ')}>
      <canvas
        ref={canvasRef}
        className="rf-signature-pad__canvas"
        width={width}
        height={height}
        role="img"
        aria-label="Signature drawing area"
        onPointerDown={(event) => {
          if (disabled) {
            return
          }
          drawingRef.current = true
          lastPointRef.current = getPoint(event)
        }}
        onPointerMove={(event) => {
          if (disabled || !drawingRef.current) {
            return
          }
          const next = getPoint(event)
          if (lastPointRef.current) {
            drawSegment(lastPointRef.current, next)
          }
          lastPointRef.current = next
        }}
        onPointerUp={() => {
          if (disabled) {
            return
          }
          drawingRef.current = false
          lastPointRef.current = null
          emit()
        }}
        onPointerLeave={() => {
          if (!drawingRef.current) {
            return
          }
          drawingRef.current = false
          lastPointRef.current = null
          emit()
        }}
      />
      <button
        type="button"
        className="rf-signature-pad__clear"
        disabled={disabled}
        onClick={() => {
          const canvas = canvasRef.current
          const context = canvas?.getContext('2d')
          if (canvas && context) {
            context.clearRect(0, 0, canvas.width, canvas.height)
          }
          emit()
        }}
      >
        {clearLabel}
      </button>
    </div>
  )
}
