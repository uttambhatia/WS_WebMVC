import './core.css'

export interface StepperStep {
  id: string
  label: React.ReactNode
  status?: 'pending' | 'active' | 'complete'
}

export interface StepperProps {
  steps: StepperStep[]
  currentStepId?: string
  className?: string
}

export function Stepper({ steps, currentStepId, className }: StepperProps) {
  return (
    <ol className={['rf-stepper', className ?? ''].filter(Boolean).join(' ')}>
      {steps.map((step, index) => {
        const state = step.status ?? (step.id === currentStepId ? 'active' : 'pending')
        return (
          <li key={step.id} className={['rf-stepper__step', `rf-stepper__step--${state}`].join(' ')}>
            <span className="rf-stepper__index" aria-hidden="true">{index + 1}</span>
            <span className="rf-stepper__label">{step.label}</span>
          </li>
        )
      })}
    </ol>
  )
}
