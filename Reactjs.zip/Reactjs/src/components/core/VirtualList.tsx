import './core.css'
import React from 'react'

export interface VirtualListProps<T> {
  items: T[]
  itemHeight: number
  renderItem: (item: T, index: number) => React.ReactNode
  height: number
  overscan?: number
  getItemKey?: (item: T, index: number) => string | number
  className?: string
}

export function VirtualList<T>({
  items,
  itemHeight,
  renderItem,
  height,
  overscan = 3,
  getItemKey,
  className,
}: VirtualListProps<T>) {
  const [scrollTop, setScrollTop] = React.useState(0)

  const totalHeight = items.length * itemHeight
  const visibleCount = Math.ceil(height / itemHeight)

  const startIndex = Math.max(0, Math.floor(scrollTop / itemHeight) - overscan)
  const endIndex = Math.min(items.length - 1, startIndex + visibleCount + overscan * 2)

  const visibleItems = items.slice(startIndex, endIndex + 1)
  const offsetY = startIndex * itemHeight

  function handleScroll(event: React.UIEvent<HTMLDivElement>) {
    setScrollTop(event.currentTarget.scrollTop)
  }

  return (
    <div
      className={['rf-virtual-list', className ?? ''].filter(Boolean).join(' ')}
      style={{ height, overflow: 'auto', position: 'relative' }}
      onScroll={handleScroll}
      role="list"
    >
      <div className="rf-virtual-list__inner" style={{ height: totalHeight, position: 'relative' }}>
        <div style={{ transform: `translateY(${offsetY}px)` }}>
          {visibleItems.map((item, localIndex) => {
            const actualIndex = startIndex + localIndex
            const key = getItemKey ? getItemKey(item, actualIndex) : actualIndex
            return (
              <div
                key={key}
                className="rf-virtual-list__item"
                style={{ height: itemHeight }}
                role="listitem"
              >
                {renderItem(item, actualIndex)}
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}
