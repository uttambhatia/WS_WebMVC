import './core.css'
import React from 'react'
import { createPortal } from 'react-dom'

export interface LightBoxItem {
  src: string
  alt?: string
  caption?: React.ReactNode
}

export interface LightBoxProps {
  open: boolean
  items: LightBoxItem[]
  initialIndex?: number
  onClose: () => void
  onIndexChange?: (index: number) => void
  className?: string
}

export function LightBox({
  open,
  items,
  initialIndex = 0,
  onClose,
  onIndexChange,
  className,
}: LightBoxProps) {
  const [internalIndex, setInternalIndex] = React.useState(initialIndex)
  const index = Math.max(0, Math.min(items.length - 1, internalIndex))
  const item = items[index]

  React.useEffect(() => {
    setInternalIndex(initialIndex)
  }, [initialIndex, open])

  React.useEffect(() => {
    if (!open) {
      return
    }

    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        event.preventDefault()
        onClose()
        return
      }
      if (event.key === 'ArrowRight') {
        event.preventDefault()
        setInternalIndex((current) => Math.min(items.length - 1, current + 1))
        return
      }
      if (event.key === 'ArrowLeft') {
        event.preventDefault()
        setInternalIndex((current) => Math.max(0, current - 1))
      }
    }

    document.addEventListener('keydown', onKeyDown)
    return () => document.removeEventListener('keydown', onKeyDown)
  }, [items.length, onClose, open])

  React.useEffect(() => {
    onIndexChange?.(index)
  }, [index, onIndexChange])

  if (!open || !item || typeof document === 'undefined') {
    return null
  }

  return createPortal(
    <div className="rf-lightbox__backdrop" role="dialog" aria-modal="true" aria-label="Media viewer">
      <div className={['rf-lightbox', className ?? ''].filter(Boolean).join(' ')}>
        <button type="button" className="rf-lightbox__close" onClick={onClose} aria-label="Close">×</button>
        <div className="rf-lightbox__content">
          <button
            type="button"
            className="rf-lightbox__nav"
            disabled={index === 0}
            onClick={() => setInternalIndex((current) => Math.max(0, current - 1))}
            aria-label="Previous"
          >
            Prev
          </button>
          <figure className="rf-lightbox__figure">
            <img className="rf-lightbox__image" src={item.src} alt={item.alt ?? 'Lightbox image'} />
            {item.caption && <figcaption className="rf-lightbox__caption">{item.caption}</figcaption>}
          </figure>
          <button
            type="button"
            className="rf-lightbox__nav"
            disabled={index === items.length - 1}
            onClick={() => setInternalIndex((current) => Math.min(items.length - 1, current + 1))}
            aria-label="Next"
          >
            Next
          </button>
        </div>
      </div>
    </div>,
    document.body,
  )
}
