import './core.css'

export interface SparklineProps {
  data: number[]
  width?: number
  height?: number
  color?: string
  fillColor?: string
  strokeWidth?: number
  className?: string
}

export function Sparkline({
  data,
  width = 80,
  height = 32,
  color = 'var(--color-primary)',
  fillColor,
  strokeWidth = 1.5,
  className,
}: SparklineProps) {
  if (data.length < 2) {
    return (
      <svg
        className={['rf-sparkline', className ?? ''].filter(Boolean).join(' ')}
        width={width}
        height={height}
        aria-hidden="true"
      />
    )
  }

  const min = Math.min(...data)
  const max = Math.max(...data)
  const range = max - min || 1

  const padding = strokeWidth
  const innerWidth = width - padding * 2
  const innerHeight = height - padding * 2

  const points = data.map((value, index) => {
    const x = padding + (index / (data.length - 1)) * innerWidth
    const y = padding + innerHeight - ((value - min) / range) * innerHeight
    return [x, y] as [number, number]
  })

  const polylinePoints = points.map(([x, y]) => `${x},${y}`).join(' ')

  let fillPath: string | undefined
  if (fillColor) {
    const first = points[0]
    const last = points[points.length - 1]
    fillPath = [
      `M ${first[0]},${height - padding}`,
      points.map(([x, y]) => `L ${x},${y}`).join(' '),
      `L ${last[0]},${height - padding}`,
      'Z',
    ].join(' ')
  }

  return (
    <svg
      className={['rf-sparkline', className ?? ''].filter(Boolean).join(' ')}
      width={width}
      height={height}
      viewBox={`0 0 ${width} ${height}`}
      aria-hidden="true"
    >
      {fillColor && fillPath && (
        <path d={fillPath} fill={fillColor} stroke="none" />
      )}
      <polyline
        points={polylinePoints}
        fill="none"
        stroke={color}
        strokeWidth={strokeWidth}
        strokeLinejoin="round"
        strokeLinecap="round"
      />
    </svg>
  )
}
