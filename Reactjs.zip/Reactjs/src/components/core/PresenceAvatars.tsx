import './core.css'

export interface PresenceUser {
  id: string
  name: string
  avatarUrl?: string
  status?: 'online' | 'away' | 'offline'
}

export interface PresenceAvatarsProps {
  users: PresenceUser[]
  maxVisible?: number
}

function initials(name: string): string {
  const parts = name.split(/\s+/).filter(Boolean)
  return parts.slice(0, 2).map((part) => part[0]?.toUpperCase() ?? '').join('')
}

export function PresenceAvatars({ users, maxVisible = 4 }: PresenceAvatarsProps) {
  const visible = users.slice(0, maxVisible)
  const overflow = Math.max(0, users.length - maxVisible)

  return (
    <div className="rf-presence" role="list" aria-label="Active users">
      {visible.map((user) => (
        <span key={user.id} className={`rf-presence__avatar rf-presence__avatar--${user.status ?? 'online'}`} role="listitem" title={user.name}>
          {user.avatarUrl ? <img src={user.avatarUrl} alt={user.name} /> : initials(user.name)}
        </span>
      ))}
      {overflow > 0 ? <span className="rf-presence__overflow">+{overflow}</span> : null}
    </div>
  )
}
