import './core.css'
import React from 'react'
import { PinInput } from './PinInput'

export interface MfaChallengeProps {
  length?: number
  expiresInSeconds?: number
  resendLabel?: string
  verifyLabel?: string
  onSubmit: (code: string) => void
  onResend?: () => void
  className?: string
}

export function MfaChallenge({
  length = 6,
  expiresInSeconds = 30,
  resendLabel = 'Resend code',
  verifyLabel = 'Verify',
  onSubmit,
  onResend,
  className,
}: MfaChallengeProps) {
  const [code, setCode] = React.useState('')
  const [remaining, setRemaining] = React.useState(expiresInSeconds)

  React.useEffect(() => {
    if (remaining <= 0) {
      return
    }

    const timer = window.setInterval(() => {
      setRemaining((current) => Math.max(0, current - 1))
    }, 1000)

    return () => {
      window.clearInterval(timer)
    }
  }, [remaining])

  const canSubmit = code.length === length

  return (
    <div className={['rf-mfa-challenge', className ?? ''].filter(Boolean).join(' ')}>
      <PinInput
        length={length}
        value={code}
        numericOnly
        onChange={setCode}
        onComplete={setCode}
      />

      <div className="rf-mfa-challenge__actions">
        <button
          type="button"
          className="rf-mfa-challenge__verify"
          disabled={!canSubmit}
          onClick={() => onSubmit(code)}
        >
          {verifyLabel}
        </button>

        <button
          type="button"
          className="rf-mfa-challenge__resend"
          disabled={remaining > 0}
          onClick={() => {
            setRemaining(expiresInSeconds)
            setCode('')
            onResend?.()
          }}
        >
          {remaining > 0 ? `${resendLabel} (${remaining}s)` : resendLabel}
        </button>
      </div>
    </div>
  )
}
