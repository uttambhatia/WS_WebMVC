import './core.css'
import React from 'react'

export interface SchedulerTimelineItem {
  id: string
  resourceId: string
  label: string
  start: number
  end: number
}

export interface SchedulerTimelineResource {
  id: string
  label: string
}

export interface SchedulerTimelineProps {
  resources: SchedulerTimelineResource[]
  items: SchedulerTimelineItem[]
  startHour?: number
  endHour?: number
  hourWidth?: number
  onItemsChange?: (items: SchedulerTimelineItem[]) => void
}

interface DragState {
  itemId: string
  originX: number
  originStart: number
  originEnd: number
}

export function SchedulerTimeline({
  resources,
  items,
  startHour = 8,
  endHour = 20,
  hourWidth = 56,
  onItemsChange,
}: SchedulerTimelineProps) {
  const [dragState, setDragState] = React.useState<DragState | null>(null)
  const totalHours = Math.max(1, endHour - startHour)

  React.useEffect(() => {
    if (!dragState) return

    const activeDrag = dragState

    function handleMove(event: PointerEvent) {
      const deltaHours = Math.round((event.clientX - activeDrag.originX) / hourWidth)
      const nextStart = Math.max(startHour, activeDrag.originStart + deltaHours)
      const duration = activeDrag.originEnd - activeDrag.originStart
      const nextEnd = Math.min(endHour, nextStart + duration)

      onItemsChange?.(items.map((item) => item.id === activeDrag.itemId
        ? { ...item, start: nextStart, end: nextEnd }
        : item))
    }

    function handleUp() {
      setDragState(null)
    }

    window.addEventListener('pointermove', handleMove)
    window.addEventListener('pointerup', handleUp)

    return () => {
      window.removeEventListener('pointermove', handleMove)
      window.removeEventListener('pointerup', handleUp)
    }
  }, [dragState, endHour, hourWidth, items, onItemsChange, startHour])

  function nudge(itemId: string, delta: number) {
    onItemsChange?.(items.map((item) => {
      if (item.id !== itemId) return item
      const duration = item.end - item.start
      const nextStart = Math.max(startHour, Math.min(endHour - duration, item.start + delta))
      return {
        ...item,
        start: nextStart,
        end: nextStart + duration,
      }
    }))
  }

  return (
    <section className="rf-scheduler-timeline" aria-label="Scheduler timeline">
      <header className="rf-scheduler-timeline__hours">
        <span className="rf-scheduler-timeline__resource-head">Resource</span>
        <div className="rf-scheduler-timeline__hour-strip" style={{ width: totalHours * hourWidth }}>
          {Array.from({ length: totalHours }).map((_, index) => (
            <span key={index} style={{ width: hourWidth }}>{startHour + index}:00</span>
          ))}
        </div>
      </header>

      {resources.map((resource) => {
        const resourceItems = items.filter((item) => item.resourceId === resource.id)

        return (
          <div key={resource.id} className="rf-scheduler-timeline__row">
            <div className="rf-scheduler-timeline__resource">{resource.label}</div>
            <div className="rf-scheduler-timeline__track" style={{ width: totalHours * hourWidth }}>
              {resourceItems.map((item) => {
                const left = (item.start - startHour) * hourWidth
                const width = Math.max(hourWidth * 0.75, (item.end - item.start) * hourWidth)
                return (
                  <button
                    key={item.id}
                    type="button"
                    className="rf-scheduler-timeline__item"
                    style={{ left, width }}
                    onPointerDown={(event) => {
                      event.currentTarget.setPointerCapture(event.pointerId)
                      setDragState({
                        itemId: item.id,
                        originX: event.clientX,
                        originStart: item.start,
                        originEnd: item.end,
                      })
                    }}
                    onKeyDown={(event) => {
                      if (event.key === 'ArrowLeft') {
                        event.preventDefault()
                        nudge(item.id, -1)
                      }
                      if (event.key === 'ArrowRight') {
                        event.preventDefault()
                        nudge(item.id, 1)
                      }
                    }}
                    aria-label={`${item.label} from ${item.start} to ${item.end}`}
                  >
                    <span>{item.label}</span>
                  </button>
                )
              })}
            </div>
          </div>
        )
      })}
    </section>
  )
}
