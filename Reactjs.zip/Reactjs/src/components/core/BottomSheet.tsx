import './core.css'
import React from 'react'
import { createPortal } from 'react-dom'

export interface BottomSheetProps {
  open: boolean
  title?: React.ReactNode
  children: React.ReactNode
  onClose: () => void
  closeOnBackdropClick?: boolean
  className?: string
}

export function BottomSheet({
  open,
  title,
  children,
  onClose,
  closeOnBackdropClick = true,
  className,
}: BottomSheetProps) {
  React.useEffect(() => {
    if (!open) {
      return
    }

    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        event.preventDefault()
        onClose()
      }
    }

    document.addEventListener('keydown', onKeyDown)
    return () => document.removeEventListener('keydown', onKeyDown)
  }, [onClose, open])

  if (!open || typeof document === 'undefined') {
    return null
  }

  return createPortal(
    <div
      className="rf-bottom-sheet__backdrop"
      onMouseDown={(event) => {
        if (event.target !== event.currentTarget) {
          return
        }
        if (closeOnBackdropClick) {
          onClose()
        }
      }}
    >
      <section className={['rf-bottom-sheet', className ?? ''].filter(Boolean).join(' ')} role="dialog" aria-modal="true">
        <div className="rf-bottom-sheet__grabber" aria-hidden="true" />
        {title && <h3 className="rf-bottom-sheet__title">{title}</h3>}
        <div className="rf-bottom-sheet__content">{children}</div>
      </section>
    </div>,
    document.body,
  )
}
