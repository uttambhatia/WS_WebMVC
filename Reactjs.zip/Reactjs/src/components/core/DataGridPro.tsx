import './core.css'
import React from 'react'

export interface DataGridProColumn<T extends Record<string, unknown>> {
  key: keyof T
  header: React.ReactNode
  width?: number
  minWidth?: number
  editable?: boolean
  pinned?: 'left'
  render?: (value: T[keyof T], row: T, rowIndex: number) => React.ReactNode
}

export interface DataGridProProps<T extends Record<string, unknown>> {
  columns: Array<DataGridProColumn<T>>
  rows: T[]
  getRowId?: (row: T, rowIndex: number) => string
  rowHeight?: number
  viewportHeight?: number
  onRowsChange?: (rows: T[]) => void
  className?: string
}

function toCellText(value: unknown): string {
  if (value === null || value === undefined) return ''
  if (typeof value === 'object') return JSON.stringify(value)
  return String(value)
}

export function DataGridPro<T extends Record<string, unknown>>({
  columns,
  rows,
  getRowId,
  rowHeight = 40,
  viewportHeight = 320,
  onRowsChange,
  className,
}: DataGridProProps<T>) {
  const [columnOrder, setColumnOrder] = React.useState(() => columns.map((column) => column.key))
  const [columnWidths, setColumnWidths] = React.useState(() => {
    const initial: Partial<Record<keyof T, number>> = {}
    columns.forEach((column) => {
      initial[column.key] = column.width ?? 180
    })
    return initial
  })
  const [scrollTop, setScrollTop] = React.useState(0)
  const [editingCell, setEditingCell] = React.useState<{ rowIndex: number, key: keyof T } | null>(null)

  const resolvedGetRowId = React.useMemo(
    () => getRowId ?? ((_row: T, rowIndex: number) => String(rowIndex)),
    [getRowId],
  )

  const orderedColumns = React.useMemo(() => {
    const byKey = new Map(columns.map((column) => [String(column.key), column]))
    const selected = columnOrder
      .map((key) => byKey.get(String(key)))
      .filter((column): column is DataGridProColumn<T> => Boolean(column))
    const remainder = columns.filter((column) => !columnOrder.includes(column.key))
    return [...selected, ...remainder]
  }, [columnOrder, columns])

  const pinnedOffsets = React.useMemo(() => {
    let runningLeft = 0
    const offsets = new Map<string, number>()
    orderedColumns.forEach((column) => {
      if (column.pinned === 'left') {
        offsets.set(String(column.key), runningLeft)
        runningLeft += columnWidths[column.key] ?? column.width ?? 180
      }
    })
    return offsets
  }, [columnWidths, orderedColumns])

  const total = rows.length
  const visibleCount = Math.max(1, Math.ceil(viewportHeight / rowHeight) + 4)
  const start = Math.max(0, Math.floor(scrollTop / rowHeight) - 2)
  const end = Math.min(total, start + visibleCount)
  const topSpacer = start * rowHeight
  const bottomSpacer = Math.max(0, (total - end) * rowHeight)
  const windowRows = rows.slice(start, end)

  function moveColumn(key: keyof T, delta: -1 | 1) {
    setColumnOrder((previous) => {
      const base = previous.length ? [...previous] : columns.map((column) => column.key)
      const currentIndex = base.findIndex((entry) => entry === key)
      if (currentIndex < 0) return previous

      const nextIndex = currentIndex + delta
      if (nextIndex < 0 || nextIndex >= base.length) return previous

      const next = [...base]
      const [moved] = next.splice(currentIndex, 1)
      next.splice(nextIndex, 0, moved)
      return next
    })
  }

  function updateCellValue(rowIndex: number, key: keyof T, value: string) {
    const nextRows = [...rows]
    const nextRow = { ...nextRows[rowIndex], [key]: value }
    nextRows[rowIndex] = nextRow
    onRowsChange?.(nextRows)
  }

  async function copyCsv() {
    const headers = orderedColumns.map((column) => String(column.header))
    const lines = rows.map((row) => orderedColumns.map((column) => {
      const raw = toCellText(row[column.key])
      const escaped = raw.replaceAll('"', '""')
      return `"${escaped}"`
    }).join(','))

    const csv = [headers.join(','), ...lines].join('\n')

    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(csv)
    }
  }

  return (
    <section className={['rf-data-grid-pro', className ?? ''].filter(Boolean).join(' ')}>
      <header className="rf-data-grid-pro__toolbar">
        <strong>DataGrid Pro</strong>
        <button type="button" className="rf-data-grid-pro__btn" onClick={() => { void copyCsv() }}>
          Copy CSV
        </button>
      </header>

      <div className="rf-data-grid-pro__table-wrap">
        <table className="rf-data-grid-pro__table">
          <thead>
            <tr>
              {orderedColumns.map((column) => {
                const width = columnWidths[column.key] ?? column.width ?? 180
                const isPinned = column.pinned === 'left'
                const style: React.CSSProperties = {
                  width,
                  minWidth: column.minWidth ?? 120,
                  ...(isPinned ? { left: pinnedOffsets.get(String(column.key)) ?? 0 } : null),
                }

                return (
                  <th
                    key={String(column.key)}
                    style={style}
                    className={isPinned ? 'rf-data-grid-pro__cell rf-data-grid-pro__cell--pinned' : 'rf-data-grid-pro__cell'}
                    scope="col"
                  >
                    <div className="rf-data-grid-pro__head">
                      <span>{column.header}</span>
                      <div className="rf-data-grid-pro__head-actions">
                        <button type="button" onClick={() => moveColumn(column.key, -1)} aria-label="Move column left">←</button>
                        <button type="button" onClick={() => moveColumn(column.key, 1)} aria-label="Move column right">→</button>
                      </div>
                    </div>
                    <input
                      className="rf-data-grid-pro__resize"
                      type="range"
                      min={column.minWidth ?? 120}
                      max={420}
                      value={width}
                      onChange={(event) => {
                        const next = Number(event.currentTarget.value)
                        setColumnWidths((previous) => ({ ...previous, [column.key]: next }))
                      }}
                      aria-label={`Resize ${String(column.header)} column`}
                    />
                  </th>
                )
              })}
            </tr>
          </thead>
        </table>
      </div>

      <div
        className="rf-data-grid-pro__viewport"
        style={{ height: viewportHeight }}
        onScroll={(event) => setScrollTop(event.currentTarget.scrollTop)}
      >
        <div style={{ height: topSpacer }} aria-hidden="true" />

        <table className="rf-data-grid-pro__table">
          <tbody>
            {windowRows.map((row, localIndex) => {
              const rowIndex = start + localIndex
              return (
                <tr key={resolvedGetRowId(row, rowIndex)} style={{ height: rowHeight }}>
                  {orderedColumns.map((column) => {
                    const width = columnWidths[column.key] ?? column.width ?? 180
                    const value = row[column.key]
                    const isEditing = editingCell?.rowIndex === rowIndex && editingCell?.key === column.key
                    const isPinned = column.pinned === 'left'
                    const style: React.CSSProperties = {
                      width,
                      minWidth: column.minWidth ?? 120,
                      ...(isPinned ? { left: pinnedOffsets.get(String(column.key)) ?? 0 } : null),
                    }

                    return (
                      <td
                        key={`${resolvedGetRowId(row, rowIndex)}-${String(column.key)}`}
                        style={style}
                        className={isPinned ? 'rf-data-grid-pro__cell rf-data-grid-pro__cell--pinned' : 'rf-data-grid-pro__cell'}
                        onDoubleClick={() => {
                          if (column.editable) setEditingCell({ rowIndex, key: column.key })
                        }}
                      >
                        {isEditing ? (
                          <input
                            autoFocus
                            className="rf-data-grid-pro__inline-edit"
                            defaultValue={toCellText(value)}
                            onBlur={(event) => {
                              updateCellValue(rowIndex, column.key, event.currentTarget.value)
                              setEditingCell(null)
                            }}
                            onKeyDown={(event) => {
                              if (event.key === 'Enter') {
                                updateCellValue(rowIndex, column.key, (event.currentTarget as HTMLInputElement).value)
                                setEditingCell(null)
                              }
                              if (event.key === 'Escape') {
                                setEditingCell(null)
                              }
                            }}
                          />
                        ) : column.render ? (
                          column.render(value, row, rowIndex)
                        ) : (
                          toCellText(value)
                        )}
                      </td>
                    )
                  })}
                </tr>
              )
            })}
          </tbody>
        </table>

        <div style={{ height: bottomSpacer }} aria-hidden="true" />
      </div>
    </section>
  )
}
