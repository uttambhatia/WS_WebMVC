import './core.css'
import React from 'react'

export interface TooltipProps {
  content: React.ReactNode
  children: React.ReactNode
  position?: 'top' | 'right' | 'bottom' | 'left'
  className?: string
}

export function Tooltip({
  content,
  children,
  position = 'top',
  className,
}: TooltipProps) {
  const [visible, setVisible] = React.useState(false)

  return (
    <span
      className={['rf-tooltip', className ?? ''].filter(Boolean).join(' ')}
      onMouseEnter={() => setVisible(true)}
      onMouseLeave={() => setVisible(false)}
      onFocus={() => setVisible(true)}
      onBlur={() => setVisible(false)}
    >
      <span className="rf-tooltip__trigger">{children}</span>
      <span
        role="tooltip"
        className={[
          'rf-tooltip__content',
          `rf-tooltip__content--${position}`,
          visible ? 'rf-tooltip__content--visible' : '',
        ].filter(Boolean).join(' ')}
      >
        {content}
      </span>
    </span>
  )
}
