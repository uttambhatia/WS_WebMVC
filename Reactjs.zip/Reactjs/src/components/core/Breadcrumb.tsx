import './core.css'
import { Link } from 'react-router-dom'

export interface BreadcrumbItem {
  label: React.ReactNode
  href?: string
}

export interface BreadcrumbProps {
  items: BreadcrumbItem[]
  separator?: React.ReactNode
  className?: string
  'aria-label'?: string
}

export function Breadcrumb({
  items,
  separator = '/',
  className,
  'aria-label': ariaLabel = 'Breadcrumb',
}: BreadcrumbProps) {
  return (
    <nav aria-label={ariaLabel} className={['rf-breadcrumb', className ?? ''].filter(Boolean).join(' ')}>
      <ol className="rf-breadcrumb__list">
        {items.map((item, index) => {
          const isLast = index === items.length - 1
          return (
            <li key={`${String(item.label)}-${index}`} className="rf-breadcrumb__item">
              {item.href && !isLast ? (
                <Link className="rf-breadcrumb__link" to={item.href}>{item.label}</Link>
              ) : (
                <span className="rf-breadcrumb__current" aria-current={isLast ? 'page' : undefined}>
                  {item.label}
                </span>
              )}
              {!isLast && <span className="rf-breadcrumb__separator" aria-hidden="true">{separator}</span>}
            </li>
          )
        })}
      </ol>
    </nav>
  )
}
