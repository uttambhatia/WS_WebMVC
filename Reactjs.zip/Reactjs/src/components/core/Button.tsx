import './core.css'

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  /** Visual style of the button. Defaults to `'primary'`. */
  variant?: 'primary' | 'secondary' | 'outline' | 'text'
  /** Size of the button. Defaults to `'md'`. */
  size?: 'sm' | 'md' | 'lg'
  /** When true the button is disabled; click/keyboard events are suppressed. */
  disabled?: boolean
  /**
   * When true the button shows a loading spinner and suppresses interaction.
   * Sets `aria-busy="true"` on the element.
   */
  loading?: boolean
  /** Content rendered inside the button. */
  children: React.ReactNode
  /** Additional class names merged on top of the base classes. */
  className?: string
}

/**
 * Button component with variant, size, disabled, and loading states.
 *
 * @example
 * ```tsx
 * <Button variant="primary" size="md" onClick={() => save()}>Save</Button>
 * <Button variant="outline" loading>Saving…</Button>
 * ```
 *
 * @remarks
 * Uses design tokens for all visual values (colors, spacing, radius).
 * Keyboard accessible: Enter/Space fire `onClick` via native `<button>` semantics.
 */
export function Button({
  variant = 'primary',
  size = 'md',
  disabled = false,
  loading = false,
  type = 'button',
  className,
  onClick,
  children,
  ...rest
}: ButtonProps) {
  const classes = [
    'rf-btn',
    `rf-btn--${variant}`,
    `rf-btn--${size}`,
    loading ? 'rf-btn--loading' : '',
    disabled ? 'rf-btn--disabled' : '',
    className ?? '',
  ]
    .filter(Boolean)
    .join(' ')

  function handleClick(event: React.MouseEvent<HTMLButtonElement>) {
    if (disabled || loading) return
    onClick?.(event)
  }

  return (
    <button
      type={type}
      className={classes}
      disabled={disabled}
      aria-busy={loading ? 'true' : undefined}
      onClick={handleClick}
      {...rest}
    >
      {loading && <span className="rf-btn__spinner" aria-hidden="true" />}
      {children}
    </button>
  )
}
