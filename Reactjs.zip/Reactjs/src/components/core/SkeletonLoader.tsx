import './core.css'

export interface SkeletonLoaderProps {
  variant?: 'text' | 'rect' | 'circle'
  width?: string
  height?: string
  className?: string
}

export function SkeletonLoader({
  variant = 'text',
  width,
  height,
  className,
}: SkeletonLoaderProps) {
  return (
    <span
      className={['rf-skeleton', `rf-skeleton--${variant}`, className ?? ''].filter(Boolean).join(' ')}
      style={{ width, height }}
      aria-hidden="true"
    />
  )
}
