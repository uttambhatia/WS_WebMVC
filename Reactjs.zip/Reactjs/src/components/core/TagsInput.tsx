import './core.css'
import React from 'react'

export interface TagsInputProps {
  value: string[]
  onChange: (tags: string[]) => void
  placeholder?: string
  maxTags?: number
  allowDuplicates?: boolean
  disabled?: boolean
  error?: boolean | string
  separator?: string[]
  className?: string
  id?: string
  'aria-label'?: string
  'aria-labelledby'?: string
}

export function TagsInput({
  value,
  onChange,
  placeholder = 'Add tag…',
  maxTags,
  allowDuplicates = false,
  disabled = false,
  error,
  separator = ['Enter', ','],
  className,
  id,
  'aria-label': ariaLabel,
  'aria-labelledby': ariaLabelledBy,
}: TagsInputProps) {
  const [inputValue, setInputValue] = React.useState('')
  const inputRef = React.useRef<HTMLInputElement | null>(null)
  const hasError = Boolean(error)
  const isFull = maxTags !== undefined && value.length >= maxTags

  function commitTag(raw: string) {
    const tag = raw.trim()
    if (!tag) return
    if (!allowDuplicates && value.some((t) => t.toLowerCase() === tag.toLowerCase())) return
    if (isFull) return
    onChange([...value, tag])
    setInputValue('')
  }

  function removeTag(index: number) {
    onChange(value.filter((_, i) => i !== index))
  }

  function handleKeyDown(event: React.KeyboardEvent<HTMLInputElement>) {
    if (separator.includes(event.key)) {
      event.preventDefault()
      commitTag(inputValue)
      return
    }
    if (event.key === 'Backspace' && inputValue === '' && value.length > 0) {
      event.preventDefault()
      onChange(value.slice(0, -1))
    }
  }

  function handleInputChange(event: React.ChangeEvent<HTMLInputElement>) {
    const raw = event.currentTarget.value
    // Commit on trailing comma in the value
    if (raw.endsWith(',')) {
      commitTag(raw.slice(0, -1))
    } else {
      setInputValue(raw)
    }
  }

  const wrapperClasses = [
    'rf-tags-input',
    disabled ? 'rf-tags-input--disabled' : '',
    hasError ? 'rf-tags-input--error' : '',
    isFull ? 'rf-tags-input--full' : '',
    className ?? '',
  ]
    .filter(Boolean)
    .join(' ')

  return (
    <div
      className={wrapperClasses}
      role="group"
      aria-label={ariaLabel}
      aria-labelledby={ariaLabelledBy}
      onClick={() => inputRef.current?.focus()}
    >
      {value.map((tag, index) => (
        <span key={`${tag}-${index}`} className="rf-tags-input__chip">
          <span className="rf-tags-input__chip-label">{tag}</span>
          {!disabled && (
            <button
              type="button"
              className="rf-tags-input__chip-remove"
              aria-label={`Remove ${tag}`}
              tabIndex={-1}
              onClick={(e) => {
                e.stopPropagation()
                removeTag(index)
              }}
            >
              ×
            </button>
          )}
        </span>
      ))}
      {!isFull && (
        <input
          ref={inputRef}
          id={id}
          type="text"
          className="rf-tags-input__field"
          value={inputValue}
          placeholder={value.length === 0 ? placeholder : ''}
          disabled={disabled}
          aria-invalid={hasError ? 'true' : undefined}
          onChange={handleInputChange}
          onKeyDown={handleKeyDown}
          onBlur={() => commitTag(inputValue)}
        />
      )}
    </div>
  )
}
