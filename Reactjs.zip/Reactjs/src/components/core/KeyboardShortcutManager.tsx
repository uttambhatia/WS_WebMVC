import './core.css'
import React from 'react'

export interface KeyboardShortcut {
  id: string
  keys: string
  description: string
  handler: () => void
}

export interface KeyboardShortcutManagerProps {
  shortcuts: KeyboardShortcut[]
  active?: boolean
  showCheatSheet?: boolean
}

function normalize(combo: string): string {
  return combo.toLowerCase().replace(/\s+/g, '')
}

function eventCombo(event: KeyboardEvent): string {
  const parts: string[] = []
  if (event.ctrlKey || event.metaKey) parts.push('ctrl')
  if (event.shiftKey) parts.push('shift')
  if (event.altKey) parts.push('alt')
  parts.push(event.key.toLowerCase())
  return parts.join('+')
}

export function KeyboardShortcutManager({
  shortcuts,
  active = true,
  showCheatSheet = true,
}: KeyboardShortcutManagerProps) {
  React.useEffect(() => {
    if (!active) return

    function onKeyDown(event: KeyboardEvent) {
      const combo = normalize(eventCombo(event))
      const matched = shortcuts.find((shortcut) => normalize(shortcut.keys) === combo)
      if (!matched) return
      event.preventDefault()
      matched.handler()
    }

    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  }, [active, shortcuts])

  if (!showCheatSheet) return null

  return (
    <aside className="rf-shortcuts" aria-label="Keyboard shortcuts">
      <h4>Shortcuts</h4>
      <ul>
        {shortcuts.map((shortcut) => (
          <li key={shortcut.id}>
            <kbd>{shortcut.keys}</kbd>
            <span>{shortcut.description}</span>
          </li>
        ))}
      </ul>
    </aside>
  )
}
