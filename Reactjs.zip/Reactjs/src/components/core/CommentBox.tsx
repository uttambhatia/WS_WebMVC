import './core.css'
import React from 'react'

export interface CommentBoxProps {
  value?: string
  defaultValue?: string
  placeholder?: string
  mentionSuggestions?: string[]
  onSubmit?: (value: string) => void
  className?: string
}

export function CommentBox({
  value,
  defaultValue = '',
  placeholder = 'Write a comment...',
  mentionSuggestions = [],
  onSubmit,
  className,
}: CommentBoxProps) {
  const [internalValue, setInternalValue] = React.useState(defaultValue)
  const current = value ?? internalValue

  const mentionMatch = /(^|\s)@([a-zA-Z0-9_]*)$/.exec(current)
  const mentionQuery = mentionMatch?.[2] ?? ''
  const showMentions = mentionMatch !== null && mentionSuggestions.length > 0
  const filteredMentions = mentionSuggestions.filter((name) => name.toLowerCase().startsWith(mentionQuery.toLowerCase()))

  const updateValue = (next: string) => {
    if (value === undefined) {
      setInternalValue(next)
    }
  }

  const submit = () => {
    const output = current.trim()
    if (!output) {
      return
    }
    onSubmit?.(output)
    if (value === undefined) {
      setInternalValue('')
    }
  }

  return (
    <div className={['rf-comment-box', className ?? ''].filter(Boolean).join(' ')}>
      <textarea
        className="rf-comment-box__input"
        value={current}
        placeholder={placeholder}
        onChange={(event) => updateValue(event.currentTarget.value)}
      />

      {showMentions && filteredMentions.length > 0 && (
        <ul className="rf-comment-box__mentions" role="listbox" aria-label="Mention suggestions">
          {filteredMentions.slice(0, 6).map((name) => (
            <li key={name}>
              <button
                type="button"
                className="rf-comment-box__mention"
                onClick={() => {
                  const next = current.replace(/@([a-zA-Z0-9_]*)$/, `@${name} `)
                  updateValue(next)
                }}
              >
                @{name}
              </button>
            </li>
          ))}
        </ul>
      )}

      <div className="rf-comment-box__actions">
        <button type="button" className="rf-comment-box__submit" onClick={submit}>Post</button>
      </div>
    </div>
  )
}
