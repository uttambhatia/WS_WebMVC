import './core.css'
import React from 'react'

export interface InspectorPanelSection {
  id: string
  title: string
  content: React.ReactNode
}

export interface InspectorPanelProps {
  title: string
  sections: InspectorPanelSection[]
  open: boolean
  onClose?: () => void
}

export function InspectorPanel({ title, sections, open, onClose }: InspectorPanelProps) {
  if (!open) return null

  return (
    <aside className="rf-inspector" aria-label={title}>
      <header className="rf-inspector__head">
        <h3>{title}</h3>
        <button type="button" className="rf-inspector__close" onClick={onClose} aria-label="Close inspector">×</button>
      </header>
      <div className="rf-inspector__body">
        {sections.map((section) => (
          <section key={section.id} className="rf-inspector__section">
            <h4>{section.title}</h4>
            <div>{section.content}</div>
          </section>
        ))}
      </div>
    </aside>
  )
}
