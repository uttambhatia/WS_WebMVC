import './core.css'
import React from 'react'
import { QueryBuilder, type QueryField, type QueryGroup } from './QueryBuilder'

export interface RuleAction {
  id: string
  type: 'set' | 'notify' | 'block'
  target: string
  value: string
}

export interface RuleDefinition {
  id: string
  name: string
  when: QueryGroup
  then: RuleAction[]
  enabled: boolean
}

export interface RuleBuilderProps {
  fields: QueryField[]
  value: RuleDefinition
  onChange: (value: RuleDefinition) => void
}

export function RuleBuilder({ fields, value, onChange }: RuleBuilderProps) {
  const validationErrors = React.useMemo(() => {
    const errors: string[] = []
    if (!value.name.trim()) errors.push('Rule name is required.')
    if (value.then.length === 0) errors.push('At least one action is required.')
    value.then.forEach((action, index) => {
      if (!action.target.trim()) errors.push(`Action ${index + 1}: target is required.`)
    })
    return errors
  }, [value])

  function updateAction(actionId: string, patch: Partial<RuleAction>) {
    onChange({
      ...value,
      then: value.then.map((action) => action.id === actionId ? { ...action, ...patch } : action),
    })
  }

  return (
    <section className="rf-rule-builder" aria-label="Rule Builder">
      <header className="rf-rule-builder__head">
        <label>
          Rule name
          <input
            className="rf-rule-builder__input"
            value={value.name}
            onChange={(event) => onChange({ ...value, name: event.currentTarget.value })}
          />
        </label>

        <label className="rf-rule-builder__toggle">
          <input
            type="checkbox"
            checked={value.enabled}
            onChange={(event) => onChange({ ...value, enabled: event.currentTarget.checked })}
          />
          Enabled
        </label>
      </header>

      <div className="rf-rule-builder__section">
        <h4>If</h4>
        <QueryBuilder
          fields={fields}
          value={value.when}
          onChange={(nextWhen) => onChange({ ...value, when: nextWhen })}
        />
      </div>

      <div className="rf-rule-builder__section">
        <h4>Then</h4>
        {value.then.map((action) => (
          <div key={action.id} className="rf-rule-builder__action">
            <select
              className="rf-rule-builder__select"
              value={action.type}
              onChange={(event) => updateAction(action.id, { type: event.currentTarget.value as RuleAction['type'] })}
            >
              <option value="set">Set value</option>
              <option value="notify">Notify</option>
              <option value="block">Block transition</option>
            </select>

            <input
              className="rf-rule-builder__input"
              placeholder="Target"
              value={action.target}
              onChange={(event) => updateAction(action.id, { target: event.currentTarget.value })}
            />

            <input
              className="rf-rule-builder__input"
              placeholder="Value"
              value={action.value}
              onChange={(event) => updateAction(action.id, { value: event.currentTarget.value })}
            />
          </div>
        ))}

        <button
          type="button"
          className="rf-rule-builder__btn"
          onClick={() => {
            const action: RuleAction = {
              id: crypto.randomUUID(),
              type: 'set',
              target: '',
              value: '',
            }
            onChange({ ...value, then: [...value.then, action] })
          }}
        >
          Add action
        </button>
      </div>

      {validationErrors.length > 0 && (
        <ul className="rf-rule-builder__errors" role="status">
          {validationErrors.map((error) => <li key={error}>{error}</li>)}
        </ul>
      )}
    </section>
  )
}
