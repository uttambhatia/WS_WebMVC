export interface SelectProps extends Omit<React.SelectHTMLAttributes<HTMLSelectElement>, 'size'> {
  /** Size variant matching the design token scale. Defaults to `'md'`. */
  size?: 'sm' | 'md' | 'lg'
  /**
   * When truthy applies error border styling and sets `aria-invalid="true"`.
   */
  error?: boolean | string
  /** `<option>` elements rendered inside the select. */
  children: React.ReactNode
  /** Additional class names merged on top of the base classes. */
  className?: string
}

/**
 * Native `<select>` component with size variants and validation state styling.
 *
 * Keyboard navigation (arrow keys, Enter, Space) is provided free-of-charge by
 * the native element. Pass `aria-label` or `aria-labelledby` when the select is
 * not associated with a visible `<label>` via `htmlFor`.
 *
 * @example
 * ```tsx
 * <FormField id="topic" label="Topic">
 *   <Select
 *     id="topic"
 *     value={topic}
 *     onChange={(e) => setTopic(e.target.value)}
 *   >
 *     <option value="">Select…</option>
 *     <option value="general">General</option>
 *     <option value="billing">Billing</option>
 *   </Select>
 * </FormField>
 * ```
 */
export function Select({
  size = 'md',
  error,
  className,
  children,
  ...rest
}: SelectProps) {
  const hasError = Boolean(error)

  const classes = [
    'rf-select',
    `rf-select--${size}`,
    hasError ? 'rf-select--error' : '',
    className ?? '',
  ]
    .filter(Boolean)
    .join(' ')

  return (
    <select
      className={classes}
      aria-invalid={hasError ? 'true' : undefined}
      {...rest}
    >
      {children}
    </select>
  )
}
