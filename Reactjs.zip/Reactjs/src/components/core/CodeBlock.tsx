import './core.css'

export interface CodeBlockProps {
  code: string
  language?: string
  showLineNumbers?: boolean
  onCopy?: (code: string) => void
  className?: string
}

export function CodeBlock({
  code,
  language = 'text',
  showLineNumbers = false,
  onCopy,
  className,
}: CodeBlockProps) {
  const lines = code.split('\n')

  const copy = async () => {
    if (typeof navigator !== 'undefined' && navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(code)
    }
    onCopy?.(code)
  }

  return (
    <figure className={['rf-code-block', className ?? ''].filter(Boolean).join(' ')}>
      <figcaption className="rf-code-block__header">
        <span className="rf-code-block__language">{language}</span>
        <button type="button" className="rf-code-block__copy" onClick={() => { void copy() }}>
          Copy
        </button>
      </figcaption>
      <pre className="rf-code-block__pre" role="region" aria-label={`${language} code block`}>
        <code>
          {lines.map((line, index) => (
            <span key={index} className="rf-code-block__line">
              {showLineNumbers && <span className="rf-code-block__line-number">{index + 1}</span>}
              <span className="rf-code-block__line-content">{line}</span>
            </span>
          ))}
        </code>
      </pre>
    </figure>
  )
}
