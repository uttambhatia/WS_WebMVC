import './core.css'

export interface DateRangeValue {
  startDate?: string
  endDate?: string
}

export interface DateRangePickerProps {
  value: DateRangeValue
  onChange: (value: DateRangeValue) => void
  className?: string
  id?: string
  labels?: {
    start?: string
    end?: string
  }
}

export function DateRangePicker({
  value,
  onChange,
  className,
  id,
  labels,
}: DateRangePickerProps) {
  const startId = id ? `${id}-start` : undefined
  const endId = id ? `${id}-end` : undefined

  return (
    <fieldset className={['rf-date-range', className ?? ''].filter(Boolean).join(' ')}>
      <legend className="rf-date-range__legend">Date range</legend>
      <label className="rf-date-range__label" htmlFor={startId}>{labels?.start ?? 'Start date'}</label>
      <input
        id={startId}
        type="date"
        className="rf-date-range__input"
        value={value.startDate ?? ''}
        onChange={(event) => {
          onChange({
            startDate: event.currentTarget.value,
            endDate: value.endDate,
          })
        }}
      />
      <span className="rf-date-range__separator" aria-hidden="true">to</span>
      <label className="rf-date-range__label" htmlFor={endId}>{labels?.end ?? 'End date'}</label>
      <input
        id={endId}
        type="date"
        className="rf-date-range__input"
        value={value.endDate ?? ''}
        onChange={(event) => {
          onChange({
            startDate: value.startDate,
            endDate: event.currentTarget.value,
          })
        }}
      />
    </fieldset>
  )
}
