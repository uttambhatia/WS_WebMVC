import './core.css'
import React from 'react'

export interface ApprovalStep {
  id: string
  approver: string
  approvedAt?: string
  notes?: string
}

export interface ApprovalGateProps {
  steps: ApprovalStep[]
  onApprove: (stepId: string, notes?: string) => void
}

export function ApprovalGate({ steps, onApprove }: ApprovalGateProps) {
  const nextPending = steps.find((step) => !step.approvedAt)
  const [notes, setNotes] = React.useState('')

  return (
    <section className="rf-approval-gate" aria-label="Approval gate">
      <ol>
        {steps.map((step) => (
          <li key={step.id} className={step.approvedAt ? 'rf-approval-gate__step rf-approval-gate__step--done' : 'rf-approval-gate__step'}>
            <div>
              <strong>{step.approver}</strong>
              {step.approvedAt ? (
                <time dateTime={step.approvedAt}> Approved {new Date(step.approvedAt).toLocaleString()}</time>
              ) : (
                <span> Pending</span>
              )}
            </div>
            {step.notes ? <p>{step.notes}</p> : null}
          </li>
        ))}
      </ol>

      <footer className="rf-approval-gate__actions">
        <textarea
          className="rf-approval-gate__notes"
          value={notes}
          onChange={(event) => setNotes(event.currentTarget.value)}
          placeholder="Approval notes"
        />
        <button
          type="button"
          className="rf-approval-gate__approve"
          disabled={!nextPending}
          onClick={() => {
            if (!nextPending) return
            onApprove(nextPending.id, notes.trim() || undefined)
            setNotes('')
          }}
        >
          Approve next stage
        </button>
      </footer>
    </section>
  )
}
