import './core.css'

export interface HeatMapProps {
  data: number[][]
  cellSize?: number
  gap?: number
  ariaLabel?: string
  className?: string
}

export function HeatMap({
  data,
  cellSize = 14,
  gap = 2,
  ariaLabel = 'Heat map',
  className,
}: HeatMapProps) {
  const cols = data.reduce((max, row) => Math.max(max, row.length), 0)
  const max = Math.max(1, ...data.flat())

  return (
    <div
      className={['rf-heat-map', className ?? ''].filter(Boolean).join(' ')}
      role="grid"
      aria-label={ariaLabel}
      style={{
        gridTemplateColumns: `repeat(${Math.max(cols, 1)}, ${cellSize}px)`,
        gap: `${gap}px`,
      }}
    >
      {data.flatMap((row, rowIndex) => row.map((value, colIndex) => {
        const intensity = value / max
        return (
          <div
            key={`${rowIndex}-${colIndex}`}
            className="rf-heat-map__cell"
            role="gridcell"
            aria-label={`Row ${rowIndex + 1}, Column ${colIndex + 1}, Value ${value}`}
            style={{
              width: `${cellSize}px`,
              height: `${cellSize}px`,
              opacity: Math.max(0.08, intensity),
            }}
          />
        )
      }))}
    </div>
  )
}
