import React from 'react'
import './core.css'

export interface InlineEditableOption {
  value: string
  label: string
}

export interface InlineEditableProps {
  /** The committed value shown in display mode. */
  value: string
  /**
   * Called with the new value when the user confirms. Return a non-empty string
   * to surface a server-side error and keep the editor open. Return `false` to
   * cancel silently without saving.
   */
  onSave: (value: string) => void | false | string | Promise<void | false | string>
  /** Called when the user cancels via Escape or the Cancel button. */
  onCancel?: () => void
  /** Client-side validation ran before `onSave`. Return an error string to block the save. */
  validate?: (value: string) => string | null | undefined
  /** Input type. Defaults to `'text'`. */
  mode?: 'text' | 'number' | 'select'
  /** Option list — required when `mode` is `'select'`. */
  options?: InlineEditableOption[]
  /** Controlled editing state. When provided the host toggles it via `onEditingChange`. */
  editing?: boolean
  /** Fires with the new editing state when the component wants to enter or leave edit mode. */
  onEditingChange?: (editing: boolean) => void
  placeholder?: string
  disabled?: boolean
  /** Save when the input loses focus. Defaults to `true`. */
  saveOnBlur?: boolean
  'aria-label'?: string
  'aria-labelledby'?: string
  className?: string
}

export function InlineEditable({
  value,
  onSave,
  onCancel,
  validate,
  mode = 'text',
  options,
  editing: editingProp,
  onEditingChange,
  placeholder = 'Click to edit',
  disabled = false,
  saveOnBlur = true,
  className,
  ...ariaProps
}: InlineEditableProps) {
  const isControlled = editingProp !== undefined
  const [editingLocal, setEditingLocal] = React.useState(false)
  const editing = isControlled ? editingProp : editingLocal

  const [draft, setDraft] = React.useState(value)
  const [error, setError] = React.useState<string | null>(null)
  const [saving, setSaving] = React.useState(false)

  const inputRef = React.useRef<HTMLInputElement | HTMLSelectElement | null>(null)
  const errorId = React.useId()

  // Keep draft in sync when the committed value changes externally.
  React.useEffect(() => {
    if (!editing) setDraft(value)
  }, [value, editing])

  // Focus the input when entering edit mode.
  React.useEffect(() => {
    if (editing) {
      setDraft(value)
      setError(null)
      Promise.resolve().then(() => inputRef.current?.focus())
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [editing])

  function openEdit() {
    if (disabled) return
    if (!isControlled) setEditingLocal(true)
    onEditingChange?.(true)
  }

  function closeEdit() {
    if (!isControlled) setEditingLocal(false)
    onEditingChange?.(false)
    setError(null)
  }

  async function handleSave() {
    if (saving) return
    const validationError = validate?.(draft)
    if (validationError) {
      setError(validationError)
      return
    }
    setSaving(true)
    const result = await Promise.resolve(onSave(draft))
    setSaving(false)
    if (result === false) {
      closeEdit()
      return
    }
    if (typeof result === 'string' && result.length > 0) {
      setError(result)
      return
    }
    closeEdit()
  }

  function handleCancel() {
    setDraft(value)
    closeEdit()
    onCancel?.()
  }

  function handleKeyDown(e: React.KeyboardEvent) {
    if (e.key === 'Enter') {
      e.preventDefault()
      handleSave()
    } else if (e.key === 'Escape') {
      e.preventDefault()
      handleCancel()
    }
  }

  function handleBlur() {
    if (!saveOnBlur || saving) return
    handleSave()
  }

  const classes = [
    'rf-inline-editable',
    editing ? 'rf-inline-editable--editing' : '',
    disabled ? 'rf-inline-editable--disabled' : '',
    className ?? '',
  ]
    .filter(Boolean)
    .join(' ')

  return (
    <span className={classes}>
      {!editing ? (
        <button
          type="button"
          className="rf-inline-editable__trigger"
          onClick={openEdit}
          disabled={disabled}
          aria-label={ariaProps['aria-label']}
          aria-labelledby={ariaProps['aria-labelledby']}
        >
          {value !== '' ? (
            <span className="rf-inline-editable__value">{value}</span>
          ) : (
            <span className="rf-inline-editable__placeholder">{placeholder}</span>
          )}
          {!disabled && (
            <span className="rf-inline-editable__icon" aria-hidden="true">✎</span>
          )}
        </button>
      ) : (
        <span className="rf-inline-editable__editor">
          {mode === 'select' ? (
            <select
              ref={inputRef as React.RefObject<HTMLSelectElement>}
              className="rf-inline-editable__input rf-inline-editable__input--select"
              value={draft}
              disabled={saving}
              aria-invalid={error ? 'true' : undefined}
              aria-describedby={error ? errorId : undefined}
              onChange={(e) => setDraft(e.target.value)}
              onKeyDown={handleKeyDown}
              onBlur={handleBlur}
            >
              {options?.map((opt) => (
                <option key={opt.value} value={opt.value}>
                  {opt.label}
                </option>
              ))}
            </select>
          ) : (
            <input
              ref={inputRef as React.RefObject<HTMLInputElement>}
              type={mode}
              className="rf-inline-editable__input"
              value={draft}
              disabled={saving}
              aria-invalid={error ? 'true' : undefined}
              aria-describedby={error ? errorId : undefined}
              onChange={(e) => setDraft(e.target.value)}
              onKeyDown={handleKeyDown}
              onBlur={handleBlur}
            />
          )}
          <span className="rf-inline-editable__actions">
            {/* onMouseDown prevents the input from blurring before the click fires */}
            <button
              type="button"
              className="rf-inline-editable__save"
              onMouseDown={(e) => e.preventDefault()}
              onClick={handleSave}
              disabled={saving}
              aria-label="Save"
            >
              {saving ? '…' : '✓'}
            </button>
            <button
              type="button"
              className="rf-inline-editable__cancel"
              onMouseDown={(e) => e.preventDefault()}
              onClick={handleCancel}
              disabled={saving}
              aria-label="Cancel"
            >
              ✕
            </button>
          </span>
          {error && (
            <span id={errorId} role="alert" className="rf-inline-editable__error">
              {error}
            </span>
          )}
        </span>
      )}
    </span>
  )
}
