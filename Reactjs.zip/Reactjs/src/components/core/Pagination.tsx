import './core.css'

export interface PaginationProps {
  currentPage: number
  totalPages: number
  onPageChange: (page: number) => void
  siblingCount?: number
  className?: string
}

function clamp(page: number, totalPages: number): number {
  return Math.max(1, Math.min(totalPages, page))
}

export function Pagination({
  currentPage,
  totalPages,
  onPageChange,
  siblingCount = 1,
  className,
}: PaginationProps) {
  const safeCurrent = clamp(currentPage, totalPages)
  const start = Math.max(1, safeCurrent - siblingCount)
  const end = Math.min(totalPages, safeCurrent + siblingCount)

  const pages: number[] = []
  for (let page = start; page <= end; page += 1) {
    pages.push(page)
  }

  return (
    <nav aria-label="Pagination" className={['rf-pagination', className ?? ''].filter(Boolean).join(' ')}>
      <button
        type="button"
        className="rf-pagination__btn"
        onClick={() => onPageChange(safeCurrent - 1)}
        disabled={safeCurrent <= 1}
      >
        Previous
      </button>
      <ul className="rf-pagination__list">
        {pages.map((page) => {
          const active = page === safeCurrent
          return (
            <li key={page}>
              <button
                type="button"
                className={['rf-pagination__btn', active ? 'rf-pagination__btn--active' : ''].filter(Boolean).join(' ')}
                aria-current={active ? 'page' : undefined}
                onClick={() => onPageChange(page)}
              >
                {page}
              </button>
            </li>
          )
        })}
      </ul>
      <button
        type="button"
        className="rf-pagination__btn"
        onClick={() => onPageChange(safeCurrent + 1)}
        disabled={safeCurrent >= totalPages}
      >
        Next
      </button>
    </nav>
  )
}
