import './core.css'
import React from 'react'

export interface AppShellSectionProps extends React.HTMLAttributes<HTMLElement> {
  children: React.ReactNode
}

export interface AppShellProps extends React.HTMLAttributes<HTMLDivElement> {
  children: React.ReactNode
}

function AppShellRoot({ children, className, ...rest }: AppShellProps) {
  return (
    <div {...rest} className={['rf-app-shell', className ?? ''].filter(Boolean).join(' ')}>
      {children}
    </div>
  )
}

function Header({ children, className, ...rest }: AppShellSectionProps) {
  return (
    <header {...rest} className={['rf-app-shell__header', className ?? ''].filter(Boolean).join(' ')}>
      {children}
    </header>
  )
}

function Sidebar({ children, className, ...rest }: AppShellSectionProps) {
  return (
    <aside {...rest} className={['rf-app-shell__sidebar', className ?? ''].filter(Boolean).join(' ')}>
      {children}
    </aside>
  )
}

function Content({ children, className, ...rest }: AppShellSectionProps) {
  return (
    <main {...rest} className={['rf-app-shell__content', className ?? ''].filter(Boolean).join(' ')}>
      {children}
    </main>
  )
}

function Footer({ children, className, ...rest }: AppShellSectionProps) {
  return (
    <footer {...rest} className={['rf-app-shell__footer', className ?? ''].filter(Boolean).join(' ')}>
      {children}
    </footer>
  )
}

type AppShellType = ((props: AppShellProps) => React.JSX.Element) & {
  Header: typeof Header
  Sidebar: typeof Sidebar
  Content: typeof Content
  Footer: typeof Footer
}

export const AppShell = Object.assign(AppShellRoot, {
  Header,
  Sidebar,
  Content,
  Footer,
}) as AppShellType
