import './core.css'
import React from 'react'

export interface ContextMenuItem {
  id: string
  label: React.ReactNode
  onSelect: () => void
  disabled?: boolean
}

export interface ContextMenuProps {
  items: ContextMenuItem[]
  children: React.ReactNode
  className?: string
}

export function ContextMenu({ items, children, className }: ContextMenuProps) {
  const [open, setOpen] = React.useState(false)
  const [position, setPosition] = React.useState({ x: 0, y: 0 })
  const rootRef = React.useRef<HTMLDivElement | null>(null)

  React.useEffect(() => {
    if (!open) return

    function onPointerDown(event: MouseEvent) {
      const target = event.target as Node
      if (rootRef.current?.contains(target)) return
      setOpen(false)
    }

    function onKeyDown(event: KeyboardEvent) {
      if (event.key === 'Escape') {
        setOpen(false)
      }
    }

    document.addEventListener('mousedown', onPointerDown)
    document.addEventListener('keydown', onKeyDown)

    return () => {
      document.removeEventListener('mousedown', onPointerDown)
      document.removeEventListener('keydown', onKeyDown)
    }
  }, [open])

  return (
    <div
      ref={rootRef}
      className={['rf-context-menu', className ?? ''].filter(Boolean).join(' ')}
      onContextMenu={(event) => {
        event.preventDefault()
        setPosition({ x: event.clientX, y: event.clientY })
        setOpen(true)
      }}
    >
      {children}
      {open && (
        <ul
          role="menu"
          className="rf-context-menu__panel"
          style={{ left: `${position.x}px`, top: `${position.y}px` }}
        >
          {items.map((item) => (
            <li key={item.id} role="none">
              <button
                type="button"
                role="menuitem"
                className="rf-context-menu__item"
                disabled={item.disabled}
                onClick={() => {
                  item.onSelect()
                  setOpen(false)
                }}
              >
                {item.label}
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}
