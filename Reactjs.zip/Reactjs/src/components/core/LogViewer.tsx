import './core.css'
import React from 'react'

export type LogLevel = 'debug' | 'info' | 'warn' | 'error'

export interface LogEntry {
  id: string
  level: LogLevel
  message: string
  timestamp?: string
}

export interface LogViewerProps {
  entries: LogEntry[]
  levelFilter?: LogLevel | 'all'
  autoScroll?: boolean
  className?: string
}

const ANSI_REGEX = new RegExp(String.fromCharCode(27) + '\\[[0-9;]*m', 'g')

export function LogViewer({
  entries,
  levelFilter = 'all',
  autoScroll = true,
  className,
}: LogViewerProps) {
  const bodyRef = React.useRef<HTMLDivElement | null>(null)
  const filtered = levelFilter === 'all'
    ? entries
    : entries.filter((entry) => entry.level === levelFilter)

  React.useEffect(() => {
    if (!autoScroll || !bodyRef.current) {
      return
    }
    bodyRef.current.scrollTop = bodyRef.current.scrollHeight
  }, [autoScroll, filtered.length])

  return (
    <div className={['rf-log-viewer', className ?? ''].filter(Boolean).join(' ')}>
      <div className="rf-log-viewer__body" ref={bodyRef} role="log" aria-label="Log stream">
        {filtered.map((entry) => (
          <div key={entry.id} className={['rf-log-viewer__line', `rf-log-viewer__line--${entry.level}`].join(' ')}>
            {entry.timestamp && <time className="rf-log-viewer__time">{entry.timestamp}</time>}
            <span className="rf-log-viewer__level">{entry.level.toUpperCase()}</span>
            <span className="rf-log-viewer__message">{entry.message.replace(ANSI_REGEX, '')}</span>
          </div>
        ))}
      </div>
    </div>
  )
}
