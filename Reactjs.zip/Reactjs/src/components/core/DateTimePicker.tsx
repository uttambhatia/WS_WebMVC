import './core.css'

export interface DateTimePickerProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'type' | 'value' | 'onChange'> {
  value?: string
  onChange?: (value: string) => void
  error?: boolean | string
  className?: string
}

export function DateTimePicker({
  value,
  onChange,
  error,
  className,
  ...rest
}: DateTimePickerProps) {
  const hasError = Boolean(error)

  return (
    <input
      type="datetime-local"
      value={value ?? ''}
      className={['rf-datetime-picker', hasError ? 'rf-datetime-picker--error' : '', className ?? ''].filter(Boolean).join(' ')}
      aria-invalid={hasError ? 'true' : undefined}
      onChange={(event) => onChange?.(event.currentTarget.value)}
      {...rest}
    />
  )
}
