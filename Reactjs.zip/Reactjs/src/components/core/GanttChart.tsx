import './core.css'

export interface GanttTask {
  id: string
  label: string
  start: number
  end: number
  progress?: number
  dependsOn?: string[]
}

export interface GanttChartProps {
  tasks: GanttTask[]
  min?: number
  max?: number
  zoom?: number
  className?: string
}

export function GanttChart({
  tasks,
  min,
  max,
  zoom = 1,
  className,
}: GanttChartProps) {
  const minValue = min ?? Math.min(...tasks.map((task) => task.start), 0)
  const maxValue = max ?? Math.max(...tasks.map((task) => task.end), 1)
  const range = Math.max(1, maxValue - minValue)

  return (
    <div className={['rf-gantt', className ?? ''].filter(Boolean).join(' ')} role="table" aria-label="Gantt chart">
      {tasks.map((task) => {
        const left = ((task.start - minValue) / range) * 100
        const width = ((task.end - task.start) / range) * 100
        const progress = Math.max(0, Math.min(100, task.progress ?? 0))

        return (
          <div key={task.id} className="rf-gantt__row" role="row">
            <div className="rf-gantt__label" role="cell">{task.label}</div>
            <div className="rf-gantt__track" role="cell">
              <div
                className="rf-gantt__bar"
                style={{
                  left: `${left}%`,
                  width: `${Math.max(1, width * zoom)}%`,
                }}
                aria-label={`${task.label} from ${task.start} to ${task.end}`}
              >
                <span className="rf-gantt__progress" style={{ width: `${progress}%` }} />
              </div>
            </div>
          </div>
        )
      })}
    </div>
  )
}
