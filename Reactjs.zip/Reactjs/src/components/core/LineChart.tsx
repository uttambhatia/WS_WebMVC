import './core.css'

export interface LineChartDatum {
  label: string
  value: number
}

export interface LineChartProps {
  data: LineChartDatum[]
  width?: number
  height?: number
  lineColor?: string
  strokeWidth?: number
  showPoints?: boolean
  ariaLabel?: string
  className?: string
}

function clamp(value: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, value))
}

export function LineChart({
  data,
  width = 320,
  height = 180,
  lineColor = 'var(--color-primary)',
  strokeWidth = 2,
  showPoints = true,
  ariaLabel = 'Line chart',
  className,
}: LineChartProps) {
  const classes = ['rf-line-chart', className ?? ''].filter(Boolean).join(' ')

  if (data.length < 2) {
    return (
      <figure className={classes}>
        <svg role="img" aria-label={ariaLabel} viewBox={`0 0 ${width} ${height}`} width={width} height={height} />
      </figure>
    )
  }

  const max = Math.max(...data.map((point) => point.value))
  const min = Math.min(...data.map((point) => point.value))
  const range = max - min || 1
  const padding = 12
  const innerWidth = width - padding * 2
  const innerHeight = height - padding * 2

  const points = data.map((point, index) => {
    const x = padding + (index / (data.length - 1)) * innerWidth
    const normalized = (point.value - min) / range
    const y = padding + (1 - normalized) * innerHeight
    return { x, y: clamp(y, padding, height - padding), point }
  })

  const polyline = points.map((point) => `${point.x},${point.y}`).join(' ')

  return (
    <figure className={classes}>
      <svg role="img" aria-label={ariaLabel} viewBox={`0 0 ${width} ${height}`} width={width} height={height}>
        <polyline
          className="rf-line-chart__line"
          points={polyline}
          fill="none"
          stroke={lineColor}
          strokeWidth={strokeWidth}
          strokeLinejoin="round"
          strokeLinecap="round"
        />
        {showPoints && points.map(({ x, y, point }, index) => (
          <g key={`${point.label}-${index}`}>
            <circle className="rf-line-chart__point" cx={x} cy={y} r={3} fill={lineColor} />
            <text className="rf-line-chart__label" x={x} y={height - 2} textAnchor="middle">
              {point.label}
            </text>
          </g>
        ))}
      </svg>
    </figure>
  )
}
