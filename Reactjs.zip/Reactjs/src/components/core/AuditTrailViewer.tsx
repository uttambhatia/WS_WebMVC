import './core.css'
import React from 'react'

export interface AuditTrailEvent {
  id: string
  actor: string
  action: string
  entity: string
  timestamp: string
  immutable?: boolean
}

export interface AuditTrailViewerProps {
  events: AuditTrailEvent[]
  actorFilter?: string
  actionFilter?: string
}

export function AuditTrailViewer({ events, actorFilter = '', actionFilter = '' }: AuditTrailViewerProps) {
  const filtered = React.useMemo(() => {
    const actor = actorFilter.trim().toLowerCase()
    const action = actionFilter.trim().toLowerCase()
    return events.filter((event) => {
      const actorMatch = !actor || event.actor.toLowerCase().includes(actor)
      const actionMatch = !action || event.action.toLowerCase().includes(action)
      return actorMatch && actionMatch
    })
  }, [actionFilter, actorFilter, events])

  return (
    <ol className="rf-audit-trail" aria-label="Audit trail">
      {filtered.map((event) => (
        <li key={event.id} className="rf-audit-trail__item">
          <div className="rf-audit-trail__meta">
            <strong>{event.action}</strong>
            {event.immutable ? <span className="rf-audit-trail__immutable">Immutable</span> : null}
          </div>
          <p>
            {event.actor} changed {event.entity}
          </p>
          <time dateTime={event.timestamp}>{new Date(event.timestamp).toLocaleString()}</time>
        </li>
      ))}
    </ol>
  )
}
