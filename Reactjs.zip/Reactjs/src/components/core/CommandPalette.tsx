import './core.css'
import React from 'react'
import { Modal } from './Modal'

export interface CommandItem {
  id: string
  label: string
  keywords?: string[]
  onSelect: () => void
}

export interface CommandPaletteProps {
  open: boolean
  commands: CommandItem[]
  onClose: () => void
  placeholder?: string
  title?: React.ReactNode
}

export function CommandPalette({
  open,
  commands,
  onClose,
  placeholder = 'Search commands',
  title = 'Command Palette',
}: CommandPaletteProps) {
  const [query, setQuery] = React.useState('')

  const filtered = React.useMemo(() => {
    const normalized = query.trim().toLowerCase()
    if (!normalized) return commands
    return commands.filter((command) => {
      const haystack = [command.label, ...(command.keywords ?? [])].join(' ').toLowerCase()
      return haystack.includes(normalized)
    })
  }, [commands, query])

  React.useEffect(() => {
    if (!open) setQuery('')
  }, [open])

  return (
    <Modal open={open} onClose={onClose} title={title} className="rf-command">
      <div className="rf-command__container">
        <input
          type="search"
          value={query}
          onChange={(event) => setQuery(event.currentTarget.value)}
          className="rf-command__search"
          placeholder={placeholder}
          aria-label="Search commands"
        />
        <ul className="rf-command__list" role="listbox" aria-label="Command results">
          {filtered.map((command) => (
            <li key={command.id}>
              <button
                type="button"
                className="rf-command__item"
                onClick={() => {
                  command.onSelect()
                  onClose()
                }}
              >
                {command.label}
              </button>
            </li>
          ))}
          {filtered.length === 0 && <li className="rf-command__empty">No commands found.</li>}
        </ul>
      </div>
    </Modal>
  )
}
