import './core.css'
import { useResponsiveChartDimensions } from './useResponsiveChartDimensions'

export interface PieChartDatum {
  label: string
  value: number
}

export type PieChartVariant = 'basic' | 'labeled' | 'grouped' | 'drilldown' | 'comparison'

export interface PieChartProps {
  data: PieChartDatum[]
  width?: number
  height?: number
  responsive?: boolean
  innerRadius?: number
  showLabels?: boolean
  showLegend?: boolean
  showPercentages?: boolean
  groupSmallSlicesThreshold?: number
  comparisonData?: PieChartDatum[]
  onSliceSelect?: (slice: PieChartDatum) => void
  ariaLabel?: string
  className?: string
  variant?: PieChartVariant
}

/**
 * PieChart renders a pie chart from normalized data values.
 * 
 * @example
 * <PieChart
 *   data={[
 *     { label: 'Product A', value: 30 },
 *     { label: 'Product B', value: 25 },
 *     { label: 'Product C', value: 45 },
 *   ]}
 *   showLabels
 *   showLegend
 *   ariaLabel="Product distribution"
 * />
 */
export function PieChart({
  data,
  width = 320,
  height = 240,
  responsive = false,
  innerRadius = 0,
  showLabels = false,
  showLegend = true,
  showPercentages = false,
  groupSmallSlicesThreshold = 0.05,
  comparisonData,
  onSliceSelect,
  ariaLabel = 'Pie chart',
  className,
  variant = 'basic',
}: PieChartProps) {
  const { containerRef, width: chartWidth, height: chartHeight } = useResponsiveChartDimensions<HTMLDivElement>(
    width,
    height,
    responsive,
  )
  const total = Math.max(data.reduce((sum, item) => sum + item.value, 0), 1)
  const centerX = chartWidth / 2
  const centerY = chartHeight / 2
  const radius = Math.min(chartWidth, chartHeight) / 2 - 20

  // Group small slices if variant requires it or threshold is set
  let slices = data
  if (variant === 'grouped' || groupSmallSlicesThreshold > 0) {
    const grouped: PieChartDatum[] = []
    let otherValue = 0
    for (const datum of data) {
      const percentage = datum.value / total
      if (percentage < groupSmallSlicesThreshold) {
        otherValue += datum.value
      } else {
        grouped.push(datum)
      }
    }
    if (otherValue > 0) {
      grouped.push({ label: 'Other', value: otherValue })
    }
    slices = grouped
  }

  const sliceData = slices.reduce<Array<typeof slices[0] & { startAngle: number; endAngle: number }>>(
    (acc, item) => {
      const sliceValue = item.value
      const sliceAngle = (sliceValue / total) * 2 * Math.PI
      const startAngle = acc.length === 0 ? -Math.PI / 2 : acc[acc.length - 1].endAngle
      const endAngle = startAngle + sliceAngle
      acc.push({ ...item, startAngle, endAngle })
      return acc
    },
    []
  )

  const classes = ['rf-pie-chart', `rf-pie-chart--${variant}`, className ?? ''].filter(Boolean).join(' ')

  const comparisonTotals = (comparisonData ?? []).reduce<Record<string, number>>((acc, item) => {
    acc[item.label] = item.value
    return acc
  }, {})

  const interactiveMode = variant === 'drilldown' || onSliceSelect != null

  return (
    <div className={classes}>
      <div className="rf-pie-chart__plot" ref={containerRef}>
        <svg
          role="img"
          aria-label={ariaLabel}
          viewBox={`0 0 ${chartWidth} ${chartHeight}`}
          width={chartWidth}
          height={chartHeight}
          className="rf-pie-chart__svg"
        >
          {sliceData.map((slice, idx) => {
            const x1 = centerX + radius * Math.cos(slice.startAngle)
            const y1 = centerY + radius * Math.sin(slice.startAngle)
            const x2 = centerX + radius * Math.cos(slice.endAngle)
            const y2 = centerY + radius * Math.sin(slice.endAngle)
            const largeArcFlag = slice.endAngle - slice.startAngle > Math.PI ? 1 : 0

            // Inner radius for donut mode
            const innerX1 = centerX + (innerRadius > 0 ? innerRadius : 0) * Math.cos(slice.startAngle)
            const innerY1 = centerY + (innerRadius > 0 ? innerRadius : 0) * Math.sin(slice.startAngle)
            const innerX2 = centerX + (innerRadius > 0 ? innerRadius : 0) * Math.cos(slice.endAngle)
            const innerY2 = centerY + (innerRadius > 0 ? innerRadius : 0) * Math.sin(slice.endAngle)

            const pathData = innerRadius > 0
              ? `M ${x1} ${y1} A ${radius} ${radius} 0 ${largeArcFlag} 1 ${x2} ${y2} L ${innerX2} ${innerY2} A ${innerRadius} ${innerRadius} 0 ${largeArcFlag} 0 ${innerX1} ${innerY1} Z`
              : `M ${centerX} ${centerY} L ${x1} ${y1} A ${radius} ${radius} 0 ${largeArcFlag} 1 ${x2} ${y2} Z`

            const percentage = ((slice.value / total) * 100).toFixed(1)
            const hueStep = (idx / sliceData.length) * 360

            const baseLabel = showPercentages ? `${slice.label} ${percentage}%` : slice.label
            const comparisonValue = comparisonTotals[slice.label]
            const ariaSliceLabel =
              variant === 'comparison' && typeof comparisonValue === 'number'
                ? `${baseLabel}. Comparison value ${comparisonValue}`
                : baseLabel

            return (
              <g key={`${slice.label}-${idx}`}>
                <path
                  className="rf-pie-chart__slice"
                  d={pathData}
                  fill={`hsl(${hueStep}, 70%, 60%)`}
                  stroke="var(--surface, #ffffff)"
                  strokeWidth="2"
                  style={{ opacity: 0.85 }}
                  role={interactiveMode ? 'button' : undefined}
                  tabIndex={interactiveMode ? 0 : undefined}
                  aria-label={ariaSliceLabel}
                  onClick={interactiveMode ? () => onSliceSelect?.(slice) : undefined}
                  onKeyDown={interactiveMode ? (e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      onSliceSelect?.(slice)
                    }
                  } : undefined}
                />
                {showLabels && (
                  <text
                    className="rf-pie-chart__label"
                    x={centerX + (radius * 0.6) * Math.cos(slice.startAngle + (slice.endAngle - slice.startAngle) / 2)}
                    y={centerY + (radius * 0.6) * Math.sin(slice.startAngle + (slice.endAngle - slice.startAngle) / 2)}
                    textAnchor="middle"
                    dy="0.3em"
                    fontSize="12"
                    fill="var(--text, #000000)"
                    pointerEvents="none"
                  >
                    {showPercentages ? `${percentage}%` : slice.label}
                  </text>
                )}
              </g>
            )
          })}
        </svg>
      </div>

      {showLegend && (
        <div className="rf-pie-chart__legend">
          {sliceData.map((slice, idx) => {
            const percentage = ((slice.value / total) * 100).toFixed(1)
            const hueStep = (idx / sliceData.length) * 360
            const comparisonValue = comparisonTotals[slice.label]
            return (
              <div key={`legend-${idx}`} className="rf-pie-chart__legend-item">
                <span
                  className="rf-pie-chart__legend-color"
                  style={{ backgroundColor: `hsl(${hueStep}, 70%, 60%)` }}
                />
                <span className="rf-pie-chart__legend-label">
                  {slice.label} ({percentage}%)
                  {variant === 'comparison' && typeof comparisonValue === 'number' ? ` | Ref: ${comparisonValue}` : ''}
                </span>
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}
