import React from 'react'
import './core.css'

export type CalendarSchedulerView = 'day' | 'week' | 'month'

export interface CalendarSchedulerEvent {
  id: string
  title: string
  start: string
  end: string
  description?: string
}

export interface CalendarSchedulerRange {
  startDate: string
  endDate: string
}

export interface CalendarSchedulerProps {
  view: CalendarSchedulerView
  events: CalendarSchedulerEvent[]
  selectedDate?: string
  onDateChange?: (date: string) => void
  onRangeChange?: (range: CalendarSchedulerRange, view: CalendarSchedulerView) => void
  onEventSelect?: (event: CalendarSchedulerEvent) => void
  onCreateEvent?: (date: string, view: CalendarSchedulerView) => void
  timezone?: string
  emptyText?: string
  className?: string
}

function startOfDay(date: Date): Date {
  return new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate()))
}

function addDays(date: Date, days: number): Date {
  const next = new Date(date)
  next.setUTCDate(next.getUTCDate() + days)
  return next
}

function addMonths(date: Date, months: number): Date {
  const next = new Date(date)
  next.setUTCMonth(next.getUTCMonth() + months)
  return next
}

function toDateKey(date: Date, timeZone: string): string {
  return new Intl.DateTimeFormat('en-CA', {
    timeZone,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(date)
}

function parseDateOnly(date: string): Date {
  const [year, month, day] = date.split('-').map(Number)
  return new Date(Date.UTC(year, (month ?? 1) - 1, day ?? 1))
}

function getViewRange(anchorDate: Date, view: CalendarSchedulerView): CalendarSchedulerRange {
  if (view === 'day') {
    const key = toDateKey(anchorDate, 'UTC')
    return { startDate: key, endDate: key }
  }

  if (view === 'week') {
    const start = addDays(anchorDate, -anchorDate.getUTCDay())
    const end = addDays(start, 6)
    return {
      startDate: toDateKey(start, 'UTC'),
      endDate: toDateKey(end, 'UTC'),
    }
  }

  const start = new Date(Date.UTC(anchorDate.getUTCFullYear(), anchorDate.getUTCMonth(), 1))
  const end = new Date(Date.UTC(anchorDate.getUTCFullYear(), anchorDate.getUTCMonth() + 1, 0))
  return {
    startDate: toDateKey(start, 'UTC'),
    endDate: toDateKey(end, 'UTC'),
  }
}

function eventOverlapsDate(event: CalendarSchedulerEvent, dateKey: string, timeZone: string): boolean {
  const start = toDateKey(new Date(event.start), timeZone)
  const end = toDateKey(new Date(event.end), timeZone)
  return start <= dateKey && dateKey <= end
}

function formatTime(dateIso: string, timeZone: string): string {
  return new Intl.DateTimeFormat('en-US', {
    timeZone,
    hour: '2-digit',
    minute: '2-digit',
  }).format(new Date(dateIso))
}

function monthTitle(anchorDate: Date): string {
  return new Intl.DateTimeFormat('en-US', { month: 'long', year: 'numeric' }).format(anchorDate)
}

function dayTitle(anchorDate: Date): string {
  return new Intl.DateTimeFormat('en-US', {
    weekday: 'long',
    month: 'long',
    day: 'numeric',
    year: 'numeric',
  }).format(anchorDate)
}

function getMonthGrid(anchorDate: Date): Date[] {
  const monthStart = new Date(Date.UTC(anchorDate.getUTCFullYear(), anchorDate.getUTCMonth(), 1))
  const monthEnd = new Date(Date.UTC(anchorDate.getUTCFullYear(), anchorDate.getUTCMonth() + 1, 0))
  const gridStart = addDays(monthStart, -monthStart.getUTCDay())
  const gridEnd = addDays(monthEnd, 6 - monthEnd.getUTCDay())

  const days: Date[] = []
  for (let cursor = startOfDay(gridStart); cursor <= gridEnd; cursor = addDays(cursor, 1)) {
    days.push(cursor)
  }
  return days
}

function getWeekDays(anchorDate: Date): Date[] {
  const start = addDays(anchorDate, -anchorDate.getUTCDay())
  return Array.from({ length: 7 }, (_, index) => addDays(start, index))
}

export function CalendarScheduler({
  view,
  events,
  selectedDate,
  onDateChange,
  onRangeChange,
  onEventSelect,
  onCreateEvent,
  timezone = 'UTC',
  emptyText = 'No events in this range.',
  className,
}: CalendarSchedulerProps) {
  const [localDate, setLocalDate] = React.useState(
    selectedDate ? parseDateOnly(selectedDate) : startOfDay(new Date()),
  )

  React.useEffect(() => {
    if (!selectedDate) return
    setLocalDate(parseDateOnly(selectedDate))
  }, [selectedDate])

  React.useEffect(() => {
    const range = getViewRange(localDate, view)
    onRangeChange?.(range, view)
  }, [localDate, onRangeChange, view])

  function setAnchorDate(next: Date) {
    const normalized = startOfDay(next)
    setLocalDate(normalized)
    onDateChange?.(toDateKey(normalized, 'UTC'))
  }

  function shift(direction: -1 | 1) {
    if (view === 'month') {
      setAnchorDate(addMonths(localDate, direction))
      return
    }

    if (view === 'week') {
      setAnchorDate(addDays(localDate, direction * 7))
      return
    }

    setAnchorDate(addDays(localDate, direction))
  }

  function renderEventList(dateKey: string) {
    const dayEvents = events.filter((event) => eventOverlapsDate(event, dateKey, timezone))

    if (dayEvents.length === 0) {
      return <p className="rf-calendar-scheduler__empty">{emptyText}</p>
    }

    return (
      <ul className="rf-calendar-scheduler__events">
        {dayEvents.map((event) => (
          <li key={event.id}>
            <button
              type="button"
              className="rf-calendar-scheduler__event"
              onClick={() => onEventSelect?.(event)}
            >
              <span className="rf-calendar-scheduler__event-title">{event.title}</span>
              <span className="rf-calendar-scheduler__event-time">
                {formatTime(event.start, timezone)} - {formatTime(event.end, timezone)}
              </span>
            </button>
          </li>
        ))}
      </ul>
    )
  }

  function renderMonthView() {
    const gridDays = getMonthGrid(localDate)

    return (
      <div className="rf-calendar-scheduler__month" role="grid" aria-label="Month view">
        {gridDays.map((day) => {
          const dateKey = toDateKey(day, 'UTC')
          const inMonth = day.getUTCMonth() === localDate.getUTCMonth()
          return (
            <div
              key={dateKey}
              className={[
                'rf-calendar-scheduler__day-cell',
                inMonth ? '' : 'rf-calendar-scheduler__day-cell--outside',
              ]
                .filter(Boolean)
                .join(' ')}
              role="gridcell"
            >
              <div className="rf-calendar-scheduler__day-head">
                <button
                  type="button"
                  className="rf-calendar-scheduler__day-number"
                  onClick={() => setAnchorDate(day)}
                >
                  {day.getUTCDate()}
                </button>
                {onCreateEvent && (
                  <button
                    type="button"
                    className="rf-calendar-scheduler__create"
                    aria-label={`Create event on ${dateKey}`}
                    onClick={() => onCreateEvent(dateKey, view)}
                  >
                    +
                  </button>
                )}
              </div>
              {renderEventList(dateKey)}
            </div>
          )
        })}
      </div>
    )
  }

  function renderWeekView() {
    const weekDays = getWeekDays(localDate)

    return (
      <div className="rf-calendar-scheduler__week" role="grid" aria-label="Week view">
        {weekDays.map((day) => {
          const dateKey = toDateKey(day, 'UTC')
          return (
            <section key={dateKey} className="rf-calendar-scheduler__week-day" role="gridcell">
              <header className="rf-calendar-scheduler__week-day-head">
                <strong>{new Intl.DateTimeFormat('en-US', { weekday: 'short' }).format(day)}</strong>
                <span>{dateKey}</span>
                {onCreateEvent && (
                  <button
                    type="button"
                    className="rf-calendar-scheduler__create"
                    aria-label={`Create event on ${dateKey}`}
                    onClick={() => onCreateEvent(dateKey, view)}
                  >
                    +
                  </button>
                )}
              </header>
              {renderEventList(dateKey)}
            </section>
          )
        })}
      </div>
    )
  }

  function renderDayView() {
    const dateKey = toDateKey(localDate, 'UTC')

    return (
      <section className="rf-calendar-scheduler__single-day" aria-label="Day view">
        <header className="rf-calendar-scheduler__week-day-head">
          <strong>{dayTitle(localDate)}</strong>
          {onCreateEvent && (
            <button
              type="button"
              className="rf-calendar-scheduler__create"
              aria-label={`Create event on ${dateKey}`}
              onClick={() => onCreateEvent(dateKey, view)}
            >
              +
            </button>
          )}
        </header>
        {renderEventList(dateKey)}
      </section>
    )
  }

  return (
    <section className={['rf-calendar-scheduler', className ?? ''].filter(Boolean).join(' ')}>
      <header className="rf-calendar-scheduler__header">
        <div className="rf-calendar-scheduler__nav">
          <button type="button" className="rf-calendar-scheduler__nav-btn" onClick={() => shift(-1)}>
            Prev
          </button>
          <button type="button" className="rf-calendar-scheduler__nav-btn" onClick={() => setAnchorDate(new Date())}>
            Today
          </button>
          <button type="button" className="rf-calendar-scheduler__nav-btn" onClick={() => shift(1)}>
            Next
          </button>
        </div>

        <div className="rf-calendar-scheduler__meta">
          <h3 className="rf-calendar-scheduler__title">{view === 'day' ? dayTitle(localDate) : monthTitle(localDate)}</h3>
          <p className="rf-calendar-scheduler__timezone">Timezone: {timezone}</p>
        </div>
      </header>

      {view === 'month' && renderMonthView()}
      {view === 'week' && renderWeekView()}
      {view === 'day' && renderDayView()}
    </section>
  )
}
