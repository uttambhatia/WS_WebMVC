import './core.css'
import React from 'react'
import { Button } from './Button'

export interface ErrorStateProps {
  title?: string
  message: string
  retryLabel?: string
  onRetry: () => void
  className?: string
}

export function ErrorState({
  title = 'Something went wrong',
  message,
  retryLabel = 'Try again',
  onRetry,
  className,
  ...rest
}: ErrorStateProps & React.HTMLAttributes<HTMLDivElement>) {
  const classes = ['rf-error-state', className].filter(Boolean).join(' ')

  return (
    <div className={classes} role="alert" {...rest}>
      <div className="rf-error-state__icon" aria-hidden="true">
        ⚠
      </div>
      <h3 className="rf-error-state__title">{title}</h3>
      <p className="rf-error-state__message">{message}</p>
      <div className="rf-error-state__actions">
        <Button type="button" variant="outline" size="sm" onClick={onRetry}>
          {retryLabel}
        </Button>
      </div>
    </div>
  )
}
