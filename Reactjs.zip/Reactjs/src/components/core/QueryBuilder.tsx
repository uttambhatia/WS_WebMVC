import './core.css'
import React from 'react'

export type QueryOperator = 'equals' | 'contains' | 'gt' | 'lt' | 'in'

export interface QueryField {
  id: string
  label: string
  type: 'text' | 'number' | 'select'
  options?: string[]
}

export interface QueryCondition {
  id: string
  fieldId: string
  operator: QueryOperator
  value: string
}

export interface QueryGroup {
  id: string
  combinator: 'and' | 'or'
  conditions: QueryCondition[]
  groups: QueryGroup[]
}

export interface QueryBuilderProps {
  fields: QueryField[]
  value: QueryGroup
  onChange: (value: QueryGroup) => void
}

function newCondition(fields: QueryField[]): QueryCondition {
  return {
    id: crypto.randomUUID(),
    fieldId: fields[0]?.id ?? 'field',
    operator: 'equals',
    value: '',
  }
}

function newGroup(fields: QueryField[]): QueryGroup {
  return {
    id: crypto.randomUUID(),
    combinator: 'and',
    conditions: [newCondition(fields)],
    groups: [],
  }
}

function allowedOperators(fieldType: QueryField['type']): QueryOperator[] {
  if (fieldType === 'number') return ['equals', 'gt', 'lt']
  if (fieldType === 'select') return ['equals', 'in']
  return ['equals', 'contains', 'in']
}

function updateGroup(root: QueryGroup, groupId: string, updater: (target: QueryGroup) => QueryGroup): QueryGroup {
  if (root.id === groupId) {
    return updater(root)
  }

  return {
    ...root,
    groups: root.groups.map((group) => updateGroup(group, groupId, updater)),
  }
}

export function QueryBuilder({ fields, value, onChange }: QueryBuilderProps) {
  function renderGroup(group: QueryGroup, depth: number): React.ReactNode {
    return (
      <section key={group.id} className="rf-query-builder__group" style={{ marginLeft: depth * 12 }}>
        <header className="rf-query-builder__group-head">
          <select
            className="rf-query-builder__select"
            value={group.combinator}
            onChange={(event) => {
              onChange(updateGroup(value, group.id, (target) => ({
                ...target,
                combinator: event.currentTarget.value as QueryGroup['combinator'],
              })))
            }}
            aria-label="Group combinator"
          >
            <option value="and">AND</option>
            <option value="or">OR</option>
          </select>

          <button
            type="button"
            className="rf-query-builder__btn"
            onClick={() => {
              onChange(updateGroup(value, group.id, (target) => ({
                ...target,
                conditions: [...target.conditions, newCondition(fields)],
              })))
            }}
          >
            Add condition
          </button>

          <button
            type="button"
            className="rf-query-builder__btn"
            onClick={() => {
              onChange(updateGroup(value, group.id, (target) => ({
                ...target,
                groups: [...target.groups, newGroup(fields)],
              })))
            }}
          >
            Add subgroup
          </button>
        </header>

        {group.conditions.map((condition) => {
          const field = fields.find((entry) => entry.id === condition.fieldId) ?? fields[0]
          const operators = allowedOperators(field?.type ?? 'text')

          return (
            <div className="rf-query-builder__condition" key={condition.id}>
              <select
                className="rf-query-builder__select"
                value={condition.fieldId}
                onChange={(event) => {
                  const fieldId = event.currentTarget.value
                  const selectedField = fields.find((entry) => entry.id === fieldId)
                  const fallbackOperator = allowedOperators(selectedField?.type ?? 'text')[0]

                  onChange(updateGroup(value, group.id, (target) => ({
                    ...target,
                    conditions: target.conditions.map((entry) => entry.id === condition.id
                      ? { ...entry, fieldId, operator: fallbackOperator, value: '' }
                      : entry),
                  })))
                }}
                aria-label="Query field"
              >
                {fields.map((entry) => <option key={entry.id} value={entry.id}>{entry.label}</option>)}
              </select>

              <select
                className="rf-query-builder__select"
                value={condition.operator}
                onChange={(event) => {
                  onChange(updateGroup(value, group.id, (target) => ({
                    ...target,
                    conditions: target.conditions.map((entry) => entry.id === condition.id
                      ? { ...entry, operator: event.currentTarget.value as QueryOperator }
                      : entry),
                  })))
                }}
                aria-label="Query operator"
              >
                {operators.map((operator) => <option key={operator} value={operator}>{operator}</option>)}
              </select>

              {field?.type === 'select' ? (
                <select
                  className="rf-query-builder__select"
                  value={condition.value}
                  onChange={(event) => {
                    onChange(updateGroup(value, group.id, (target) => ({
                      ...target,
                      conditions: target.conditions.map((entry) => entry.id === condition.id
                        ? { ...entry, value: event.currentTarget.value }
                        : entry),
                    })))
                  }}
                  aria-label="Query value"
                >
                  <option value="">Select</option>
                  {(field.options ?? []).map((option) => <option key={option} value={option}>{option}</option>)}
                </select>
              ) : (
                <input
                  className="rf-query-builder__input"
                  type={field?.type === 'number' ? 'number' : 'text'}
                  value={condition.value}
                  onChange={(event) => {
                    onChange(updateGroup(value, group.id, (target) => ({
                      ...target,
                      conditions: target.conditions.map((entry) => entry.id === condition.id
                        ? { ...entry, value: event.currentTarget.value }
                        : entry),
                    })))
                  }}
                />
              )}
            </div>
          )
        })}

        {group.groups.map((child) => renderGroup(child, depth + 1))}
      </section>
    )
  }

  return (
    <div className="rf-query-builder">
      {renderGroup(value, 0)}
    </div>
  )
}
