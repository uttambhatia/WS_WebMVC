import './core.css'
import { Toast, type ToastMessage } from './Toast'

export interface NotificationCenterProps {
  messages: ToastMessage[]
  onDismiss: (id: string) => void
  className?: string
}

export function NotificationCenter({ messages, onDismiss, className }: NotificationCenterProps) {
  return (
    <section className={['rf-notification-center', className ?? ''].filter(Boolean).join(' ')} aria-live="polite" aria-label="Notifications">
      {messages.map((message) => (
        <Toast key={message.id} message={message} onDismiss={onDismiss} />
      ))}
    </section>
  )
}
