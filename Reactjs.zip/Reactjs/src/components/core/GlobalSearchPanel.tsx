import './core.css'
import React from 'react'

export interface GlobalSearchResult {
  id: string
  title: string
  subtitle?: string
  group: string
  keywords?: string[]
  onSelect?: () => void
}

export interface GlobalSearchPanelProps {
  results: GlobalSearchResult[]
  query: string
  onQueryChange: (query: string) => void
}

export function GlobalSearchPanel({ results, query, onQueryChange }: GlobalSearchPanelProps) {
  const grouped = React.useMemo(() => {
    const normalized = query.trim().toLowerCase()
    const filtered = !normalized
      ? results
      : results.filter((result) => {
          const haystack = [result.title, result.subtitle ?? '', ...(result.keywords ?? [])].join(' ').toLowerCase()
          return haystack.includes(normalized)
        })

    const map = new Map<string, GlobalSearchResult[]>()
    filtered.forEach((result) => {
      const bucket = map.get(result.group) ?? []
      bucket.push(result)
      map.set(result.group, bucket)
    })
    return map
  }, [query, results])

  return (
    <section className="rf-global-search" aria-label="Global search panel">
      <input
        className="rf-global-search__input"
        type="search"
        value={query}
        onChange={(event) => onQueryChange(event.currentTarget.value)}
        placeholder="Search routes, entities, and docs"
      />

      <div className="rf-global-search__groups">
        {Array.from(grouped.entries()).map(([group, entries]) => (
          <section key={group}>
            <h4>{group}</h4>
            <ul>
              {entries.map((entry) => (
                <li key={entry.id}>
                  <button type="button" className="rf-global-search__result" onClick={entry.onSelect}>
                    <strong>{entry.title}</strong>
                    {entry.subtitle ? <span>{entry.subtitle}</span> : null}
                  </button>
                </li>
              ))}
            </ul>
          </section>
        ))}
      </div>
    </section>
  )
}
