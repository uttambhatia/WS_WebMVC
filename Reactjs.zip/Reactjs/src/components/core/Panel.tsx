import './core.css'
import React from 'react'

export interface PanelProps {
  variant: 'info' | 'success' | 'warning' | 'error'
  title?: string
  icon?: React.ReactNode
  children?: React.ReactNode
  className?: string
}

const DEFAULT_ICONS: Record<PanelProps['variant'], string> = {
  info: 'ℹ',
  success: '✓',
  warning: '⚠',
  error: '✕',
}

export function Panel({
  variant,
  title,
  icon,
  children,
  className,
  ...rest
}: PanelProps & React.HTMLAttributes<HTMLElement>) {
  const role = variant === 'error' || variant === 'warning' ? 'alert' : 'status'
  const resolvedIcon = icon !== undefined ? icon : DEFAULT_ICONS[variant]

  const classes = ['rf-panel', `rf-panel--${variant}`, className]
    .filter(Boolean)
    .join(' ')

  return (
    <div className={classes} role={role} {...rest}>
      <span className="rf-panel__icon" aria-hidden="true">
        {resolvedIcon}
      </span>
      <div className="rf-panel__body">
        {title && <p className="rf-panel__title">{title}</p>}
        <div className="rf-panel__content">{children}</div>
      </div>
    </div>
  )
}
