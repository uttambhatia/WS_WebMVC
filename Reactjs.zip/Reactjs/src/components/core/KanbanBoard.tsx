import './core.css'
import React from 'react'

export interface KanbanCard {
  id: string
  title: string
  description?: string
  badge?: React.ReactNode
  metadata?: React.ReactNode
}

export interface KanbanColumn {
  id: string
  title: string
  cards: KanbanCard[]
  wipLimit?: number
  addCardLabel?: string
}

export interface KanbanBoardProps {
  columns: KanbanColumn[]
  onCardMove?: (
    cardId: string,
    fromColumnId: string,
    toColumnId: string,
    newIndex: number,
  ) => void
  onAddCard?: (columnId: string) => void
  onCardClick?: (card: KanbanCard, columnId: string) => void
  renderCard?: (card: KanbanCard, columnId: string) => React.ReactNode
  className?: string
}

interface DragState {
  cardId: string
  fromColumnId: string
}

interface MoveDialogState {
  card: KanbanCard
  fromColumnId: string
}

export function KanbanBoard({
  columns,
  onCardMove,
  onAddCard,
  onCardClick,
  renderCard,
  className,
}: KanbanBoardProps) {
  const [dragState, setDragState] = React.useState<DragState | null>(null)
  const [dragOverColumnId, setDragOverColumnId] = React.useState<string | null>(null)
  const [dragOverIndex, setDragOverIndex] = React.useState<number>(0)
  const [moveDialog, setMoveDialog] = React.useState<MoveDialogState | null>(null)
  const [moveTargetColumnId, setMoveTargetColumnId] = React.useState<string>('')
  const [moveTargetIndex, setMoveTargetIndex] = React.useState<number>(0)

  function handleDragStart(cardId: string, fromColumnId: string) {
    setDragState({ cardId, fromColumnId })
  }

  function handleDragOver(event: React.DragEvent, columnId: string, cardIndex: number) {
    event.preventDefault()
    setDragOverColumnId(columnId)
    setDragOverIndex(cardIndex)
  }

  function handleDrop(event: React.DragEvent, toColumnId: string) {
    event.preventDefault()
    if (!dragState) return

    onCardMove?.(dragState.cardId, dragState.fromColumnId, toColumnId, dragOverIndex)

    setDragState(null)
    setDragOverColumnId(null)
    setDragOverIndex(0)
  }

  function handleDragEnd() {
    setDragState(null)
    setDragOverColumnId(null)
    setDragOverIndex(0)
  }

  function openMoveDialog(card: KanbanCard, fromColumnId: string) {
    const firstOtherColumn = columns.find((c) => c.id !== fromColumnId)
    setMoveDialog({ card, fromColumnId })
    setMoveTargetColumnId(firstOtherColumn?.id ?? columns[0]?.id ?? '')
    setMoveTargetIndex(0)
  }

  function confirmMove() {
    if (!moveDialog) return
    const targetColumn = columns.find((c) => c.id === moveTargetColumnId)
    const safeIndex = Math.max(0, Math.min(moveTargetIndex, targetColumn?.cards.length ?? 0))
    onCardMove?.(moveDialog.card.id, moveDialog.fromColumnId, moveTargetColumnId, safeIndex)
    setMoveDialog(null)
  }

  function renderDefaultCard(card: KanbanCard) {
    return (
      <>
        {card.badge && <div className="rf-kanban__card-badge">{card.badge}</div>}
        <p className="rf-kanban__card-title">{card.title}</p>
        {card.description && (
          <p className="rf-kanban__card-description">{card.description}</p>
        )}
        {card.metadata && <div className="rf-kanban__card-meta">{card.metadata}</div>}
      </>
    )
  }

  return (
    <div className={['rf-kanban', className ?? ''].filter(Boolean).join(' ')}>
      <div className="rf-kanban__columns">
        {columns.map((column) => {
          const isOverLimit = column.wipLimit !== undefined && column.cards.length > column.wipLimit

          return (
            <div
              key={column.id}
              className={[
                'rf-kanban__column',
                isOverLimit ? 'rf-kanban__column--over-limit' : '',
                dragOverColumnId === column.id ? 'rf-kanban__column--drag-over' : '',
              ]
                .filter(Boolean)
                .join(' ')}
              onDragOver={(e) => handleDragOver(e, column.id, column.cards.length)}
              onDrop={(e) => handleDrop(e, column.id)}
            >
              <div className="rf-kanban__column-header">
                <span className="rf-kanban__column-title">{column.title}</span>
                <span className="rf-kanban__column-count" aria-label={`${column.cards.length} cards`}>
                  {column.cards.length}
                  {column.wipLimit !== undefined && (
                    <span className="rf-kanban__wip-limit" aria-label={`WIP limit ${column.wipLimit}`}>
                      {isOverLimit ? ' ⚠' : ` / ${column.wipLimit}`}
                    </span>
                  )}
                </span>
              </div>

              <ul className="rf-kanban__cards" role="list" aria-label={`${column.title} cards`}>
                {column.cards.map((card, cardIndex) => {
                  const isDragging = dragState?.cardId === card.id

                  return (
                    <li
                      key={card.id}
                      role="listitem"
                      draggable
                      aria-grabbed={isDragging ? 'true' : 'false'}
                      className={[
                        'rf-kanban__card',
                        isDragging ? 'rf-kanban__card--dragging' : '',
                      ]
                        .filter(Boolean)
                        .join(' ')}
                      onDragStart={() => handleDragStart(card.id, column.id)}
                      onDragOver={(e) => {
                        e.stopPropagation()
                        handleDragOver(e, column.id, cardIndex)
                      }}
                      onDragEnd={handleDragEnd}
                      onClick={() => onCardClick?.(card, column.id)}
                    >
                      {renderCard ? renderCard(card, column.id) : renderDefaultCard(card)}

                      {onCardMove && (
                        <button
                          type="button"
                          className="rf-kanban__card-move"
                          aria-label={`Move card: ${card.title}`}
                          onClick={(e) => {
                            e.stopPropagation()
                            openMoveDialog(card, column.id)
                          }}
                        >
                          ⇄
                        </button>
                      )}
                    </li>
                  )
                })}
              </ul>

              {onAddCard && (
                <button
                  type="button"
                  className="rf-kanban__add-card"
                  onClick={() => onAddCard(column.id)}
                  aria-label={column.addCardLabel ?? `Add card to ${column.title}`}
                >
                  + {column.addCardLabel ?? 'Add card'}
                </button>
              )}
            </div>
          )
        })}
      </div>

      {/* Keyboard move dialog */}
      {moveDialog && (
        <div className="rf-kanban__move-dialog" role="dialog" aria-modal="true" aria-label="Move card">
          <div className="rf-kanban__move-dialog-panel">
            <p className="rf-kanban__move-dialog-title">Move "{moveDialog.card.title}"</p>
            <label className="rf-kanban__move-dialog-label" htmlFor="kanban-move-column">
              To column
            </label>
            <select
              id="kanban-move-column"
              className="rf-kanban__move-dialog-select"
              value={moveTargetColumnId}
              onChange={(e) => {
                setMoveTargetColumnId(e.currentTarget.value)
                setMoveTargetIndex(0)
              }}
            >
              {columns.map((col) => (
                <option key={col.id} value={col.id} disabled={col.id === moveDialog.fromColumnId}>
                  {col.title}
                </option>
              ))}
            </select>
            <label className="rf-kanban__move-dialog-label" htmlFor="kanban-move-index">
              Position
            </label>
            <select
              id="kanban-move-index"
              className="rf-kanban__move-dialog-select"
              value={String(moveTargetIndex)}
              onChange={(e) => setMoveTargetIndex(Number(e.currentTarget.value))}
            >
              {(() => {
                const col = columns.find((c) => c.id === moveTargetColumnId)
                const count = col?.cards.length ?? 0
                return Array.from({ length: count + 1 }, (_, i) => (
                  <option key={i} value={String(i)}>
                    {i === 0 ? 'Top' : i === count ? 'Bottom' : `After card ${i}`}
                  </option>
                ))
              })()}
            </select>
            <div className="rf-kanban__move-dialog-actions">
              <button type="button" className="rf-btn rf-btn--outline rf-btn--sm" onClick={() => setMoveDialog(null)}>
                Cancel
              </button>
              <button type="button" className="rf-btn rf-btn--primary rf-btn--sm" onClick={confirmMove}>
                Move
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
