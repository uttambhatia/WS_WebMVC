import './core.css'
import React from 'react'

export interface PivotRow {
  [key: string]: string | number
}

export interface PivotTableProps {
  data: PivotRow[]
  rowField: string
  columnField: string
  valueField: string
  aggregator?: 'sum' | 'count'
  className?: string
}

function toNumber(value: unknown): number {
  const parsed = Number(value)
  return Number.isFinite(parsed) ? parsed : 0
}

export function PivotTable({
  data,
  rowField,
  columnField,
  valueField,
  aggregator = 'sum',
  className,
}: PivotTableProps) {
  const rowKeys = React.useMemo(() => Array.from(new Set(data.map((row) => String(row[rowField])))), [data, rowField])
  const columnKeys = React.useMemo(() => Array.from(new Set(data.map((row) => String(row[columnField])))), [columnField, data])

  const matrix = React.useMemo(() => {
    const map = new Map<string, number>()

    for (const row of data) {
      const r = String(row[rowField])
      const c = String(row[columnField])
      const key = `${r}::${c}`
      const current = map.get(key) ?? 0
      const next = aggregator === 'count' ? current + 1 : current + toNumber(row[valueField])
      map.set(key, next)
    }

    return map
  }, [aggregator, columnField, data, rowField, valueField])

  return (
    <table className={['rf-pivot-table', className ?? ''].filter(Boolean).join(' ')}>
      <thead>
        <tr>
          <th>{rowField}</th>
          {columnKeys.map((column) => (
            <th key={column}>{column}</th>
          ))}
        </tr>
      </thead>
      <tbody>
        {rowKeys.map((row) => (
          <tr key={row}>
            <th>{row}</th>
            {columnKeys.map((column) => {
              const key = `${row}::${column}`
              return <td key={column}>{matrix.get(key) ?? 0}</td>
            })}
          </tr>
        ))}
      </tbody>
    </table>
  )
}
