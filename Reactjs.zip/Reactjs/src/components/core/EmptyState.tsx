import './core.css'
import React from 'react'

export interface EmptyStateProps {
  title: string
  description?: string
  icon?: React.ReactNode
  action?: React.ReactNode
  align?: 'left' | 'center'
  className?: string
}

const DEFAULT_ICON = '📭'

export function EmptyState({
  title,
  description,
  icon,
  action,
  align = 'center',
  className,
  ...rest
}: EmptyStateProps & React.HTMLAttributes<HTMLDivElement>) {
  const classes = ['rf-empty-state', `rf-empty-state--${align}`, className].filter(Boolean).join(' ')
  const resolvedIcon = icon ?? DEFAULT_ICON

  return (
    <div className={classes} {...rest}>
      <div className="rf-empty-state__icon" aria-hidden="true">
        {resolvedIcon}
      </div>
      <h3 className="rf-empty-state__title">{title}</h3>
      {description && <p className="rf-empty-state__description">{description}</p>}
      {action && <div className="rf-empty-state__action">{action}</div>}
    </div>
  )
}
