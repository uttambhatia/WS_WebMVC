import './core.css'
import React from 'react'

export interface PopoverProps {
  trigger: React.ReactNode
  children: React.ReactNode
  open?: boolean
  defaultOpen?: boolean
  onOpenChange?: (open: boolean) => void
  placement?: 'top' | 'right' | 'bottom' | 'left'
  className?: string
}

export function Popover({
  trigger,
  children,
  open,
  defaultOpen = false,
  onOpenChange,
  placement = 'bottom',
  className,
}: PopoverProps) {
  const [internalOpen, setInternalOpen] = React.useState(defaultOpen)
  const rootRef = React.useRef<HTMLDivElement | null>(null)
  const isOpen = open ?? internalOpen

  const setOpen = React.useCallback((next: boolean) => {
    if (open === undefined) {
      setInternalOpen(next)
    }
    onOpenChange?.(next)
  }, [onOpenChange, open])

  React.useEffect(() => {
    if (!isOpen) return

    function onPointerDown(event: MouseEvent) {
      const target = event.target as Node
      if (rootRef.current?.contains(target)) return
      setOpen(false)
    }

    function onKeyDown(event: KeyboardEvent) {
      if (event.key === 'Escape') {
        event.preventDefault()
        setOpen(false)
      }
    }

    document.addEventListener('mousedown', onPointerDown)
    document.addEventListener('keydown', onKeyDown)

    return () => {
      document.removeEventListener('mousedown', onPointerDown)
      document.removeEventListener('keydown', onKeyDown)
    }
  }, [isOpen, setOpen])

  return (
    <div ref={rootRef} className={['rf-popover', className ?? ''].filter(Boolean).join(' ')}>
      <button
        type="button"
        className="rf-popover__trigger"
        aria-expanded={isOpen ? 'true' : 'false'}
        onClick={() => setOpen(!isOpen)}
      >
        {trigger}
      </button>
      {isOpen && (
        <div className={['rf-popover__panel', `rf-popover__panel--${placement}`].join(' ')} role="dialog">
          {children}
        </div>
      )}
    </div>
  )
}
