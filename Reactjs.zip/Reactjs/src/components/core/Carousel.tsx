import './core.css'
import React from 'react'

export interface CarouselProps {
  children: React.ReactNode[]
  initialIndex?: number
  onIndexChange?: (index: number) => void
  className?: string
}

export function Carousel({
  children,
  initialIndex = 0,
  onIndexChange,
  className,
}: CarouselProps) {
  const slides = React.Children.toArray(children)
  const [index, setIndex] = React.useState(Math.max(0, Math.min(slides.length - 1, initialIndex)))

  React.useEffect(() => {
    onIndexChange?.(index)
  }, [index, onIndexChange])

  if (slides.length === 0) {
    return null
  }

  return (
    <div className={['rf-carousel', className ?? ''].filter(Boolean).join(' ')}>
      <div className="rf-carousel__viewport" role="region" aria-label="Carousel">
        <div
          className="rf-carousel__track"
          style={{ transform: `translateX(-${index * 100}%)` }}
        >
          {slides.map((slide, slideIndex) => (
            <div className="rf-carousel__slide" key={slideIndex} aria-hidden={slideIndex !== index}>
              {slide}
            </div>
          ))}
        </div>
      </div>
      <div className="rf-carousel__controls">
        <button
          type="button"
          className="rf-carousel__btn"
          onClick={() => setIndex((current) => Math.max(0, current - 1))}
          disabled={index === 0}
        >
          Prev
        </button>
        <div className="rf-carousel__dots">
          {slides.map((_, dotIndex) => (
            <button
              key={dotIndex}
              type="button"
              className={[
                'rf-carousel__dot',
                dotIndex === index ? 'rf-carousel__dot--active' : '',
              ].filter(Boolean).join(' ')}
              aria-label={`Go to slide ${dotIndex + 1}`}
              onClick={() => setIndex(dotIndex)}
            />
          ))}
        </div>
        <button
          type="button"
          className="rf-carousel__btn"
          onClick={() => setIndex((current) => Math.min(slides.length - 1, current + 1))}
          disabled={index === slides.length - 1}
        >
          Next
        </button>
      </div>
    </div>
  )
}
