import React from 'react'

export interface PermissionGateProps {
  permissions?: string[]
  roles?: string[]
  userPermissions?: string[]
  userRoles?: string[]
  mode?: 'all' | 'any'
  fallback?: React.ReactNode
  children: React.ReactNode
}

function passes(required: string[], actual: string[], mode: 'all' | 'any'): boolean {
  if (required.length === 0) {
    return true
  }
  if (mode === 'all') {
    return required.every((item) => actual.includes(item))
  }
  return required.some((item) => actual.includes(item))
}

export function PermissionGate({
  permissions = [],
  roles = [],
  userPermissions = [],
  userRoles = [],
  mode = 'all',
  fallback = null,
  children,
}: PermissionGateProps) {
  const permissionPass = passes(permissions, userPermissions, mode)
  const rolePass = passes(roles, userRoles, mode)

  if (permissionPass && rolePass) {
    return <>{children}</>
  }

  return <>{fallback}</>
}
