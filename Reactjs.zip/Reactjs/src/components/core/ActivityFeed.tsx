import './core.css'
import React from 'react'

export interface ActivityItem {
  id: string
  actor: string
  type: string
  message: string
  createdAt: string
}

export interface ActivityFeedProps {
  items: ActivityItem[]
  actorFilter?: string
  typeFilter?: string
}

export function ActivityFeed({ items, actorFilter = '', typeFilter = '' }: ActivityFeedProps) {
  const filtered = React.useMemo(() => {
    const actor = actorFilter.trim().toLowerCase()
    const type = typeFilter.trim().toLowerCase()

    return items.filter((item) => {
      const actorMatch = !actor || item.actor.toLowerCase().includes(actor)
      const typeMatch = !type || item.type.toLowerCase() === type
      return actorMatch && typeMatch
    })
  }, [actorFilter, items, typeFilter])

  return (
    <ol className="rf-activity-feed" aria-label="Activity feed">
      {filtered.map((item) => (
        <li key={item.id} className="rf-activity-feed__item">
          <div className="rf-activity-feed__meta">
            <strong>{item.actor}</strong>
            <span className="rf-activity-feed__type">{item.type}</span>
            <time dateTime={item.createdAt}>{new Date(item.createdAt).toLocaleString()}</time>
          </div>
          <p>{item.message}</p>
        </li>
      ))}
      {filtered.length === 0 ? <li className="rf-activity-feed__empty">No matching activity.</li> : null}
    </ol>
  )
}
