import './core.css'
import React from 'react'

export interface ToastMessage {
  id: string
  title?: React.ReactNode
  description: React.ReactNode
  variant?: 'info' | 'success' | 'warning' | 'error'
  timeoutMs?: number
}

export interface ToastProps {
  message: ToastMessage
  onDismiss: (id: string) => void
}

export function Toast({ message, onDismiss }: ToastProps) {
  React.useEffect(() => {
    if (!message.timeoutMs) return
    const timeout = window.setTimeout(() => onDismiss(message.id), message.timeoutMs)
    return () => window.clearTimeout(timeout)
  }, [message.id, message.timeoutMs, onDismiss])

  const variant = message.variant ?? 'info'

  return (
    <div className={['rf-toast', `rf-toast--${variant}`].join(' ')} role="status">
      <div className="rf-toast__content">
        {message.title && <p className="rf-toast__title">{message.title}</p>}
        <p className="rf-toast__description">{message.description}</p>
      </div>
      <button type="button" className="rf-toast__dismiss" onClick={() => onDismiss(message.id)} aria-label="Dismiss toast">
        ×
      </button>
    </div>
  )
}
