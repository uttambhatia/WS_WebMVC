import './core.css'
import { useResponsiveChartWidth } from './useResponsiveChartWidth'

export interface StackedBarChartDatum {
  label: string
  [key: string]: number | string
}

type StackedSeriesPoint = {
  name?: string
  value?: number
}

export type StackedBarOrientation = 'vertical' | 'horizontal'
export type StackMode = 'absolute' | 'percent'
export type StackedBarVariant = 'vertical' | 'horizontal' | 'percent' | 'grouped-stacked' | 'diverging'

export interface StackedBarChartProps {
  data: StackedBarChartDatum[]
  series: string[]
  width?: number
  height?: number
  responsive?: boolean
  variant?: StackedBarVariant
  orientation?: StackedBarOrientation
  stackMode?: StackMode
  showLegend?: boolean
  groupField?: string
  divergingBaseline?: boolean
  ariaLabel?: string
  className?: string
}

/**
 * StackedBarChart renders stacked or diverging bar charts with multiple series.
 * 
 * @example
 * <StackedBarChart
 *   data={[
 *     { label: 'A', sales: 100, returns: 20 },
 *     { label: 'B', sales: 150, returns: 30 },
 *   ]}
 *   series={['sales', 'returns']}
 *   showLegend
 * />
 */
export function StackedBarChart({
  data,
  series,
  width = 320,
  height = 240,
  responsive = false,
  variant = 'vertical',
  orientation = 'vertical',
  stackMode = 'absolute',
  showLegend = true,
  groupField,
  divergingBaseline = false,
  ariaLabel = 'Stacked bar chart',
  className,
}: StackedBarChartProps) {
  const { containerRef, width: responsiveWidth } = useResponsiveChartWidth<HTMLElement>(width, responsive)

  const resolvedOrientation =
    variant === 'horizontal' ? 'horizontal' : orientation
  const resolvedStackMode =
    variant === 'percent' ? 'percent' : stackMode
  const resolvedDiverging =
    variant === 'diverging' || divergingBaseline

  const isVertical = resolvedOrientation === 'vertical'
  const chartWidth = isVertical ? responsiveWidth : height
  const chartHeight = isVertical ? height : responsiveWidth

  const getNumericValue = (datum: StackedBarChartDatum, key: string): number => {
    const value = datum[key]
    return typeof value === 'number' ? value : 0
  }

  // Handle data structure - extract series keys if not provided
  const seriesKeys = series ?? (data.length > 0 && data[0].series ? Object.keys(data[0]) : [])
  const groupValues =
    variant === 'grouped-stacked' && groupField
      ? Array.from(new Set(data.map((datum) => String(datum[groupField] ?? 'default'))))
      : ['default']

  // Calculate totals for normalization
  const totals = data.map((d) => {
    const rawSeries = d.series
    if (Array.isArray(rawSeries)) {
      return rawSeries.reduce((sum: number, item) => {
        const seriesItem = item as StackedSeriesPoint
        return sum + (typeof seriesItem.value === 'number' ? seriesItem.value : 0)
      }, 0)
    }
    return seriesKeys.reduce((sum: number, key: string) => sum + getNumericValue(d, key), 0)
  })

  const maxTotal = Math.max(...totals, 1)

  const padding = 30
  const innerWidth = chartWidth - padding * 2
  const innerHeight = chartHeight - padding * 2

  const barCount = data.length
  const barWidth = isVertical ? innerWidth / barCount : innerHeight / barCount
  const barHeight = isVertical ? innerHeight : innerWidth

  const classes = [
    'rf-stacked-bar-chart',
    `rf-stacked-bar-chart--${resolvedOrientation}`,
    resolvedStackMode === 'percent' ? 'rf-stacked-bar-chart--percent' : '',
    resolvedDiverging ? 'rf-stacked-bar-chart--diverging' : '',
    variant === 'grouped-stacked' ? 'rf-stacked-bar-chart--grouped-stacked' : '',
    className ?? '',
  ]
    .filter(Boolean)
    .join(' ')

  return (
    <figure className={classes} ref={containerRef}>
      <svg
        role="img"
        aria-label={ariaLabel}
        viewBox={`0 0 ${chartWidth} ${chartHeight}`}
        width={chartWidth}
        height={chartHeight}
        className="rf-stacked-bar-chart__svg"
      >
        {/* Render bars */}
        {data.map((datum, dataIdx) => {
          const total = totals[dataIdx]
          let offset = resolvedDiverging ? total / 2 : 0
          const datumGroup =
            variant === 'grouped-stacked' && groupField
              ? String(datum[groupField] ?? 'default')
              : 'default'
          const groupIndex = Math.max(groupValues.indexOf(datumGroup), 0)
          const groupSlot = barWidth / Math.max(groupValues.length, 1)
          const barSlotWidth = variant === 'grouped-stacked' ? groupSlot * 0.75 : barWidth * 0.8

          return (
            <g key={`bar-${dataIdx}`}>
              {series.map((seriesKey, seriesIdx) => {
                const value = typeof datum[seriesKey] === 'number' ? (datum[seriesKey] as number) : 0
                let segmentSize =
                  resolvedStackMode === 'percent'
                    ? total > 0
                      ? (value / total) * barHeight
                      : 0
                    : (value / maxTotal) * barHeight

                if (resolvedDiverging) {
                  segmentSize = total > 0 ? (value / total) * (barHeight / 2) : 0
                  offset -= segmentSize / 2
                }

                const slotOffset =
                  variant === 'grouped-stacked'
                    ? groupIndex * groupSlot + (groupSlot - barSlotWidth) / 2
                    : (barWidth - barSlotWidth) / 2
                const x = isVertical ? padding + dataIdx * barWidth + slotOffset : padding + offset
                const y = isVertical
                  ? padding + barHeight - (resolvedDiverging ? barHeight / 2 + segmentSize / 2 : segmentSize)
                  : padding + dataIdx * barWidth + slotOffset
                const rectWidth = isVertical ? barSlotWidth : segmentSize
                const rectHeight = isVertical ? segmentSize : barSlotWidth

                const hueStep = (seriesIdx / series.length) * 360

                return (
                  <rect
                    key={`segment-${dataIdx}-${seriesIdx}`}
                    x={x}
                    y={y}
                    width={rectWidth}
                    height={rectHeight}
                    fill={`hsl(${hueStep}, 70%, 60%)`}
                    stroke="none"
                    className="rf-stacked-bar-chart__segment"
                    aria-label={`${datum.label} - ${seriesKey}: ${value}`}
                  />
                )
              })}

              {/* Category label */}
              <text
                x={isVertical ? padding + dataIdx * barWidth + barWidth / 2 : padding - 5}
                y={isVertical ? chartHeight - padding + 12 : padding + dataIdx * barWidth + barWidth / 2}
                textAnchor={isVertical ? 'middle' : 'end'}
                dy={isVertical ? '0' : '0.3em'}
                fontSize="12"
                fill="var(--text, #000000)"
                className="rf-stacked-bar-chart__label"
              >
                {String(datum.label)}
              </text>
            </g>
          )
        })}

        {/* Baseline for diverging */}
        {resolvedDiverging && (
          <line
            x1={isVertical ? padding : padding}
            y1={isVertical ? padding + barHeight / 2 : padding}
            x2={isVertical ? chartWidth - padding : padding}
            y2={isVertical ? padding + barHeight / 2 : chartHeight - padding}
            stroke="var(--border, #ccc)"
            strokeWidth="1"
          />
        )}
      </svg>

      {showLegend && (
        <div className="rf-stacked-bar-chart__legend">
          {series.map((seriesKey, idx) => {
            const hueStep = (idx / series.length) * 360
            return (
              <div key={`legend-${idx}`} className="rf-stacked-bar-chart__legend-item">
                <span
                  className="rf-stacked-bar-chart__legend-color"
                  style={{ backgroundColor: `hsl(${hueStep}, 70%, 60%)` }}
                />
                <span className="rf-stacked-bar-chart__legend-label">{seriesKey}</span>
              </div>
            )
          })}
        </div>
      )}
    </figure>
  )
}
