import './core.css'
import React from 'react'
import { createPortal } from 'react-dom'

export interface ModalProps {
  open: boolean
  title?: React.ReactNode
  children: React.ReactNode
  onClose: () => void
  closeOnBackdropClick?: boolean
  closeOnEscape?: boolean
  footer?: React.ReactNode
  className?: string
}

export function Modal({
  open,
  title,
  children,
  onClose,
  closeOnBackdropClick = true,
  closeOnEscape = true,
  footer,
  className,
}: ModalProps) {
  const panelRef = React.useRef<HTMLDivElement | null>(null)
  const lastFocusedRef = React.useRef<HTMLElement | null>(null)

  React.useEffect(() => {
    if (!open) return

    lastFocusedRef.current = document.activeElement as HTMLElement | null

    const onKeyDown = (event: KeyboardEvent) => {
      if (closeOnEscape && event.key === 'Escape') {
        event.preventDefault()
        onClose()
      }
    }

    document.addEventListener('keydown', onKeyDown)
    return () => {
      document.removeEventListener('keydown', onKeyDown)
    }
  }, [closeOnEscape, onClose, open])

  React.useEffect(() => {
    if (!open) return
    const firstFocusable = panelRef.current?.querySelector<HTMLElement>(
      'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])',
    )
    firstFocusable?.focus()
  }, [open])

  React.useEffect(() => {
    if (open) return
    lastFocusedRef.current?.focus()
  }, [open])

  if (!open || typeof document === 'undefined') {
    return null
  }

  function handleBackdropClick(event: React.MouseEvent<HTMLDivElement>) {
    if (event.target !== event.currentTarget) return
    if (closeOnBackdropClick) {
      onClose()
    }
  }

  return createPortal(
    <div className="rf-modal__backdrop" onMouseDown={handleBackdropClick}>
      <div
        ref={panelRef}
        className={['rf-modal', className ?? ''].filter(Boolean).join(' ')}
        role="dialog"
        aria-modal="true"
        aria-label={typeof title === 'string' ? title : undefined}
      >
        <div className="rf-modal__header">
          <div className="rf-modal__title">{title}</div>
          <button type="button" className="rf-modal__close" onClick={onClose} aria-label="Close modal">
            ×
          </button>
        </div>
        <div className="rf-modal__body">{children}</div>
        {footer && <div className="rf-modal__footer">{footer}</div>}
      </div>
    </div>,
    document.body,
  )
}
