import './core.css'

export interface ChatMessage {
  id: string
  author: string
  text: string
  timestamp: string
  avatar?: string
  read?: boolean
}

export interface ChatThreadProps {
  messages: ChatMessage[]
  currentUser?: string
  className?: string
}

export function ChatThread({
  messages,
  currentUser,
  className,
}: ChatThreadProps) {
  return (
    <div className={['rf-chat-thread', className ?? ''].filter(Boolean).join(' ')} role="log" aria-label="Chat thread">
      {messages.map((message) => {
        const isOwn = currentUser !== undefined && message.author === currentUser
        return (
          <article
            key={message.id}
            className={[
              'rf-chat-thread__message',
              isOwn ? 'rf-chat-thread__message--own' : '',
            ].filter(Boolean).join(' ')}
          >
            <div className="rf-chat-thread__avatar" aria-hidden="true">
              {message.avatar ? <img src={message.avatar} alt="" /> : message.author.slice(0, 1).toUpperCase()}
            </div>
            <div className="rf-chat-thread__bubble">
              <header className="rf-chat-thread__meta">
                <span className="rf-chat-thread__author">{message.author}</span>
                <time className="rf-chat-thread__time">{message.timestamp}</time>
              </header>
              <p className="rf-chat-thread__text">{message.text}</p>
              {message.read !== undefined && (
                <span className="rf-chat-thread__receipt">{message.read ? 'Read' : 'Sent'}</span>
              )}
            </div>
          </article>
        )
      })}
    </div>
  )
}
