import './core.css'
import React from 'react'

export type DataExporterFormat = 'csv' | 'json'

export interface DataExporterColumn {
  key: string
  label: string
}

export interface DataExporterProps {
  rows: Record<string, unknown>[]
  columns?: DataExporterColumn[]
  defaultFormat?: DataExporterFormat
  filename?: string
  onExport?: (payload: { format: DataExporterFormat; content: string; filename: string }) => void
  className?: string
}

function escapeCsv(value: unknown): string {
  const text = String(value ?? '')
  if (!/[",\n]/.test(text)) {
    return text
  }
  return `"${text.replace(/"/g, '""')}"`
}

function toCsv(rows: Record<string, unknown>[], columns: DataExporterColumn[]): string {
  const header = columns.map((col) => escapeCsv(col.label)).join(',')
  const lines = rows.map((row) => columns.map((col) => escapeCsv(row[col.key])).join(','))
  return [header, ...lines].join('\n')
}

function triggerDownload(content: string, filename: string, mimeType: string): void {
  const blob = new Blob([content], { type: mimeType })
  const url = URL.createObjectURL(blob)
  const anchor = document.createElement('a')
  anchor.href = url
  anchor.download = filename
  document.body.appendChild(anchor)
  anchor.click()
  anchor.remove()
  URL.revokeObjectURL(url)
}

export function DataExporter({
  rows,
  columns,
  defaultFormat = 'csv',
  filename = 'export',
  onExport,
  className,
}: DataExporterProps) {
  const resolvedColumns = React.useMemo(() => {
    if (columns && columns.length > 0) {
      return columns
    }

    const keys = new Set<string>()
    for (const row of rows) {
      Object.keys(row).forEach((key) => keys.add(key))
    }

    return Array.from(keys).map((key) => ({ key, label: key }))
  }, [columns, rows])

  const [format, setFormat] = React.useState<DataExporterFormat>(defaultFormat)
  const [selectedKeys, setSelectedKeys] = React.useState<string[]>(() => resolvedColumns.map((col) => col.key))

  React.useEffect(() => {
    setSelectedKeys(resolvedColumns.map((col) => col.key))
  }, [resolvedColumns])

  const selectedColumns = resolvedColumns.filter((col) => selectedKeys.includes(col.key))

  const handleExport = () => {
    const safeColumns = selectedColumns.length > 0 ? selectedColumns : resolvedColumns
    const content = format === 'json'
      ? JSON.stringify(rows.map((row) => {
        const out: Record<string, unknown> = {}
        for (const col of safeColumns) {
          out[col.key] = row[col.key]
        }
        return out
      }), null, 2)
      : toCsv(rows, safeColumns)

    const ext = format === 'json' ? 'json' : 'csv'
    const outputName = `${filename}.${ext}`

    onExport?.({ format, content, filename: outputName })
    triggerDownload(content, outputName, format === 'json' ? 'application/json' : 'text/csv')
  }

  return (
    <div className={['rf-data-exporter', className ?? ''].filter(Boolean).join(' ')}>
      <fieldset className="rf-data-exporter__columns">
        <legend className="rf-data-exporter__legend">Columns</legend>
        {resolvedColumns.map((column) => (
          <label key={column.key} className="rf-data-exporter__option">
            <input
              type="checkbox"
              checked={selectedKeys.includes(column.key)}
              onChange={(event) => {
                setSelectedKeys((current) => (
                  event.currentTarget.checked
                    ? [...current, column.key]
                    : current.filter((key) => key !== column.key)
                ))
              }}
            />
            {column.label}
          </label>
        ))}
      </fieldset>

      <div className="rf-data-exporter__actions">
        <label>
          Format
          <select value={format} onChange={(event) => setFormat(event.currentTarget.value as DataExporterFormat)}>
            <option value="csv">CSV</option>
            <option value="json">JSON</option>
          </select>
        </label>
        <button type="button" className="rf-data-exporter__button" onClick={handleExport}>
          Export
        </button>
      </div>
    </div>
  )
}
