import './core.css'

export interface ToggleProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'type' | 'size'> {
  label: React.ReactNode
  size?: 'sm' | 'md'
  className?: string
}

export function Toggle({
  id,
  label,
  size = 'md',
  className,
  disabled,
  ...rest
}: ToggleProps) {
  const classes = [
    'rf-toggle',
    `rf-toggle--${size}`,
    disabled ? 'rf-toggle--disabled' : '',
    className ?? '',
  ]
    .filter(Boolean)
    .join(' ')

  return (
    <label htmlFor={id} className={classes}>
      <input id={id} type="checkbox" role="switch" className="rf-toggle__input" disabled={disabled} {...rest} />
      <span className="rf-toggle__track" aria-hidden="true">
        <span className="rf-toggle__thumb" />
      </span>
      <span className="rf-toggle__label">{label}</span>
    </label>
  )
}
