import './core.css'
import React from 'react'

export interface AuditTimelineEvent {
  id: string
  timestamp: string | Date
  title: string
  description?: string
  actor?: string
  category?: string
  metadata?: Record<string, string>
}

export interface AuditTimelineFilters {
  query: string
  category: string
  actor: string
}

export interface AuditTimelineProps {
  events: AuditTimelineEvent[]
  groupByDay?: boolean
  showFilters?: boolean
  emptyText?: string
  className?: string
  onFilterChange?: (filters: AuditTimelineFilters) => void
  renderEventActions?: (event: AuditTimelineEvent) => React.ReactNode
}

interface ResolvedEvent {
  event: AuditTimelineEvent
  date: Date
  isoTimestamp: string
}

function toDate(value: string | Date): Date {
  return value instanceof Date ? value : new Date(value)
}

function toDayKey(date: Date): string {
  return date.toISOString().slice(0, 10)
}

function formatTimestamp(date: Date): string {
  return date.toLocaleString()
}

function formatDayHeading(date: Date): string {
  return date.toLocaleDateString(undefined, {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  })
}

export function AuditTimeline({
  events,
  groupByDay = true,
  showFilters = true,
  emptyText = 'No audit events match the current filters.',
  className,
  onFilterChange,
  renderEventActions,
}: AuditTimelineProps) {
  const [filters, setFilters] = React.useState<AuditTimelineFilters>({
    query: '',
    category: 'all',
    actor: 'all',
  })

  const categories = React.useMemo(() => {
    const values = new Set<string>()
    events.forEach((event) => {
      if (event.category) values.add(event.category)
    })
    return Array.from(values).sort((left, right) => left.localeCompare(right))
  }, [events])

  const actors = React.useMemo(() => {
    const values = new Set<string>()
    events.forEach((event) => {
      if (event.actor) values.add(event.actor)
    })
    return Array.from(values).sort((left, right) => left.localeCompare(right))
  }, [events])

  const sortedEvents = React.useMemo<ResolvedEvent[]>(() => {
    return events
      .map((event) => {
        const date = toDate(event.timestamp)
        return {
          event,
          date,
          isoTimestamp: date.toISOString(),
        }
      })
      .sort((left, right) => right.date.getTime() - left.date.getTime())
  }, [events])

  const filteredEvents = React.useMemo(() => {
    const normalizedQuery = filters.query.trim().toLowerCase()

    return sortedEvents.filter(({ event }) => {
      if (filters.category !== 'all' && event.category !== filters.category) {
        return false
      }

      if (filters.actor !== 'all' && event.actor !== filters.actor) {
        return false
      }

      if (!normalizedQuery) {
        return true
      }

      const haystack = [
        event.title,
        event.description,
        event.actor,
        event.category,
        ...Object.entries(event.metadata ?? {}).flatMap(([key, value]) => [key, value]),
      ]
        .filter(Boolean)
        .join(' ')
        .toLowerCase()

      return haystack.includes(normalizedQuery)
    })
  }, [filters.actor, filters.category, filters.query, sortedEvents])

  const groupedEvents = React.useMemo(() => {
    if (!groupByDay) {
      return [
        {
          key: 'all',
          label: 'All events',
          items: filteredEvents,
        },
      ]
    }

    const groups = new Map<string, ResolvedEvent[]>()
    filteredEvents.forEach((entry) => {
      const dayKey = toDayKey(entry.date)
      const current = groups.get(dayKey) ?? []
      current.push(entry)
      groups.set(dayKey, current)
    })

    return Array.from(groups.entries()).map(([key, items]) => ({
      key,
      label: formatDayHeading(items[0].date),
      items,
    }))
  }, [filteredEvents, groupByDay])

  function updateFilters(partial: Partial<AuditTimelineFilters>) {
    const next = { ...filters, ...partial }
    setFilters(next)
    onFilterChange?.(next)
  }

  return (
    <section className={['rf-audit-timeline', className ?? ''].filter(Boolean).join(' ')}>
      {showFilters && (
        <div className="rf-audit-timeline__filters" role="group" aria-label="Timeline filters">
          <label className="rf-audit-timeline__filter">
            <span>Search</span>
            <input
              type="search"
              value={filters.query}
              onChange={(event) => updateFilters({ query: event.currentTarget.value })}
              placeholder="Search title, actor, metadata"
            />
          </label>

          <label className="rf-audit-timeline__filter">
            <span>Category</span>
            <select
              value={filters.category}
              onChange={(event) => updateFilters({ category: event.currentTarget.value })}
            >
              <option value="all">All categories</option>
              {categories.map((category) => (
                <option key={category} value={category}>{category}</option>
              ))}
            </select>
          </label>

          <label className="rf-audit-timeline__filter">
            <span>Actor</span>
            <select
              value={filters.actor}
              onChange={(event) => updateFilters({ actor: event.currentTarget.value })}
            >
              <option value="all">All actors</option>
              {actors.map((actor) => (
                <option key={actor} value={actor}>{actor}</option>
              ))}
            </select>
          </label>
        </div>
      )}

      {filteredEvents.length === 0 ? (
        <p className="rf-audit-timeline__empty" role="status">{emptyText}</p>
      ) : (
        <ol className="rf-audit-timeline__groups" aria-label="Audit timeline">
          {groupedEvents.map((group) => (
            <li key={group.key} className="rf-audit-timeline__group">
              {groupByDay && <h4 className="rf-audit-timeline__heading">{group.label}</h4>}
              <ol className="rf-audit-timeline__events">
                {group.items.map(({ event, date, isoTimestamp }) => (
                  <li key={event.id} className="rf-audit-timeline__event-item">
                    <article className="rf-audit-timeline__event">
                      <header className="rf-audit-timeline__event-header">
                        <h5 className="rf-audit-timeline__event-title">{event.title}</h5>
                        <time dateTime={isoTimestamp} className="rf-audit-timeline__event-time">
                          {formatTimestamp(date)}
                        </time>
                      </header>

                      {event.description && (
                        <p className="rf-audit-timeline__event-description">{event.description}</p>
                      )}

                      <p className="rf-audit-timeline__event-meta">
                        {event.actor && <span>Actor: {event.actor}</span>}
                        {event.category && <span>Category: {event.category}</span>}
                      </p>

                      {event.metadata && Object.keys(event.metadata).length > 0 && (
                        <dl className="rf-audit-timeline__metadata">
                          {Object.entries(event.metadata).map(([key, value]) => (
                            <div key={key} className="rf-audit-timeline__metadata-item">
                              <dt>{key}</dt>
                              <dd>{value}</dd>
                            </div>
                          ))}
                        </dl>
                      )}

                      {renderEventActions && (
                        <div className="rf-audit-timeline__actions">
                          {renderEventActions(event)}
                        </div>
                      )}
                    </article>
                  </li>
                ))}
              </ol>
            </li>
          ))}
        </ol>
      )}
    </section>
  )
}
