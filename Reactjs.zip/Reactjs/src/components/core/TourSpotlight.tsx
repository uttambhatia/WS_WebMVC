import './core.css'
import React from 'react'
import { createPortal } from 'react-dom'

export interface TourStep {
  title: string
  description: React.ReactNode
  targetSelector?: string
}

export interface TourSpotlightProps {
  open: boolean
  steps: TourStep[]
  currentStep?: number
  onStepChange?: (index: number) => void
  onClose: () => void
  className?: string
}

export function TourSpotlight({
  open,
  steps,
  currentStep,
  onStepChange,
  onClose,
  className,
}: TourSpotlightProps) {
  const [internalStep, setInternalStep] = React.useState(0)
  const [highlightRect, setHighlightRect] = React.useState<DOMRect | null>(null)
  const stepIndex = currentStep ?? internalStep
  const step = steps[stepIndex]

  const setStep = (index: number) => {
    const next = Math.max(0, Math.min(steps.length - 1, index))
    if (currentStep === undefined) {
      setInternalStep(next)
    }
    onStepChange?.(next)
  }

  React.useEffect(() => {
    if (!open) {
      return
    }

    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        event.preventDefault()
        onClose()
      }
    }

    document.addEventListener('keydown', onKeyDown)
    return () => document.removeEventListener('keydown', onKeyDown)
  }, [onClose, open])

  React.useEffect(() => {
    if (!open || !step?.targetSelector) {
      setHighlightRect(null)
      return
    }

    const target = document.querySelector(step.targetSelector)
    if (!target) {
      setHighlightRect(null)
      return
    }

    setHighlightRect(target.getBoundingClientRect())
  }, [open, step?.targetSelector])

  if (!open || !step || typeof document === 'undefined') {
    return null
  }

  const last = stepIndex === steps.length - 1

  return createPortal(
    <div className="rf-tour__backdrop" role="dialog" aria-modal="true" aria-label="Product tour">
      {highlightRect && (
        <div
          className="rf-tour__spotlight"
          style={{
            top: `${highlightRect.top + window.scrollY - 6}px`,
            left: `${highlightRect.left + window.scrollX - 6}px`,
            width: `${highlightRect.width + 12}px`,
            height: `${highlightRect.height + 12}px`,
          }}
        />
      )}
      <div className={['rf-tour', className ?? ''].filter(Boolean).join(' ')}>
        <p className="rf-tour__progress">Step {stepIndex + 1} of {steps.length}</p>
        <h3 className="rf-tour__title">{step.title}</h3>
        <div className="rf-tour__description">{step.description}</div>
        <div className="rf-tour__actions">
          <button type="button" className="rf-tour__btn" onClick={onClose}>Skip</button>
          <button
            type="button"
            className="rf-tour__btn"
            disabled={stepIndex === 0}
            onClick={() => setStep(stepIndex - 1)}
          >
            Back
          </button>
          <button
            type="button"
            className="rf-tour__btn rf-tour__btn--primary"
            onClick={() => {
              if (last) {
                onClose()
                return
              }
              setStep(stepIndex + 1)
            }}
          >
            {last ? 'Done' : 'Next'}
          </button>
        </div>
      </div>
    </div>,
    document.body,
  )
}
