import React from 'react'
import type { CSSProperties } from 'react'

export interface StackProps {
  direction?: 'row' | 'column'
  gap?: 'none' | 'xs' | 'sm' | 'md' | 'lg' | 'xl'
  align?: CSSProperties['alignItems']
  justify?: CSSProperties['justifyContent']
  wrap?: boolean
  as?: React.ElementType
  children?: React.ReactNode
  className?: string
}

const GAP_MAP: Record<NonNullable<StackProps['gap']>, string> = {
  none: '0',
  xs: 'var(--spacing-xs)',
  sm: 'var(--spacing-sm)',
  md: 'var(--spacing-md)',
  lg: 'var(--spacing-lg)',
  xl: 'var(--spacing-xl)',
}

export function Stack({
  direction = 'column',
  gap = 'md',
  align,
  justify,
  wrap = false,
  as: Tag = 'div',
  children,
  className,
  style,
  ...rest
}: StackProps & React.HTMLAttributes<HTMLElement>) {
  const inlineStyle: CSSProperties = {
    display: 'flex',
    flexDirection: direction,
    gap: GAP_MAP[gap],
    ...(align !== undefined ? { alignItems: align } : {}),
    ...(justify !== undefined ? { justifyContent: justify } : {}),
    ...(wrap ? { flexWrap: 'wrap' } : {}),
    ...style,
  }

  return (
    <Tag className={className} style={inlineStyle} {...rest}>
      {children}
    </Tag>
  )
}
