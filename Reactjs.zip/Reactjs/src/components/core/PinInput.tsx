import './core.css'
import React from 'react'

export interface PinInputProps {
  length?: number
  value?: string
  defaultValue?: string
  numericOnly?: boolean
  mask?: boolean
  autoFocus?: boolean
  disabled?: boolean
  onChange?: (value: string) => void
  onComplete?: (value: string) => void
  className?: string
}

function normalizeValue(value: string, numericOnly: boolean): string {
  const source = numericOnly ? value.replace(/[^0-9]/g, '') : value
  return source
}

export function PinInput({
  length = 6,
  value,
  defaultValue = '',
  numericOnly = true,
  mask = false,
  autoFocus = false,
  disabled = false,
  onChange,
  onComplete,
  className,
}: PinInputProps) {
  const [internalValue, setInternalValue] = React.useState(() => normalizeValue(defaultValue, numericOnly).slice(0, length))
  const current = (value ?? internalValue).slice(0, length)
  const refs = React.useRef<Array<HTMLInputElement | null>>([])

  const commit = (next: string) => {
    const normalized = normalizeValue(next, numericOnly).slice(0, length)
    if (value === undefined) {
      setInternalValue(normalized)
    }
    onChange?.(normalized)
    if (normalized.length === length) {
      onComplete?.(normalized)
    }
  }

  const setAt = (index: number, nextChar: string) => {
    const chars = Array.from({ length }, (_, idx) => current[idx] ?? '')
    chars[index] = nextChar
    commit(chars.join('').trim())
  }

  return (
    <div className={['rf-pin-input', className ?? ''].filter(Boolean).join(' ')} role="group" aria-label="PIN input">
      {Array.from({ length }, (_, index) => (
        <input
          key={index}
          ref={(node) => {
            refs.current[index] = node
          }}
          className="rf-pin-input__cell"
          type={mask ? 'password' : 'text'}
          inputMode={numericOnly ? 'numeric' : 'text'}
          maxLength={1}
          autoFocus={autoFocus && index === 0}
          disabled={disabled}
          value={current[index] ?? ''}
          onChange={(event) => {
            const next = normalizeValue(event.currentTarget.value, numericOnly)
            if (!next) {
              setAt(index, '')
              return
            }
            setAt(index, next[0])
            refs.current[index + 1]?.focus()
          }}
          onKeyDown={(event) => {
            if (event.key === 'Backspace' && !current[index]) {
              refs.current[index - 1]?.focus()
            }
          }}
          onPaste={(event) => {
            event.preventDefault()
            const pasted = normalizeValue(event.clipboardData.getData('text'), numericOnly).slice(0, length)
            commit(pasted)
          }}
          aria-label={`Digit ${index + 1}`}
        />
      ))}
    </div>
  )
}
