import './core.css'
import React from 'react'

export interface DiffViewerProps {
  before: string
  after: string
  showLineNumbers?: boolean
}

interface DiffLine {
  type: 'added' | 'removed' | 'unchanged' | 'modified'
  beforeLine?: string
  afterLine?: string
}

function createLineDiff(before: string, after: string): DiffLine[] {
  const beforeLines = before.split('\n')
  const afterLines = after.split('\n')
  const maxLength = Math.max(beforeLines.length, afterLines.length)
  const diff: DiffLine[] = []

  for (let index = 0; index < maxLength; index += 1) {
    const prev = beforeLines[index]
    const next = afterLines[index]

    if (prev === undefined && next !== undefined) {
      diff.push({ type: 'added', afterLine: next })
      continue
    }

    if (prev !== undefined && next === undefined) {
      diff.push({ type: 'removed', beforeLine: prev })
      continue
    }

    if (prev === next) {
      diff.push({ type: 'unchanged', beforeLine: prev, afterLine: next })
      continue
    }

    diff.push({ type: 'modified', beforeLine: prev, afterLine: next })
  }

  return diff
}

export function DiffViewer({ before, after, showLineNumbers = true }: DiffViewerProps) {
  const lines = React.useMemo(() => createLineDiff(before, after), [before, after])

  return (
    <table className="rf-diff-viewer" aria-label="Diff viewer">
      <thead>
        <tr>
          <th>Before</th>
          <th>After</th>
        </tr>
      </thead>
      <tbody>
        {lines.map((line, index) => (
          <tr key={index} className={`rf-diff-viewer__row rf-diff-viewer__row--${line.type}`}>
            <td>
              {showLineNumbers ? <span className="rf-diff-viewer__line-no">{index + 1}</span> : null}
              <code>{line.beforeLine ?? ''}</code>
            </td>
            <td>
              {showLineNumbers ? <span className="rf-diff-viewer__line-no">{index + 1}</span> : null}
              <code>{line.afterLine ?? ''}</code>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  )
}
