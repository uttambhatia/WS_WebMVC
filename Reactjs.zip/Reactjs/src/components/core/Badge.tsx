import './core.css'
import React from 'react'

export interface BadgeProps {
  variant?: 'primary' | 'success' | 'warning' | 'error'
  size?: 'sm' | 'md'
  children: React.ReactNode
  className?: string
}

export function Badge({
  variant = 'primary',
  size = 'md',
  children,
  className,
  ...rest
}: BadgeProps & React.HTMLAttributes<HTMLSpanElement>) {
  const classes = ['rf-badge', `rf-badge--${variant}`, `rf-badge--${size}`, className]
    .filter(Boolean)
    .join(' ')

  return (
    <span className={classes} {...rest}>
      {children}
    </span>
  )
}
