import './core.css'
import React from 'react'
import { Modal } from './Modal'
import { Button } from './Button'
import { Spinner } from './Spinner'

export interface ConfirmationDialogProps {
  open: boolean
  title?: string
  message: React.ReactNode
  confirmLabel?: string
  cancelLabel?: string
  variant?: 'default' | 'danger'
  loading?: boolean
  onConfirm: () => void
  onCancel: () => void
  className?: string
}

export function ConfirmationDialog({
  open,
  title = 'Are you sure?',
  message,
  confirmLabel = 'Confirm',
  cancelLabel = 'Cancel',
  variant = 'default',
  loading = false,
  onConfirm,
  onCancel,
  className,
}: ConfirmationDialogProps) {
  const footerContent = (
    <div className={['rf-confirm-dialog__actions', className ?? ''].filter(Boolean).join(' ')}>
      <Button
        variant="outline"
        size="md"
        disabled={loading}
        onClick={onCancel}
        // autoFocus — safer default: focus cancel so accidental Enter doesn't confirm
        autoFocus
      >
        {cancelLabel}
      </Button>
      <Button
        variant={variant === 'danger' ? 'primary' : 'primary'}
        size="md"
        disabled={loading}
        className={variant === 'danger' ? 'rf-btn--danger' : undefined}
        onClick={onConfirm}
        aria-busy={loading ? 'true' : undefined}
      >
        {loading ? (
          <>
            <Spinner size="sm" inline label="Processing" />
            {confirmLabel}
          </>
        ) : (
          confirmLabel
        )}
      </Button>
    </div>
  )

  return (
    <Modal
      open={open}
      title={title}
      onClose={onCancel}
      closeOnBackdropClick={!loading}
      closeOnEscape={!loading}
      footer={footerContent}
      className="rf-confirm-dialog"
    >
      <div className="rf-confirm-dialog__message">{message}</div>
    </Modal>
  )
}
