import './core.css'
import React from 'react'

export interface JsonViewerProps {
  value: unknown
  expandedDepth?: number
  searchQuery?: string
  className?: string
}

function renderPrimitive(value: unknown): string {
  if (typeof value === 'string') {
    return `"${value}"`
  }
  return String(value)
}

function matchesSearch(path: string, searchQuery: string): boolean {
  if (!searchQuery.trim()) {
    return true
  }
  return path.toLowerCase().includes(searchQuery.toLowerCase())
}

function JsonNode({
  label,
  value,
  depth,
  expandedDepth,
  path,
  searchQuery,
}: {
  label?: string
  value: unknown
  depth: number
  expandedDepth: number
  path: string
  searchQuery: string
}) {
  const [open, setOpen] = React.useState(depth < expandedDepth)
  const isArray = Array.isArray(value)
  const isObject = value !== null && typeof value === 'object'

  if (!isObject) {
    if (!matchesSearch(path, searchQuery)) {
      return null
    }
    return (
      <div className="rf-json-viewer__node">
        {label !== undefined && <span className="rf-json-viewer__key">{label}: </span>}
        <span className="rf-json-viewer__value">{renderPrimitive(value)}</span>
      </div>
    )
  }

  const entries = isArray
    ? (value as unknown[]).map((item, index) => [String(index), item] as const)
    : Object.entries(value as Record<string, unknown>)

  const filteredEntries = entries.filter(([key]) => matchesSearch(`${path}.${key}`, searchQuery))

  return (
    <div className="rf-json-viewer__node">
      <button
        type="button"
        className="rf-json-viewer__toggle"
        onClick={() => setOpen((current) => !current)}
        aria-label={open ? 'Collapse node' : 'Expand node'}
      >
        {open ? '-' : '+'}
      </button>
      {label !== undefined && <span className="rf-json-viewer__key">{label}: </span>}
      <span className="rf-json-viewer__type">{isArray ? 'Array' : 'Object'}</span>
      {open && (
        <div className="rf-json-viewer__children">
          {filteredEntries.map(([key, child]) => (
            <JsonNode
              key={key}
              label={key}
              value={child}
              depth={depth + 1}
              expandedDepth={expandedDepth}
              path={`${path}.${key}`}
              searchQuery={searchQuery}
            />
          ))}
        </div>
      )}
    </div>
  )
}

export function JsonViewer({
  value,
  expandedDepth = 1,
  searchQuery = '',
  className,
}: JsonViewerProps) {
  return (
    <div className={['rf-json-viewer', className ?? ''].filter(Boolean).join(' ')} role="tree" aria-label="JSON viewer">
      <JsonNode value={value} depth={0} expandedDepth={expandedDepth} path="root" searchQuery={searchQuery} />
    </div>
  )
}
