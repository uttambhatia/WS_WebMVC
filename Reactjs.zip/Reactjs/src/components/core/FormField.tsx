export interface FormFieldProps {
  /**
   * Unique id that connects the label to the input via `htmlFor`.
   * Error and help text IDs are derived as `{id}-error` and `{id}-help`
   * — pass these to the child input's `aria-describedby` prop.
   */
  id: string
  /** Visible label text rendered in a `<label>` element. */
  label: string
  /** When true a required indicator (*) is shown next to the label. */
  required?: boolean
  /**
   * Error message displayed below the input.
   * Renders as `role="alert"` — screen readers will announce it on appearance.
   * Use `{id}-error` as the `aria-describedby` value on the child input.
   */
  error?: string
  /**
   * Optional hint text displayed below the input (before the error).
   * Use `{id}-help` as part of `aria-describedby` on the child input.
   */
  helpText?: string
  /** The input element (Input, Select, Checkbox group, etc.). */
  children: React.ReactNode
  /** Additional class names for the wrapper element. */
  className?: string
}

/**
 * FormField wraps an input with a label, optional help text, and error message.
 *
 * @example
 * ```tsx
 * <FormField id="email" label="Email address" required error={errors.email}>
 *   <Input
 *     id="email"
 *     type="email"
 *     aria-describedby={errors.email ? 'email-error' : undefined}
 *   />
 * </FormField>
 * ```
 *
 * @remarks
 * `aria-describedby` is NOT injected automatically — pass `{id}-error` and/or
 * `{id}-help` explicitly to the child input for full screen reader support.
 */
export function FormField({
  id,
  label,
  required = false,
  error,
  helpText,
  children,
  className,
}: FormFieldProps) {
  return (
    <div className={['rf-form-field', className].filter(Boolean).join(' ')}>
      <label htmlFor={id} className="rf-form-field__label">
        {label}
        {required && (
          <span className="rf-form-field__required" aria-hidden="true">
            {' '}*
          </span>
        )}
      </label>
      {children}
      {helpText && !error && (
        <span id={`${id}-help`} className="rf-form-field__help">
          {helpText}
        </span>
      )}
      {error && (
        <span id={`${id}-error`} className="rf-form-field__error" role="alert">
          {error}
        </span>
      )}
    </div>
  )
}
