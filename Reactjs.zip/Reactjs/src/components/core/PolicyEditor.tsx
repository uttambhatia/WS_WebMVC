import './core.css'

export interface PolicyRule {
  id: string
  role: string
  permission: string
  effect: 'allow' | 'deny'
}

export interface PolicyEditorProps {
  value: PolicyRule[]
  onChange: (value: PolicyRule[]) => void
  availableRoles: string[]
  availablePermissions: string[]
}

export function PolicyEditor({
  value,
  onChange,
  availableRoles,
  availablePermissions,
}: PolicyEditorProps) {
  return (
    <section className="rf-policy-editor" aria-label="Policy editor">
      <table>
        <thead>
          <tr>
            <th>Role</th>
            <th>Permission</th>
            <th>Effect</th>
          </tr>
        </thead>
        <tbody>
          {value.map((rule) => (
            <tr key={rule.id}>
              <td>
                <select
                  value={rule.role}
                  onChange={(event) => onChange(value.map((entry) => entry.id === rule.id ? { ...entry, role: event.currentTarget.value } : entry))}
                >
                  {availableRoles.map((role) => <option key={role} value={role}>{role}</option>)}
                </select>
              </td>
              <td>
                <select
                  value={rule.permission}
                  onChange={(event) => onChange(value.map((entry) => entry.id === rule.id ? { ...entry, permission: event.currentTarget.value } : entry))}
                >
                  {availablePermissions.map((permission) => <option key={permission} value={permission}>{permission}</option>)}
                </select>
              </td>
              <td>
                <select
                  value={rule.effect}
                  onChange={(event) => onChange(value.map((entry) => entry.id === rule.id ? { ...entry, effect: event.currentTarget.value as PolicyRule['effect'] } : entry))}
                >
                  <option value="allow">Allow</option>
                  <option value="deny">Deny</option>
                </select>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <button
        type="button"
        className="rf-policy-editor__add"
        onClick={() => onChange([
          ...value,
          {
            id: crypto.randomUUID(),
            role: availableRoles[0] ?? '',
            permission: availablePermissions[0] ?? '',
            effect: 'allow',
          },
        ])}
      >
        Add rule
      </button>
    </section>
  )
}
