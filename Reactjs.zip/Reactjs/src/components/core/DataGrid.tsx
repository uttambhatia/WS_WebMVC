import './core.css'
import React from 'react'
import { Table, type TableColumn } from './Table'

export type DataGridColumnVisibility<T extends Record<string, unknown>> = Partial<Record<keyof T, boolean>>
export type DataGridColumnWidths<T extends Record<string, unknown>> = Partial<Record<keyof T, number>>

export interface DataGridProps<T extends Record<string, unknown>> {
  columns: TableColumn<T>[]
  rows: T[]
  page: number
  pageSize: number
  totalRows?: number
  onPageChange?: (page: number) => void
  selectable?: boolean
  selectedRowIds?: string[]
  getRowId?: (row: T, rowIndex: number) => string
  onSelectionChange?: (ids: string[]) => void
  sortBy?: keyof T
  sortDirection?: 'asc' | 'desc'
  onSortChange?: (key: keyof T, direction: 'asc' | 'desc') => void
  globalFilter?: string
  columnFilters?: Partial<Record<keyof T, string>>
  pinnedColumnKeys?: Array<keyof T>
  emptyState?: React.ReactNode
  onVisibleRowsChange?: (rows: T[]) => void
  columnVisibility?: DataGridColumnVisibility<T>
  onColumnVisibilityChange?: (visibility: DataGridColumnVisibility<T>) => void
  columnOrder?: Array<keyof T>
  onColumnOrderChange?: (order: Array<keyof T>) => void
  columnWidths?: DataGridColumnWidths<T>
  onColumnResize?: (key: keyof T, width: number) => void
  showColumnControls?: boolean
}

function toKeyString(key: PropertyKey): string {
  return String(key)
}

export function DataGrid<T extends Record<string, unknown>>({
  columns,
  rows,
  page,
  pageSize,
  selectable = false,
  selectedRowIds = [],
  getRowId,
  onSelectionChange,
  sortBy,
  sortDirection,
  onSortChange,
  globalFilter,
  columnFilters,
  pinnedColumnKeys = [],
  emptyState,
  onVisibleRowsChange,
  columnVisibility,
  onColumnVisibilityChange,
  columnOrder,
  onColumnOrderChange,
  columnWidths,
  onColumnResize,
  showColumnControls = false,
}: DataGridProps<T>) {
  const filteredRows = React.useMemo(() => {
    const normalizedGlobal = (globalFilter ?? '').trim().toLowerCase()

    return rows.filter((row) => {
      if (normalizedGlobal) {
        const rowText = Object.values(row)
          .map((value) => String(value ?? '').toLowerCase())
          .join(' ')
        if (!rowText.includes(normalizedGlobal)) {
          return false
        }
      }

      if (!columnFilters) {
        return true
      }

      return Object.entries(columnFilters).every(([key, filterValue]) => {
        const normalizedFilter = String(filterValue ?? '').trim().toLowerCase()
        if (!normalizedFilter) return true
        const rowValue = String(row[key as keyof T] ?? '').toLowerCase()
        return rowValue.includes(normalizedFilter)
      })
    })
  }, [columnFilters, globalFilter, rows])

  const pageRows = React.useMemo(() => {
    const start = (page - 1) * pageSize
    return filteredRows.slice(start, start + pageSize)
  }, [filteredRows, page, pageSize])

  const resolvedGetRowId = React.useMemo(
    () => getRowId ?? ((_row: T, rowIndex: number) => String(rowIndex)),
    [getRowId],
  )

  const columnsByKey = React.useMemo(() => {
    const map = new Map<string, TableColumn<T>>()
    columns.forEach((column) => {
      map.set(toKeyString(column.key), column)
    })
    return map
  }, [columns])

  const orderedColumns = React.useMemo(() => {
    if (!columnOrder || columnOrder.length === 0) return columns

    const orderSet = new Set(columnOrder.map((key) => toKeyString(key)))
    const ordered = columnOrder
      .map((key) => columnsByKey.get(toKeyString(key)))
      .filter((column): column is TableColumn<T> => Boolean(column))

    const remainder = columns.filter((column) => !orderSet.has(toKeyString(column.key)))
    return [...ordered, ...remainder]
  }, [columnOrder, columns, columnsByKey])

  const visibleColumns = React.useMemo(() => {
    return orderedColumns.filter((column) => {
      if (!columnVisibility) return true
      const visible = columnVisibility[column.key]
      return visible !== false
    })
  }, [columnVisibility, orderedColumns])

  const dataColumns = React.useMemo(() => {
    const mappedColumns = visibleColumns.map((column) => {
      const width = columnWidths?.[column.key]
      return {
        ...column,
        pinned: pinnedColumnKeys.includes(column.key) ? 'left' : column.pinned,
        headerStyle: {
          ...column.headerStyle,
          ...(width ? { width: `${width}px`, minWidth: `${width}px`, maxWidth: `${width}px` } : null),
        },
        cellStyle: {
          ...column.cellStyle,
          ...(width ? { width: `${width}px`, minWidth: `${width}px`, maxWidth: `${width}px` } : null),
        },
      }
    })

    if (!selectable) return mappedColumns

    const selectColumn: TableColumn<T> = {
      key: ('__select__' as keyof T),
      header: '',
      pinned: 'left',
      headerClassName: 'rf-table__selection-col',
      cellClassName: 'rf-table__selection-col',
      render: (_value, row, rowIndex) => {
        const id = resolvedGetRowId(row, rowIndex)
        const checked = selectedRowIds.includes(id)
        return (
          <input
            type="checkbox"
            aria-label="Select row"
            checked={checked}
            onChange={(event) => {
              const next = event.target.checked
                ? [...selectedRowIds, id]
                : selectedRowIds.filter((item) => item !== id)
              onSelectionChange?.(next)
            }}
          />
        )
      },
    }

    return [selectColumn, ...mappedColumns]
  }, [columnWidths, onSelectionChange, pinnedColumnKeys, resolvedGetRowId, selectable, selectedRowIds, visibleColumns])

  React.useEffect(() => {
    onVisibleRowsChange?.(pageRows)
  }, [onVisibleRowsChange, pageRows])

  function setColumnVisibility(key: keyof T, visible: boolean) {
    const next = { ...(columnVisibility ?? {}) } as DataGridColumnVisibility<T>
    next[key] = visible
    onColumnVisibilityChange?.(next)
  }

  function moveColumn(key: keyof T, offset: -1 | 1) {
    const baseOrder = (columnOrder?.length ? [...columnOrder] : columns.map((column) => column.key)) as Array<keyof T>
    const index = baseOrder.findIndex((item) => toKeyString(item) === toKeyString(key))
    if (index < 0) return

    const nextIndex = index + offset
    if (nextIndex < 0 || nextIndex >= baseOrder.length) return

    const nextOrder = [...baseOrder]
    const [moved] = nextOrder.splice(index, 1)
    nextOrder.splice(nextIndex, 0, moved)
    onColumnOrderChange?.(nextOrder)
  }

  const resolvedEmptyState = emptyState ?? 'No matching rows found.'

  return (
    <div className="rf-data-grid">
      {showColumnControls && (
        <div className="rf-data-grid__controls" role="group" aria-label="Data grid column controls">
          {columns.map((column) => {
            const key = column.key
            const keyText = toKeyString(key)
            const isVisible = columnVisibility?.[key] !== false
            const widthValue = columnWidths?.[key] ?? 180

            return (
              <div key={keyText} className="rf-data-grid__column-control">
                <label className="rf-data-grid__toggle">
                  <input
                    type="checkbox"
                    checked={isVisible}
                    onChange={(event) => setColumnVisibility(key, event.currentTarget.checked)}
                    disabled={!onColumnVisibilityChange}
                  />
                  <span>{column.header}</span>
                </label>

                <div className="rf-data-grid__order-actions">
                  <button
                    type="button"
                    className="rf-data-grid__order-btn"
                    onClick={() => moveColumn(key, -1)}
                    disabled={!onColumnOrderChange}
                    aria-label={`Move ${keyText} left`}
                  >
                    ←
                  </button>
                  <button
                    type="button"
                    className="rf-data-grid__order-btn"
                    onClick={() => moveColumn(key, 1)}
                    disabled={!onColumnOrderChange}
                    aria-label={`Move ${keyText} right`}
                  >
                    →
                  </button>
                </div>

                <label className="rf-data-grid__width">
                  <span>Width</span>
                  <input
                    type="range"
                    min={120}
                    max={420}
                    value={widthValue}
                    onInput={(event) => onColumnResize?.(key, Number((event.currentTarget as HTMLInputElement).value))}
                    onChange={(event) => onColumnResize?.(key, Number(event.currentTarget.value))}
                    disabled={!onColumnResize}
                  />
                </label>
              </div>
            )
          })}
        </div>
      )}

      <Table
        columns={dataColumns}
        data={pageRows}
        rowKey={(row, rowIndex) => resolvedGetRowId(row, rowIndex)}
        sortBy={sortBy}
        sortDirection={sortDirection}
        onSortChange={onSortChange}
      />

      {pageRows.length === 0 && (
        <p className="rf-data-grid__empty" role="status">{resolvedEmptyState}</p>
      )}
    </div>
  )
}
