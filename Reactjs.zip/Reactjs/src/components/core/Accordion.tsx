import './core.css'
import React from 'react'

export interface AccordionItem {
  id: string
  title: React.ReactNode
  content: React.ReactNode
  disabled?: boolean
}

export interface AccordionProps {
  items: AccordionItem[]
  multiple?: boolean
  defaultExpandedIds?: string[]
  className?: string
}

export function Accordion({
  items,
  multiple = false,
  defaultExpandedIds = [],
  className,
}: AccordionProps) {
  const [expandedIds, setExpandedIds] = React.useState<string[]>(defaultExpandedIds)

  function toggle(id: string) {
    setExpandedIds((current) => {
      const exists = current.includes(id)
      if (exists) return current.filter((item) => item !== id)
      if (!multiple) return [id]
      return [...current, id]
    })
  }

  return (
    <div className={['rf-accordion', className ?? ''].filter(Boolean).join(' ')}>
      {items.map((item) => {
        const expanded = expandedIds.includes(item.id)
        return (
          <section key={item.id} className="rf-accordion__item">
            <h3 className="rf-accordion__heading">
              <button
                type="button"
                className="rf-accordion__trigger"
                aria-expanded={expanded ? 'true' : 'false'}
                aria-controls={`rf-accordion-panel-${item.id}`}
                disabled={item.disabled}
                onClick={() => toggle(item.id)}
              >
                {item.title}
              </button>
            </h3>
            {expanded && (
              <div id={`rf-accordion-panel-${item.id}`} className="rf-accordion__panel">
                {item.content}
              </div>
            )}
          </section>
        )
      })}
    </div>
  )
}
