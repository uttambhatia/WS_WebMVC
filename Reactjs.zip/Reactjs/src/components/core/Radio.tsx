export interface RadioProps {
  /** Unique id for the input element. */
  id: string
  /** Visible label text displayed next to the radio button. */
  label: string
  /** Groups radio buttons together — all radios in the same group share a `name`. */
  name: string
  /** The value submitted when this radio is selected. */
  value: string
  /** Controlled checked state. */
  checked: boolean
  /** Called when this radio button becomes selected. */
  onChange: React.ChangeEventHandler<HTMLInputElement>
  /** When true the radio button is not interactive. */
  disabled?: boolean
  /** Additional class names for the wrapper label element. */
  className?: string
}

/**
 * Radio button component with a visible label.
 *
 * Group multiple Radio components with the same `name` prop to create a
 * mutually exclusive selection. Clicking anywhere on the label selects it.
 *
 * @example
 * ```tsx
 * <fieldset>
 *   <legend>Contact preference</legend>
 *   <Radio id="pref-email" name="pref" value="email" label="Email"
 *     checked={pref === 'email'} onChange={(e) => setPref(e.target.value)} />
 *   <Radio id="pref-phone" name="pref" value="phone" label="Phone"
 *     checked={pref === 'phone'} onChange={(e) => setPref(e.target.value)} />
 * </fieldset>
 * ```
 */
export function Radio({
  id,
  label,
  name,
  value,
  checked,
  onChange,
  disabled = false,
  className,
}: RadioProps) {
  const classes = [
    'rf-radio',
    disabled ? 'rf-radio--disabled' : '',
    className ?? '',
  ]
    .filter(Boolean)
    .join(' ')

  return (
    <label className={classes}>
      <input
        type="radio"
        id={id}
        className="rf-radio__input"
        name={name}
        value={value}
        checked={checked}
        onChange={onChange}
        disabled={disabled}
      />
      <span className="rf-radio__label">{label}</span>
    </label>
  )
}
