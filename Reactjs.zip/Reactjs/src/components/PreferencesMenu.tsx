import { useEffect, useId, useMemo, useRef, useState } from 'react'
import { useLayout, useTheme } from '../framework/hooks'

type PreferenceOption = {
  id: string
  label: string
  type: 'layout' | 'theme'
  checked: boolean
  onSelect: () => void
}

export function PreferencesMenu() {
  const { layouts, currentLayoutId, setLayoutId } = useLayout()
  const { themes, currentThemeId, setThemeId } = useTheme()
  const rootRef = useRef<HTMLDivElement | null>(null)
  const triggerRef = useRef<HTMLButtonElement | null>(null)
  const menuRef = useRef<HTMLDivElement | null>(null)
  const optionRefs = useRef<Array<HTMLButtonElement | null>>([])
  const [isOpen, setIsOpen] = useState(false)
  const [menuAlign, setMenuAlign] = useState<'left' | 'right'>('left')
  const triggerId = useId()
  const menuId = useId()
  const layoutLabelId = useId()
  const themeLabelId = useId()

  const options = useMemo<PreferenceOption[]>(
    () => [
      ...layouts.map((layout) => ({
        id: layout.id,
        label: layout.label,
        type: 'layout' as const,
        checked: layout.id === currentLayoutId,
        onSelect: () => setLayoutId(layout.id),
      })),
      ...themes.map((theme) => ({
        id: theme.id,
        label: theme.label,
        type: 'theme' as const,
        checked: theme.id === currentThemeId,
        onSelect: () => setThemeId(theme.id),
      })),
    ],
    [currentLayoutId, currentThemeId, layouts, setLayoutId, setThemeId, themes],
  )

  const focusOption = (index: number) => {
    optionRefs.current[index]?.focus()
  }

  const openMenu = (targetIndex?: number) => {
    setIsOpen(true)

    if (targetIndex !== undefined) {
      window.requestAnimationFrame(() => focusOption(targetIndex))
    }
  }

  const closeMenu = (restoreFocus?: boolean) => {
    setIsOpen(false)

    if (restoreFocus) {
      window.requestAnimationFrame(() => triggerRef.current?.focus())
    }
  }

  useEffect(() => {
    if (!isOpen) {
      return
    }

    const positionMenu = () => {
      const rootEl = rootRef.current
      const menuEl = menuRef.current
      if (!rootEl || !menuEl) {
        return
      }

      const viewportPadding = 8
      const viewportWidth = window.innerWidth
      const rootRect = rootEl.getBoundingClientRect()
      const menuWidth = menuEl.offsetWidth || 280

      const wouldOverflowRight = rootRect.left + menuWidth > viewportWidth - viewportPadding
      const wouldOverflowLeft = rootRect.right - menuWidth < viewportPadding
      const resolvedMenuAlign = wouldOverflowRight && !wouldOverflowLeft ? 'right' : 'left'
      setMenuAlign(resolvedMenuAlign)
    }

    positionMenu()
    const handlePointerDown = (event: MouseEvent) => {
      if (!rootRef.current?.contains(event.target as Node)) {
        closeMenu(false)
      }
    }

    window.addEventListener('resize', positionMenu)
    window.addEventListener('mousedown', handlePointerDown)

    return () => {
      window.removeEventListener('resize', positionMenu)
      window.removeEventListener('mousedown', handlePointerDown)
    }
  }, [isOpen])

  const selectedIndex = options.findIndex((option) => option.checked)

  const rootClasses = ['rf-preferences', isOpen ? 'is-open' : '', menuAlign === 'right' ? 'rf-preferences--menu-right' : 'rf-preferences--menu-left']
    .filter(Boolean)
    .join(' ')

  const handleTriggerKeyDown = (event: React.KeyboardEvent<HTMLButtonElement>) => {
    if (event.key === 'ArrowDown' || event.key === 'Enter' || event.key === ' ') {
      event.preventDefault()
      openMenu(selectedIndex >= 0 ? selectedIndex : 0)
    }
  }

  const handleOptionKeyDown = (event: React.KeyboardEvent<HTMLButtonElement>) => {
    const currentIndex = Number(event.currentTarget.dataset.index)

    if (Number.isNaN(currentIndex)) {
      return
    }

    switch (event.key) {
      case 'ArrowDown':
      case 'ArrowRight':
        event.preventDefault()
        focusOption((currentIndex + 1) % options.length)
        break
      case 'ArrowUp':
      case 'ArrowLeft':
        event.preventDefault()
        focusOption((currentIndex - 1 + options.length) % options.length)
        break
      case 'Home':
        event.preventDefault()
        focusOption(0)
        break
      case 'End':
        event.preventDefault()
        focusOption(options.length - 1)
        break
      case 'Escape':
        event.preventDefault()
        closeMenu(true)
        break
      case 'Tab':
        closeMenu(false)
        break
      default:
        break
    }
  }

  return (
    <div ref={rootRef} className={rootClasses}>
      <button
        ref={triggerRef}
        id={triggerId}
        type="button"
        className="rf-preferences__trigger"
        aria-haspopup="menu"
        aria-expanded={isOpen}
        aria-controls={menuId}
        onClick={() => (isOpen ? closeMenu(false) : openMenu())}
        onKeyDown={handleTriggerKeyDown}
      >
        Preferences
      </button>
      <div ref={menuRef} id={menuId} className="rf-preferences__menu" role="menu" aria-labelledby={triggerId}>
        <section className="rf-preferences__section" aria-labelledby={layoutLabelId}>
          <p id={layoutLabelId} className="rf-preferences__label">
            Layout
          </p>
          <div className="rf-preferences__group" role="group" aria-labelledby={layoutLabelId}>
            {layouts.map((layout) => (
              <button
                key={layout.id}
                ref={(element) => {
                  const optionIndex = options.findIndex((option) => option.id === layout.id && option.type === 'layout')
                  optionRefs.current[optionIndex] = element
                }}
                type="button"
                role="menuitemradio"
                aria-checked={layout.id === currentLayoutId}
                data-index={options.findIndex((option) => option.id === layout.id && option.type === 'layout')}
                className={layout.id === currentLayoutId ? 'rf-preferences__option is-active' : 'rf-preferences__option'}
                onClick={() => setLayoutId(layout.id)}
                onKeyDown={handleOptionKeyDown}
              >
                {layout.label}
              </button>
            ))}
          </div>
        </section>

        <section className="rf-preferences__section" aria-labelledby={themeLabelId}>
          <p id={themeLabelId} className="rf-preferences__label">
            Theme
          </p>
          <div className="rf-preferences__group" role="group" aria-labelledby={themeLabelId}>
            {themes.map((theme) => (
              <button
                key={theme.id}
                ref={(element) => {
                  const optionIndex = options.findIndex((option) => option.id === theme.id && option.type === 'theme')
                  optionRefs.current[optionIndex] = element
                }}
                type="button"
                role="menuitemradio"
                aria-checked={theme.id === currentThemeId}
                data-index={options.findIndex((option) => option.id === theme.id && option.type === 'theme')}
                className={theme.id === currentThemeId ? 'rf-preferences__option is-active' : 'rf-preferences__option'}
                onClick={() => setThemeId(theme.id)}
                onKeyDown={handleOptionKeyDown}
              >
                {theme.label}
              </button>
            ))}
          </div>
        </section>
      </div>
    </div>
  )
}
