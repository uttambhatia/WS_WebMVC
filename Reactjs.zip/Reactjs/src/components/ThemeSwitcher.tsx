import { useTheme } from '../framework/hooks'

export function ThemeSwitcher({ compact }: { compact?: boolean }) {
  const { themes, currentThemeId, setThemeId } = useTheme()

  return (
    <div
      style={{
        display: 'flex',
        flexDirection: compact ? 'row' : 'column',
        alignItems: compact ? 'center' : undefined,
        gap: compact ? '0.35rem' : '0.5rem',
      }}
    >
      <label style={{ fontSize: compact ? '0.78rem' : '0.85rem', fontWeight: 600, color: 'var(--muted)' }}>
        Theme
      </label>
      <select
        value={currentThemeId}
        onChange={(event) => setThemeId(event.target.value)}
        style={{
          padding: compact ? '0.28rem 0.38rem' : '0.4rem 0.5rem',
          borderRadius: 6,
          border: '1px solid var(--border)',
          fontSize: compact ? '0.82rem' : undefined,
        }}
      >
        {themes.map((theme) => (
          <option key={theme.id} value={theme.id}>
            {theme.label}
          </option>
        ))}
      </select>
    </div>
  )
}
