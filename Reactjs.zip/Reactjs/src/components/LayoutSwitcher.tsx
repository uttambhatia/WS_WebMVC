import { useLayout } from '../framework/hooks'

export function LayoutSwitcher({ compact }: { compact?: boolean }) {
  const { layouts, currentLayoutId, setLayoutId } = useLayout()

  return (
    <div
      style={{
        display: 'flex',
        flexDirection: compact ? 'row' : 'column',
        alignItems: compact ? 'center' : undefined,
        gap: compact ? '0.35rem' : '0.5rem',
      }}
    >
      <label style={{ fontSize: compact ? '0.78rem' : '0.85rem', fontWeight: 600, color: 'var(--muted)' }}>
        Layout
      </label>
      <select
        value={currentLayoutId}
        onChange={(event) => setLayoutId(event.target.value)}
        style={{
          padding: compact ? '0.28rem 0.38rem' : '0.4rem 0.5rem',
          borderRadius: 6,
          border: '1px solid var(--border)',
          fontSize: compact ? '0.82rem' : undefined,
        }}
      >
        {layouts.map((layout) => (
          <option key={layout.id} value={layout.id}>
            {layout.label}
          </option>
        ))}
      </select>
    </div>
  )
}
