import { NavLink, useLocation } from 'react-router-dom'
import { useLayoutContext } from '../framework/provider'
import type { RouteDefinition, RoutePolicyContext } from '../framework/registry'

export type NavRouteGroup = {
  key: string
  label?: string
  routes: RouteDefinition[]
}

function defaultVisibilityCheck(route: RouteDefinition, context: RoutePolicyContext): boolean {
  if (route.visibility === undefined || route.visibility === 'always') {
    return true
  }

  if (route.visibility === 'authenticated') {
    return context.isAuthenticated === true
  }

  if (route.visibility === 'admin') {
    return Boolean(context.roles?.includes('admin'))
  }

  if (typeof route.visibility === 'function') {
    try {
      return route.visibility(context, route)
    } catch {
      return false
    }
  }

  return false
}

export function isRouteVisible(
  route: RouteDefinition,
  routePolicy?: (route: RouteDefinition, context: RoutePolicyContext) => boolean,
  context: RoutePolicyContext = {},
): boolean {
  if (routePolicy) {
    return routePolicy(route, context)
  }

  return defaultVisibilityCheck(route, context)
}

export function prepareNavRoutes(
  routes: RouteDefinition[],
  routePolicy?: (route: RouteDefinition, context: RoutePolicyContext) => boolean,
  context: RoutePolicyContext = {},
): RouteDefinition[] {
  return routes
    .filter((route) => route.label)
    .filter((route) => isRouteVisible(route, routePolicy, context))
    .sort((a, b) => {
      const aHasOrder = typeof a.order === 'number'
      const bHasOrder = typeof b.order === 'number'

      if (aHasOrder && bHasOrder) {
        return (a.order as number) - (b.order as number)
      }
      if (aHasOrder && !bHasOrder) {
        return -1
      }
      if (!aHasOrder && bHasOrder) {
        return 1
      }

      return a.path.localeCompare(b.path)
    })
}

export function buildNavGroups(routes: RouteDefinition[]): NavRouteGroup[] {
  const groups = new Map<string, NavRouteGroup>()
  const keyOrder: string[] = []

  for (const route of routes) {
    const groupLabel = route.group?.trim()
    const key = groupLabel && groupLabel.length > 0 ? groupLabel : '__ungrouped__'

    if (!groups.has(key)) {
      groups.set(key, {
        key,
        label: key === '__ungrouped__' ? undefined : groupLabel,
        routes: [],
      })
      keyOrder.push(key)
    }

    groups.get(key)?.routes.push(route)
  }

  return keyOrder.map((key) => groups.get(key) as NavRouteGroup)
}

function isActivePath(routePath: string, pathname: string): boolean {
  if (routePath === pathname) {
    return true
  }

  if (routePath === '/') {
    return pathname === '/'
  }

  return pathname.startsWith(`${routePath}/`)
}

export function MainNav({ vertical }: { vertical?: boolean }) {
  const { routes, routePolicy, routePolicyContext } = useLayoutContext()
  const location = useLocation()
  const navRoutes = prepareNavRoutes(routes, routePolicy, routePolicyContext)
  const routeGroups = buildNavGroups(navRoutes)
  const shouldRenderGroupLabels = routeGroups.filter((group) => group.label).length > 1

  if (!vertical) {
    const groupedRoutes = routeGroups.filter((group) => group.label)
    const ungroupedRoutes = routeGroups
      .filter((group) => !group.label)
      .flatMap((group) => group.routes)

    return (
      <nav className="rf-main-nav" aria-label="Primary">
        {ungroupedRoutes.map((route) => (
          <NavLink
            key={`__ungrouped__:${route.path}`}
            to={route.path}
            className={({ isActive }) => (isActive ? 'rf-main-nav__link is-active' : 'rf-main-nav__link')}
          >
            {route.icon ? <span className="rf-main-nav__icon" aria-hidden="true">{route.icon}</span> : null}
            <span>{route.label}</span>
          </NavLink>
        ))}

        {groupedRoutes.map((group) => {
          const isGroupActive = group.routes.some((route) => isActivePath(route.path, location.pathname))

          return (
            <details
              key={group.key}
              className={isGroupActive ? 'rf-main-nav__dropdown is-active' : 'rf-main-nav__dropdown'}
            >
              <summary className="rf-main-nav__dropdown-trigger">
                <span>{group.label}</span>
                <span className="rf-main-nav__dropdown-caret" aria-hidden="true">▾</span>
              </summary>
              <div className="rf-main-nav__dropdown-menu" role="menu" aria-label={`${group.label} links`}>
                {group.routes.map((route) => (
                  <NavLink
                    key={`${group.key}:${route.path}`}
                    to={route.path}
                    className={({ isActive }) =>
                      isActive ? 'rf-main-nav__link rf-main-nav__dropdown-link is-active' : 'rf-main-nav__link rf-main-nav__dropdown-link'
                    }
                  >
                    {route.icon ? <span className="rf-main-nav__icon" aria-hidden="true">{route.icon}</span> : null}
                    <span>{route.label}</span>
                  </NavLink>
                ))}
              </div>
            </details>
          )
        })}
      </nav>
    )
  }

  return (
    <nav className={vertical ? 'rf-main-nav rf-main-nav--vertical' : 'rf-main-nav'} aria-label="Primary">
      {routeGroups.map((group) => (
        <div key={group.key} className="rf-main-nav__group">
          {shouldRenderGroupLabels && group.label ? (
            <p className="rf-main-nav__group-title">{group.label}</p>
          ) : null}

          {group.routes.map((route) => (
            <NavLink
              key={`${group.key}:${route.path}`}
              to={route.path}
              className={({ isActive }) => (isActive ? 'rf-main-nav__link is-active' : 'rf-main-nav__link')}
            >
              {route.icon ? <span className="rf-main-nav__icon" aria-hidden="true">{route.icon}</span> : null}
              <span>{route.label}</span>
            </NavLink>
          ))}
        </div>
      ))}
    </nav>
  )
}
