import React from 'react'

export type LayoutDefinition = {
  id: string
  label: string
  description?: string
  slots?: LayoutSlotDefinition[]
  Component: React.ComponentType<{ children: React.ReactNode }>
}

export type LayoutSlotDefinition = {
  id: string
  label?: string
  description?: string
  metadata?: Record<string, unknown>
}

export type LayoutSlotInjection = {
  layoutId: string
  slotId: string
  component: React.ComponentType
  metadata?: Record<string, unknown>
}

export type RouteDefinition = {
  path: string
  element: React.ReactElement
  label?: string
  /** Optional icon key rendered by navigation UIs. */
  icon?: string
  /** Optional navigation group label. */
  group?: string
  /** Visibility mode or predicate used by policy-aware navigation. */
  visibility?: RouteVisibility
  /** Optional breadcrumb labels for downstream breadcrumb UIs. */
  breadcrumb?: string[]
  /** Optional permission keys interpreted by consumer policy callbacks. */
  permissions?: string[]
  /** Optional sort rank (ascending). Routes without order appear last. */
  order?: number
}

export type RoutePolicyContext = {
  isAuthenticated?: boolean
  roles?: string[]
  featureFlags?: Record<string, boolean>
  [key: string]: unknown
}

export type RouteVisibilityMode = 'always' | 'authenticated' | 'admin'
export type RouteVisibilityPredicate = (
  context: RoutePolicyContext,
  route: RouteDefinition,
) => boolean
export type RouteVisibility = RouteVisibilityMode | RouteVisibilityPredicate

export type ThemeDefinition = {
  /** Unique theme id used for selection and persistence. */
  id: string
  /** Human-readable label shown in theme switchers. */
  label: string
  description?: string
  /** CSS custom properties to apply on :root (for example --text, --surface). */
  variables: Record<string, string>
}

export const REQUIRED_THEME_TOKENS = [
  '--surface',
  '--border',
  '--text',
  '--muted',
  '--primary-hover',
  '--bg',
  '--brand',
  '--link',
  '--link-hover',
  '--spacing-xs',
  '--spacing-sm',
  '--spacing-md',
  '--spacing-lg',
  '--spacing-xl',
  '--font-size-xs',
  '--font-size-sm',
  '--font-size-md',
  '--font-size-lg',
  '--font-size-xl',
  '--font-weight-regular',
  '--font-weight-medium',
  '--font-weight-semibold',
  '--font-weight-bold',
  '--color-primary',
  '--color-secondary',
  '--color-success',
  '--color-warning',
  '--color-error',
  '--radius-sm',
  '--radius-md',
  '--radius-lg',
  '--radius-pill',
  '--elevation-sm',
  '--elevation-md',
] as const

export type RequiredThemeToken = (typeof REQUIRED_THEME_TOKENS)[number]

export type ThemeValidationResult = {
  valid: boolean
  missingTokens: RequiredThemeToken[]
  invalidTokens: RequiredThemeToken[]
}

export interface FrameworkRegistry {
  registerLayout(layout: LayoutDefinition): void
  getLayouts(): LayoutDefinition[]
  getLayout(id: string): LayoutDefinition | undefined
  registerLayoutSlot(injection: LayoutSlotInjection): void
  getLayoutSlots(layoutId: string): LayoutSlotInjection[]
  getLayoutSlot(layoutId: string, slotId: string): LayoutSlotInjection | undefined

  /** Register a theme. Existing ids are overwritten. */
  registerTheme(theme: ThemeDefinition): void
  /** Get all registered themes in registration order. */
  getThemes(): ThemeDefinition[]
  /** Get a single theme by id. */
  getTheme(id: string): ThemeDefinition | undefined

  registerRoute(route: RouteDefinition): void
  getRoutes(): RouteDefinition[]
}

export type FrameworkPlugin = (registry: FrameworkRegistry) => void

const ROUTE_VISIBILITY_MODES: RouteVisibilityMode[] = ['always', 'authenticated', 'admin']

/**
 * Validate required token coverage for a theme definition.
 */
export function validateTheme(theme: ThemeDefinition): ThemeValidationResult {
  const missingTokens: RequiredThemeToken[] = []
  const invalidTokens: RequiredThemeToken[] = []

  for (const token of REQUIRED_THEME_TOKENS) {
    if (!(token in theme.variables)) {
      missingTokens.push(token)
      continue
    }

    const value = theme.variables[token]
    if (typeof value !== 'string' || value.trim() === '') {
      invalidTokens.push(token)
    }
  }

  return {
    valid: missingTokens.length === 0 && invalidTokens.length === 0,
    missingTokens,
    invalidTokens,
  }
}

/**
 * Validate route metadata fields and emit diagnostics for invalid entries.
 */
export function isValidRouteMetadata(route: Partial<RouteDefinition>): boolean {
  if (route.icon !== undefined && typeof route.icon !== 'string') {
    console.warn('[Framework] Route metadata "icon" must be a string when provided.')
    return false
  }

  if (route.group !== undefined && typeof route.group !== 'string') {
    console.warn('[Framework] Route metadata "group" must be a string when provided.')
    return false
  }

  if (route.visibility !== undefined) {
    const validVisibility =
      typeof route.visibility === 'function' ||
      (typeof route.visibility === 'string' &&
        ROUTE_VISIBILITY_MODES.includes(route.visibility as RouteVisibilityMode))

    if (!validVisibility) {
      console.warn(
        '[Framework] Route metadata "visibility" must be one of "always", "authenticated", "admin", or a predicate function.',
      )
      return false
    }
  }

  if (
    route.breadcrumb !== undefined &&
    (!Array.isArray(route.breadcrumb) || route.breadcrumb.some((item) => typeof item !== 'string'))
  ) {
    console.warn('[Framework] Route metadata "breadcrumb" must be a string array when provided.')
    return false
  }

  if (
    route.permissions !== undefined &&
    (!Array.isArray(route.permissions) || route.permissions.some((item) => typeof item !== 'string'))
  ) {
    console.warn('[Framework] Route metadata "permissions" must be a string array when provided.')
    return false
  }

  if (
    route.order !== undefined &&
    (typeof route.order !== 'number' || !Number.isFinite(route.order))
  ) {
    console.warn('[Framework] Route metadata "order" must be a finite number when provided.')
    return false
  }

  return true
}

/**
 * Validate full route shape and emit diagnostics when invalid.
 */
export function isValidRoute(route: unknown): route is RouteDefinition {
  if (!route || typeof route !== 'object') {
    console.warn('[Framework] Route must be an object.')
    return false
  }

  const candidate = route as Partial<RouteDefinition>

  if (!candidate.path || typeof candidate.path !== 'string' || candidate.path.trim() === '') {
    console.warn('[Framework] Route "path" must be a non-empty string.')
    return false
  }

  if (!candidate.element || typeof candidate.element !== 'object') {
    console.warn('[Framework] Route "element" must be a valid React element.')
    return false
  }

  if (candidate.label !== undefined && typeof candidate.label !== 'string') {
    console.warn('[Framework] Route "label" must be a string when provided.')
    return false
  }

  return isValidRouteMetadata(candidate)
}

/**
 * Concrete registry implementation.
 * @internal — Use the `FrameworkRegistry` interface for typing; use the exported `framework`
 * singleton for access. This class is not part of the public API.
 */
export class DefaultFrameworkRegistry implements FrameworkRegistry {
  private layouts = new Map<string, LayoutDefinition>()
  private layoutSlots = new Map<string, Map<string, LayoutSlotInjection>>()
  private themes = new Map<string, ThemeDefinition>()
  private routes: RouteDefinition[] = []

  registerLayout(layout: LayoutDefinition) {
    if (this.layouts.has(layout.id)) {
      console.warn(`[Framework] Layout with id "${layout.id}" already registered, overwriting.`)
    }
    this.layouts.set(layout.id, layout)
  }

  getLayouts() {
    return Array.from(this.layouts.values())
  }

  getLayout(id: string) {
    return this.layouts.get(id)
  }

  registerLayoutSlot(injection: LayoutSlotInjection) {
    const layout = this.layouts.get(injection.layoutId)
    if (!layout) {
      console.warn(
        `[Framework] Layout slot target "${injection.layoutId}" is not registered. Slot will still be stored.`,
      )
    } else if (layout.slots?.length && !layout.slots.some((slot) => slot.id === injection.slotId)) {
      console.warn(
        `[Framework] Layout slot "${injection.slotId}" is not declared on layout "${injection.layoutId}". Slot will still be stored.`,
      )
    }

    const layoutSlots = this.layoutSlots.get(injection.layoutId) ?? new Map<string, LayoutSlotInjection>()

    if (layoutSlots.has(injection.slotId)) {
      console.warn(
        `[Framework] Layout slot "${injection.layoutId}:${injection.slotId}" already registered, overwriting.`,
      )
    }

    layoutSlots.set(injection.slotId, injection)
    this.layoutSlots.set(injection.layoutId, layoutSlots)
  }

  getLayoutSlots(layoutId: string) {
    return Array.from((this.layoutSlots.get(layoutId) ?? new Map<string, LayoutSlotInjection>()).values())
  }

  getLayoutSlot(layoutId: string, slotId: string) {
    return this.layoutSlots.get(layoutId)?.get(slotId)
  }

  registerTheme(theme: ThemeDefinition) {
    const validation = validateTheme(theme)
    if (!validation.valid) {
      if (validation.missingTokens.length > 0) {
        console.warn(
          `[Framework] Theme "${theme.id}" is missing required tokens: ${validation.missingTokens.join(', ')}.`,
        )
      }

      if (validation.invalidTokens.length > 0) {
        console.warn(
          `[Framework] Theme "${theme.id}" has invalid required token values: ${validation.invalidTokens.join(', ')}.`,
        )
      }
    }

    if (this.themes.has(theme.id)) {
      console.warn(`[Framework] Theme with id "${theme.id}" already registered, overwriting.`)
    }
    this.themes.set(theme.id, theme)
  }

  getThemes() {
    return Array.from(this.themes.values())
  }

  getTheme(id: string) {
    return this.themes.get(id)
  }

  registerRoute(route: RouteDefinition) {
    const routePath = route.path

    if (!isValidRoute(route)) {
      console.warn(
        `[Framework] Route "${routePath}" failed validation. Registering anyway for backward compatibility.`,
      )
    }

    if (this.routes.some((r) => r.path === routePath)) {
      console.warn(`[Framework] Route path "${routePath}" already registered, overwriting.`)
      this.routes = this.routes.filter((r) => r.path !== routePath)
    }
    this.routes.push(route)
  }

  getRoutes() {
    return [...this.routes]
  }
}

/**
 * Factory that creates a new registry instance.
 * @internal — Use the exported `framework` singleton instead of calling this directly.
 * Consumers should not need to create registry instances.
 */
export function createFrameworkRegistry() {
  return new DefaultFrameworkRegistry()
}
