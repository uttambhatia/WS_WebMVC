import type { FrameworkPlugin } from './registry'
import './framework.css'
import {
  AdaptiveTwoPaneLayout,
  CardGridFlowLayout,
  CommandSurfaceLayout,
  FocusedWorkspaceLayout,
  ListDetailResponsiveLayout,
  SidebarLayout,
  StepJourneyLayout,
  TopNavLayout,
} from './layouts'
import { enterpriseThemePresets } from './enterpriseThemes'
import { bankingThemePresets } from './bankingThemes'

const sharedTokenScales: Record<string, string> = {
  '--spacing-xs': '0.25rem',
  '--spacing-sm': '0.5rem',
  '--spacing-md': '0.75rem',
  '--spacing-lg': '1rem',
  '--spacing-xl': '1.5rem',
  '--font-size-xs': '0.75rem',
  '--font-size-sm': '0.875rem',
  '--font-size-md': '1rem',
  '--font-size-lg': '1.2rem',
  '--font-size-xl': '2rem',
  '--font-weight-regular': '400',
  '--font-weight-medium': '500',
  '--font-weight-semibold': '600',
  '--font-weight-bold': '700',
  '--radius-sm': '0.25rem',
  '--radius-md': '0.5rem',
  '--radius-lg': '0.9rem',
  '--radius-pill': '999px',
  '--elevation-sm': '0 8px 20px rgba(0, 0, 0, 0.08)',
  '--elevation-md': '0 16px 40px rgba(0, 0, 0, 0.14)',
}

export const corePlugin: FrameworkPlugin = (registry) => {
  // Core themes
  registry.registerTheme({
    id: 'ubs',
    label: 'UBS',
    description: 'Clean white surface with restrained neutrals and UBS red accents',
    variables: {
      ...sharedTokenScales,
      '--surface': '#ffffff',
      '--border': '#d7d7d7',
      '--text': '#1b1b1b',
      '--muted': '#5b5b5b',
      '--primary-hover': '#f7e5e8',
      '--bg': '#ffffff',
      '--brand': '#e60028',
      '--link': '#1b1b1b',
      '--link-hover': '#e60028',
      '--color-primary': '#e60028',
      '--color-secondary': '#1b1b1b',
      '--color-success': '#0f7b4d',
      '--color-warning': '#9a5b00',
      '--color-error': '#c42b1c',
    },
  })

  registry.registerTheme({
    id: 'classic',
    label: 'Classic',
    description: 'Dark chrome with light content, inspired by the localhost:4200 reference style',
    variables: {
      ...sharedTokenScales,
      '--surface': '#050505',
      '--border': '#1c1c1c',
      '--text': '#fdfdfd',
      '--muted': '#9d9d9d',
      '--primary-hover': 'rgba(255, 255, 255, 0.07)',
      '--bg': '#f5f5f5',
      '--brand': '#fdfdfd',
      '--link': '#fdfdfd',
      '--link-hover': '#ffffff',
      '--color-primary': '#fdfdfd',
      '--color-secondary': '#9d9d9d',
      '--color-success': '#3fbf7f',
      '--color-warning': '#ffd166',
      '--color-error': '#ff6b6b',
      '--elevation-sm': '0 10px 24px rgba(0, 0, 0, 0.28)',
      '--elevation-md': '0 18px 44px rgba(0, 0, 0, 0.34)',
    },
  })

  registry.registerTheme({
    id: 'high-contrast',
    label: 'High Contrast',
    description: 'Accessibility-first palette with strong contrast and explicit semantic states',
    variables: {
      ...sharedTokenScales,
      '--surface': '#000000',
      '--border': '#ffffff',
      '--text': '#ffffff',
      '--muted': '#d7d7d7',
      '--primary-hover': '#202020',
      '--bg': '#000000',
      '--brand': '#00e5ff',
      '--link': '#00e5ff',
      '--link-hover': '#8af7ff',
      '--color-primary': '#00e5ff',
      '--color-secondary': '#ffffff',
      '--color-success': '#00ff88',
      '--color-warning': '#ffcc00',
      '--color-error': '#ff4d4d',
      '--elevation-sm': '0 0 0 2px rgba(255, 255, 255, 0.45)',
      '--elevation-md': '0 0 0 3px rgba(255, 255, 255, 0.65)',
    },
  })

  for (const theme of enterpriseThemePresets) {
    registry.registerTheme(theme)
  }

  for (const theme of bankingThemePresets) {
    registry.registerTheme(theme)
  }

  // Core layouts
  registry.registerLayout({
    id: 'sidebar',
    label: 'Sidebar',
    description: 'Sidebar navigation with a settings panel',
    slots: [
      { id: 'headerSlot', label: 'Sidebar Header' },
      { id: 'footerSlot', label: 'Sidebar Footer' },
      { id: 'contentBeforeSlot', label: 'Content Before' },
    ],
    Component: SidebarLayout,
  })

  registry.registerLayout({
    id: 'topnav',
    label: 'Top',
    description: 'Top navigation bar with content below',
    slots: [
      { id: 'headerSlot', label: 'Header Above Nav' },
      { id: 'headerActionsSlot', label: 'Header Actions' },
      { id: 'contentBeforeSlot', label: 'Content Before' },
    ],
    Component: TopNavLayout,
  })

  registry.registerLayout({
    id: 'focused-workspace',
    label: 'Focused Workspace',
    description: 'Single primary content column with optional collapsible inspector',
    slots: [
      { id: 'contentBeforeSlot', label: 'Content Before' },
      { id: 'headerActionsSlot', label: 'Header Actions' },
      { id: 'inspectorSlot', label: 'Inspector Panel' },
    ],
    Component: FocusedWorkspaceLayout,
  })

  registry.registerLayout({
    id: 'list-detail-responsive',
    label: 'List Detail',
    description: 'Master list and detail panel with mobile drill-in toggles',
    slots: [
      { id: 'listSlot', label: 'List Pane' },
      { id: 'headerActionsSlot', label: 'Header Actions' },
    ],
    Component: ListDetailResponsiveLayout,
  })

  registry.registerLayout({
    id: 'adaptive-two-pane',
    label: 'Adaptive Two-Pane',
    description: 'Navigation rail and content pane with compact responsive rail behavior',
    slots: [
      { id: 'railTopSlot', label: 'Rail Header' },
      { id: 'headerActionsSlot', label: 'Header Actions' },
      { id: 'contentBeforeSlot', label: 'Content Before' },
    ],
    Component: AdaptiveTwoPaneLayout,
  })

  registry.registerLayout({
    id: 'card-grid-flow',
    label: 'Card Grid Flow',
    description: 'Fluid card grid for high-scan analytical and gallery content',
    slots: [
      { id: 'headerActionsSlot', label: 'Header Actions' },
      { id: 'contentBeforeSlot', label: 'Content Before' },
    ],
    Component: CardGridFlowLayout,
  })

  registry.registerLayout({
    id: 'step-journey',
    label: 'Step Journey',
    description: 'Progress-first workflow shell with sticky actions footer',
    slots: [
      { id: 'progressSlot', label: 'Progress Header' },
      { id: 'actionsSlot', label: 'Sticky Actions' },
      { id: 'contentBeforeSlot', label: 'Content Before' },
    ],
    Component: StepJourneyLayout,
  })

  registry.registerLayout({
    id: 'command-surface',
    label: 'Command Surface',
    description: 'Sticky command area with results and optional side panel',
    slots: [
      { id: 'commandBarSlot', label: 'Command Bar' },
      { id: 'resultsSlot', label: 'Results Pane' },
      { id: 'sidePanelSlot', label: 'Side Panel' },
    ],
    Component: CommandSurfaceLayout,
  })
}
