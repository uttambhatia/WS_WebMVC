import { createFrameworkRegistry } from './registry'

export const framework = createFrameworkRegistry()
