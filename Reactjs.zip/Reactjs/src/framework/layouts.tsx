import React from 'react'
import { Link } from 'react-router-dom'
import { PreferencesMenu } from '../components/PreferencesMenu'
import { MainNav } from '../components/MainNav'
import { useLayoutSlot } from './hooks'
import { useLayoutContext } from './provider'

const MAIN_CONTENT_ID = 'rf-main-content'

export function SidebarLayout({ children }: { children: React.ReactNode }) {
  const { appTitle, appLogo } = useLayoutContext()
  const HeaderSlot = useLayoutSlot('headerSlot')?.component
  const FooterSlot = useLayoutSlot('footerSlot')?.component
  const ContentBeforeSlot = useLayoutSlot('contentBeforeSlot')?.component

  return (
    <div className="rf-sidebar-layout">
      <a className="rf-skip-link" href={`#${MAIN_CONTENT_ID}`}>
        Skip to content
      </a>
      <aside className="rf-sidebar-layout__aside">
        {HeaderSlot ? <HeaderSlot /> : null}
        <div className="rf-layout__brand-wrap">
          <h2 className="rf-layout__brand-title">
            <Link to="/" className="rf-app-brand rf-layout__brand-link">
              {appLogo ? <span className="rf-app-brand__logo">{appLogo}</span> : null}
              {appTitle}
            </Link>
          </h2>
        </div>
        <PreferencesMenu />
        <div className="rf-layout__nav-wrap">
          <MainNav vertical />
        </div>
        {FooterSlot ? <FooterSlot /> : null}
      </aside>
      <main id={MAIN_CONTENT_ID} className="rf-sidebar-layout__main" tabIndex={-1}>
        {ContentBeforeSlot ? <ContentBeforeSlot /> : null}
        {children}
      </main>
    </div>
  )
}

export function TopNavLayout({ children }: { children: React.ReactNode }) {
  const { appTitle, appLogo } = useLayoutContext()
  const HeaderSlot = useLayoutSlot('headerSlot')?.component
  const HeaderActionsSlot = useLayoutSlot('headerActionsSlot')?.component
  const ContentBeforeSlot = useLayoutSlot('contentBeforeSlot')?.component

  return (
    <div className="rf-topnav-layout">
      <a className="rf-skip-link" href={`#${MAIN_CONTENT_ID}`}>
        Skip to content
      </a>
      {HeaderSlot ? <HeaderSlot /> : null}
      <header className="rf-topnav-layout__header">
        <div className="rf-topnav-layout__left">
          <h1 className="rf-layout__brand-title">
            <Link to="/" className="rf-app-brand rf-layout__brand-link">
              {appLogo ? <span className="rf-app-brand__logo">{appLogo}</span> : null}
              {appTitle}
            </Link>
          </h1>
          <MainNav />
        </div>
        <div className="rf-topnav-layout__switcher">
          {HeaderActionsSlot ? <HeaderActionsSlot /> : null}
          <PreferencesMenu />
        </div>
      </header>
      <main id={MAIN_CONTENT_ID} className="rf-topnav-layout__main" tabIndex={-1}>
        {ContentBeforeSlot ? <ContentBeforeSlot /> : null}
        {children}
      </main>
    </div>
  )
}

export function FocusedWorkspaceLayout({ children }: { children: React.ReactNode }) {
  const { appTitle, appLogo } = useLayoutContext()
  const HeaderActionsSlot = useLayoutSlot('headerActionsSlot')?.component
  const InspectorSlot = useLayoutSlot('inspectorSlot')?.component
  const ContentBeforeSlot = useLayoutSlot('contentBeforeSlot')?.component
  const [inspectorOpen, setInspectorOpen] = React.useState(Boolean(InspectorSlot))

  React.useEffect(() => {
    if (!InspectorSlot) {
      setInspectorOpen(false)
      return
    }

    setInspectorOpen(true)
  }, [InspectorSlot])

  return (
    <div className="rf-focused-layout">
      <a className="rf-skip-link" href={`#${MAIN_CONTENT_ID}`}>
        Skip to content
      </a>

      <header className="rf-focused-layout__header">
        <div className="rf-focused-layout__brand">
          <h1 className="rf-layout__brand-title">
            <Link to="/" className="rf-app-brand rf-layout__brand-link">
              {appLogo ? <span className="rf-app-brand__logo">{appLogo}</span> : null}
              {appTitle}
            </Link>
          </h1>
          <MainNav />
        </div>
        <div className="rf-focused-layout__controls">
          {HeaderActionsSlot ? <HeaderActionsSlot /> : null}
          {InspectorSlot ? (
            <button
              type="button"
              className="rf-focused-layout__inspector-toggle"
              onClick={() => setInspectorOpen((value) => !value)}
              aria-pressed={inspectorOpen}
            >
              {inspectorOpen ? 'Hide Inspector' : 'Show Inspector'}
            </button>
          ) : null}
          <PreferencesMenu />
        </div>
      </header>

      <div className={['rf-focused-layout__body', inspectorOpen ? 'is-inspector-open' : ''].filter(Boolean).join(' ')}>
        <main id={MAIN_CONTENT_ID} className="rf-focused-layout__main" tabIndex={-1}>
          {ContentBeforeSlot ? <ContentBeforeSlot /> : null}
          {children}
        </main>

        {InspectorSlot ? (
          <aside className="rf-focused-layout__inspector" aria-hidden={!inspectorOpen}>
            <InspectorSlot />
          </aside>
        ) : null}
      </div>
    </div>
  )
}

export function ListDetailResponsiveLayout({ children }: { children: React.ReactNode }) {
  const { appTitle, appLogo } = useLayoutContext()
  const ListSlot = useLayoutSlot('listSlot')?.component
  const HeaderActionsSlot = useLayoutSlot('headerActionsSlot')?.component
  const [mobilePane, setMobilePane] = React.useState<'list' | 'detail'>('list')

  return (
    <div className={['rf-list-detail-layout', mobilePane === 'detail' ? 'is-detail-active' : 'is-list-active'].join(' ')}>
      <a className="rf-skip-link" href={`#${MAIN_CONTENT_ID}`}>
        Skip to content
      </a>

      <header className="rf-list-detail-layout__header">
        <div className="rf-list-detail-layout__brand">
          <h1 className="rf-layout__brand-title">
            <Link to="/" className="rf-app-brand rf-layout__brand-link">
              {appLogo ? <span className="rf-app-brand__logo">{appLogo}</span> : null}
              {appTitle}
            </Link>
          </h1>
          <MainNav />
        </div>

        <div className="rf-list-detail-layout__controls">
          {HeaderActionsSlot ? <HeaderActionsSlot /> : null}
          <PreferencesMenu />
        </div>
      </header>

      <div className="rf-list-detail-layout__mobile-toggle" role="tablist" aria-label="List detail panes">
        <button
          type="button"
          role="tab"
          aria-selected={mobilePane === 'list'}
          className={mobilePane === 'list' ? 'is-active' : ''}
          onClick={() => setMobilePane('list')}
        >
          List
        </button>
        <button
          type="button"
          role="tab"
          aria-selected={mobilePane === 'detail'}
          className={mobilePane === 'detail' ? 'is-active' : ''}
          onClick={() => setMobilePane('detail')}
        >
          Detail
        </button>
      </div>

      <div className="rf-list-detail-layout__body" data-mobile-pane={mobilePane}>
        <aside className="rf-list-detail-layout__list" aria-hidden={mobilePane !== 'list'}>
          {ListSlot ? <ListSlot /> : <div className="rf-list-detail-layout__empty">No list slot content registered.</div>}
        </aside>

        <main id={MAIN_CONTENT_ID} className="rf-list-detail-layout__detail" tabIndex={-1} aria-hidden={mobilePane !== 'detail'}>
          {children}
        </main>
      </div>
    </div>
  )
}

export function AdaptiveTwoPaneLayout({ children }: { children: React.ReactNode }) {
  const { appTitle, appLogo } = useLayoutContext()
  const HeaderActionsSlot = useLayoutSlot('headerActionsSlot')?.component
  const RailTopSlot = useLayoutSlot('railTopSlot')?.component
  const ContentBeforeSlot = useLayoutSlot('contentBeforeSlot')?.component
  const [compactRail, setCompactRail] = React.useState(false)

  return (
    <div className={['rf-adaptive-layout', compactRail ? 'is-rail-compact' : ''].filter(Boolean).join(' ')}>
      <a className="rf-skip-link" href={`#${MAIN_CONTENT_ID}`}>
        Skip to content
      </a>

      <header className="rf-adaptive-layout__header">
        <h1 className="rf-layout__brand-title">
          <Link to="/" className="rf-app-brand rf-layout__brand-link">
            {appLogo ? <span className="rf-app-brand__logo">{appLogo}</span> : null}
            {appTitle}
          </Link>
        </h1>

        <div className="rf-adaptive-layout__header-actions">
          <button
            type="button"
            className="rf-adaptive-layout__rail-toggle"
            aria-pressed={compactRail}
            onClick={() => setCompactRail((value) => !value)}
          >
            {compactRail ? 'Expand Rail' : 'Compact Rail'}
          </button>
          {HeaderActionsSlot ? <HeaderActionsSlot /> : null}
          <PreferencesMenu />
        </div>
      </header>

      <div className="rf-adaptive-layout__body">
        <aside className="rf-adaptive-layout__rail" aria-label="Navigation rail">
          {RailTopSlot ? <RailTopSlot /> : null}
          <MainNav vertical />
        </aside>

        <main id={MAIN_CONTENT_ID} className="rf-adaptive-layout__content" tabIndex={-1}>
          {ContentBeforeSlot ? <ContentBeforeSlot /> : null}
          {children}
        </main>
      </div>
    </div>
  )
}

export function CardGridFlowLayout({ children }: { children: React.ReactNode }) {
  const { appTitle, appLogo } = useLayoutContext()
  const HeaderActionsSlot = useLayoutSlot('headerActionsSlot')?.component
  const ContentBeforeSlot = useLayoutSlot('contentBeforeSlot')?.component
  const [density, setDensity] = React.useState<'comfortable' | 'compact'>('comfortable')

  return (
    <div className={['rf-card-grid-layout', `is-${density}`].join(' ')}>
      <a className="rf-skip-link" href={`#${MAIN_CONTENT_ID}`}>
        Skip to content
      </a>

      <header className="rf-card-grid-layout__header">
        <div className="rf-card-grid-layout__brand">
          <h1 className="rf-layout__brand-title">
            <Link to="/" className="rf-app-brand rf-layout__brand-link">
              {appLogo ? <span className="rf-app-brand__logo">{appLogo}</span> : null}
              {appTitle}
            </Link>
          </h1>
          <MainNav />
        </div>
        <div className="rf-card-grid-layout__controls">
          <button
            type="button"
            className="rf-card-grid-layout__density-toggle"
            onClick={() => setDensity((value) => (value === 'comfortable' ? 'compact' : 'comfortable'))}
          >
            Density: {density === 'comfortable' ? 'Comfortable' : 'Compact'}
          </button>
          {HeaderActionsSlot ? <HeaderActionsSlot /> : null}
          <PreferencesMenu />
        </div>
      </header>

      <main id={MAIN_CONTENT_ID} className="rf-card-grid-layout__main" tabIndex={-1}>
        {ContentBeforeSlot ? <ContentBeforeSlot /> : null}
        <div className="rf-card-grid-layout__grid">{children}</div>
      </main>
    </div>
  )
}

export function StepJourneyLayout({ children }: { children: React.ReactNode }) {
  const { appTitle, appLogo } = useLayoutContext()
  const ProgressSlot = useLayoutSlot('progressSlot')?.component
  const ActionsSlot = useLayoutSlot('actionsSlot')?.component
  const ContentBeforeSlot = useLayoutSlot('contentBeforeSlot')?.component

  return (
    <div className="rf-step-journey-layout">
      <a className="rf-skip-link" href={`#${MAIN_CONTENT_ID}`}>
        Skip to content
      </a>

      <header className="rf-step-journey-layout__header">
        <div className="rf-step-journey-layout__brand">
          <h1 className="rf-layout__brand-title">
            <Link to="/" className="rf-app-brand rf-layout__brand-link">
              {appLogo ? <span className="rf-app-brand__logo">{appLogo}</span> : null}
              {appTitle}
            </Link>
          </h1>
          <MainNav />
        </div>
        <PreferencesMenu />
      </header>

      {ProgressSlot ? <div className="rf-step-journey-layout__progress"><ProgressSlot /></div> : null}

      <main id={MAIN_CONTENT_ID} className="rf-step-journey-layout__main" tabIndex={-1}>
        {ContentBeforeSlot ? <ContentBeforeSlot /> : null}
        {children}
      </main>

      {ActionsSlot ? (
        <footer className="rf-step-journey-layout__actions">
          <ActionsSlot />
        </footer>
      ) : null}
    </div>
  )
}

export function CommandSurfaceLayout({ children }: { children: React.ReactNode }) {
  const { appTitle, appLogo } = useLayoutContext()
  const CommandBarSlot = useLayoutSlot('commandBarSlot')?.component
  const ResultsSlot = useLayoutSlot('resultsSlot')?.component
  const SidePanelSlot = useLayoutSlot('sidePanelSlot')?.component
  const [sidePanelOpen, setSidePanelOpen] = React.useState(true)

  return (
    <div className={['rf-command-layout', sidePanelOpen ? 'is-side-open' : 'is-side-closed'].join(' ')}>
      <a className="rf-skip-link" href={`#${MAIN_CONTENT_ID}`}>
        Skip to content
      </a>

      <header className="rf-command-layout__header">
        <h1 className="rf-layout__brand-title">
          <Link to="/" className="rf-app-brand rf-layout__brand-link">
            {appLogo ? <span className="rf-app-brand__logo">{appLogo}</span> : null}
            {appTitle}
          </Link>
        </h1>
        <div className="rf-command-layout__header-actions">
          {SidePanelSlot ? (
            <button
              type="button"
              className="rf-command-layout__side-toggle"
              onClick={() => setSidePanelOpen((value) => !value)}
              aria-pressed={sidePanelOpen}
            >
              {sidePanelOpen ? 'Collapse Side Panel' : 'Expand Side Panel'}
            </button>
          ) : null}
          <PreferencesMenu />
        </div>
      </header>

      <div className="rf-command-layout__command-bar">
        {CommandBarSlot ? <CommandBarSlot /> : <MainNav />}
      </div>

      <div className="rf-command-layout__body">
        <aside className="rf-command-layout__results">
          {ResultsSlot ? <ResultsSlot /> : <div className="rf-command-layout__empty">No search results slot registered.</div>}
        </aside>

        <main id={MAIN_CONTENT_ID} className="rf-command-layout__main" tabIndex={-1}>
          {children}
        </main>

        {SidePanelSlot ? (
          <aside className="rf-command-layout__side" aria-hidden={!sidePanelOpen}>
            <SidePanelSlot />
          </aside>
        ) : null}
      </div>
    </div>
  )
}
