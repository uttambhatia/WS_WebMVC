import { useCallback, useState } from 'react'

export interface ChartDrilldownSelection {
  dimension: string
  value: string
}

export type ChartDrilldownResolver<TItem> = (item: TItem, dimension: string) => unknown

/**
 * Computes the next drilldown selection deterministically.
 * Selecting the same value toggles selection off.
 */
export function nextChartDrilldownSelection(
  current: ChartDrilldownSelection | null,
  dimension: string,
  value: string | null,
): ChartDrilldownSelection | null {
  if (!value) {
    return null
  }

  if (current && current.dimension === dimension && current.value === value) {
    return null
  }

  return { dimension, value }
}

/**
 * Filters chart datasets with a shared drilldown selection.
 */
export function applyChartDrilldown<TItem>(
  items: TItem[],
  selection: ChartDrilldownSelection | null,
  resolver: ChartDrilldownResolver<TItem>,
): TItem[] {
  if (!selection) {
    return items
  }

  return items.filter((item) => {
    const resolved = resolver(item, selection.dimension)
    return String(resolved) === selection.value
  })
}

/**
 * Shared drilldown orchestration helper for coordinating chart interactions.
 */
export function useChartDrilldown(initialSelection: ChartDrilldownSelection | null = null) {
  const [selection, setSelectionState] = useState<ChartDrilldownSelection | null>(initialSelection)

  const setSelection = useCallback((dimension: string, value: string | null) => {
    setSelectionState((current) => nextChartDrilldownSelection(current, dimension, value))
  }, [])

  const clearSelection = useCallback(() => {
    setSelectionState(null)
  }, [])

  const bindDimension = useCallback(
    (dimension: string) => (value: string | null) => {
      setSelection(dimension, value)
    },
    [setSelection],
  )

  const filterData = useCallback(
    <TItem,>(items: TItem[], resolver: ChartDrilldownResolver<TItem>) => applyChartDrilldown(items, selection, resolver),
    [selection],
  )

  return {
    selection,
    setSelection,
    clearSelection,
    bindDimension,
    filterData,
  }
}
