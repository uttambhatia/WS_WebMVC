import type React from 'react'
import type { FrameworkRegistry, FrameworkPlugin, RouteDefinition, ThemeDefinition } from './registry'

/**
 * Configuration for framework initialization.
 *
 * Captures all app and layout data needed to set up the framework
 * before rendering the React app. Use this object to keep configuration
 * in one place instead of scattered guard checks.
 *
 * @example
 * const config: FrameworkConfig = {
 *   appTitle: 'My App',
 *   appLogo: <img src="logo.svg" alt="Logo" />,
 *   defaultLayoutId: 'sidebar',
 *   defaultThemeId: 'dark',
 *   plugins: [corePlugin, customPlugin],
 *   routes: [
 *     { path: '/', element: <HomePage />, label: 'Home' },
 *     { path: '/about', element: <AboutPage />, label: 'About' },
 *   ],
 *   themes: [
 *     { id: 'dark', label: 'Dark', variables: { '--text': '#fff', '--bg': '#000' } },
 *   ],
 * }
 *
 * const result = initializeFramework(framework, config)
 * if (!result.success) console.error(result.errors)
 */
export type FrameworkConfig = {
  /** App title displayed in layout headers and nav bars. */
  appTitle?: string

  /** App logo element (JSX) rendered alongside the title. */
  appLogo?: React.ReactNode

  /** ID of the layout to activate on first load (before user preference is persisted). */
  defaultLayoutId?: string

  /** ID of the theme to activate on first load (before user preference is persisted). */
  defaultThemeId?: string

  /**
   * Plugins to execute in order. Each plugin receives the registry and registers
   * layouts, themes, and other artifacts. Plugins are run before routes and themes.
   */
  plugins: FrameworkPlugin[]

  /** Routes to register after all plugins have run. */
  routes: RouteDefinition[]

  /** Themes to register after all plugins have run. */
  themes: ThemeDefinition[]
}

/**
 * Result returned by {@link initializeFramework}.
 *
 * Check the `success` flag before rendering. If false, review `errors` for what
 * went wrong. `warnings` contains non-blocking issues that may indicate misconfiguration.
 *
 * @example
 * const result = initializeFramework(framework, config)
 * if (!result.success) {
 *   console.error('[App] Framework init failed:', result.errors)
 * }
 * if (result.warnings.length > 0) {
 *   console.warn('[App] Framework warnings:', result.warnings)
 * }
 */
export type InitializationResult = {
  /**
   * `true` if no blocking errors were found; `false` if at least one error occurred.
   * The framework can still attempt to render on failure, but behavior is undefined.
   */
  success: boolean

  /** Blocking issues. Framework cannot function correctly if any are present. */
  errors: string[]

  /** Non-blocking issues. Framework can render but may look incorrect or be incomplete. */
  warnings: string[]
}

/**
 * Validate the current registry state for consistency.
 * Called internally by {@link initializeFramework} after all registrations complete.
 *
 * @internal
 */
function validateFramework(registry: FrameworkRegistry): { errors: string[]; warnings: string[] } {
  const errors: string[] = []
  const warnings: string[] = []

  const routes = registry.getRoutes()
  const layouts = registry.getLayouts()
  const themes = registry.getThemes()

  if (layouts.length === 0) {
    errors.push('[Framework] No layouts registered. Framework cannot render.')
  }

  if (routes.length === 0) {
    warnings.push('[Framework] No routes registered. App will show empty content.')
  }

  if (themes.length === 0) {
    warnings.push('[Framework] No themes registered. App will use default fallback theme.')
  }

  for (const route of routes) {
    if (!route.path || typeof route.path !== 'string' || route.path.trim() === '') {
      errors.push(`[Framework] Route has invalid or empty path: "${route.path}"`)
    }
    if (!route.element) {
      errors.push(`[Framework] Route "${route.path}" has no element. JSX is required.`)
    }
  }

  for (const theme of themes) {
    if (!theme.id || typeof theme.id !== 'string') {
      errors.push('[Framework] Theme has missing or invalid id.')
    }
    if (!theme.label || typeof theme.label !== 'string') {
      errors.push('[Framework] Theme has missing or invalid label.')
    }
    if (!theme.variables || Object.keys(theme.variables).length === 0) {
      warnings.push(
        `[Framework] Theme "${theme.id}" has no CSS variables. It may render with default styles.`,
      )
    }
  }

  for (const layout of layouts) {
    if (!layout.id || typeof layout.id !== 'string') {
      errors.push('[Framework] Layout has missing or invalid id.')
    }
    if (!layout.label || typeof layout.label !== 'string') {
      errors.push('[Framework] Layout has missing or invalid label.')
    }
    if (typeof layout.Component !== 'function') {
      errors.push(`[Framework] Layout "${layout.id}" is not a valid React component.`)
    }
  }

  return { errors, warnings }
}

/**
 * Initialize the framework with a declarative configuration object.
 *
 * Call this **once at module level** in your App file before rendering any components.
 * It runs plugins in order, registers routes and themes, then validates the registry state.
 * Errors are collected rather than thrown, so partial initialization is possible.
 *
 * @param registry - The FrameworkRegistry singleton to populate
 * @param config - Configuration containing plugins, routes, themes, and branding
 * @returns {@link InitializationResult} with `success` flag and diagnostic arrays
 *
 * @example
 * // App.tsx — at module level, before the App component definition
 * const config: FrameworkConfig = {
 *   appTitle: 'My App',
 *   plugins: [corePlugin],
 *   routes: [
 *     { path: '/', element: <HomePage />, label: 'Home' },
 *   ],
 *   themes: [
 *     { id: 'light', label: 'Light', variables: { '--text': '#000', '--bg': '#fff' } },
 *   ],
 * }
 *
 * const result = initializeFramework(framework, config)
 * if (!result.success) {
 *   console.error('Framework initialization failed:', result.errors)
 * }
 */
export function initializeFramework(
  registry: FrameworkRegistry,
  config: FrameworkConfig,
): InitializationResult {
  const errors: string[] = []
  const warnings: string[] = []

  // 1. Run plugins first so layouts/themes they contribute are available
  for (const plugin of config.plugins) {
    try {
      plugin(registry)
    } catch (err) {
      errors.push(
        `[Framework] Plugin failed: ${err instanceof Error ? err.message : String(err)}`,
      )
    }
  }

  // 2. Register consumer routes (detect duplicates in config before registering)
  const seenPaths = new Set<string>()
  for (const route of config.routes) {
    if (route.path && seenPaths.has(route.path)) {
      warnings.push(
        `[Framework] Duplicate route path in config: "${route.path}". Last registration will override.`,
      )
    }
    seenPaths.add(route.path)
    try {
      registry.registerRoute(route)
    } catch (err) {
      errors.push(
        `[Framework] Route "${route.path}" failed: ${err instanceof Error ? err.message : String(err)}`,
      )
    }
  }

  // 3. Register consumer themes
  for (const theme of config.themes) {
    try {
      registry.registerTheme(theme)
    } catch (err) {
      errors.push(
        `[Framework] Theme "${theme.id}" failed: ${err instanceof Error ? err.message : String(err)}`,
      )
    }
  }

  // 4. Validate the full registry state
  const validationResult = validateFramework(registry)
  errors.push(...validationResult.errors)
  warnings.push(...validationResult.warnings)

  return {
    success: errors.length === 0,
    errors,
    warnings,
  }
}
