import { useCallback } from 'react'
import type { LayoutSlotInjection } from './registry'
import { useLayoutContext } from './provider'

export function useLayout() {
  return useLayoutContext()
}

/**
 * Resolve a slot injection for the current layout.
 * Returns the injected component and metadata when present.
 */
export function useLayoutSlot(slotId: string) {
  const { currentLayoutId, getLayoutSlot } = useLayoutContext()
  return getLayoutSlot(slotId, currentLayoutId)
}

/**
 * Register or replace a slot injection at runtime.
 * If layoutId is omitted, the current layout is used.
 */
export function useSetLayoutSlot() {
  const { currentLayoutId, setLayoutSlot } = useLayoutContext()

  return useCallback((
    slotId: string,
    component: LayoutSlotInjection['component'],
    options?: {
      layoutId?: string
      metadata?: Record<string, unknown>
    },
  ) => {
    setLayoutSlot({
      layoutId: options?.layoutId ?? currentLayoutId,
      slotId,
      component,
      metadata: options?.metadata,
    })
  }, [currentLayoutId, setLayoutSlot])
}

/**
 * Theme helper for built-in and consumer UIs.
 * Returns available themes, current theme, and setter for theme switching.
 */
export function useTheme() {
  const { themes, currentTheme, currentThemeId, setThemeId } = useLayoutContext()
  return { themes, currentTheme, currentThemeId, setThemeId }
}
