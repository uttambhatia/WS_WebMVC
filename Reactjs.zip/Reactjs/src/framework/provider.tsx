import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react'
import { Navigate, Route, Routes } from 'react-router-dom'
import type {
  FrameworkRegistry,
  LayoutDefinition,
  LayoutSlotInjection,
  RouteDefinition,
  RoutePolicyContext,
  ThemeDefinition,
} from './registry'

const LAYOUT_STORAGE_KEY = 'framework.layoutId'
const THEME_STORAGE_KEY = 'framework.themeId'

/**
 * Shape of the layout context value.
 * @alpha — This type may change as the context API evolves. Avoid depending on it directly
 * in production-critical paths; prefer the focused hooks `useLayout()` and `useTheme()`.
 */
export type LayoutContextValue = {
  currentLayoutId: string
  setLayoutId: (id: string) => void
  layouts: LayoutDefinition[]
  currentLayout: LayoutDefinition
  currentThemeId: string
  setThemeId: (id: string) => void
  themes: ThemeDefinition[]
  currentTheme: ThemeDefinition
  routes: RouteDefinition[]
  getLayoutSlot: (slotId: string, layoutId?: string) => LayoutSlotInjection | undefined
  setLayoutSlot: (injection: LayoutSlotInjection) => void
  routePolicy?: (route: RouteDefinition, context: RoutePolicyContext) => boolean
  routePolicyContext: RoutePolicyContext
  appTitle: string
  appLogo?: React.ReactNode
}

const LayoutContext = createContext<LayoutContextValue | undefined>(undefined)

/**
 * Raw context accessor.
 * @internal — Use `useLayout()` or `useTheme()` from hooks.ts instead.
 * This function is not part of the public API and may change without notice.
 */
export function useLayoutContext() {
  const ctx = useContext(LayoutContext)
  if (!ctx) {
    throw new Error('useLayoutContext must be used within a LayoutProvider')
  }
  return ctx
}

export type LayoutProviderProps = {
  /** Framework registry with layouts, routes, and themes already registered. */
  framework: FrameworkRegistry
  /** App name shown in built-in layout headers. */
  appTitle?: string
  /** Optional logo element rendered before app title in built-in layouts. */
  appLogo?: React.ReactNode
  /**
   * Optional startup layout id.
   * Priority on first load: localStorage -> defaultLayoutId -> first registered layout.
   */
  defaultLayoutId?: string
  /**
   * Optional startup theme id.
   * Priority on first load: localStorage -> defaultThemeId -> ubs -> first registered theme.
   */
  defaultThemeId?: string
  /**
   * Optional route policy callback used by navigation UIs.
   * When provided, it is treated as the authoritative visibility check.
   */
  routePolicy?: (route: RouteDefinition, context: RoutePolicyContext) => boolean
  /**
   * Optional context object forwarded to route policy checks.
   * Typical fields include auth status, roles, and feature flags.
   */
  routePolicyContext?: RoutePolicyContext
  /**
   * Optional slot injections applied during provider initialization.
   * Runtime slot registration can still override these values later.
   */
  initialSlotInjections?: LayoutSlotInjection[]
  children: React.ReactNode
}

export function LayoutProvider({
  framework,
  appTitle = 'AI Agent Evals',
  appLogo,
  defaultLayoutId,
  defaultThemeId,
  routePolicy,
  routePolicyContext = {},
  initialSlotInjections = [],
  children,
}: LayoutProviderProps) {
  const layouts = framework.getLayouts()
  const resolvedDefaultLayoutId =
    (defaultLayoutId && layouts.some((l) => l.id === defaultLayoutId) ? defaultLayoutId : undefined) ??
    layouts[0]?.id ??
    'default'
  const themes = framework.getThemes()
  const routes = framework.getRoutes()
  const [slotVersion, setSlotVersion] = useState(0)
  const appliedInitialSlotKeysRef = useRef<Set<string>>(new Set())
  const resolvedDefaultThemeId =
    (defaultThemeId && themes.some((t) => t.id === defaultThemeId) ? defaultThemeId : undefined) ??
    themes.find((t) => t.id === 'ubs')?.id ??
    themes[0]?.id ??
    'default'

  const [currentLayoutId, setCurrentLayoutId] = useState(() => {
    if (typeof window === 'undefined') {
      return resolvedDefaultLayoutId
    }
    const stored = window.localStorage.getItem(LAYOUT_STORAGE_KEY)
    return stored && layouts.some((l) => l.id === stored) ? stored : resolvedDefaultLayoutId
  })

  const [currentThemeId, setCurrentThemeId] = useState(() => {
    if (typeof window === 'undefined') {
      return resolvedDefaultThemeId
    }
    const stored = window.localStorage.getItem(THEME_STORAGE_KEY)
    return stored && themes.some((t) => t.id === stored) ? stored : resolvedDefaultThemeId
  })

  useEffect(() => {
    if (!layouts.some((l) => l.id === currentLayoutId)) {
      setCurrentLayoutId(resolvedDefaultLayoutId)
    }
  }, [layouts, currentLayoutId, resolvedDefaultLayoutId])

  useEffect(() => {
    if (typeof window !== 'undefined') {
      window.localStorage.setItem(LAYOUT_STORAGE_KEY, currentLayoutId)
    }
  }, [currentLayoutId])

  useEffect(() => {
    if (!themes.some((t) => t.id === currentThemeId)) {
      setCurrentThemeId(resolvedDefaultThemeId)
    }
  }, [themes, currentThemeId, resolvedDefaultThemeId])

  useEffect(() => {
    if (typeof window !== 'undefined') {
      window.localStorage.setItem(THEME_STORAGE_KEY, currentThemeId)
    }
  }, [currentThemeId])

  const currentLayout = layouts.find((l) => l.id === currentLayoutId) ?? layouts[0]
  const currentTheme = themes.find((t) => t.id === currentThemeId) ?? themes[0]

  useEffect(() => {
    let appliedAny = false

    for (const injection of initialSlotInjections) {
      const injectionKey = `${injection.layoutId}:${injection.slotId}`
      const existing = framework.getLayoutSlot(injection.layoutId, injection.slotId)

      if (
        appliedInitialSlotKeysRef.current.has(injectionKey) ||
        (existing !== undefined && existing.component === injection.component)
      ) {
        continue
      }

      framework.registerLayoutSlot(injection)
      appliedInitialSlotKeysRef.current.add(injectionKey)
      appliedAny = true
    }

    if (appliedAny) {
      setSlotVersion((value) => value + 1)
    }
  }, [framework, initialSlotInjections])

  useEffect(() => {
    if (typeof document === 'undefined') {
      return
    }

    const theme =
      currentTheme ?? {
        id: 'default',
        label: 'Default',
        variables: {},
      }

    document.documentElement.setAttribute('data-rf-theme', theme.id)
    Object.entries(theme.variables).forEach(([name, value]) => {
      document.documentElement.style.setProperty(name, value)
    })
  }, [currentTheme])

  const getLayoutSlot = useCallback(
    (slotId: string, layoutId = currentLayoutId) => {
      return framework.getLayoutSlot(layoutId, slotId)
    },
    [framework, currentLayoutId],
  )

  const setLayoutSlot = useCallback(
    (injection: LayoutSlotInjection) => {
      framework.registerLayoutSlot(injection)
      setSlotVersion((version) => version + 1)
    },
    [framework],
  )

  const value = useMemo<LayoutContextValue>(() => {
    // Slot updates must invalidate the context value even though the version is not exposed publicly.
    void slotVersion

    return {
      currentLayoutId,
      setLayoutId: setCurrentLayoutId,
      layouts,
      currentThemeId,
      setThemeId: setCurrentThemeId,
      themes,
      currentTheme:
        currentTheme ?? {
          id: 'default',
          label: 'Default',
          variables: {},
        },
      routes,
      getLayoutSlot,
      setLayoutSlot,
      routePolicy,
      routePolicyContext,
      appTitle,
      appLogo,
      currentLayout:
        currentLayout ?? {
          id: 'default',
          label: 'Default',
          Component: ({ children }) => <>{children}</>,
        },
    }
  }, [currentLayoutId, layouts, currentLayout, currentThemeId, themes, currentTheme, routes, getLayoutSlot, setLayoutSlot, routePolicy, routePolicyContext, appTitle, appLogo, slotVersion])

  return <LayoutContext.Provider value={value}>{children}</LayoutContext.Provider>
}

export function LayoutRenderer() {
  const { currentLayout, routes } = useLayoutContext()
  const LayoutComponent = currentLayout.Component
  const fallbackPath = routes[0]?.path ?? '/'

  return (
    <LayoutComponent>
      <Routes>
        {routes.map((route) => (
          <Route key={route.path} path={route.path} element={route.element} />
        ))}
        <Route path="*" element={<Navigate to={fallbackPath} replace />} />
      </Routes>
    </LayoutComponent>
  )
}
