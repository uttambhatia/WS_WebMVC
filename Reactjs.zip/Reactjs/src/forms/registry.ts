import type React from 'react'
import { isValueEmpty, type FormFieldSchema, type FormOption, type FormSchema, type FormValues } from './schema'

export type ValidatorContext = {
  schema: FormSchema
  field: FormFieldSchema
  values: FormValues
  stage: 'field' | 'cross-field' | 'async'
  signal: AbortSignal
}

export type ValidatorFn = (
  value: unknown,
  args: Record<string, unknown> | undefined,
  context: ValidatorContext,
) => string | undefined | Promise<string | undefined>

export type LookupContext = {
  field: FormFieldSchema
  values: FormValues
  signal: AbortSignal
}

export type LookupProvider = (
  query: string,
  context: LookupContext,
) => Promise<FormOption[]>

export type FormWidgetProps = {
  id: string
  field: FormFieldSchema
  value: unknown
  error?: string
  required: boolean
  disabled?: boolean
  describedBy?: string
  values: FormValues
  options: FormOption[]
  onValueChange: (value: unknown) => void
  onBlur: () => void
  loadOptions?: LookupProvider
}

export type FormWidget = React.ComponentType<FormWidgetProps>

export class FormEngineRegistry {
  private readonly validators = new Map<string, ValidatorFn>()
  private readonly widgets = new Map<string, FormWidget>()
  private readonly lookupProviders = new Map<string, LookupProvider>()

  registerValidator(name: string, validator: ValidatorFn): void {
    this.validators.set(name, validator)
  }

  getValidator(name: string): ValidatorFn | undefined {
    return this.validators.get(name)
  }

  hasValidator(name: string): boolean {
    return this.validators.has(name)
  }

  registerWidget(name: string, widget: FormWidget): void {
    this.widgets.set(name, widget)
  }

  getWidget(name: string): FormWidget | undefined {
    return this.widgets.get(name)
  }

  hasWidget(name: string): boolean {
    return this.widgets.has(name)
  }

  registerLookupProvider(name: string, provider: LookupProvider): void {
    this.lookupProviders.set(name, provider)
  }

  getLookupProvider(name: string): LookupProvider | undefined {
    return this.lookupProviders.get(name)
  }

  hasLookupProvider(name: string): boolean {
    return this.lookupProviders.has(name)
  }
}

export function registerDefaultValidators(registry: FormEngineRegistry): void {
  registry.registerValidator('required', (value) => {
    if (isValueEmpty(value)) {
      return 'This field is required.'
    }

    return undefined
  })

  registry.registerValidator('minLength', (value, args) => {
    if (typeof value !== 'string') {
      return undefined
    }

    const min = Number(args?.value)
    if (Number.isFinite(min) && value.length < min) {
      return `Minimum length is ${min}.`
    }

    return undefined
  })

  registry.registerValidator('maxLength', (value, args) => {
    if (typeof value !== 'string') {
      return undefined
    }

    const max = Number(args?.value)
    if (Number.isFinite(max) && value.length > max) {
      return `Maximum length is ${max}.`
    }

    return undefined
  })

  registry.registerValidator('pattern', (value, args) => {
    if (typeof value !== 'string') {
      return undefined
    }

    const source = typeof args?.value === 'string' ? args.value : undefined
    if (!source) {
      return undefined
    }

    const pattern = new RegExp(source)
    if (!pattern.test(value)) {
      return 'Value does not match the expected format.'
    }

    return undefined
  })

  registry.registerValidator('min', (value, args) => {
    const current = Number(value)
    const min = Number(args?.value)

    if (Number.isFinite(current) && Number.isFinite(min) && current < min) {
      return `Value must be at least ${min}.`
    }

    return undefined
  })

  registry.registerValidator('max', (value, args) => {
    const current = Number(value)
    const max = Number(args?.value)

    if (Number.isFinite(current) && Number.isFinite(max) && current > max) {
      return `Value must be at most ${max}.`
    }

    return undefined
  })

  registry.registerValidator('oneOf', (value, args) => {
    const choices = Array.isArray(args?.value) ? args.value : []
    if (choices.length > 0 && !choices.some((entry) => Object.is(entry, value))) {
      return 'Value is not in the allowed set.'
    }

    return undefined
  })
}
