import React from 'react'
import { FormField } from '../components/core/FormField'
import type { FormEngine } from './bootstrap'
import { SchemaFormProvider, useSchemaForm } from './context'
import type { FormFieldSchema, FormValues } from './schema'

export type SchemaFormProps = {
  engine: FormEngine
  initialValues?: FormValues
  className?: string
  submitLabel?: string
  disabled?: boolean
  onSubmit?: (values: FormValues) => void | Promise<void>
}

function FieldRenderer({ field, disabled }: { field: FormFieldSchema; disabled?: boolean }) {
  const {
    engine,
    schema,
    values,
    errors,
    asyncStatusByField,
    visibleByField,
    requiredByField,
    lookupResetVersionByField,
    resolveLookupOptions,
    setValue,
    markTouched,
    validateField,
  } = useSchemaForm()

  if (!visibleByField[field.key]) {
    return null
  }

  const id = `${schema.id}-${field.key}`
  const asyncError = asyncStatusByField[field.key]?.error
  const error = errors[field.key] ?? asyncError
  const required = requiredByField[field.key]
  const describedBy = error ? `${id}-error` : field.helpText ? `${id}-help` : undefined
  const widgetName = field.widget ?? field.type
  const widget = engine.registry.getWidget(widgetName)

  if (!widget) {
    return null
  }

  const widgetNode = React.createElement(widget, {
    key: `${field.key}-${lookupResetVersionByField[field.key] ?? 0}`,
    id,
    field,
    value: values[field.key],
    error,
    required,
    disabled: disabled || field.disabled,
    describedBy,
    values,
    options: field.options ?? [],
    loadOptions: field.lookup
      ? (_query, context) => resolveLookupOptions(field, _query, context.signal)
      : undefined,
    onValueChange: (nextValue: unknown) => {
      setValue(field.key, nextValue)
    },
    onBlur: () => {
      markTouched(field.key)
      void validateField(field)
    },
  })

  if (field.type === 'checkbox' || field.type === 'toggle') {
    return (
      <div className="rf-form-field" key={field.key}>
        {widgetNode}
        {error && (
          <span id={`${id}-error`} className="rf-form-field__error" role="alert">
            {error}
          </span>
        )}
      </div>
    )
  }

  return (
    <FormField
      id={id}
      key={field.key}
      label={field.label}
      required={required}
      helpText={field.helpText}
      error={error}
    >
      {widgetNode}
    </FormField>
  )
}

function SchemaFormBody({ className, submitLabel = 'Submit', disabled = false, onSubmit }: Omit<SchemaFormProps, 'engine' | 'initialValues'>) {
  const { schema, values, validateForm } = useSchemaForm()

  return (
    <form
      className={['rf-schema-form', className ?? ''].filter(Boolean).join(' ')}
      onSubmit={async (event) => {
        event.preventDefault()
        const valid = await validateForm()
        if (!valid) {
          return
        }

        await onSubmit?.(values)
      }}
    >
      {schema.fields.map((field) => (
        <FieldRenderer key={field.key} field={field} disabled={disabled} />
      ))}

      <div className="rf-schema-form__actions">
        <button type="submit" className="rf-btn rf-btn--primary rf-btn--md" disabled={disabled}>
          {submitLabel}
        </button>
      </div>
    </form>
  )
}

export function SchemaForm({ engine, initialValues, className, submitLabel, disabled, onSubmit }: SchemaFormProps) {
  return (
    <SchemaFormProvider engine={engine} initialValues={initialValues}>
      <SchemaFormBody
        className={className}
        submitLabel={submitLabel}
        disabled={disabled}
        onSubmit={onSubmit}
      />
    </SchemaFormProvider>
  )
}
