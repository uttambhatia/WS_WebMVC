import React from 'react'
import type { FormEngine } from './bootstrap'
import type {
  AsyncPolicy,
  FormFieldSchema,
  FormOption,
  FormSchema,
  FormValues,
  ValidatorSpec,
} from './schema'
import { evaluateCondition, isValueEmpty } from './schema'

export type AsyncFieldStatus = {
  loading: boolean
  attempts: number
  error?: string
  lastCompletedAt?: number
}

export type SchemaFormContextValue = {
  engine: FormEngine
  schema: FormSchema
  values: FormValues
  errors: Record<string, string>
  asyncStatusByField: Record<string, AsyncFieldStatus>
  touched: Record<string, boolean>
  visibleByField: Record<string, boolean>
  requiredByField: Record<string, boolean>
  lookupResetVersionByField: Record<string, number>
  setValue: (fieldKey: string, value: unknown) => void
  markTouched: (fieldKey: string) => void
  validateField: (field: FormFieldSchema) => Promise<string | undefined>
  validateForm: () => Promise<boolean>
  resolveLookupOptions: (field: FormFieldSchema, query: string, signal: AbortSignal) => Promise<FormOption[]>
}

export type SchemaFormProviderProps = {
  engine: FormEngine
  initialValues?: FormValues
  children: React.ReactNode
}

const SchemaFormContext = React.createContext<SchemaFormContextValue | undefined>(undefined)

function defaultValueForField(field: FormFieldSchema): unknown {
  if (field.defaultValue !== undefined) {
    return field.defaultValue
  }

  if (field.type === 'checkbox' || field.type === 'toggle') {
    return false
  }

  return ''
}

function isAbortError(error: unknown): boolean {
  return (error as { name?: string })?.name === 'AbortError'
}

function waitWithAbort(ms: number, signal: AbortSignal): Promise<void> {
  if (ms <= 0) {
    return Promise.resolve()
  }

  return new Promise((resolve, reject) => {
    const timeoutId = window.setTimeout(() => {
      cleanup()
      resolve()
    }, ms)

    function onAbort() {
      cleanup()
      reject(new DOMException('Aborted', 'AbortError'))
    }

    function cleanup() {
      window.clearTimeout(timeoutId)
      signal.removeEventListener('abort', onAbort)
    }

    signal.addEventListener('abort', onAbort)
  })
}

function createComposedController(parent: AbortSignal, timeoutMs?: number): {
  controller: AbortController
  cleanup: () => void
} {
  const controller = new AbortController()
  const timeout = Number(timeoutMs)

  function abortFromParent() {
    controller.abort(parent.reason)
  }

  let timeoutId: number | undefined

  if (parent.aborted) {
    controller.abort(parent.reason)
  } else {
    parent.addEventListener('abort', abortFromParent)
  }

  if (Number.isFinite(timeout) && timeout > 0) {
    timeoutId = window.setTimeout(() => {
      controller.abort(new DOMException('Timeout exceeded', 'AbortError'))
    }, timeout)
  }

  return {
    controller,
    cleanup: () => {
      parent.removeEventListener('abort', abortFromParent)
      if (timeoutId !== undefined) {
        window.clearTimeout(timeoutId)
      }
    },
  }
}

async function runWithAsyncPolicy<T>(
  runner: (signal: AbortSignal) => Promise<T>,
  parentSignal: AbortSignal,
  policy?: AsyncPolicy,
): Promise<{ result: T; attempts: number }> {
  const maxAttempts = Math.max(1, Number(policy?.retry?.maxAttempts ?? 1))
  const backoffMs = Math.max(0, Number(policy?.retry?.backoffMs ?? 150))

  let attempt = 0
  while (attempt < maxAttempts) {
    attempt += 1
    const { controller, cleanup } = createComposedController(parentSignal, policy?.timeoutMs)

    try {
      const result = await runner(controller.signal)
      cleanup()
      return { result, attempts: attempt }
    } catch (error) {
      cleanup()

      if (isAbortError(error)) {
        throw error
      }

      if (attempt >= maxAttempts) {
        throw error
      }

      await waitWithAbort(backoffMs * attempt, parentSignal)
    }
  }

  throw new Error('Unexpected async policy execution flow.')
}

function buildDependencyMap(
  schema: FormSchema,
  extractor: (field: FormFieldSchema) => string[],
): Map<string, string[]> {
  const map = new Map<string, Set<string>>()

  for (const field of schema.fields) {
    for (const dependency of extractor(field)) {
      if (!map.has(dependency)) {
        map.set(dependency, new Set<string>())
      }

      map.get(dependency)?.add(field.key)
    }
  }

  const normalized = new Map<string, string[]>()
  for (const [key, value] of map.entries()) {
    normalized.set(key, [...value])
  }

  return normalized
}

function collectTransitiveDependents(
  sourceKey: string,
  dependencies: Map<string, string[]>,
): string[] {
  const discovered = new Set<string>()
  const queue = [...(dependencies.get(sourceKey) ?? [])]

  while (queue.length > 0) {
    const current = queue.shift() as string
    if (discovered.has(current)) {
      continue
    }

    discovered.add(current)
    for (const next of dependencies.get(current) ?? []) {
      if (!discovered.has(next)) {
        queue.push(next)
      }
    }
  }

  return [...discovered]
}

function buildInitialValues(schema: FormSchema, initialValues: FormValues): FormValues {
  const values: FormValues = {}

  for (const field of schema.fields) {
    if (Object.prototype.hasOwnProperty.call(initialValues, field.key)) {
      values[field.key] = initialValues[field.key]
      continue
    }

    values[field.key] = defaultValueForField(field)
  }

  return values
}

function deriveRuleState(schema: FormSchema, values: FormValues): {
  visibleByField: Record<string, boolean>
  requiredByField: Record<string, boolean>
} {
  const visibilityPolicy = schema.rulePolicy?.visibility ?? 'last-wins'
  const requiredPolicy = schema.rulePolicy?.required ?? 'last-wins'

  const visibleByField: Record<string, boolean> = {}
  const requiredByField: Record<string, boolean> = {}

  for (const field of schema.fields) {
    const showOutcomes: boolean[] = []
    const hideOutcomes: boolean[] = []
    const requireOutcomes: boolean[] = []

    let visible = true
    let required = Boolean(field.required)

    for (const rule of field.rules ?? []) {
      if (rule.kind === 'show') {
        const outcome = evaluateCondition(rule.when, values)
        showOutcomes.push(outcome)

        if (visibilityPolicy === 'last-wins') {
          visible = outcome
        }
      }

      if (rule.kind === 'hide') {
        const outcome = evaluateCondition(rule.when, values)
        hideOutcomes.push(outcome)

        if (visibilityPolicy === 'last-wins' && outcome) {
          visible = false
        }
      }

      if (rule.kind === 'require') {
        const outcome = evaluateCondition(rule.when, values)
        requireOutcomes.push(outcome)

        if (requiredPolicy === 'last-wins') {
          required = outcome
        }
      }
    }

    if (visibilityPolicy === 'hide-wins') {
      const hidden = hideOutcomes.some(Boolean)
      if (hidden) {
        visible = false
      } else if (showOutcomes.length > 0) {
        visible = showOutcomes.some(Boolean)
      }
    }

    if (visibilityPolicy === 'show-wins') {
      if (showOutcomes.some(Boolean)) {
        visible = true
      } else if (hideOutcomes.some(Boolean)) {
        visible = false
      }
    }

    if (requiredPolicy === 'require-wins') {
      required = required || requireOutcomes.some(Boolean)
    }

    if (requiredPolicy === 'optional-wins') {
      const hasOptionalSignal = requireOutcomes.some((entry) => !entry)
      if (hasOptionalSignal) {
        required = false
      } else {
        required = required || requireOutcomes.some(Boolean)
      }
    }

    visibleByField[field.key] = visible
    requiredByField[field.key] = required
  }

  return { visibleByField, requiredByField }
}

function applyComputeRules(schema: FormSchema, values: FormValues): FormValues {
  const computePolicy = schema.rulePolicy?.compute ?? 'last-wins'
  let nextValues = values

  for (let pass = 0; pass < 10; pass += 1) {
    let changed = false

    for (const field of schema.fields) {
      const matchedValues: unknown[] = []

      for (const rule of field.rules ?? []) {
        if (rule.kind !== 'compute') {
          continue
        }

        if (rule.when && !evaluateCondition(rule.when, nextValues)) {
          continue
        }

        const computed =
          rule.fromField !== undefined
            ? nextValues[rule.fromField]
            : rule.value

        matchedValues.push(computed)
      }

      if (matchedValues.length === 0) {
        continue
      }

      const computed = computePolicy === 'first-wins'
        ? matchedValues[0]
        : matchedValues[matchedValues.length - 1]

      if (!Object.is(nextValues[field.key], computed)) {
        if (nextValues === values) {
          nextValues = { ...values }
        }

        nextValues[field.key] = computed
        changed = true
      }
    }

    if (!changed) {
      break
    }
  }

  return nextValues
}

export function SchemaFormProvider({ engine, initialValues = {}, children }: SchemaFormProviderProps) {
  const schema = engine.schema
  const fieldByKey = React.useMemo(
    () => new Map(schema.fields.map((field) => [field.key, field])),
    [schema.fields],
  )
  const lookupDependentsByField = React.useMemo(
    () => buildDependencyMap(schema, (field) => field.lookup?.dependsOn ?? []),
    [schema],
  )
  const validatorDependentsByField = React.useMemo(
    () =>
      buildDependencyMap(schema, (field) =>
        (field.validators ?? []).flatMap((validator) => validator.dependsOn ?? []),
      ),
    [schema],
  )

  const [values, setValues] = React.useState<FormValues>(() =>
    applyComputeRules(schema, buildInitialValues(schema, initialValues)),
  )
  const [errors, setErrors] = React.useState<Record<string, string>>({})
  const [asyncStatusByField, setAsyncStatusByField] = React.useState<Record<string, AsyncFieldStatus>>({})
  const [touched, setTouched] = React.useState<Record<string, boolean>>({})
  const [lookupResetVersionByField, setLookupResetVersionByField] = React.useState<Record<string, number>>({})

  const lookupControllersRef = React.useRef(new Map<string, AbortController>())
  const lookupRequestVersionRef = React.useRef(new Map<string, number>())
  const validationControllersRef = React.useRef(new Map<string, AbortController>())
  const validationRequestVersionRef = React.useRef(new Map<string, number>())
  const prevValuesRef = React.useRef<FormValues>(values)

  React.useEffect(() => {
    const lookupControllers = lookupControllersRef.current
    const validationControllers = validationControllersRef.current

    return () => {
      for (const controller of lookupControllers.values()) {
        controller.abort()
      }

      for (const controller of validationControllers.values()) {
        controller.abort()
      }
    }
  }, [])

  const { visibleByField, requiredByField } = React.useMemo(
    () => deriveRuleState(schema, values),
    [schema, values],
  )

  React.useEffect(() => {
    setErrors((current) => {
      const next = { ...current }
      let changed = false

      for (const [key, visible] of Object.entries(visibleByField)) {
        if (!visible && next[key]) {
          delete next[key]
          changed = true
        }
      }

      return changed ? next : current
    })
  }, [visibleByField])

  const setValue = React.useCallback((fieldKey: string, value: unknown) => {
    const lookupDependents = collectTransitiveDependents(fieldKey, lookupDependentsByField)

    setValues((current) => {
      const next: FormValues = {
        ...current,
        [fieldKey]: value,
      }

      for (const dependentKey of lookupDependents) {
        const dependent = fieldByKey.get(dependentKey)
        if (!dependent) {
          continue
        }

        if (dependent.lookup?.invalidateOnDependencyChange === false) {
          continue
        }

        next[dependentKey] = defaultValueForField(dependent)
      }

      return applyComputeRules(schema, next)
    })

    if (lookupDependents.length > 0) {
      setErrors((current) => {
        const next = { ...current }
        let changed = false

        for (const dependentKey of lookupDependents) {
          if (dependentKey in next) {
            delete next[dependentKey]
            changed = true
          }
        }

        return changed ? next : current
      })

      setTouched((current) => {
        const next = { ...current }
        let changed = false

        for (const dependentKey of lookupDependents) {
          if (dependentKey in next) {
            delete next[dependentKey]
            changed = true
          }
        }

        return changed ? next : current
      })

      setAsyncStatusByField((current) => {
        const next = { ...current }
        let changed = false

        for (const dependentKey of lookupDependents) {
          if (dependentKey in next) {
            delete next[dependentKey]
            changed = true
          }
        }

        return changed ? next : current
      })

      setLookupResetVersionByField((current) => {
        const next = { ...current }
        for (const dependentKey of lookupDependents) {
          next[dependentKey] = (next[dependentKey] ?? 0) + 1
        }
        return next
      })

      for (const dependentKey of lookupDependents) {
        lookupControllersRef.current.get(dependentKey)?.abort()
        validationControllersRef.current.get(dependentKey)?.abort()
      }
    }
  }, [fieldByKey, lookupDependentsByField, schema])

  const markTouched = React.useCallback((fieldKey: string) => {
    setTouched((current) => ({
      ...current,
      [fieldKey]: true,
    }))
  }, [])

  const runValidatorSpec = React.useCallback(
    async (
      field: FormFieldSchema,
      value: unknown,
      spec: ValidatorSpec,
      stage: 'field' | 'cross-field' | 'async',
      signal: AbortSignal,
    ): Promise<string | undefined> => {
      const validator = engine.registry.getValidator(spec.name)
      if (!validator) {
        return undefined
      }

      const result = await validator(value, spec.args, {
        schema,
        field,
        values,
        stage,
        signal,
      })

      if (typeof result === 'string' && result.length > 0) {
        return spec.message ?? result
      }

      return undefined
    },
    [engine.registry, schema, values],
  )

  const validateField = React.useCallback(
    async (field: FormFieldSchema) => {
      const syncAbortController = new AbortController()

      if (!visibleByField[field.key]) {
        validationControllersRef.current.get(field.key)?.abort()

        setErrors((current) => {
          if (!(field.key in current)) {
            return current
          }

          const next = { ...current }
          delete next[field.key]
          return next
        })

        return undefined
      }

      const value = values[field.key]
      const required = requiredByField[field.key]

      if (required && isValueEmpty(value)) {
        const message = 'This field is required.'
        setErrors((current) => ({ ...current, [field.key]: message }))
        return message
      }

      const fieldValidators = (field.validators ?? []).filter(
        (spec) => (spec.stage ?? 'field') === 'field',
      )
      const crossFieldValidators = (field.validators ?? []).filter(
        (spec) => (spec.stage ?? 'field') === 'cross-field',
      )
      const asyncValidators = (field.validators ?? []).filter(
        (spec) => (spec.stage ?? 'field') === 'async',
      )

      for (const spec of fieldValidators) {
        const message = await runValidatorSpec(field, value, spec, 'field', syncAbortController.signal)
        if (message) {
          setErrors((current) => ({ ...current, [field.key]: message }))
          return message
        }
      }

      for (const spec of crossFieldValidators) {
        const message = await runValidatorSpec(field, value, spec, 'cross-field', syncAbortController.signal)
        if (message) {
          setErrors((current) => ({ ...current, [field.key]: message }))
          return message
        }
      }

      if (asyncValidators.length > 0) {
        validationControllersRef.current.get(field.key)?.abort()
        const asyncController = new AbortController()
        validationControllersRef.current.set(field.key, asyncController)

        const requestVersion = (validationRequestVersionRef.current.get(field.key) ?? 0) + 1
        validationRequestVersionRef.current.set(field.key, requestVersion)

        setAsyncStatusByField((current) => ({
          ...current,
          [field.key]: {
            loading: true,
            attempts: 0,
          },
        }))

        for (const spec of asyncValidators) {
          try {
            const execution = await runWithAsyncPolicy(
              (signal) => runValidatorSpec(field, value, spec, 'async', signal),
              asyncController.signal,
              spec.asyncPolicy,
            )

            if (validationRequestVersionRef.current.get(field.key) !== requestVersion) {
              return undefined
            }

            setAsyncStatusByField((current) => ({
              ...current,
              [field.key]: {
                loading: false,
                attempts: execution.attempts,
                lastCompletedAt: Date.now(),
              },
            }))

            const asyncMessage = execution.result
            if (typeof asyncMessage === 'string' && asyncMessage.length > 0) {
              setErrors((current) => ({ ...current, [field.key]: asyncMessage }))
              return asyncMessage
            }
          } catch (error) {
            if (isAbortError(error)) {
              return undefined
            }

            const message = spec.message ?? (error instanceof Error ? error.message : 'Async validation failed.')
            setAsyncStatusByField((current) => ({
              ...current,
              [field.key]: {
                loading: false,
                attempts: Number(spec.asyncPolicy?.retry?.maxAttempts ?? 1),
                error: message,
                lastCompletedAt: Date.now(),
              },
            }))
            setErrors((current) => ({ ...current, [field.key]: message }))
            return message
          }
        }
      }

      setErrors((current) => {
        if (!(field.key in current)) {
          return current
        }

        const next = { ...current }
        delete next[field.key]
        return next
      })

      return undefined
    },
    [requiredByField, runValidatorSpec, values, visibleByField],
  )

  React.useEffect(() => {
    const previousValues = prevValuesRef.current
    const changedKeys = new Set<string>()

    for (const field of schema.fields) {
      if (!Object.is(previousValues[field.key], values[field.key])) {
        changedKeys.add(field.key)
      }
    }

    prevValuesRef.current = values

    if (changedKeys.size === 0) {
      return
    }

    for (const changedKey of changedKeys) {
      const dependents = validatorDependentsByField.get(changedKey) ?? []
      for (const dependentKey of dependents) {
        if (!touched[dependentKey]) {
          continue
        }

        const dependentField = fieldByKey.get(dependentKey)
        if (!dependentField) {
          continue
        }

        void validateField(dependentField)
      }
    }
  }, [fieldByKey, schema.fields, touched, validateField, validatorDependentsByField, values])

  const resolveLookupOptions = React.useCallback(
    async (field: FormFieldSchema, query: string, upstreamSignal: AbortSignal): Promise<FormOption[]> => {
      if (!field.lookup) {
        return []
      }

      const provider = engine.registry.getLookupProvider(field.lookup.provider)
      if (!provider) {
        return []
      }

      lookupControllersRef.current.get(field.key)?.abort()
      const requestController = new AbortController()
      lookupControllersRef.current.set(field.key, requestController)

      function abortFromUpstream() {
        requestController.abort(upstreamSignal.reason)
      }

      if (upstreamSignal.aborted) {
        requestController.abort(upstreamSignal.reason)
      } else {
        upstreamSignal.addEventListener('abort', abortFromUpstream)
      }

      const requestVersion = (lookupRequestVersionRef.current.get(field.key) ?? 0) + 1
      lookupRequestVersionRef.current.set(field.key, requestVersion)

      setAsyncStatusByField((current) => ({
        ...current,
        [field.key]: {
          loading: true,
          attempts: 0,
          error: undefined,
        },
      }))

      try {
        const execution = await runWithAsyncPolicy(
          (signal) => provider(query, { field, values, signal }),
          requestController.signal,
          field.lookup.asyncPolicy,
        )

        if (lookupRequestVersionRef.current.get(field.key) === requestVersion) {
          setAsyncStatusByField((current) => ({
            ...current,
            [field.key]: {
              loading: false,
              attempts: execution.attempts,
              lastCompletedAt: Date.now(),
            },
          }))
        }

        return execution.result
      } catch (error) {
        if (!isAbortError(error) && lookupRequestVersionRef.current.get(field.key) === requestVersion) {
          setAsyncStatusByField((current) => ({
            ...current,
            [field.key]: {
              loading: false,
              attempts: Number(field.lookup?.asyncPolicy?.retry?.maxAttempts ?? 1),
              error: error instanceof Error ? error.message : 'Lookup failed.',
              lastCompletedAt: Date.now(),
            },
          }))
        }

        throw error
      } finally {
        upstreamSignal.removeEventListener('abort', abortFromUpstream)
      }
    },
    [engine.registry, values],
  )

  const validateForm = React.useCallback(async () => {
    let valid = true

    for (const field of schema.fields) {
      const message = await validateField(field)
      if (message) {
        valid = false
      }
    }

    return valid
  }, [schema.fields, validateField])

  const contextValue = React.useMemo<SchemaFormContextValue>(() => {
    return {
      engine,
      schema,
      values,
      errors,
      asyncStatusByField,
      touched,
      visibleByField,
      requiredByField,
      lookupResetVersionByField,
      setValue,
      markTouched,
      validateField,
      validateForm,
      resolveLookupOptions,
    }
  }, [engine, schema, values, errors, asyncStatusByField, touched, visibleByField, requiredByField, lookupResetVersionByField, setValue, markTouched, validateField, validateForm, resolveLookupOptions])

  return <SchemaFormContext.Provider value={contextValue}>{children}</SchemaFormContext.Provider>
}

export function useSchemaForm(): SchemaFormContextValue {
  const context = React.useContext(SchemaFormContext)

  if (!context) {
    throw new Error('useSchemaForm must be used within SchemaFormProvider')
  }

  return context
}
