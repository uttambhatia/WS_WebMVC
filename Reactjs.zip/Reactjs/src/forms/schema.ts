export type FormValues = Record<string, unknown>

export type RuleEvaluationPolicy = {
  visibility?: 'last-wins' | 'hide-wins' | 'show-wins'
  required?: 'last-wins' | 'require-wins' | 'optional-wins'
  compute?: 'last-wins' | 'first-wins'
}

export type RetryPolicy = {
  maxAttempts?: number
  backoffMs?: number
}

export type AsyncPolicy = {
  timeoutMs?: number
  retry?: RetryPolicy
}

export type FormFieldType =
  | 'text'
  | 'email'
  | 'password'
  | 'number'
  | 'textarea'
  | 'select'
  | 'checkbox'
  | 'toggle'
  | 'async-select'

export type FormOption = {
  label: string
  value: string
}

export type Condition = {
  field?: string
  value?: unknown
  ref?: string
  eq?: unknown
  neq?: unknown
  in?: unknown[]
  notIn?: unknown[]
  gt?: number
  gte?: number
  lt?: number
  lte?: number
  truthy?: boolean
  falsy?: boolean
  exists?: boolean
  empty?: boolean
  notEmpty?: boolean
  contains?: string
  startsWith?: string
  endsWith?: string
  matches?: string
  includesAll?: unknown[]
  includesAny?: unknown[]
  includesNone?: unknown[]
  lengthEq?: number
  lengthGte?: number
  lengthLte?: number
  and?: Condition[]
  or?: Condition[]
  xor?: Condition[]
  not?: Condition
}

export type ShowRule = {
  kind: 'show'
  when: Condition
}

export type HideRule = {
  kind: 'hide'
  when: Condition
}

export type RequireRule = {
  kind: 'require'
  when: Condition
}

export type ComputeRule = {
  kind: 'compute'
  when?: Condition
  /** Static value assigned when rule condition passes. */
  value?: unknown
  /** Copies value from another field when rule condition passes. */
  fromField?: string
}

export type FieldRule = ShowRule | HideRule | RequireRule | ComputeRule

export type ValidatorSpec = {
  name: string
  args?: Record<string, unknown>
  message?: string
  stage?: 'field' | 'cross-field' | 'async'
  dependsOn?: string[]
  asyncPolicy?: AsyncPolicy
}

export type LookupSpec = {
  provider: string
  dependsOn?: string[]
  minQueryLength?: number
  invalidateOnDependencyChange?: boolean
  asyncPolicy?: AsyncPolicy
}

export type FormFieldSchema = {
  key: string
  label: string
  type: FormFieldType
  helpText?: string
  placeholder?: string
  required?: boolean
  defaultValue?: unknown
  options?: FormOption[]
  widget?: string
  validators?: ValidatorSpec[]
  rules?: FieldRule[]
  lookup?: LookupSpec
  disabled?: boolean
}

export type FormSchema = {
  id: string
  title?: string
  description?: string
  fields: FormFieldSchema[]
  rulePolicy?: RuleEvaluationPolicy
}

export function isValueEmpty(value: unknown): boolean {
  if (value === null || value === undefined) {
    return true
  }

  if (typeof value === 'string') {
    return value.trim().length === 0
  }

  if (Array.isArray(value)) {
    return value.length === 0
  }

  return false
}

export function evaluateCondition(condition: Condition, values: FormValues): boolean {
  if (condition.and && condition.and.length > 0) {
    return condition.and.every((entry) => evaluateCondition(entry, values))
  }

  if (condition.or && condition.or.length > 0) {
    return condition.or.some((entry) => evaluateCondition(entry, values))
  }

  if (condition.xor && condition.xor.length > 0) {
    const matches = condition.xor.filter((entry) => evaluateCondition(entry, values)).length
    return matches === 1
  }

  if (condition.not) {
    return !evaluateCondition(condition.not, values)
  }

  const fieldRef = condition.field ?? condition.ref
  if (!fieldRef) {
    return true
  }

  const current = values[fieldRef]

  if (condition.value !== undefined && !Object.is(current, condition.value)) {
    return false
  }

  if (condition.exists !== undefined) {
    const exists = current !== undefined && current !== null
    if (exists !== condition.exists) {
      return false
    }
  }

  if (condition.truthy !== undefined) {
    const truthy = Boolean(current)
    if (truthy !== condition.truthy) {
      return false
    }
  }

  if (condition.falsy !== undefined) {
    const falsy = !current
    if (falsy !== condition.falsy) {
      return false
    }
  }

  if (condition.empty !== undefined) {
    const empty = isValueEmpty(current)
    if (empty !== condition.empty) {
      return false
    }
  }

  if (condition.notEmpty !== undefined) {
    const notEmpty = !isValueEmpty(current)
    if (notEmpty !== condition.notEmpty) {
      return false
    }
  }

  if (condition.eq !== undefined && !Object.is(current, condition.eq)) {
    return false
  }

  if (condition.neq !== undefined && Object.is(current, condition.neq)) {
    return false
  }

  if (condition.in && !condition.in.some((entry) => Object.is(entry, current))) {
    return false
  }

  if (condition.notIn && condition.notIn.some((entry) => Object.is(entry, current))) {
    return false
  }

  if (condition.contains !== undefined) {
    if (typeof current !== 'string' || !current.includes(condition.contains)) {
      return false
    }
  }

  if (condition.startsWith !== undefined) {
    if (typeof current !== 'string' || !current.startsWith(condition.startsWith)) {
      return false
    }
  }

  if (condition.endsWith !== undefined) {
    if (typeof current !== 'string' || !current.endsWith(condition.endsWith)) {
      return false
    }
  }

  if (condition.matches !== undefined) {
    if (typeof current !== 'string') {
      return false
    }

    const regex = new RegExp(condition.matches)
    if (!regex.test(current)) {
      return false
    }
  }

  if (Array.isArray(current)) {
    if (condition.includesAll && !condition.includesAll.every((entry) => current.some((item) => Object.is(item, entry)))) {
      return false
    }

    if (condition.includesAny && !condition.includesAny.some((entry) => current.some((item) => Object.is(item, entry)))) {
      return false
    }

    if (condition.includesNone && condition.includesNone.some((entry) => current.some((item) => Object.is(item, entry)))) {
      return false
    }
  }

  const measuredLength = typeof current === 'string' || Array.isArray(current)
    ? current.length
    : undefined

  if (condition.lengthEq !== undefined) {
    if (measuredLength === undefined || measuredLength !== condition.lengthEq) {
      return false
    }
  }

  if (condition.lengthGte !== undefined) {
    if (measuredLength === undefined || measuredLength < condition.lengthGte) {
      return false
    }
  }

  if (condition.lengthLte !== undefined) {
    if (measuredLength === undefined || measuredLength > condition.lengthLte) {
      return false
    }
  }

  if (typeof current === 'number') {
    if (condition.gt !== undefined && !(current > condition.gt)) {
      return false
    }

    if (condition.gte !== undefined && !(current >= condition.gte)) {
      return false
    }

    if (condition.lt !== undefined && !(current < condition.lt)) {
      return false
    }

    if (condition.lte !== undefined && !(current <= condition.lte)) {
      return false
    }
  }

  return true
}
