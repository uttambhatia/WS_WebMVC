import { registerDefaultWidgets } from './defaults'
import { FormEngineRegistry, registerDefaultValidators } from './registry'
import type { FormFieldSchema, FormSchema } from './schema'

export type FormEngine = {
  schema: FormSchema
  registry: FormEngineRegistry
}

export type FormEngineConfig = {
  schema: FormSchema
  register?: (registry: FormEngineRegistry) => void
}

export type FormEngineInitializationResult = {
  success: boolean
  errors: string[]
  warnings: string[]
  engine?: FormEngine
}

function hasLookupDependencyCycle(fields: FormFieldSchema[]): boolean {
  const edges = new Map<string, Set<string>>()

  for (const field of fields) {
    edges.set(field.key, new Set(field.lookup?.dependsOn ?? []))
  }

  const visited = new Set<string>()
  const inPath = new Set<string>()

  function dfs(node: string): boolean {
    if (inPath.has(node)) {
      return true
    }

    if (visited.has(node)) {
      return false
    }

    visited.add(node)
    inPath.add(node)

    const deps = edges.get(node)
    if (deps) {
      for (const dep of deps) {
        if (edges.has(dep) && dfs(dep)) {
          return true
        }
      }
    }

    inPath.delete(node)
    return false
  }

  for (const key of edges.keys()) {
    if (dfs(key)) {
      return true
    }
  }

  return false
}

export function initializeFormEngine(config: FormEngineConfig): FormEngineInitializationResult {
  const errors: string[] = []
  const warnings: string[] = []
  const fieldKeys = new Set<string>()

  if (!config.schema.id || config.schema.id.trim().length === 0) {
    errors.push('[FormEngine] Schema id is required.')
  }

  if (!Array.isArray(config.schema.fields) || config.schema.fields.length === 0) {
    errors.push('[FormEngine] Schema must include at least one field.')
  }

  for (const field of config.schema.fields) {
    if (!field.key || field.key.trim().length === 0) {
      errors.push('[FormEngine] Every field must declare a non-empty key.')
      continue
    }

    if (fieldKeys.has(field.key)) {
      errors.push(`[FormEngine] Duplicate field key found: "${field.key}".`)
      continue
    }

    fieldKeys.add(field.key)
  }

  if (hasLookupDependencyCycle(config.schema.fields)) {
    errors.push('[FormEngine] Lookup dependency cycle detected in schema fields.')
  }

  const registry = new FormEngineRegistry()
  registerDefaultValidators(registry)
  registerDefaultWidgets(registry)
  config.register?.(registry)

  for (const field of config.schema.fields) {
    const widgetName = field.widget ?? field.type
    if (!registry.hasWidget(widgetName)) {
      warnings.push(`[FormEngine] Missing widget registration for "${widgetName}" (field: "${field.key}").`)
    }

    for (const dependency of field.lookup?.dependsOn ?? []) {
      if (!fieldKeys.has(dependency)) {
        warnings.push(
          `[FormEngine] Lookup dependency "${dependency}" referenced by "${field.key}" does not exist in schema.`,
        )
      }
    }

    const lookupRetryAttempts = Number(field.lookup?.asyncPolicy?.retry?.maxAttempts ?? 1)
    if (!Number.isFinite(lookupRetryAttempts) || lookupRetryAttempts < 1) {
      warnings.push(
        `[FormEngine] Lookup retry maxAttempts for field "${field.key}" must be >= 1. Falling back to defaults.`,
      )
    }

    const lookupTimeout = field.lookup?.asyncPolicy?.timeoutMs
    if (lookupTimeout !== undefined && (!Number.isFinite(lookupTimeout) || lookupTimeout < 0)) {
      warnings.push(
        `[FormEngine] Lookup timeoutMs for field "${field.key}" should be a non-negative number.`,
      )
    }

    for (const validator of field.validators ?? []) {
      if (!registry.hasValidator(validator.name)) {
        warnings.push(
          `[FormEngine] Unknown validator "${validator.name}" on field "${field.key}".`,
        )
      }

      for (const dependency of validator.dependsOn ?? []) {
        if (!fieldKeys.has(dependency)) {
          warnings.push(
            `[FormEngine] Validator dependency "${dependency}" on field "${field.key}" does not exist in schema.`,
          )
        }
      }

      const validatorRetryAttempts = Number(validator.asyncPolicy?.retry?.maxAttempts ?? 1)
      if (!Number.isFinite(validatorRetryAttempts) || validatorRetryAttempts < 1) {
        warnings.push(
          `[FormEngine] Validator retry maxAttempts for "${validator.name}" on field "${field.key}" must be >= 1.`,
        )
      }

      const validatorTimeout = validator.asyncPolicy?.timeoutMs
      if (validatorTimeout !== undefined && (!Number.isFinite(validatorTimeout) || validatorTimeout < 0)) {
        warnings.push(
          `[FormEngine] Validator timeoutMs for "${validator.name}" on field "${field.key}" should be non-negative.`,
        )
      }
    }

    if (field.lookup && !registry.hasLookupProvider(field.lookup.provider)) {
      warnings.push(
        `[FormEngine] Missing lookup provider "${field.lookup.provider}" on field "${field.key}".`,
      )
    }
  }

  if (errors.length > 0) {
    return {
      success: false,
      errors,
      warnings,
    }
  }

  return {
    success: true,
    errors,
    warnings,
    engine: {
      schema: config.schema,
      registry,
    },
  }
}
