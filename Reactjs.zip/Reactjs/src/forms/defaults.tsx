import { AsyncAutocomplete } from '../components/core/AsyncAutocomplete'
import { Checkbox } from '../components/core/Checkbox'
import { Input } from '../components/core/Input'
import { Select } from '../components/core/Select'
import { Textarea } from '../components/core/Textarea'
import { Toggle } from '../components/core/Toggle'
import { FormEngineRegistry, type FormWidgetProps } from './registry'

function TextWidget({ id, value, error, describedBy, field, required, disabled, onValueChange, onBlur }: FormWidgetProps) {
  const inputType = field.type === 'email' || field.type === 'password' ? field.type : 'text'

  return (
    <Input
      id={id}
      type={inputType}
      value={typeof value === 'string' ? value : ''}
      placeholder={field.placeholder}
      aria-describedby={describedBy}
      required={required}
      disabled={disabled}
      error={error}
      onBlur={onBlur}
      onChange={(event) => onValueChange(event.currentTarget.value)}
    />
  )
}

function NumberWidget({ id, value, error, describedBy, field, required, disabled, onValueChange, onBlur }: FormWidgetProps) {
  return (
    <Input
      id={id}
      type="number"
      value={typeof value === 'number' ? String(value) : typeof value === 'string' ? value : ''}
      placeholder={field.placeholder}
      aria-describedby={describedBy}
      required={required}
      disabled={disabled}
      error={error}
      onBlur={onBlur}
      onChange={(event) => {
        const raw = event.currentTarget.value
        if (raw.trim() === '') {
          onValueChange('')
          return
        }

        const parsed = Number(raw)
        onValueChange(Number.isFinite(parsed) ? parsed : raw)
      }}
    />
  )
}

function TextareaWidget({ id, value, error, describedBy, field, required, disabled, onValueChange, onBlur }: FormWidgetProps) {
  return (
    <Textarea
      id={id}
      value={typeof value === 'string' ? value : ''}
      placeholder={field.placeholder}
      aria-describedby={describedBy}
      required={required}
      disabled={disabled}
      error={error}
      onBlur={onBlur}
      onChange={(event) => onValueChange(event.currentTarget.value)}
    />
  )
}

function SelectWidget({ id, value, error, describedBy, field, required, disabled, options, onValueChange, onBlur }: FormWidgetProps) {
  const renderedOptions = field.options ?? options

  return (
    <Select
      id={id}
      value={typeof value === 'string' ? value : ''}
      aria-describedby={describedBy}
      required={required}
      disabled={disabled}
      error={error}
      onBlur={onBlur}
      onChange={(event) => onValueChange(event.currentTarget.value)}
    >
      <option value="">Select...</option>
      {renderedOptions.map((option) => (
        <option key={option.value} value={option.value}>
          {option.label}
        </option>
      ))}
    </Select>
  )
}

function CheckboxWidget({ id, value, field, disabled, onValueChange, onBlur }: FormWidgetProps) {
  return (
    <Checkbox
      id={id}
      label={field.label}
      checked={Boolean(value)}
      disabled={disabled}
      onChange={(event) => {
        onValueChange(event.currentTarget.checked)
        onBlur()
      }}
    />
  )
}

function ToggleWidget({ id, value, field, disabled, onValueChange, onBlur }: FormWidgetProps) {
  return (
    <Toggle
      id={id}
      label={field.label}
      checked={Boolean(value)}
      disabled={disabled}
      onBlur={onBlur}
      onChange={(event) => onValueChange(event.currentTarget.checked)}
    />
  )
}

function AsyncSelectWidget({ id, value, field, loadOptions, onValueChange, values }: FormWidgetProps) {
  return (
    <AsyncAutocomplete
      id={id}
      value={typeof value === 'string' ? value : ''}
      placeholder={field.placeholder}
      minQueryLength={field.lookup?.minQueryLength}
      loadOptions={async (query, context) => {
        if (!loadOptions) {
          return []
        }

        return loadOptions(query, {
          field,
          values,
          signal: context.signal,
        })
      }}
      getOptionLabel={(option) => option.label}
      getOptionValue={(option) => option.value}
      onChange={(nextValue) => onValueChange(nextValue)}
    />
  )
}

export function registerDefaultWidgets(registry: FormEngineRegistry): void {
  registry.registerWidget('text', TextWidget)
  registry.registerWidget('email', TextWidget)
  registry.registerWidget('password', TextWidget)
  registry.registerWidget('number', NumberWidget)
  registry.registerWidget('textarea', TextareaWidget)
  registry.registerWidget('select', SelectWidget)
  registry.registerWidget('checkbox', CheckboxWidget)
  registry.registerWidget('toggle', ToggleWidget)
  registry.registerWidget('async-select', AsyncSelectWidget)
}
