# Design Tokens

This document defines the required design token contract for framework themes.

## Required Tokens

### Spacing
- `--spacing-xs`: 0.25rem
- `--spacing-sm`: 0.5rem
- `--spacing-md`: 0.75rem
- `--spacing-lg`: 1rem
- `--spacing-xl`: 1.5rem

### Typography
- `--font-size-xs`: 0.75rem
- `--font-size-sm`: 0.875rem
- `--font-size-md`: 1rem
- `--font-size-lg`: 1.2rem
- `--font-size-xl`: 2rem
- `--font-weight-regular`: 400
- `--font-weight-medium`: 500
- `--font-weight-semibold`: 600
- `--font-weight-bold`: 700

### Semantic Colors
- `--surface`
- `--border`
- `--text`
- `--muted`
- `--primary-hover`
- `--bg`
- `--brand`
- `--link`
- `--link-hover`
- `--color-primary`
- `--color-secondary`
- `--color-success`
- `--color-warning`
- `--color-error`

### Radius and Elevation
- `--radius-sm`
- `--radius-md`
- `--radius-lg`
- `--radius-pill`
- `--elevation-sm`
- `--elevation-md`

## Optional Enterprise Tokens

These tokens are not required by `validateTheme()` but are included in enterprise presets for richer UI state handling.

### Typography Enhancements
- `--font-family-sans`
- `--font-family-mono`
- `--line-height-tight`
- `--line-height-normal`
- `--line-height-relaxed`

### Component State Tokens
- `--state-focus-ring-width`
- `--state-focus-ring-offset`
- `--state-focus-ring`
- `--state-hover-surface`
- `--state-active-surface`
- `--state-selected-bg`
- `--state-selected-border`
- `--state-disabled-bg`
- `--state-disabled-border`
- `--state-disabled-text`
- `--state-info`
- `--state-info-soft`

### Optional Button State Tokens
- `--button-primary-bg`
- `--button-primary-text`
- `--button-primary-hover`
- `--button-secondary-bg`
- `--button-secondary-text`
- `--button-secondary-hover`

## Theme Submission Rule
A theme should provide all required token keys. Missing or invalid values are reported by `validateTheme()` during registration.

Enterprise-ready packs are available in `src/framework/enterpriseThemes.ts` and include all required tokens plus optional state tokens.

## Usage Rules
- Prefer semantic tokens over hard-coded values.
- Use spacing tokens for component paddings/gaps.
- Use semantic color tokens for status and interaction states.
- Keep inline styles layout-only; token values should live in CSS classes.

## Example

```css
.rf-state-panel--success {
  border-left: 4px solid var(--color-success);
}

.rf-main-nav__link {
  padding: calc(var(--spacing-xs) + 0.2rem) calc(var(--spacing-sm) + var(--spacing-xs));
  border-radius: var(--radius-md);
}
```

## References
- `src/framework/framework.css`
- `src/framework/registry.ts`
- `src/framework/enterpriseThemes.ts`
- `docs/governance/DESIGN_RULES.md`
- `docs/governance/ENTERPRISE_THEME_CATALOG.md`
