import { useMemo, useState } from 'react'
import {
  AreaChart,
  BubbleChart,
  Card,
  DonutChart,
  Grid,
  PieChart,
  RadarChart,
  ScatterChart,
  Stack,
  StackedBarChart,
  useChartDrilldown,
  type AreaChartVariant,
  type BubbleChartVariant,
  type RadarChartProps,
  type StackedBarVariant,
} from 'reactjs-framework'

type InsightRecord = {
  id: string
  status: 'Completed' | 'Pending' | 'Blocked'
  team: 'North' | 'South' | 'Central'
  quarter: 'Q1' | 'Q2' | 'Q3' | 'Q4'
  throughput: number
  quality: number
  effort: number
  risk: number
  impact: number
  timeStep: number
}

const DATASET: InsightRecord[] = [
  { id: '1', status: 'Completed', team: 'North', quarter: 'Q1', throughput: 22, quality: 8, effort: 15, risk: 3, impact: 7, timeStep: 1 },
  { id: '2', status: 'Pending', team: 'North', quarter: 'Q1', throughput: 16, quality: 7, effort: 11, risk: 5, impact: 6, timeStep: 1 },
  { id: '3', status: 'Blocked', team: 'South', quarter: 'Q1', throughput: 11, quality: 6, effort: 9, risk: 8, impact: 4, timeStep: 1 },
  { id: '4', status: 'Completed', team: 'South', quarter: 'Q2', throughput: 24, quality: 9, effort: 16, risk: 2, impact: 8, timeStep: 2 },
  { id: '5', status: 'Pending', team: 'Central', quarter: 'Q2', throughput: 17, quality: 7, effort: 12, risk: 5, impact: 5, timeStep: 2 },
  { id: '6', status: 'Blocked', team: 'North', quarter: 'Q2', throughput: 9, quality: 5, effort: 8, risk: 9, impact: 3, timeStep: 2 },
  { id: '7', status: 'Completed', team: 'Central', quarter: 'Q3', throughput: 26, quality: 9, effort: 17, risk: 2, impact: 9, timeStep: 3 },
  { id: '8', status: 'Pending', team: 'South', quarter: 'Q3', throughput: 19, quality: 8, effort: 13, risk: 4, impact: 6, timeStep: 3 },
  { id: '9', status: 'Blocked', team: 'Central', quarter: 'Q3', throughput: 12, quality: 6, effort: 9, risk: 8, impact: 4, timeStep: 3 },
  { id: '10', status: 'Completed', team: 'North', quarter: 'Q4', throughput: 28, quality: 9, effort: 18, risk: 1, impact: 9, timeStep: 4 },
  { id: '11', status: 'Pending', team: 'Central', quarter: 'Q4', throughput: 18, quality: 7, effort: 13, risk: 5, impact: 6, timeStep: 4 },
  { id: '12', status: 'Blocked', team: 'South', quarter: 'Q4', throughput: 10, quality: 5, effort: 8, risk: 9, impact: 3, timeStep: 4 },
]

function aggregateByStatus(records: InsightRecord[]) {
  const statusOrder: InsightRecord['status'][] = ['Completed', 'Pending', 'Blocked']
  return statusOrder.map((status) => ({
    label: status,
    value: records.filter((record) => record.status === status).length,
  }))
}

export function C11ShowcasePage() {
  const [areaVariant, setAreaVariant] = useState<AreaChartVariant>('range')
  const [scatterVariant, setScatterVariant] = useState<'basic' | 'categorized' | 'regression' | 'quadrant' | 'density'>('density')
  const [stackedVariant, setStackedVariant] = useState<StackedBarVariant>('grouped-stacked')
  const [radarVariant, setRadarVariant] = useState<RadarChartProps['variant']>('delta')
  const [bubbleVariant, setBubbleVariant] = useState<BubbleChartVariant>('annotated')
  const [timelineStep, setTimelineStep] = useState(2)

  const { selection, clearSelection, bindDimension, filterData } = useChartDrilldown()
  const setStatusSelection = bindDimension('status')

  const filtered = useMemo(
    () => filterData(DATASET, (record, dimension) => (dimension === 'status' ? record.status : '')),
    [filterData],
  )

  const source = filtered.length > 0 ? filtered : DATASET

  const pieData = useMemo(() => aggregateByStatus(DATASET), [])
  const pieComparisonData = useMemo(() => aggregateByStatus(source), [source])

  const donutData = useMemo(() => aggregateByStatus(source), [source])

  const areaSingle = useMemo(
    () =>
      source.map((record, idx) => ({
        x: idx + 1,
        y: record.throughput,
        label: record.quarter,
      })),
    [source],
  )

  const areaSeries = useMemo(
    () => [
      source.map((record, idx) => ({ x: idx + 1, y: record.throughput, label: record.quarter })),
      source.map((record, idx) => ({ x: idx + 1, y: record.quality * 2, label: record.quarter })),
      source.map((record, idx) => ({ x: idx + 1, y: record.effort, label: record.quarter })),
    ],
    [source],
  )

  const areaRangeSeries = useMemo(
    () =>
      source.map((record, idx) => ({
        x: idx + 1,
        min: Math.max(record.throughput - 4, 0),
        max: record.throughput + 4,
        label: record.quarter,
      })),
    [source],
  )

  const scatterData = useMemo(
    () =>
      source.map((record) => ({
        x: record.effort,
        y: record.impact,
        label: `${record.id}-${record.team}`,
        group: record.team,
      })),
    [source],
  )

  const stackedData = useMemo(() => {
    const quarterOrder: InsightRecord['quarter'][] = ['Q1', 'Q2', 'Q3', 'Q4']
    return quarterOrder.map((quarter) => {
      const records = source.filter((record) => record.quarter === quarter)
      return {
        label: quarter,
        group: records[0]?.team ?? 'North',
        completed: records.filter((record) => record.status === 'Completed').length,
        pending: records.filter((record) => record.status === 'Pending').length,
        blocked: records.filter((record) => record.status === 'Blocked').length,
      }
    })
  }, [source])

  const radarAxes = useMemo(() => ['Quality', 'Throughput', 'Impact', 'Effort', 'Risk'], [])
  const radarData = useMemo(
    () => [
      {
        label: 'Current',
        values: [
          Math.round(source.reduce((sum, row) => sum + row.quality, 0) / source.length),
          Math.round(source.reduce((sum, row) => sum + row.throughput, 0) / source.length / 3),
          Math.round(source.reduce((sum, row) => sum + row.impact, 0) / source.length),
          Math.round(source.reduce((sum, row) => sum + row.effort, 0) / source.length / 2),
          Math.round(source.reduce((sum, row) => sum + row.risk, 0) / source.length),
        ],
      },
      {
        label: 'Target',
        values: [8, 8, 8, 7, 3],
      },
    ],
    [source],
  )

  const bubbleData = useMemo(
    () =>
      source.map((record) => ({
        x: record.effort,
        y: record.impact,
        r: Math.max(record.throughput / 2, 4),
        label: record.id,
        group: record.team,
        timeStep: record.timeStep,
      })),
    [source],
  )

  const bubbleAnnotations = useMemo(
    () => [
      { label: 'High Impact', x: 15, y: 9 },
      { label: 'At Risk', x: 14, y: 4 },
    ],
    [],
  )

  const areaInput = areaVariant === 'single' || areaVariant === 'range' ? areaSingle : areaSeries

  return (
    <section className="rf-content-panel consumer-page">
      <p className="consumer-page__eyebrow">Component Showcase</p>
      <h2 style={{ margin: 0 }}>Sprint C11 Variant Showcase</h2>
      <p className="consumer-page__lead">
        One-route validation surface for all C11 chart variants with shared drilldown orchestration.
      </p>

      <Card>
        <Stack gap="sm">
          <h3 style={{ margin: 0 }}>Cross-chart drilldown controller</h3>
          <p style={{ margin: 0 }}>
            Active selection: {selection ? `${selection.dimension}=${selection.value}` : 'none'}
          </p>
          <div>
            <button type="button" className="rf-btn rf-btn--outline rf-btn--sm" onClick={clearSelection}>
              Clear Drilldown
            </button>
          </div>
        </Stack>
      </Card>

      <Grid columns="auto-fit" minColWidth="21rem" gap="md">
        <Card>
          <Stack gap="sm">
            <h3 style={{ margin: 0 }}>Pie drilldown/comparison</h3>
            <PieChart
              data={pieData}
              comparisonData={pieComparisonData}
              variant="drilldown"
              showLegend
              showLabels
              onSliceSelect={(slice) => setStatusSelection(slice.label)}
              ariaLabel="Status distribution pie"
            />
          </Stack>
        </Card>

        <Card>
          <Stack gap="sm">
            <h3 style={{ margin: 0 }}>Donut interactive</h3>
            <DonutChart
              data={donutData}
              variant="interactive"
              centerValue={source.length}
              centerLabel="Records"
              activeSliceId={selection?.value}
              onSliceFocus={setStatusSelection}
              showLegend
              ariaLabel="Status donut"
            />
          </Stack>
        </Card>

        <Card>
          <Stack gap="sm">
            <h3 style={{ margin: 0 }}>Area variants</h3>
            <select value={areaVariant} onChange={(e) => setAreaVariant(e.target.value as AreaChartVariant)}>
              <option value="single">single</option>
              <option value="multi">multi</option>
              <option value="stacked">stacked</option>
              <option value="percent">percent</option>
              <option value="range">range</option>
            </select>
            <AreaChart
              data={areaInput}
              variant={areaVariant}
              rangeSeries={areaVariant === 'range' ? areaRangeSeries : undefined}
              showPoints={areaVariant !== 'range'}
              showMedianLine
              ariaLabel="Area variant validation"
            />
          </Stack>
        </Card>

        <Card>
          <Stack gap="sm">
            <h3 style={{ margin: 0 }}>Scatter variants</h3>
            <select value={scatterVariant} onChange={(e) => setScatterVariant(e.target.value as typeof scatterVariant)}>
              <option value="basic">basic</option>
              <option value="categorized">categorized</option>
              <option value="regression">regression</option>
              <option value="quadrant">quadrant</option>
              <option value="density">density</option>
            </select>
            <ScatterChart
              data={scatterData}
              variant={scatterVariant}
              showLabels={scatterVariant !== 'density'}
              trendline={scatterVariant === 'regression'}
              quadrants={scatterVariant === 'quadrant' ? [{ label: 'Q1', color: 'var(--color-primary)' }, { label: 'Q2', color: 'var(--color-secondary)' }] : []}
              ariaLabel="Scatter variant validation"
            />
          </Stack>
        </Card>

        <Card>
          <Stack gap="sm">
            <h3 style={{ margin: 0 }}>Stacked bar variants</h3>
            <select value={stackedVariant} onChange={(e) => setStackedVariant(e.target.value as StackedBarVariant)}>
              <option value="vertical">vertical</option>
              <option value="horizontal">horizontal</option>
              <option value="percent">percent</option>
              <option value="grouped-stacked">grouped-stacked</option>
              <option value="diverging">diverging</option>
            </select>
            <StackedBarChart
              data={stackedData}
              series={['completed', 'pending', 'blocked']}
              variant={stackedVariant}
              groupField="group"
              showLegend
              ariaLabel="Stacked bar variant validation"
            />
          </Stack>
        </Card>

        <Card>
          <Stack gap="sm">
            <h3 style={{ margin: 0 }}>Radar variants</h3>
            <select value={radarVariant} onChange={(e) => setRadarVariant(e.target.value as RadarChartProps['variant'])}>
              <option value="basic">basic</option>
              <option value="filled">filled</option>
              <option value="threshold">threshold</option>
              <option value="delta">delta</option>
            </select>
            <RadarChart
              data={radarData}
              axes={radarAxes}
              variant={radarVariant}
              benchmarkSeries={radarVariant === 'threshold' ? [7, 7, 7, 7, 4] : undefined}
              deltaBaseline={radarVariant === 'delta' ? [6, 6, 6, 6, 6] : undefined}
              showLegend
              ariaLabel="Radar variant validation"
            />
          </Stack>
        </Card>

        <Card>
          <Stack gap="sm">
            <h3 style={{ margin: 0 }}>Bubble variants</h3>
            <select value={bubbleVariant} onChange={(e) => setBubbleVariant(e.target.value as BubbleChartVariant)}>
              <option value="basic">basic</option>
              <option value="categorized">categorized</option>
              <option value="timeline">timeline</option>
              <option value="packed">packed</option>
              <option value="annotated">annotated</option>
            </select>
            {bubbleVariant === 'timeline' && (
              <select value={timelineStep} onChange={(e) => setTimelineStep(Number(e.target.value))}>
                <option value={1}>step 1</option>
                <option value={2}>step 2</option>
                <option value={3}>step 3</option>
                <option value={4}>step 4</option>
              </select>
            )}
            <BubbleChart
              data={bubbleData}
              variant={bubbleVariant}
              timeStep={bubbleVariant === 'timeline' ? timelineStep : undefined}
              annotations={bubbleVariant === 'annotated' ? bubbleAnnotations : undefined}
              showLabels
              labelStrategy="top-n"
              topN={4}
              ariaLabel="Bubble variant validation"
            />
          </Stack>
        </Card>
      </Grid>
    </section>
  )
}
