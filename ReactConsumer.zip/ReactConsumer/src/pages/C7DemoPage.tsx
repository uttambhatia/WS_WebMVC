import { useMemo, useState } from 'react'
import {
  Breadcrumb,
  Button,
  Card,
  ConfirmationDialog,
  Grid,
  KPICard,
  KanbanBoard,
  SliderInput,
  Sparkline,
  Stack,
  TagsInput,
  VirtualList,
  type KanbanColumn,
} from 'reactjs-framework'

type VirtualItem = { id: string; name: string }

const VIRTUAL_ITEMS: VirtualItem[] = Array.from({ length: 500 }, (_, i) => ({
  id: `row-${i + 1}`,
  name: `Service ${i + 1}`,
}))

const INITIAL_COLUMNS: KanbanColumn[] = [
  {
    id: 'todo',
    title: 'To Do',
    wipLimit: 4,
    cards: [
      { id: 'k-1', title: 'Investigate failed jobs', description: 'Batch processor alerts' },
      { id: 'k-2', title: 'Prepare release notes' },
    ],
  },
  {
    id: 'doing',
    title: 'In Progress',
    wipLimit: 3,
    cards: [{ id: 'k-3', title: 'Tune query performance' }],
  },
  {
    id: 'done',
    title: 'Done',
    cards: [{ id: 'k-4', title: 'Audit dashboard cleanup' }],
  },
]

function moveCard(columns: KanbanColumn[], cardId: string, fromId: string, toId: string, targetIndex: number): KanbanColumn[] {
  const next = columns.map((col) => ({ ...col, cards: [...col.cards] }))
  const from = next.find((col) => col.id === fromId)
  const to = next.find((col) => col.id === toId)
  if (!from || !to) {
    return columns
  }

  const fromIndex = from.cards.findIndex((card) => card.id === cardId)
  if (fromIndex < 0) {
    return columns
  }

  const [card] = from.cards.splice(fromIndex, 1)
  const safeIndex = Math.max(0, Math.min(targetIndex, to.cards.length))
  to.cards.splice(safeIndex, 0, card)

  return next
}

export function C7DemoPage() {
  const [sliderValue, setSliderValue] = useState<number | [number, number]>(42)
  const [dualValue, setDualValue] = useState<number | [number, number]>([20, 75])
  const [tags, setTags] = useState<string[]>(['ops', 'priority'])
  const [dialogOpen, setDialogOpen] = useState(false)
  const [kanbanColumns, setKanbanColumns] = useState<KanbanColumn[]>(INITIAL_COLUMNS)

  const sparklineData = useMemo(() => [4, 9, 6, 12, 8, 14, 17], [])

  return (
    <section className="rf-content-panel consumer-page">
      <p className="consumer-page__eyebrow">Component Showcase</p>
      <h2 style={{ margin: 0 }}>Sprint C7 Demo</h2>
      <p className="consumer-page__lead">
        Consumer verification page for C7 components: sliders, tags, KPI, virtualized list, confirmation dialog, and kanban workflow.
      </p>

      <Breadcrumb
        items={[
          { label: 'Home', href: '/' },
          { label: 'Components', href: '/c7-demo' },
          { label: 'C7 Demo' },
        ]}
      />

      <Grid columns="auto-fit" minColWidth="18rem" gap="md">
        <Card>
          <Stack gap="sm">
            <h3 style={{ margin: 0 }}>SliderInput</h3>
            <SliderInput
              value={sliderValue}
              showValue
              onChange={(next) => setSliderValue(next)}
              aria-label="Single slider"
            />
            <SliderInput
              dual
              value={dualValue}
              showValue
              showTicks
              onChange={(next) => setDualValue(next)}
              aria-label="Range slider"
            />
          </Stack>
        </Card>

        <Card>
          <Stack gap="sm">
            <h3 style={{ margin: 0 }}>TagsInput</h3>
            <TagsInput
              value={tags}
              onChange={setTags}
              placeholder="Add environment tag"
              maxTags={6}
              aria-label="Tag editor"
            />
            <p className="consumer-c7__hint">Current tags: {tags.join(', ') || 'none'}</p>
          </Stack>
        </Card>

        <Card>
          <Stack gap="sm">
            <h3 style={{ margin: 0 }}>KPICard + Sparkline</h3>
            <KPICard
              title="Active incidents"
              value={18}
              delta={12}
              trend="up"
              deltaLabel="vs last hour"
              sparkline={<Sparkline data={sparklineData} fillColor="rgba(11, 95, 165, 0.16)" />}
              footer={<span>Target under 25</span>}
            />
          </Stack>
        </Card>
      </Grid>

      <Card>
        <Stack gap="sm">
          <h3 style={{ margin: 0 }}>VirtualList</h3>
          <VirtualList
            items={VIRTUAL_ITEMS}
            itemHeight={36}
            height={220}
            getItemKey={(item) => item.id}
            renderItem={(item) => <div className="consumer-c7__row">{item.name}</div>}
          />
        </Stack>
      </Card>

      <Card>
        <Stack gap="sm">
          <h3 style={{ margin: 0 }}>KanbanBoard</h3>
          <KanbanBoard
            columns={kanbanColumns}
            onCardMove={(cardId, fromColumnId, toColumnId, newIndex) => {
              setKanbanColumns((current) => moveCard(current, cardId, fromColumnId, toColumnId, newIndex))
            }}
            onAddCard={(columnId) => {
              setKanbanColumns((current) => current.map((column) => {
                if (column.id !== columnId) {
                  return column
                }
                const nextId = `k-${Date.now()}`
                return {
                  ...column,
                  cards: [...column.cards, { id: nextId, title: 'New card' }],
                }
              }))
            }}
          />
        </Stack>
      </Card>

      <Card>
        <Stack gap="sm">
          <h3 style={{ margin: 0 }}>ConfirmationDialog</h3>
          <Button onClick={() => setDialogOpen(true)}>Open Confirmation</Button>
          <ConfirmationDialog
            open={dialogOpen}
            title="Apply rollout plan"
            message="This will trigger deployment workflow for all selected services."
            variant="danger"
            onCancel={() => setDialogOpen(false)}
            onConfirm={() => setDialogOpen(false)}
          />
        </Stack>
      </Card>
    </section>
  )
}
