import { useMemo, useState } from 'react'
import {
  Accordion,
  Breadcrumb,
  Button,
  Card,
  CommandPalette,
  DataGrid,
  DatePicker,
  DropdownMenu,
  FileUpload,
  Grid,
  Modal,
  MultiSelect,
  NotificationCenter,
  Pagination,
  Popover,
  ProgressBar,
  SkeletonLoader,
  Stack,
  Stepper,
  Table,
  Tabs,
  Textarea,
  Toggle,
  Tooltip,
  TreeView,
  type TableColumn,
  type ToastMessage,
  type TreeNode,
} from 'reactjs-framework'

type DemoRow = {
  id: string
  name: string
  status: string
  score: number
}

const DEMO_ROWS: DemoRow[] = [
  { id: 'r1', name: 'Alpha', status: 'Healthy', score: 92 },
  { id: 'r2', name: 'Bravo', status: 'Warning', score: 74 },
  { id: 'r3', name: 'Charlie', status: 'Healthy', score: 88 },
  { id: 'r4', name: 'Delta', status: 'Critical', score: 56 },
  { id: 'r5', name: 'Echo', status: 'Healthy', score: 95 },
  { id: 'r6', name: 'Foxtrot', status: 'Warning', score: 69 },
]

const TREE_NODES: TreeNode[] = [
  {
    id: 'platform',
    label: 'Platform',
    children: [
      { id: 'ui', label: 'UI Framework' },
      { id: 'api', label: 'API Gateway' },
      { id: 'auth', label: 'Identity Service' },
    ],
  },
  {
    id: 'analytics',
    label: 'Analytics',
    children: [
      { id: 'pipelines', label: 'Pipelines' },
      { id: 'dashboard', label: 'Dashboards' },
    ],
  },
]

export function C4DemoPage() {
  const [notes, setNotes] = useState('')
  const [enabled, setEnabled] = useState(true)
  const [selectedTags, setSelectedTags] = useState<string[]>(['core'])
  const [dueDate, setDueDate] = useState('2026-03-14')
  const [progress, setProgress] = useState(42)
  const [modalOpen, setModalOpen] = useState(false)
  const [commandOpen, setCommandOpen] = useState(false)
  const [currentPage, setCurrentPage] = useState(1)
  const [sortBy, setSortBy] = useState<keyof DemoRow>('name')
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc')
  const [selectedRowIds, setSelectedRowIds] = useState<string[]>([])
  const [messages, setMessages] = useState<ToastMessage[]>([])

  function pushToast(message: Omit<ToastMessage, 'id'>) {
    const id = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`
    setMessages((prev) => [...prev, { ...message, id }])
  }

  const tableColumns = useMemo<TableColumn<DemoRow>[]>(() => [
    { key: 'name', header: 'Name', sortable: true },
    { key: 'status', header: 'Status', sortable: true },
    { key: 'score', header: 'Score', sortable: true },
  ], [])

  const sortedRows = useMemo(() => {
    const sorted = [...DEMO_ROWS].sort((a, b) => {
      const left = a[sortBy]
      const right = b[sortBy]
      if (left === right) return 0
      if (left > right) return sortDirection === 'asc' ? 1 : -1
      return sortDirection === 'asc' ? -1 : 1
    })
    return sorted
  }, [sortBy, sortDirection])

  const commandItems = [
    {
      id: 'toast-success',
      label: 'Show success toast',
      keywords: ['success', 'notify'],
      onSelect: () => pushToast({ title: 'Saved', description: 'Changes were saved.', variant: 'success', timeoutMs: 2200 }),
    },
    {
      id: 'open-modal',
      label: 'Open demo modal',
      keywords: ['dialog', 'modal'],
      onSelect: () => setModalOpen(true),
    },
    {
      id: 'increase-progress',
      label: 'Increase progress by 10%',
      keywords: ['progress'],
      onSelect: () => setProgress((value) => Math.min(100, value + 10)),
    },
  ]

  return (
    <section className="rf-content-panel consumer-page">
      <p className="consumer-page__eyebrow">Component Showcase</p>
      <h2 style={{ margin: 0 }}>Sprint C4 Demo</h2>
      <p className="consumer-page__lead">Interactive examples of the newly added C4 components in the consumer UI.</p>

      <Breadcrumb
        items={[
          { label: 'Home', href: '/' },
          { label: 'Components', href: '/c4-demo' },
          { label: 'C4 Demo' },
        ]}
      />

      <Grid columns="auto-fit" minColWidth="18rem" gap="md">
        <Card>
          <Stack gap="sm">
            <h3 style={{ margin: 0 }}>Inputs</h3>
            <Textarea
              value={notes}
              onChange={(event) => setNotes(event.target.value)}
              placeholder="Try typing notes here..."
              rows={4}
            />
            <Toggle
              id="c4-toggle"
              label="Enable automated reminders"
              checked={enabled}
              onChange={(event) => setEnabled(event.currentTarget.checked)}
            />
            <DatePicker value={dueDate} onChange={setDueDate} />
            <MultiSelect
              ariaLabel="Demo tags"
              values={selectedTags}
              onChange={setSelectedTags}
              options={[
                { value: 'core', label: 'Core' },
                { value: 'a11y', label: 'Accessibility' },
                { value: 'perf', label: 'Performance' },
                { value: 'docs', label: 'Documentation' },
              ]}
            />
            <FileUpload
              id="demo-upload"
              label="Attach artifacts"
              multiple
              onFilesChange={(files) => {
                if (files.length > 0) {
                  pushToast({
                    title: 'Files selected',
                    description: `${files.length} file(s) ready for upload.`,
                    variant: 'info',
                    timeoutMs: 2000,
                  })
                }
              }}
            />
          </Stack>
        </Card>

        <Card>
          <Stack gap="sm">
            <h3 style={{ margin: 0 }}>Overlays and Menus</h3>
            <Stack direction="row" wrap gap="sm">
              <Popover trigger="Open Popover" placement="bottom">
                <p style={{ margin: 0 }}>This is a popover panel using C4 primitives.</p>
              </Popover>
              <DropdownMenu
                triggerLabel="Actions"
                items={[
                  { id: 'one', label: 'Create note', onSelect: () => pushToast({ title: 'Action', description: 'Create note clicked.', variant: 'info', timeoutMs: 1800 }) },
                  { id: 'two', label: 'Archive', onSelect: () => pushToast({ title: 'Archived', description: 'Archive action executed.', variant: 'warning', timeoutMs: 1800 }) },
                ]}
              />
              <Tooltip content="This opens a modal dialog.">
                <Button variant="outline" onClick={() => setModalOpen(true)}>Open Modal</Button>
              </Tooltip>
              <Button variant="secondary" onClick={() => setCommandOpen(true)}>Open Command Palette</Button>
            </Stack>
            <Accordion
              multiple
              defaultExpandedIds={['acc-1']}
              items={[
                { id: 'acc-1', title: 'What is C4?', content: 'C4 extends the framework with advanced reusable UI primitives.' },
                { id: 'acc-2', title: 'Can I use these in plugins?', content: 'Yes. They are exported through the framework public alpha API.' },
              ]}
            />
          </Stack>
        </Card>
      </Grid>

      <Card>
        <Stack gap="md">
          <h3 style={{ margin: 0 }}>Navigation and Progress</h3>
          <Tabs
            tabs={[
              { id: 'overview', label: 'Overview', content: <p style={{ margin: 0 }}>Tab navigation supports arrow key movement and semantic roles.</p> },
              { id: 'status', label: 'Status', content: <p style={{ margin: 0 }}>Current progress is tracked below with determinate and indeterminate bars.</p> },
              { id: 'ops', label: 'Ops', content: <p style={{ margin: 0 }}>Use Stepper and TreeView for process and hierarchy UIs.</p> },
            ]}
          />
          <ProgressBar value={progress} max={100} label={`Progress ${progress}%`} />
          <ProgressBar label="Background sync" />
          <Stepper
            currentStepId="build"
            steps={[
              { id: 'design', label: 'Design', status: 'complete' },
              { id: 'build', label: 'Build', status: 'active' },
              { id: 'release', label: 'Release', status: 'pending' },
            ]}
          />
          <TreeView nodes={TREE_NODES} defaultExpandedIds={['platform']} />
        </Stack>
      </Card>

      <Grid columns="auto-fit" minColWidth="22rem" gap="md">
        <Card>
          <Stack gap="sm">
            <h3 style={{ margin: 0 }}>Table and Pagination</h3>
            <Table
              columns={tableColumns}
              data={sortedRows.slice(0, 4)}
              sortBy={sortBy}
              sortDirection={sortDirection}
              onSortChange={(key, direction) => {
                setSortBy(key as keyof DemoRow)
                setSortDirection(direction)
              }}
            />
            <Pagination currentPage={currentPage} totalPages={3} onPageChange={setCurrentPage} />
          </Stack>
        </Card>

        <Card>
          <Stack gap="sm">
            <h3 style={{ margin: 0 }}>DataGrid (MVP)</h3>
            <DataGrid
              columns={tableColumns}
              rows={sortedRows}
              page={currentPage}
              pageSize={2}
              selectable
              selectedRowIds={selectedRowIds}
              getRowId={(row) => row.id}
              onSelectionChange={setSelectedRowIds}
              sortBy={sortBy}
              sortDirection={sortDirection}
              onSortChange={(key, direction) => {
                setSortBy(key as keyof DemoRow)
                setSortDirection(direction)
              }}
            />
            <p className="consumer-c4__note">Selected rows: {selectedRowIds.join(', ') || 'none'}</p>
          </Stack>
        </Card>
      </Grid>

      <Card>
        <Stack gap="sm">
          <h3 style={{ margin: 0 }}>Skeleton Loader</h3>
          <div className="consumer-c4__skeleton-grid">
            <SkeletonLoader variant="circle" width="2.5rem" height="2.5rem" />
            <SkeletonLoader variant="text" width="80%" />
            <SkeletonLoader variant="rect" height="5rem" />
          </div>
        </Stack>
      </Card>

      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title="C4 Modal Demo"
        footer={<Button onClick={() => setModalOpen(false)}>Close</Button>}
      >
        <p style={{ marginTop: 0 }}>This modal demonstrates focus management and backdrop dismissal.</p>
      </Modal>

      <CommandPalette
        open={commandOpen}
        onClose={() => setCommandOpen(false)}
        commands={commandItems}
      />

      <NotificationCenter
        messages={messages}
        onDismiss={(id) => setMessages((prev) => prev.filter((message) => message.id !== id))}
      />
    </section>
  )
}
