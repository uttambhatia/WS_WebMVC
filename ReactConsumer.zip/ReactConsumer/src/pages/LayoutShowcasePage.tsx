import { Breadcrumb, Card, Grid, Stack } from 'reactjs-framework'

export function LayoutShowcasePage() {
  return (
    <section className="rf-content-panel consumer-page">
      <p className="consumer-page__eyebrow">Layout Showcase</p>
      <h2 style={{ margin: 0 }}>Responsive Layout Demonstration</h2>
      <p className="consumer-page__lead">
        Use the Preferences menu to switch layouts and verify each slot region, responsive behavior, and UX intent.
      </p>

      <Breadcrumb
        items={[
          { label: 'Home', href: '/' },
          { label: 'Components', href: '/layout-showcase' },
          { label: 'Layout Showcase' },
        ]}
      />

      <Card>
        <Stack gap="sm">
          <h3 style={{ margin: 0 }}>How to Validate</h3>
          <ol className="consumer-layoutshowcase__list">
            <li>Open Preferences and switch to Focused Workspace.</li>
            <li>Toggle the inspector and verify mobile bottom-sheet behavior.</li>
            <li>Switch to List Detail and verify mobile list/detail pane switching.</li>
            <li>Switch to Adaptive Two-Pane and toggle compact rail mode.</li>
            <li>Switch to Card Grid Flow and toggle density in the header.</li>
            <li>Switch to Step Journey and verify sticky actions on desktop.</li>
            <li>Switch to Command Surface and collapse/expand side panel.</li>
          </ol>
        </Stack>
      </Card>

      <Grid columns="auto-fit" minColWidth="16rem" gap="md">
        <Card>
          <h3 style={{ marginTop: 0 }}>Focused Workspace</h3>
          <p className="consumer-layoutshowcase__hint">Primary authoring content + optional inspector.</p>
        </Card>
        <Card>
          <h3 style={{ marginTop: 0 }}>List Detail</h3>
          <p className="consumer-layoutshowcase__hint">Master list + detail pane with mobile drill-in.</p>
        </Card>
        <Card>
          <h3 style={{ marginTop: 0 }}>Adaptive Two-Pane</h3>
          <p className="consumer-layoutshowcase__hint">Rail navigation with compact mode for tighter screens.</p>
        </Card>
        <Card>
          <h3 style={{ marginTop: 0 }}>Card Grid Flow</h3>
          <p className="consumer-layoutshowcase__hint">Density-aware responsive card grid for scanability.</p>
        </Card>
        <Card>
          <h3 style={{ marginTop: 0 }}>Step Journey</h3>
          <p className="consumer-layoutshowcase__hint">Progress-first stage layout with sticky action bar.</p>
        </Card>
        <Card>
          <h3 style={{ marginTop: 0 }}>Command Surface</h3>
          <p className="consumer-layoutshowcase__hint">Sticky command zone with results and side panel.</p>
        </Card>
      </Grid>
    </section>
  )
}
