export function HomePage() {
  return (
    <section className="rf-content-panel consumer-page consumer-page--narrow">
      <p className="consumer-page__eyebrow">Overview</p>
      <h2>Home</h2>
      <p className="consumer-page__lead">This consumer app demonstrates the shared framework with stable navigation, theme preferences, and reusable content patterns.</p>
      <div className="consumer-page__grid" aria-label="Overview metrics">
        <div className="consumer-metric">
          <strong>8</strong>
          <span>built-in layouts available</span>
        </div>
        <div className="consumer-metric">
          <strong>14</strong>
          <span>registered routes in the consumer app</span>
        </div>
        <div className="consumer-metric">
          <strong>27</strong>
          <span>theme options currently exposed</span>
        </div>
      </div>
    </section>
  )
}
