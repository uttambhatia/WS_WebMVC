import { useMemo, useState } from 'react'
import {
  AsyncAutocomplete,
  AuditTimeline,
  Breadcrumb,
  Button,
  CalendarScheduler,
  Card,
  CommandBar,
  CommandPalette,
  DataGrid,
  FileManager,
  FormWizard,
  Grid,
  InlineEditable,
  RichTextEditorField,
  SplitLayout,
  Stack,
  type AuditTimelineEvent,
  type CommandItem,
  type FileManagerItem,
  type FormWizardStep,
  type CalendarSchedulerEvent,
  type CalendarSchedulerView,
  type RichTextEditorOutput,
  type TableColumn,
} from 'reactjs-framework'

type OpsRow = {
  id: string
  service: string
  status: 'Healthy' | 'Warning' | 'Critical'
  owner: string
}

const OPS_ROWS: OpsRow[] = [
  { id: 'op-1', service: 'Payments API', status: 'Healthy', owner: 'Platform' },
  { id: 'op-2', service: 'Risk Scoring', status: 'Warning', owner: 'Analytics' },
  { id: 'op-3', service: 'Auth Gateway', status: 'Critical', owner: 'Identity' },
  { id: 'op-4', service: 'Trade Ledger', status: 'Healthy', owner: 'Core' },
  { id: 'op-5', service: 'Market Feed', status: 'Warning', owner: 'Data' },
]

const SERVICE_OPTIONS = [
  { id: 'payments-api', label: 'Payments API' },
  { id: 'risk-scoring', label: 'Risk Scoring' },
  { id: 'auth-gateway', label: 'Auth Gateway' },
  { id: 'trade-ledger', label: 'Trade Ledger' },
  { id: 'market-feed', label: 'Market Feed' },
  { id: 'audit-trail', label: 'Audit Trail' },
]

const SCHEDULER_EVENTS: CalendarSchedulerEvent[] = [
  {
    id: 'sched-1',
    title: 'Ops Standup',
    start: '2026-03-14T09:00:00Z',
    end: '2026-03-14T09:30:00Z',
  },
  {
    id: 'sched-2',
    title: 'Incident Review',
    start: '2026-03-15T13:00:00Z',
    end: '2026-03-15T14:00:00Z',
  },
  {
    id: 'sched-3',
    title: 'Release Cutover',
    start: '2026-03-18T16:00:00Z',
    end: '2026-03-18T17:00:00Z',
  },
]

const INITIAL_FILES: FileManagerItem[] = [
  {
    id: 'file-1',
    name: 'runbook-v3.md',
    size: 18240,
    type: 'text/markdown',
    versionLabel: '3.0',
    metadata: {
      owner: 'SRE',
      region: 'global',
    },
  },
  {
    id: 'file-2',
    name: 'incident-retro.pdf',
    size: 642000,
    type: 'application/pdf',
    versionLabel: '1.2',
    metadata: {
      owner: 'Platform',
      retention: '12 months',
    },
  },
]

const INITIAL_AUDIT_EVENTS: AuditTimelineEvent[] = [
  {
    id: 'audit-1',
    timestamp: '2026-03-14T08:30:00Z',
    title: 'Runbook updated',
    description: 'Updated rollback guidance and severity matrix.',
    actor: 'A. Kumar',
    category: 'documentation',
    metadata: {
      changeId: 'CHG-2241',
      env: 'prod',
    },
  },
  {
    id: 'audit-2',
    timestamp: '2026-03-14T09:40:00Z',
    title: 'Pager escalation policy changed',
    actor: 'S. Miller',
    category: 'policy',
    metadata: {
      policy: 'P1 escalation',
      approval: 'CAB',
    },
  },
  {
    id: 'audit-3',
    timestamp: '2026-03-13T16:15:00Z',
    title: 'Sandbox deployment completed',
    actor: 'R. Chen',
    category: 'deployment',
    metadata: {
      release: '2026.03.14.2',
      target: 'sandbox',
    },
  },
]

const COMMAND_PALETTE_ITEMS: CommandItem[] = [
  { id: 'cp-refresh', label: 'Refresh dashboard', keywords: ['reload', 'sync'], onSelect: () => window.alert('Dashboard refreshed.') },
  { id: 'cp-export', label: 'Export operations report', keywords: ['report', 'download'], onSelect: () => window.alert('Report export started.') },
  { id: 'cp-open-retro', label: 'Open latest retrospective', keywords: ['retro', 'postmortem'], onSelect: () => window.alert('Opening retrospective document.') },
]

export function C6DemoPage() {
  const [selectedServiceId, setSelectedServiceId] = useState('')
  const [runbookTitle, setRunbookTitle] = useState('Incident triage runbook')
  const [priority, setPriority] = useState('P2')

  const [currentStepId, setCurrentStepId] = useState('details')
  const [detailsValid, setDetailsValid] = useState(false)
  const [submitted, setSubmitted] = useState(false)

  const [columnVisibility, setColumnVisibility] = useState<Partial<Record<keyof OpsRow, boolean>>>({
    service: true,
    status: true,
    owner: true,
  })
  const [columnOrder, setColumnOrder] = useState<Array<keyof OpsRow>>(['service', 'status', 'owner'])
  const [columnWidths, setColumnWidths] = useState<Partial<Record<keyof OpsRow, number>>>({
    service: 220,
    status: 140,
    owner: 180,
  })

  const [splitSizes, setSplitSizes] = useState<number[]>([62, 38])
  const [calendarView, setCalendarView] = useState<CalendarSchedulerView>('week')
  const [calendarDate, setCalendarDate] = useState('2026-03-14')
  const [calendarRange, setCalendarRange] = useState<{ startDate: string; endDate: string } | null>(null)
  const [lastSelectedEvent, setLastSelectedEvent] = useState<string>('none')
  const [createdSlots, setCreatedSlots] = useState<string[]>([])
  const [commandSearch, setCommandSearch] = useState('')
  const [commandPaletteOpen, setCommandPaletteOpen] = useState(false)
  const [commandMessage, setCommandMessage] = useState('No action yet.')
  const [editorOutput, setEditorOutput] = useState<RichTextEditorOutput>('html')
  const [editorValue, setEditorValue] = useState('<p><strong>Ops note:</strong> confirm rollback owner before deploy.</p>')
  const [fileItems, setFileItems] = useState<FileManagerItem[]>(INITIAL_FILES)
  const [auditFilterText, setAuditFilterText] = useState('')

  const columns = useMemo<TableColumn<OpsRow>[]>(() => [
    { key: 'service', header: 'Service', sortable: true },
    { key: 'status', header: 'Status', sortable: true },
    { key: 'owner', header: 'Owner', sortable: true },
  ], [])

  const wizardSteps = useMemo<FormWizardStep[]>(() => [
    {
      id: 'details',
      title: 'Details',
      description: 'Set scope and title',
      validateStep: () => (detailsValid ? null : 'Mark details as complete before continuing.'),
      content: (
        <Stack gap="sm">
          <p className="consumer-c6__note">Use InlineEditable to update title and priority inline.</p>
          <div className="consumer-c6__inline-grid">
            <span className="consumer-c6__label">Runbook</span>
            <InlineEditable
              value={runbookTitle}
              onSave={(value) => {
                if (value.trim().length === 0) return 'Title cannot be empty.'
                setRunbookTitle(value)
              }}
              validate={(value) => (value.trim().length === 0 ? 'Title cannot be empty.' : null)}
            />

            <span className="consumer-c6__label">Priority</span>
            <InlineEditable
              mode="select"
              value={priority}
              options={[
                { value: 'P1', label: 'P1 - Critical' },
                { value: 'P2', label: 'P2 - High' },
                { value: 'P3', label: 'P3 - Medium' },
              ]}
              onSave={(value) => setPriority(value)}
            />
          </div>

          <Button variant={detailsValid ? 'secondary' : 'outline'} onClick={() => setDetailsValid((prev) => !prev)}>
            {detailsValid ? 'Details complete' : 'Mark details complete'}
          </Button>
        </Stack>
      ),
    },
    {
      id: 'review',
      title: 'Review',
      description: 'Confirm operational state',
      content: (
        <Stack gap="sm">
          <p className="consumer-c6__note">Review current configuration before final submission.</p>
          <ul className="consumer-c6__list">
            <li>Service: {selectedServiceId || 'none selected'}</li>
            <li>Runbook: {runbookTitle}</li>
            <li>Priority: {priority}</li>
          </ul>
        </Stack>
      ),
    },
    {
      id: 'submit',
      title: 'Submit',
      description: 'Finalize',
      content: (
        <p className="consumer-c6__note">Submit to complete this demo workflow.</p>
      ),
    },
  ], [detailsValid, selectedServiceId, runbookTitle, priority])

  return (
    <section className="rf-content-panel consumer-page">
      <p className="consumer-page__eyebrow">Component Showcase</p>
      <h2 style={{ margin: 0 }}>Sprint C6 Demo</h2>
      <p className="consumer-page__lead">
        Integrated demo for C6 must-have and nice-to-have components, including CommandBar, RichTextEditorField, FileManager, and AuditTimeline.
      </p>

      <Breadcrumb
        items={[
          { label: 'Home', href: '/' },
          { label: 'Components', href: '/c6-demo' },
          { label: 'C6 Demo' },
        ]}
      />

      <Grid columns="auto-fit" minColWidth="20rem" gap="md">
        <Card>
          <Stack gap="sm">
            <h3 style={{ margin: 0 }}>AsyncAutocomplete</h3>
            <AsyncAutocomplete
              id="c6-async-service"
              value={selectedServiceId}
              minQueryLength={1}
              debounceMs={160}
              loadOptions={async (query) => {
                await new Promise((resolve) => setTimeout(resolve, 120))
                const q = query.trim().toLowerCase()
                return SERVICE_OPTIONS.filter((opt) => opt.label.toLowerCase().includes(q))
              }}
              getOptionLabel={(option) => option.label}
              getOptionValue={(option) => option.id}
              onChange={setSelectedServiceId}
              ariaLabel="Service search"
            />
            <p className="consumer-c6__note">Selected service id: {selectedServiceId || 'none'}</p>
          </Stack>
        </Card>

        <Card>
          <Stack gap="sm">
            <h3 style={{ margin: 0 }}>FormWizard + InlineEditable</h3>
            <FormWizard
              steps={wizardSteps}
              currentStepId={currentStepId}
              onStepChange={(id) => {
                setSubmitted(false)
                setCurrentStepId(id)
              }}
              onSubmit={() => setSubmitted(true)}
            />
            {submitted && <p className="consumer-c6__success">Submitted successfully.</p>}
          </Stack>
        </Card>
      </Grid>

      <Card>
        <Stack gap="sm">
          <h3 style={{ margin: 0 }}>SplitLayout + DataGrid Pro Controls</h3>
          <p className="consumer-c6__note">Drag separators or use arrow keys on focused handles to resize panes.</p>

          <div className="consumer-c6__split-wrap">
            <SplitLayout
              panes={[
                {
                  id: 'grid-pane',
                  label: 'Grid pane',
                  content: (
                    <DataGrid
                      columns={columns}
                      rows={OPS_ROWS}
                      page={1}
                      pageSize={5}
                      showColumnControls
                      columnVisibility={columnVisibility}
                      onColumnVisibilityChange={setColumnVisibility}
                      columnOrder={columnOrder}
                      onColumnOrderChange={(next) => setColumnOrder(next as Array<keyof OpsRow>)}
                      columnWidths={columnWidths}
                      onColumnResize={(key, width) => {
                        const columnKey = key as keyof OpsRow
                        setColumnWidths((prev) => ({ ...prev, [columnKey]: width }))
                      }}
                    />
                  ),
                },
                {
                  id: 'detail-pane',
                  label: 'Detail pane',
                  content: (
                    <div className="consumer-c6__detail">
                      <h4 style={{ marginTop: 0 }}>Pane State</h4>
                      <p className="consumer-c6__note">Current split sizes: {splitSizes.map((n) => n.toFixed(1)).join('% / ')}%</p>
                      <p className="consumer-c6__note">Visible columns are controlled from DataGrid column controls.</p>
                      <p className="consumer-c6__note">Try collapse buttons to validate controlled size updates.</p>
                    </div>
                  ),
                },
              ]}
              sizes={splitSizes}
              minSizes={[35, 25]}
              collapsible
              onSizesChange={setSplitSizes}
            />
          </div>
        </Stack>
      </Card>

      <Card>
        <Stack gap="sm">
          <h3 style={{ margin: 0 }}>CalendarScheduler (C6.6 kickoff)</h3>
          <div className="consumer-c6__calendar-tools">
            <Button variant={calendarView === 'day' ? 'secondary' : 'outline'} onClick={() => setCalendarView('day')}>Day</Button>
            <Button variant={calendarView === 'week' ? 'secondary' : 'outline'} onClick={() => setCalendarView('week')}>Week</Button>
            <Button variant={calendarView === 'month' ? 'secondary' : 'outline'} onClick={() => setCalendarView('month')}>Month</Button>
          </div>

          <CalendarScheduler
            view={calendarView}
            events={SCHEDULER_EVENTS}
            selectedDate={calendarDate}
            timezone="UTC"
            onDateChange={setCalendarDate}
            onRangeChange={(range) => setCalendarRange(range)}
            onEventSelect={(event) => setLastSelectedEvent(event.title)}
            onCreateEvent={(date, view) => {
              setCreatedSlots((prev) => [
                `${view}:${date}`,
                ...prev,
              ].slice(0, 4))
            }}
          />

          <p className="consumer-c6__note">
            Active range: {calendarRange ? `${calendarRange.startDate} to ${calendarRange.endDate}` : 'none'}
          </p>
          <p className="consumer-c6__note">Last selected event: {lastSelectedEvent}</p>
          <p className="consumer-c6__note">Created slots: {createdSlots.length > 0 ? createdSlots.join(', ') : 'none'}</p>
        </Stack>
      </Card>

      <Grid columns="auto-fit" minColWidth="22rem" gap="md">
        <Card>
          <Stack gap="sm">
            <h3 style={{ margin: 0 }}>CommandBar + CommandPalette</h3>
            <p className="consumer-c6__note">Use contextual actions and overflow to trigger operational commands.</p>
            <CommandBar
              title="Incident Controls"
              maxVisibleActions={2}
              searchValue={commandSearch}
              onSearchChange={setCommandSearch}
              onSearchSubmit={(query) => {
                setCommandMessage(`Searched actions for "${query || 'all'}"`)
              }}
              onOpenCommandPalette={() => setCommandPaletteOpen(true)}
              actions={[
                {
                  id: 'ack',
                  label: 'Acknowledge',
                  shortcutHint: 'A',
                  onSelect: () => setCommandMessage('Incident acknowledged.'),
                },
                {
                  id: 'assign',
                  label: 'Assign owner',
                  shortcutHint: 'O',
                  onSelect: () => setCommandMessage('Owner assignment started.'),
                },
                {
                  id: 'mute',
                  label: 'Mute alerts',
                  shortcutHint: 'M',
                  onSelect: () => setCommandMessage('Alert channel muted for 30 minutes.'),
                },
              ]}
              overflowActions={[
                {
                  id: 'rollback',
                  label: 'Prepare rollback',
                  onSelect: () => setCommandMessage('Rollback checklist opened.'),
                },
              ]}
            />
            <p className="consumer-c6__note">{commandMessage}</p>

            <CommandPalette
              open={commandPaletteOpen}
              commands={COMMAND_PALETTE_ITEMS}
              onClose={() => setCommandPaletteOpen(false)}
              title="Ops command palette"
            />
          </Stack>
        </Card>

        <Card>
          <Stack gap="sm">
            <h3 style={{ margin: 0 }}>RichTextEditorField</h3>
            <p className="consumer-c6__note">Output contract is explicit and can switch between html and text.</p>
            <div className="consumer-c6__editor-tools">
              <Button variant={editorOutput === 'html' ? 'secondary' : 'outline'} onClick={() => setEditorOutput('html')}>HTML</Button>
              <Button variant={editorOutput === 'text' ? 'secondary' : 'outline'} onClick={() => setEditorOutput('text')}>Text</Button>
            </div>
            <RichTextEditorField
              value={editorValue}
              output={editorOutput}
              maxLength={280}
              onChange={(nextValue) => setEditorValue(nextValue)}
              error={editorValue.trim().length === 0 ? 'Content is required.' : undefined}
              aria-label="Operational note editor"
            />
            <div className="consumer-c6__output">
              <p className="consumer-c6__note">Current output ({editorOutput}):</p>
              <pre>{editorValue}</pre>
            </div>
          </Stack>
        </Card>
      </Grid>

      <Grid columns="auto-fit" minColWidth="22rem" gap="md">
        <Card>
          <Stack gap="sm">
            <h3 style={{ margin: 0 }}>FileManager</h3>
            <p className="consumer-c6__note">Upload, replace, remove, and preview with metadata and version labels.</p>
            <FileManager
              files={fileItems}
              accept=".md,.txt,.pdf,.json"
              maxFileSize={750000}
              maxFiles={6}
              onFilesChange={setFileItems}
              onUpload={(files) => {
                setCommandMessage(`Uploaded ${files.length} file(s).`)
              }}
              onRemove={(item) => {
                setCommandMessage(`Removed ${item.name}.`)
              }}
              onReplace={(item, file) => {
                setCommandMessage(`Replaced ${item.name} with ${file.name}.`)
              }}
              onPreview={(item) => {
                window.alert(`Preview requested for ${item.name}`)
              }}
            />
          </Stack>
        </Card>

        <Card>
          <Stack gap="sm">
            <h3 style={{ margin: 0 }}>AuditTimeline</h3>
            <p className="consumer-c6__note">Chronological grouping, filter controls, and optional event actions.</p>
            <AuditTimeline
              events={INITIAL_AUDIT_EVENTS}
              onFilterChange={(filters) => setAuditFilterText(`${filters.query}|${filters.category}|${filters.actor}`)}
              renderEventActions={(event) => (
                <>
                  <Button variant="outline" size="sm" onClick={() => setCommandMessage(`Viewing ${event.id}`)}>View</Button>
                  <Button variant="text" size="sm" onClick={() => setCommandMessage(`Escalated ${event.id}`)}>Escalate</Button>
                </>
              )}
            />
            <p className="consumer-c6__note">Last filter snapshot: {auditFilterText || 'none'}</p>
          </Stack>
        </Card>
      </Grid>
    </section>
  )
}
