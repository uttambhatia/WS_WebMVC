import { useMemo } from 'react'
import {
  AreaChart,
  BubbleChart,
  Card,
  DonutChart,
  Grid,
  PieChart,
  RadarChart,
  ScatterChart,
  Stack,
  StackedBarChart,
} from 'reactjs-framework'

export function C10DemoPage() {
  const pieData = useMemo(
    () => [
      { label: 'Platform', value: 36 },
      { label: 'Security', value: 24 },
      { label: 'Operations', value: 20 },
      { label: 'Data', value: 12 },
      { label: 'Other', value: 8 },
    ],
    [],
  )

  const donutData = useMemo(
    () => [
      { label: 'Completed', value: 68 },
      { label: 'In progress', value: 22 },
      { label: 'Blocked', value: 10 },
    ],
    [],
  )

  const areaData = useMemo(
    () => [
      { x: 1, y: 12, label: 'W1' },
      { x: 2, y: 18, label: 'W2' },
      { x: 3, y: 16, label: 'W3' },
      { x: 4, y: 24, label: 'W4' },
      { x: 5, y: 22, label: 'W5' },
    ],
    [],
  )

  const scatterData = useMemo(
    () => [
      { x: 10, y: 12, label: 'Case A', group: 'Team A' },
      { x: 15, y: 18, label: 'Case B', group: 'Team A' },
      { x: 18, y: 9, label: 'Case C', group: 'Team B' },
      { x: 24, y: 25, label: 'Case D', group: 'Team B' },
      { x: 29, y: 21, label: 'Case E', group: 'Team C' },
    ],
    [],
  )

  const stackedData = useMemo(
    () => [
      { label: 'Q1', approved: 32, pending: 12, rejected: 5 },
      { label: 'Q2', approved: 41, pending: 10, rejected: 7 },
      { label: 'Q3', approved: 36, pending: 16, rejected: 6 },
      { label: 'Q4', approved: 45, pending: 8, rejected: 4 },
    ],
    [],
  )

  const radarAxes = useMemo(() => ['Quality', 'Speed', 'Coverage', 'Reliability', 'Security'], [])

  const radarData = useMemo(
    () => [
      { label: 'Current', values: [8, 7, 9, 8, 7] },
      { label: 'Target', values: [9, 8, 9, 9, 8] },
    ],
    [],
  )

  const bubbleData = useMemo(
    () => [
      { x: 12, y: 20, r: 8, label: 'Node A', group: 'Core' },
      { x: 20, y: 30, r: 14, label: 'Node B', group: 'Core' },
      { x: 28, y: 17, r: 10, label: 'Node C', group: 'Edge' },
      { x: 36, y: 26, r: 18, label: 'Node D', group: 'Edge' },
      { x: 42, y: 14, r: 7, label: 'Node E', group: 'Ops' },
    ],
    [],
  )

  return (
    <section className="rf-content-panel consumer-page">
      <p className="consumer-page__eyebrow">Component Showcase</p>
      <h2 style={{ margin: 0 }}>Sprint C10 Demo</h2>
      <p className="consumer-page__lead">
        Consumer verification page for advanced C10 chart components.
      </p>

      <Grid columns="auto-fit" minColWidth="20rem" gap="md">
        <Card>
          <Stack gap="sm">
            <h3 style={{ margin: 0 }}>PieChart</h3>
            <PieChart data={pieData} showLabels showLegend showPercentages variant="labeled" />
          </Stack>
        </Card>

        <Card>
          <Stack gap="sm">
            <h3 style={{ margin: 0 }}>DonutChart</h3>
            <DonutChart
              data={donutData}
              centerValue="68%"
              centerLabel="Completed"
              showLegend
            />
          </Stack>
        </Card>

        <Card>
          <Stack gap="sm">
            <h3 style={{ margin: 0 }}>AreaChart</h3>
            <AreaChart data={areaData} showPoints showMedianLine variant="single" />
          </Stack>
        </Card>

        <Card>
          <Stack gap="sm">
            <h3 style={{ margin: 0 }}>ScatterChart</h3>
            <ScatterChart data={scatterData} showTrendline showLabels />
          </Stack>
        </Card>

        <Card>
          <Stack gap="sm">
            <h3 style={{ margin: 0 }}>StackedBarChart</h3>
            <StackedBarChart
              data={stackedData}
              series={['approved', 'pending', 'rejected']}
              orientation="vertical"
              stackMode="absolute"
              showLegend
            />
          </Stack>
        </Card>

        <Card>
          <Stack gap="sm">
            <h3 style={{ margin: 0 }}>RadarChart</h3>
            <RadarChart data={radarData} axes={radarAxes} variant="filled" fillMode showLegend />
          </Stack>
        </Card>

        <Card>
          <Stack gap="sm">
            <h3 style={{ margin: 0 }}>BubbleChart</h3>
            <BubbleChart
              data={bubbleData}
              variant="categorized"
              showLabels
              labelStrategy="top-n"
              topN={3}
            />
          </Stack>
        </Card>
      </Grid>
    </section>
  )
}
