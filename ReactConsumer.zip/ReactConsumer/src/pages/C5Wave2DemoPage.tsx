import { useMemo, useState } from 'react'
import {
  Breadcrumb,
  Button,
  Card,
  DataGrid,
  DateTimePicker,
  Drawer,
  DrawerBody,
  DrawerFooter,
  DrawerHeader,
  Grid,
  Input,
  Stack,
  type TableColumn,
} from 'reactjs-framework'

type IncidentRow = {
  id: string
  name: string
  status: 'Healthy' | 'Warning' | 'Critical'
  owner: string
  updatedAt: string
}

const INCIDENT_ROWS: IncidentRow[] = [
  { id: 'i-1001', name: 'Payments API', status: 'Healthy', owner: 'Platform', updatedAt: '2026-03-14 08:15' },
  { id: 'i-1002', name: 'Risk Scoring', status: 'Warning', owner: 'Analytics', updatedAt: '2026-03-14 08:10' },
  { id: 'i-1003', name: 'Auth Gateway', status: 'Critical', owner: 'Identity', updatedAt: '2026-03-14 07:58' },
  { id: 'i-1004', name: 'Trade Ledger', status: 'Healthy', owner: 'Core', updatedAt: '2026-03-14 07:44' },
  { id: 'i-1005', name: 'Market Feed', status: 'Warning', owner: 'Data', updatedAt: '2026-03-14 07:31' },
  { id: 'i-1006', name: 'Audit Trail', status: 'Healthy', owner: 'Security', updatedAt: '2026-03-14 07:18' },
]

export function C5Wave2DemoPage() {
  const [globalFilter, setGlobalFilter] = useState('')
  const [statusFilter, setStatusFilter] = useState('')
  const [currentPage, setCurrentPage] = useState(1)
  const [selectedDateTime, setSelectedDateTime] = useState('2026-03-14T09:00')
  const [sortBy, setSortBy] = useState<keyof IncidentRow>('name')
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc')
  const [drawerOpen, setDrawerOpen] = useState(false)
  const [visibleRows, setVisibleRows] = useState<IncidentRow[]>([])

  const columns = useMemo<TableColumn<IncidentRow>[]>(() => [
    { key: 'name', header: 'Service', sortable: true },
    { key: 'status', header: 'Status', sortable: true },
    { key: 'owner', header: 'Owner', sortable: true },
    { key: 'updatedAt', header: 'Last update', sortable: true },
  ], [])

  return (
    <section className="rf-content-panel consumer-page">
      <p className="consumer-page__eyebrow">Component Showcase</p>
      <h2 style={{ margin: 0 }}>Sprint C5 Wave 2 Demo</h2>
      <p className="consumer-page__lead">
        Visual review page for DateTimePicker, DataGrid advanced filtering and pinning, and composable Drawer sections.
      </p>

      <Breadcrumb
        items={[
          { label: 'Home', href: '/' },
          { label: 'Components', href: '/c5-wave2-demo' },
          { label: 'C5 Wave 2 Demo' },
        ]}
      />

      <Grid columns="auto-fit" minColWidth="20rem" gap="md">
        <Card>
          <Stack gap="sm">
            <h3 style={{ margin: 0 }}>DateTimePicker</h3>
            <DateTimePicker
              value={selectedDateTime}
              onChange={setSelectedDateTime}
              aria-label="Demo datetime"
            />
            <p className="consumer-wave2__note">Selected value: {selectedDateTime || 'none'}</p>
          </Stack>
        </Card>

        <Card>
          <Stack gap="sm">
            <h3 style={{ margin: 0 }}>Composable Drawer</h3>
            <p className="consumer-wave2__note">Open the drawer to review custom header, body, and footer sections.</p>
            <Button onClick={() => setDrawerOpen(true)}>Open Workflow Drawer</Button>
          </Stack>
        </Card>
      </Grid>

      <Card>
        <Stack gap="md">
          <h3 style={{ margin: 0 }}>DataGrid Advanced</h3>
          <div className="consumer-wave2__filters">
            <Input
              value={globalFilter}
              onChange={(event) => {
                setGlobalFilter(event.target.value)
                setCurrentPage(1)
              }}
              placeholder="Global filter (service, owner, status)"
              aria-label="Global filter"
            />
            <Input
              value={statusFilter}
              onChange={(event) => {
                setStatusFilter(event.target.value)
                setCurrentPage(1)
              }}
              placeholder="Status filter"
              aria-label="Status filter"
            />
          </div>

          <DataGrid
            columns={columns}
            rows={INCIDENT_ROWS}
            page={currentPage}
            pageSize={4}
            sortBy={sortBy}
            sortDirection={sortDirection}
            onSortChange={(key, direction) => {
              setSortBy(key as keyof IncidentRow)
              setSortDirection(direction)
            }}
            globalFilter={globalFilter}
            columnFilters={{ status: statusFilter }}
            pinnedColumnKeys={['name']}
            emptyState="No incidents match the current filters."
            onVisibleRowsChange={(rows) => setVisibleRows(rows)}
          />

          <div className="consumer-wave2__meta">
            <span>Visible rows on current page: {visibleRows.length}</span>
            <span>Pinned column: Service</span>
          </div>

          <div className="consumer-wave2__pager">
            <Button
              variant="outline"
              onClick={() => setCurrentPage((prev) => Math.max(1, prev - 1))}
              disabled={currentPage <= 1}
            >
              Previous
            </Button>
            <span>Page {currentPage}</span>
            <Button
              variant="outline"
              onClick={() => setCurrentPage((prev) => prev + 1)}
              disabled={visibleRows.length < 4}
            >
              Next
            </Button>
          </div>
        </Stack>
      </Card>

      <Drawer open={drawerOpen} onClose={() => setDrawerOpen(false)} composable>
        <DrawerHeader
          title="Incident Workflow"
          actions={(
            <Button variant="text" onClick={() => setDrawerOpen(false)}>
              Close
            </Button>
          )}
        />
        <DrawerBody>
          <Stack gap="sm">
            <p className="consumer-wave2__note">Use composable regions to shape drawer flows without relying on a fixed shell.</p>
            <p className="consumer-wave2__note">This body can host forms, review summaries, or task checklists.</p>
          </Stack>
        </DrawerBody>
        <DrawerFooter>
          <div className="consumer-wave2__drawer-actions">
            <Button variant="outline" onClick={() => setDrawerOpen(false)}>Cancel</Button>
            <Button onClick={() => setDrawerOpen(false)}>Confirm</Button>
          </div>
        </DrawerFooter>
      </Drawer>
    </section>
  )
}
