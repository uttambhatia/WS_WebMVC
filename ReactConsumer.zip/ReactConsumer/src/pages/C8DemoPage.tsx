import { useMemo, useState } from 'react'
import {
  AppShell,
  BarChart,
  BottomSheet,
  Breadcrumb,
  Card,
  Carousel,
  ChatThread,
  CodeBlock,
  ColorPicker,
  CommentBox,
  DataExporter,
  DockLayout,
  DragAndDropList,
  GanttChart,
  Grid,
  HeatMap,
  JsonViewer,
  LightBox,
  LineChart,
  LogViewer,
  MaskedInput,
  MfaChallenge,
  PermissionGate,
  PinInput,
  PivotTable,
  RatingInput,
  SignaturePad,
  Stack,
  Sticky,
  TourSpotlight,
  type DockPanel,
  type DragAndDropListProps,
  type LogEntry,
} from 'reactjs-framework'

const LIGHTBOX_ITEMS = [
  {
    src: 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="640" height="360"><rect width="100%" height="100%" fill="%230b5fa5"/><text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" fill="white" font-size="28">Batch 3 Slide A</text></svg>',
    alt: 'Slide A',
    caption: 'Synthetic lightbox image A',
  },
  {
    src: 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="640" height="360"><rect width="100%" height="100%" fill="%23117a65"/><text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" fill="white" font-size="28">Batch 3 Slide B</text></svg>',
    alt: 'Slide B',
    caption: 'Synthetic lightbox image B',
  },
]

export function C8DemoPage() {
  const [rating, setRating] = useState(3)
  const [pin, setPin] = useState('')
  const [masked, setMasked] = useState('')
  const [pickedColor, setPickedColor] = useState('#0b5fff')
  const [signaturePreview, setSignaturePreview] = useState('')
  const [dndItems, setDndItems] = useState([{ id: 'a', title: 'First' }, { id: 'b', title: 'Second' }, { id: 'c', title: 'Third' }])
  const [tourOpen, setTourOpen] = useState(false)
  const [lightboxOpen, setLightboxOpen] = useState(false)
  const [sheetOpen, setSheetOpen] = useState(false)
  const [commentText, setCommentText] = useState('')

  const barData = useMemo(() => [
    { label: 'Mon', value: 8 },
    { label: 'Tue', value: 11 },
    { label: 'Wed', value: 6 },
    { label: 'Thu', value: 14 },
  ], [])

  const lineData = useMemo(() => [
    { label: 'Q1', value: 22 },
    { label: 'Q2', value: 31 },
    { label: 'Q3', value: 28 },
    { label: 'Q4', value: 36 },
  ], [])

  const logEntries = useMemo<LogEntry[]>(() => [
    { id: 'l1', level: 'info', message: 'Startup complete', timestamp: '16:32:01' },
    { id: 'l2', level: 'warn', message: 'Latency threshold reached', timestamp: '16:32:06' },
    { id: 'l3', level: 'error', message: 'Retry failed after 3 attempts', timestamp: '16:32:09' },
  ], [])

  const dockPanels = useMemo<DockPanel[]>(() => [
    { id: 'left-tools', title: 'Navigator', dock: 'left', collapsible: true, content: <span>Project tree</span> },
    { id: 'center-main', title: 'Workspace', dock: 'center', content: <span id="tour-target">Active editor and tabs</span> },
    { id: 'right-info', title: 'Inspector', dock: 'right', collapsible: true, content: <span>Property details</span> },
    { id: 'bottom-console', title: 'Console', dock: 'bottom', collapsible: true, content: <span>Build output stream</span> },
  ], [])

  return (
    <section className="rf-content-panel consumer-page">
      <p className="consumer-page__eyebrow">Component Showcase</p>
      <h2 style={{ margin: 0 }}>Sprint C8 Demo</h2>
      <p className="consumer-page__lead">
        Consumer verification page covering C8 Batch 1-4 components in one place.
      </p>

      <Breadcrumb
        items={[
          { label: 'Home', href: '/' },
          { label: 'Components', href: '/c8-demo' },
          { label: 'C8 Demo' },
        ]}
      />

      <Sticky>
        <Card>
          <strong>C8 sticky context bar</strong>
        </Card>
      </Sticky>

      <Grid columns="auto-fit" minColWidth="18rem" gap="md">
        <Card>
          <Stack gap="sm">
            <h3 style={{ margin: 0 }}>BarChart / LineChart / HeatMap</h3>
            <BarChart data={barData} />
            <LineChart data={lineData} />
            <HeatMap data={[[0, 1, 2, 3], [2, 4, 1, 0], [1, 0, 3, 4]]} />
          </Stack>
        </Card>

        <Card>
          <Stack gap="sm">
            <h3 style={{ margin: 0 }}>Rating / Pin / Masked / Color</h3>
            <RatingInput value={rating} onChange={setRating} />
            <PinInput length={6} value={pin} onChange={setPin} />
            <MaskedInput mask="###-##-####" value={masked} onChange={setMasked} placeholder="___-__-____" />
            <ColorPicker value={pickedColor} onChange={setPickedColor} />
          </Stack>
        </Card>

        <Card>
          <Stack gap="sm">
            <h3 style={{ margin: 0 }}>Signature / MFA / PermissionGate</h3>
            <SignaturePad onChange={setSignaturePreview} />
            <MfaChallenge onSubmit={() => undefined} expiresInSeconds={0} />
            <PermissionGate
              roles={['admin']}
              userRoles={['admin']}
              fallback={<span>Permission denied</span>}
            >
              <span className="consumer-c8__allowed">Permission granted</span>
            </PermissionGate>
            {signaturePreview && <small className="consumer-c8__hint">Signature captured</small>}
          </Stack>
        </Card>
      </Grid>

      <Card>
        <Stack gap="sm">
          <h3 style={{ margin: 0 }}>DataExporter / JsonViewer / CodeBlock</h3>
          <DataExporter
            rows={[{ service: 'Auth', status: 'healthy', incidents: 1 }, { service: 'Payments', status: 'warning', incidents: 3 }]}
          />
          <JsonViewer value={{ rating, pin, masked, pickedColor, commentText }} expandedDepth={2} />
          <CodeBlock
            language="ts"
            showLineNumbers
            code={`const health = { auth: 'healthy', payments: 'warning' }\nconsole.log(health)\n`}
          />
        </Stack>
      </Card>

      <Card>
        <Stack gap="sm">
          <h3 style={{ margin: 0 }}>Batch 2 / 3 Interaction Components</h3>
          <DragAndDropList
            items={dndItems}
            getItemId={(item) => item.id}
            renderItem={(item) => <span>{item.title}</span>}
            onReorder={(next) => setDndItems(next as DragAndDropListProps<{ id: string; title: string }>['items'])}
          />

          <div className="consumer-c8__actions">
            <button type="button" className="rf-btn rf-btn--outline rf-btn--sm" onClick={() => setTourOpen(true)}>Open Tour</button>
            <button type="button" className="rf-btn rf-btn--outline rf-btn--sm" onClick={() => setLightboxOpen(true)}>Open LightBox</button>
            <button type="button" className="rf-btn rf-btn--outline rf-btn--sm" onClick={() => setSheetOpen(true)}>Open BottomSheet</button>
          </div>

          <Carousel>
            {[
              <Card key="one">Slide one content</Card>,
              <Card key="two">Slide two content</Card>,
              <Card key="three">Slide three content</Card>,
            ]}
          </Carousel>

          <ChatThread
            currentUser="me"
            messages={[
              { id: 'm1', author: 'me', text: 'Can we deploy at 17:00?', timestamp: '16:00', read: true },
              { id: 'm2', author: 'ops', text: 'Yes, rollout window confirmed.', timestamp: '16:02', read: false },
            ]}
          />

          <CommentBox
            mentionSuggestions={['alex', 'sam', 'lee']}
            onSubmit={setCommentText}
          />

          <LogViewer entries={logEntries} levelFilter="all" />
        </Stack>
      </Card>

      <Card>
        <Stack gap="sm">
          <h3 style={{ margin: 0 }}>Batch 4 Layout + Timeline + Pivot</h3>
          <DockLayout panels={dockPanels} />
          <GanttChart
            tasks={[
              { id: 'g1', label: 'Design', start: 0, end: 3, progress: 100 },
              { id: 'g2', label: 'Implementation', start: 2, end: 8, progress: 60 },
              { id: 'g3', label: 'Validation', start: 7, end: 10, progress: 20, dependsOn: ['g2'] },
            ]}
          />
          <PivotTable
            data={[
              { team: 'Platform', month: 'Jan', value: 8 },
              { team: 'Platform', month: 'Feb', value: 11 },
              { team: 'Ops', month: 'Jan', value: 5 },
              { team: 'Ops', month: 'Feb', value: 7 },
            ]}
            rowField="team"
            columnField="month"
            valueField="value"
          />
        </Stack>
      </Card>

      <Card>
        <Stack gap="sm">
          <h3 style={{ margin: 0 }}>AppShell composition</h3>
          <div className="consumer-c8__shell-wrap">
            <AppShell>
              <AppShell.Header>Header Slot</AppShell.Header>
              <AppShell.Sidebar>Sidebar Slot</AppShell.Sidebar>
              <AppShell.Content>Content Slot</AppShell.Content>
              <AppShell.Footer>Footer Slot</AppShell.Footer>
            </AppShell>
          </div>
        </Stack>
      </Card>

      <TourSpotlight
        open={tourOpen}
        onClose={() => setTourOpen(false)}
        steps={[
          { title: 'Welcome', description: 'This demo validates C8 overlays.' },
          { title: 'Dock center panel', description: 'Spotlight points to dock workspace.', targetSelector: '#tour-target' },
        ]}
      />

      <LightBox
        open={lightboxOpen}
        onClose={() => setLightboxOpen(false)}
        items={LIGHTBOX_ITEMS}
      />

      <BottomSheet open={sheetOpen} title="Bottom Sheet" onClose={() => setSheetOpen(false)}>
        <p className="consumer-c8__hint">Mobile-style bottom sheet content.</p>
      </BottomSheet>
    </section>
  )
}
