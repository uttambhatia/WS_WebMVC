export function AboutPage() {
  return (
    <section className="rf-content-panel consumer-page consumer-page--narrow">
      <p className="consumer-page__eyebrow">Framework Notes</p>
      <h2>About</h2>
      <p className="consumer-page__lead">The consumer app inherits layout, theming, and navigation behavior from the shared framework while keeping page content application-specific.</p>
      <div className="rf-state-panel rf-state-panel--info">
        <h3 className="rf-state-panel__title">What changed in this pass</h3>
        <p className="rf-state-panel__text">Shared navigation is now more keyboard-friendly, main content has a skip link target, and the app has reusable panel styles for future loading, empty, and error states.</p>
      </div>
    </section>
  )
}
