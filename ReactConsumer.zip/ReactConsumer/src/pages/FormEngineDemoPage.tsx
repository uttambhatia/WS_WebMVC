import { useMemo, useState } from 'react'
import {
  Alert,
  Breadcrumb,
  Card,
  Grid,
  SchemaForm,
  Stack,
  initializeFormEngine,
  type FormSchema,
  type FormValues,
} from 'reactjs-framework'

type DatasetOption = {
  label: string
  value: string
}

const DATASETS_BY_MODEL: Record<string, DatasetOption[]> = {
  'gpt-5.3-codex': [
    { label: 'Customer Support - Gold', value: 'cs-gold' },
    { label: 'Policy QA - Strict', value: 'policy-strict' },
    { label: 'Risk Triage - Balanced', value: 'risk-balanced' },
  ],
  'gpt-5.3-mini': [
    { label: 'Quick Smoke - Lite', value: 'smoke-lite' },
    { label: 'Routing Eval - Fast', value: 'routing-fast' },
    { label: 'Regression Sanity - Mini', value: 'reg-mini' },
  ],
}

const FORM_SCHEMA: FormSchema = {
  id: 'consumer-form-engine-demo',
  title: 'AI Agent Test Configuration',
  rulePolicy: {
    visibility: 'hide-wins',
    required: 'require-wins',
    compute: 'last-wins',
  },
  fields: [
    {
      key: 'scenarioName',
      label: 'Scenario Name',
      type: 'text',
      required: true,
      placeholder: 'Ex: PROD-Refund escalations',
      validators: [
        { name: 'minLength', args: { value: 6 } },
        {
          name: 'prodPrefix',
          stage: 'cross-field',
          dependsOn: ['environment'],
          message: 'For prod environment, scenario name must start with "PROD-".',
        },
      ],
    },
    {
      key: 'environment',
      label: 'Environment',
      type: 'select',
      required: true,
      defaultValue: 'dev',
      options: [
        { label: 'Development', value: 'dev' },
        { label: 'Staging', value: 'staging' },
        { label: 'Production', value: 'prod' },
      ],
    },
    {
      key: 'model',
      label: 'Model',
      type: 'select',
      required: true,
      defaultValue: 'gpt-5.3-codex',
      options: [
        { label: 'gpt-5.3-codex', value: 'gpt-5.3-codex' },
        { label: 'gpt-5.3-mini', value: 'gpt-5.3-mini' },
      ],
    },
    {
      key: 'dataset',
      label: 'Dataset',
      type: 'async-select',
      required: true,
      helpText: 'Changing model invalidates dataset selection and fetches a new option pool.',
      lookup: {
        provider: 'datasets.byModel',
        dependsOn: ['model'],
        minQueryLength: 1,
        invalidateOnDependencyChange: true,
        asyncPolicy: {
          timeoutMs: 1200,
          retry: {
            maxAttempts: 2,
            backoffMs: 120,
          },
        },
      },
      validators: [
        {
          name: 'datasetAllowedForModel',
          stage: 'async',
          dependsOn: ['model'],
          asyncPolicy: {
            timeoutMs: 900,
            retry: {
              maxAttempts: 2,
              backoffMs: 80,
            },
          },
        },
      ],
    },
    {
      key: 'requiresApproval',
      label: 'Require Human Approval',
      type: 'toggle',
      defaultValue: false,
    },
    {
      key: 'approvalReason',
      label: 'Approval Reason',
      type: 'textarea',
      placeholder: 'Why is approval required?',
      rules: [
        {
          kind: 'show',
          when: {
            field: 'requiresApproval',
            eq: true,
          },
        },
        {
          kind: 'require',
          when: {
            field: 'requiresApproval',
            eq: true,
          },
        },
      ],
      validators: [
        { name: 'minLength', args: { value: 12 } },
      ],
    },
    {
      key: 'maxTokens',
      label: 'Max Tokens',
      type: 'number',
      defaultValue: 512,
      validators: [
        { name: 'min', args: { value: 128 } },
        { name: 'max', args: { value: 4096 } },
      ],
      rules: [
        {
          kind: 'compute',
          when: { field: 'model', eq: 'gpt-5.3-mini' },
          value: 256,
        },
      ],
    },
  ],
}

export function FormEngineDemoPage() {
  const [submittedValues, setSubmittedValues] = useState<FormValues | null>(null)

  const formInit = useMemo(
    () =>
      initializeFormEngine({
        schema: FORM_SCHEMA,
        register: (registry) => {
          let lookupFailures = 0

          registry.registerValidator('prodPrefix', (value, _args, context) => {
            const name = typeof value === 'string' ? value.trim() : ''
            const environment = context.values.environment

            if (environment === 'prod' && !name.startsWith('PROD-')) {
              return 'Production scenarios must start with "PROD-".'
            }

            return undefined
          })

          registry.registerValidator('datasetAllowedForModel', async (value, _args, context) => {
            if (!value || typeof value !== 'string') {
              return undefined
            }

            await new Promise<void>((resolve, reject) => {
              const timeoutId = window.setTimeout(resolve, 120)

              function onAbort() {
                window.clearTimeout(timeoutId)
                reject(new DOMException('Aborted', 'AbortError'))
              }

              if (context.signal.aborted) {
                onAbort()
                return
              }

              context.signal.addEventListener('abort', onAbort, { once: true })
            })

            const model = typeof context.values.model === 'string' ? context.values.model : ''
            const allowed = (DATASETS_BY_MODEL[model] ?? []).some((option) => option.value === value)
            if (!allowed) {
              return 'Selected dataset is not valid for the current model.'
            }

            return undefined
          })

          registry.registerLookupProvider('datasets.byModel', async (query, context) => {
            await new Promise<void>((resolve, reject) => {
              const timeoutId = window.setTimeout(resolve, 160)

              function onAbort() {
                window.clearTimeout(timeoutId)
                reject(new DOMException('Aborted', 'AbortError'))
              }

              if (context.signal.aborted) {
                onAbort()
                return
              }

              context.signal.addEventListener('abort', onAbort, { once: true })
            })

            lookupFailures += 1
            if (lookupFailures % 3 === 1) {
              throw new Error('Transient source timeout. Retry policy should recover automatically.')
            }

            const model = typeof context.values.model === 'string' ? context.values.model : ''
            const options = DATASETS_BY_MODEL[model] ?? []
            const normalized = query.trim().toLowerCase()

            return options.filter((option) => option.label.toLowerCase().includes(normalized))
          })
        },
      }),
    [],
  )

  return (
    <section className="rf-content-panel consumer-page consumer-page--narrow">
      <p className="consumer-page__eyebrow">Component Showcase</p>
      <h2 style={{ margin: 0 }}>Form Engine Demo</h2>
      <p className="consumer-page__lead">
        Generic schema-driven Form Engine with dynamic rules, dependency-driven async invalidation,
        retry and timeout policies, plus cross-field and async validator stages.
      </p>

      <Breadcrumb
        items={[
          { label: 'Home', href: '/' },
          { label: 'Components', href: '/form-engine-demo' },
          { label: 'Form Engine Demo' },
        ]}
      />

      {!formInit.success && (
        <Alert variant="error" title="Form initialization failed">
          {formInit.errors.join(' | ')}
        </Alert>
      )}

      {formInit.success && formInit.warnings.length > 0 && (
        <Alert variant="warning" title="Form initialization warnings">
          {formInit.warnings.join(' | ')}
        </Alert>
      )}

      <Grid columns={1} gap="md">
        <Card>
          <Stack gap="md">
            <h3 style={{ margin: 0 }}>Schema Form</h3>
            {formInit.success && formInit.engine && (
              <SchemaForm
                engine={formInit.engine}
                submitLabel="Save Configuration"
                onSubmit={(values) => setSubmittedValues(values)}
              />
            )}
          </Stack>
        </Card>

        <Card>
          <Stack gap="sm">
            <h3 style={{ margin: 0 }}>Submitted Payload</h3>
            <p className="consumer-formengine__hint">
              Submit the form to inspect normalized values emitted by the schema renderer.
            </p>
            <pre className="consumer-formengine__json">
              {JSON.stringify(submittedValues, null, 2) ?? 'null'}
            </pre>
          </Stack>
        </Card>
      </Grid>
    </section>
  )
}
