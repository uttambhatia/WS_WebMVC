import { useMemo, useState } from 'react'
import {
  ActivityFeed,
  ApprovalGate,
  AuditTrailViewer,
  Breadcrumb,
  Button,
  Card,
  DataClassificationBadgeSet,
  DataGridPro,
  DiffViewer,
  FieldLevelPermissionMatrix,
  GlobalSearchPanel,
  Grid,
  InlineCommentThreads,
  InspectorPanel,
  KeyboardShortcutManager,
  PolicyEditor,
  PresenceAvatars,
  QueryBuilder,
  RichTextEditor,
  RuleBuilder,
  SchedulerTimeline,
  SplitViewWorkbench,
  Stack,
  WorkflowStepper,
  type ActivityItem,
  type ApprovalStep,
  type AuditTrailEvent,
  type DataGridProColumn,
  type GlobalSearchResult,
  type InlineComment,
  type KeyboardShortcut,
  type PolicyRule,
  type QueryField,
  type QueryGroup,
  type RuleDefinition,
  type SchedulerTimelineItem,
  type WorkflowStep,
} from 'reactjs-framework'

type GridRow = {
  id: string
  name: string
  status: string
  owner: string
}

const GRID_COLUMNS: Array<DataGridProColumn<GridRow>> = [
  { key: 'name', header: 'Name', width: 220, editable: true, pinned: 'left' },
  { key: 'status', header: 'Status', width: 150, editable: true },
  { key: 'owner', header: 'Owner', width: 180, editable: true },
]

const QUERY_FIELDS: QueryField[] = [
  { id: 'owner', label: 'Owner', type: 'text' },
  { id: 'priority', label: 'Priority', type: 'select', options: ['low', 'medium', 'high'] },
  { id: 'score', label: 'Score', type: 'number' },
]

const WORKFLOW_STEPS: WorkflowStep[] = [
  { id: 'draft', label: 'Draft', description: 'Create request' },
  { id: 'review', label: 'Review', description: 'Peer validation' },
  { id: 'approve', label: 'Approve', description: 'Final approval' },
]

const SEARCH_RESULTS: GlobalSearchResult[] = [
  { id: 'sr-1', title: 'Customer Policy', subtitle: 'Security policy', group: 'Documents', keywords: ['policy', 'security'] },
  { id: 'sr-2', title: 'Quarterly Report', subtitle: 'Operations dashboard', group: 'Reports', keywords: ['ops', 'kpi'] },
  { id: 'sr-3', title: 'Settings Route', subtitle: 'App settings', group: 'Routes', keywords: ['settings', 'configuration'] },
]

const PREVIOUS_APPROVAL_AT = '2026-03-15T09:00:00.000Z'

export function C9DemoPage() {
  const [gridRows, setGridRows] = useState<GridRow[]>([
    { id: 'r-1', name: 'Case Review', status: 'Open', owner: 'Alex' },
    { id: 'r-2', name: 'Risk Assessment', status: 'In Progress', owner: 'Sam' },
    { id: 'r-3', name: 'Approval Packet', status: 'Ready', owner: 'Jordan' },
  ])

  const [query, setQuery] = useState<QueryGroup>({
    id: 'q-root',
    combinator: 'and',
    conditions: [{ id: 'q-1', fieldId: 'priority', operator: 'equals', value: 'high' }],
    groups: [],
  })

  const [rule, setRule] = useState<RuleDefinition>({
    id: 'rule-1',
    name: 'Escalate High Priority',
    enabled: true,
    when: {
      id: 'rw-root',
      combinator: 'and',
      conditions: [{ id: 'rw-1', fieldId: 'priority', operator: 'equals', value: 'high' }],
      groups: [],
    },
    then: [{ id: 'ra-1', type: 'notify', target: 'oncall-team', value: 'Escalation triggered' }],
  })

  const [currentStepId, setCurrentStepId] = useState('draft')
  const [timelineItems, setTimelineItems] = useState<SchedulerTimelineItem[]>([
    { id: 't-1', resourceId: 'res-1', label: 'Planning', start: 9, end: 11 },
    { id: 't-2', resourceId: 'res-2', label: 'Review', start: 12, end: 15 },
  ])
  const [richTextValue, setRichTextValue] = useState('<p>Initial draft content.</p>')

  const [comments, setComments] = useState<InlineComment[]>([
    {
      id: 'c-1',
      anchorId: 'summary',
      author: 'Sam',
      message: 'Please include compliance notes.',
      createdAt: new Date().toISOString(),
    },
  ])

  const [searchQuery, setSearchQuery] = useState('')
  const [inspectorOpen, setInspectorOpen] = useState(true)
  const [lastShortcut, setLastShortcut] = useState('none')

  const [policyRules, setPolicyRules] = useState<PolicyRule[]>([
    { id: 'p-1', role: 'admin', permission: 'records.read', effect: 'allow' },
    { id: 'p-2', role: 'analyst', permission: 'records.write', effect: 'deny' },
  ])

  const [fieldPermissions, setFieldPermissions] = useState<Record<string, Record<string, boolean>>>({
    admin: { ssn: true, amount: true, owner: true },
    analyst: { ssn: false, amount: true, owner: true },
    auditor: { ssn: false, amount: false, owner: true },
  })

  const [approvalSteps, setApprovalSteps] = useState<ApprovalStep[]>([
    { id: 'ap-1', approver: 'Team Lead', approvedAt: PREVIOUS_APPROVAL_AT, notes: 'Looks good.' },
    { id: 'ap-2', approver: 'Risk Owner' },
    { id: 'ap-3', approver: 'Compliance' },
  ])

  const activityItems = useMemo<ActivityItem[]>(() => [
    { id: 'a-1', actor: 'Alex', type: 'create', message: 'Created workflow draft', createdAt: new Date().toISOString() },
    { id: 'a-2', actor: 'Sam', type: 'update', message: 'Updated rule conditions', createdAt: new Date().toISOString() },
    { id: 'a-3', actor: 'Jordan', type: 'review', message: 'Requested clarification', createdAt: new Date().toISOString() },
  ], [])

  const auditEvents = useMemo<AuditTrailEvent[]>(() => [
    { id: 'au-1', actor: 'Alex', action: 'Updated', entity: 'Policy Rule', timestamp: new Date().toISOString(), immutable: true },
    { id: 'au-2', actor: 'Sam', action: 'Viewed', entity: 'Permission Matrix', timestamp: new Date().toISOString() },
  ], [])

  const shortcuts = useMemo<KeyboardShortcut[]>(() => [
    { id: 'ks-1', keys: 'alt+1', description: 'Focus search', handler: () => setLastShortcut('alt+1') },
    { id: 'ks-2', keys: 'alt+2', description: 'Toggle inspector', handler: () => setInspectorOpen((open) => !open) },
  ], [])

  const inspectorSections = useMemo(() => [
    { id: 'sec-1', title: 'Selection', content: <span>Record: Case Review</span> },
    { id: 'sec-2', title: 'Meta', content: <span>Owner: Alex | Status: Open</span> },
  ], [])

  return (
    <section className="rf-content-panel consumer-page">
      <p className="consumer-page__eyebrow">Component Showcase</p>
      <h2 style={{ margin: 0 }}>Sprint C9 Demo</h2>
      <p className="consumer-page__lead">
        Consumer verification page for all C9 components across data authoring, collaboration, power shell, and governance workflows.
      </p>

      <Breadcrumb
        items={[
          { label: 'Home', href: '/' },
          { label: 'Components', href: '/c9-demo' },
          { label: 'C9 Demo' },
        ]}
      />

      <Grid columns="auto-fit" minColWidth="20rem" gap="md">
        <Card>
          <Stack gap="sm">
            <h3 style={{ margin: 0 }}>DataGridPro</h3>
            <DataGridPro
              columns={GRID_COLUMNS}
              rows={gridRows}
              getRowId={(row) => row.id}
              onRowsChange={setGridRows}
              viewportHeight={220}
            />
          </Stack>
        </Card>

        <Card>
          <Stack gap="sm">
            <h3 style={{ margin: 0 }}>QueryBuilder</h3>
            <QueryBuilder fields={QUERY_FIELDS} value={query} onChange={setQuery} />
          </Stack>
        </Card>

        <Card>
          <Stack gap="sm">
            <h3 style={{ margin: 0 }}>RuleBuilder</h3>
            <RuleBuilder fields={QUERY_FIELDS} value={rule} onChange={setRule} />
          </Stack>
        </Card>
      </Grid>

      <Card>
        <Stack gap="sm">
          <h3 style={{ margin: 0 }}>WorkflowStepper + SchedulerTimeline</h3>
          <WorkflowStepper
            steps={WORKFLOW_STEPS}
            currentStepId={currentStepId}
            onStepChange={setCurrentStepId}
          />
          <SchedulerTimeline
            resources={[{ id: 'res-1', label: 'Team A' }, { id: 'res-2', label: 'Team B' }]}
            items={timelineItems}
            onItemsChange={setTimelineItems}
          />
        </Stack>
      </Card>

      <Grid columns="auto-fit" minColWidth="20rem" gap="md">
        <Card>
          <Stack gap="sm">
            <h3 style={{ margin: 0 }}>RichTextEditor + DiffViewer</h3>
            <RichTextEditor value={richTextValue} onChange={setRichTextValue} output="html" />
            <DiffViewer
              before={'Title: Draft\nStatus: In Progress\nOwner: Alex'}
              after={'Title: Draft\nStatus: Ready for Review\nOwner: Alex'}
            />
          </Stack>
        </Card>

        <Card>
          <Stack gap="sm">
            <h3 style={{ margin: 0 }}>InlineCommentThreads + Presence</h3>
            <PresenceAvatars
              users={[
                { id: 'u-1', name: 'Alex Morgan', status: 'online' },
                { id: 'u-2', name: 'Sam Lee', status: 'away' },
                { id: 'u-3', name: 'Jordan Smith', status: 'online' },
                { id: 'u-4', name: 'Priya Das', status: 'offline' },
                { id: 'u-5', name: 'Chris Bell', status: 'online' },
              ]}
              maxVisible={4}
            />
            <InlineCommentThreads
              anchors={[{ id: 'summary', label: 'Summary' }, { id: 'details', label: 'Details' }]}
              comments={comments}
              onAddComment={(comment) => setComments((prev) => [...prev, comment])}
            />
          </Stack>
        </Card>

        <Card>
          <Stack gap="sm">
            <h3 style={{ margin: 0 }}>ActivityFeed</h3>
            <ActivityFeed items={activityItems} />
          </Stack>
        </Card>
      </Grid>

      <Card>
        <Stack gap="sm">
          <h3 style={{ margin: 0 }}>GlobalSearchPanel + SplitViewWorkbench + InspectorPanel</h3>
          <div className="consumer-c9__actions">
            <Button variant="outline" size="sm" onClick={() => setInspectorOpen((open) => !open)}>
              Toggle Inspector
            </Button>
            <span className="consumer-c9__hint">Last shortcut: {lastShortcut}</span>
          </div>

          <SplitViewWorkbench
            left={<GlobalSearchPanel results={SEARCH_RESULTS} query={searchQuery} onQueryChange={setSearchQuery} />}
            right={
              <Stack gap="sm">
                <KeyboardShortcutManager shortcuts={shortcuts} />
                <p className="consumer-c9__hint">Try Alt+1 and Alt+2.</p>
                <InspectorPanel
                  title="Entity Inspector"
                  sections={inspectorSections}
                  open={inspectorOpen}
                  onClose={() => setInspectorOpen(false)}
                />
              </Stack>
            }
          />
        </Stack>
      </Card>

      <Grid columns="auto-fit" minColWidth="20rem" gap="md">
        <Card>
          <Stack gap="sm">
            <h3 style={{ margin: 0 }}>AuditTrailViewer</h3>
            <AuditTrailViewer events={auditEvents} />
          </Stack>
        </Card>

        <Card>
          <Stack gap="sm">
            <h3 style={{ margin: 0 }}>PolicyEditor</h3>
            <PolicyEditor
              value={policyRules}
              onChange={setPolicyRules}
              availableRoles={['admin', 'analyst', 'auditor']}
              availablePermissions={['records.read', 'records.write', 'records.approve']}
            />
          </Stack>
        </Card>

        <Card>
          <Stack gap="sm">
            <h3 style={{ margin: 0 }}>FieldLevelPermissionMatrix</h3>
            <FieldLevelPermissionMatrix
              roles={['admin', 'analyst', 'auditor']}
              fields={['ssn', 'amount', 'owner']}
              value={fieldPermissions}
              onChange={setFieldPermissions}
              inheritedFromRole={{ analyst: 'auditor' }}
            />
          </Stack>
        </Card>
      </Grid>

      <Card>
        <Stack gap="sm">
          <h3 style={{ margin: 0 }}>DataClassificationBadgeSet + ApprovalGate</h3>
          <DataClassificationBadgeSet values={['internal', 'confidential', 'pii']} />
          <ApprovalGate
            steps={approvalSteps}
            onApprove={(stepId, notes) => {
              const now = new Date().toISOString()
              setApprovalSteps((steps) => steps.map((step) => {
                if (step.id !== stepId) return step
                return { ...step, approvedAt: now, notes: notes ?? step.notes }
              }))
            }}
          />
        </Stack>
      </Card>
    </section>
  )
}
