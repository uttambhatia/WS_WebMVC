export function ReportsPage() {
  return (
    <section className="rf-content-panel consumer-page consumer-page--narrow">
      <p className="consumer-page__eyebrow">State Patterns</p>
      <h2>Reports</h2>
      <p className="consumer-page__lead">This page still uses placeholder content, but it now shows the shared state-panel patterns that will support the first async workflow.</p>
      <div className="rf-state-panel rf-state-panel--empty">
        <h3 className="rf-state-panel__title">No reports loaded yet</h3>
        <p className="rf-state-panel__text">The next implementation step should replace this placeholder with loading, success, empty, and retry behavior backed by a real async flow.</p>
      </div>
    </section>
  )
}
