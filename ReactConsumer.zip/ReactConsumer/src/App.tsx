import {
  LayoutProvider,
  LayoutRenderer,
  framework,
  corePlugin,
  initializeFramework,
  type FrameworkConfig,
  type LayoutSlotInjection,
} from 'reactjs-framework'
import { HomePage } from './pages/HomePage'
import { AboutPage } from './pages/AboutPage'
import { ReportsPage } from './pages/ReportsPage'
import { C4DemoPage } from './pages/C4DemoPage'
import { C5Wave2DemoPage } from './pages/C5Wave2DemoPage'
import { C6DemoPage } from './pages/C6DemoPage'
import { C7DemoPage } from './pages/C7DemoPage'
import { C8DemoPage } from './pages/C8DemoPage'
import { C9DemoPage } from './pages/C9DemoPage'
import { C10DemoPage } from './pages/C10DemoPage'
import { C11ShowcasePage } from './pages/C11ShowcasePage'
import { C12ResponsiveDemoPage } from './pages/C12ResponsiveDemoPage'
import { FormEngineDemoPage } from './pages/FormEngineDemoPage'
import { LayoutShowcasePage } from './pages/LayoutShowcasePage'

function MyFooter() {
  return (
    <div style={{ padding: '0.75rem 1rem', borderTop: '1px solid var(--border)', fontSize: '0.75rem', color: 'var(--muted)' }}>
      AI Agent Evals &mdash; Consumer footer slot
    </div>
  )
}

function HeaderActions() {
  return <span className="consumer-slot-chip">Consumer Actions</span>
}

function FocusedInspector() {
  return (
    <div className="consumer-slot-panel">
      <h4>Inspector Slot</h4>
      <p>Context details and validation hints for focused editing flows.</p>
    </div>
  )
}

function ListPane() {
  return (
    <div className="consumer-slot-panel">
      <h4>List Slot</h4>
      <ul className="consumer-slot-list">
        <li>Case-101: Needs review</li>
        <li>Case-204: Approved</li>
        <li>Case-309: Awaiting owner</li>
      </ul>
    </div>
  )
}

function RailTop() {
  return <div className="consumer-slot-chip">Quick Filters</div>
}

function StepProgress() {
  return (
    <div className="consumer-slot-progress" aria-label="Journey progress slot">
      <span className="is-active">Draft</span>
      <span>Review</span>
      <span>Approval</span>
    </div>
  )
}

function StepActions() {
  return (
    <div className="consumer-slot-actions">
      <button type="button" className="rf-btn rf-btn--outline rf-btn--sm">Back</button>
      <button type="button" className="rf-btn rf-btn--primary rf-btn--sm">Continue</button>
    </div>
  )
}

function CommandBarSlot() {
  return (
    <div className="consumer-slot-panel">
      <strong>Command Bar Slot</strong>
      <p>Try search terms like policy, audit, or incident.</p>
    </div>
  )
}

function ResultsSlot() {
  return (
    <div className="consumer-slot-panel">
      <h4>Results Slot</h4>
      <ul className="consumer-slot-list">
        <li>Policy update - 3 matches</li>
        <li>Incident trend - 2 matches</li>
        <li>Route metadata - 5 matches</li>
      </ul>
    </div>
  )
}

function SidePanelSlot() {
  return (
    <div className="consumer-slot-panel">
      <h4>Side Panel Slot</h4>
      <p>Keyboard shortcuts, filters, and task context.</p>
    </div>
  )
}

const slotInjections: LayoutSlotInjection[] = [
  { layoutId: 'sidebar', slotId: 'footerSlot', component: MyFooter },
  { layoutId: 'focused-workspace', slotId: 'headerActionsSlot', component: HeaderActions },
  { layoutId: 'focused-workspace', slotId: 'inspectorSlot', component: FocusedInspector },
  { layoutId: 'list-detail-responsive', slotId: 'headerActionsSlot', component: HeaderActions },
  { layoutId: 'list-detail-responsive', slotId: 'listSlot', component: ListPane },
  { layoutId: 'adaptive-two-pane', slotId: 'headerActionsSlot', component: HeaderActions },
  { layoutId: 'adaptive-two-pane', slotId: 'railTopSlot', component: RailTop },
  { layoutId: 'card-grid-flow', slotId: 'headerActionsSlot', component: HeaderActions },
  { layoutId: 'step-journey', slotId: 'progressSlot', component: StepProgress },
  { layoutId: 'step-journey', slotId: 'actionsSlot', component: StepActions },
  { layoutId: 'command-surface', slotId: 'commandBarSlot', component: CommandBarSlot },
  { layoutId: 'command-surface', slotId: 'resultsSlot', component: ResultsSlot },
  { layoutId: 'command-surface', slotId: 'sidePanelSlot', component: SidePanelSlot },
]

const frameworkConfig: FrameworkConfig = {
  appTitle: 'AI Agent Evals',
  appLogo: (
    <img
      src="/UBS_Logo_Semibold.svg"
      alt="App logo"
      loading="lazy"
    />
  ),
  defaultLayoutId: 'topnav',
  defaultThemeId: 'azure-governance',

  plugins: [corePlugin],

  routes: [
    { path: '/', element: <HomePage />, label: 'Home', order: 1, icon: '🏠' },
    { path: '/about', element: <AboutPage />, label: 'About', order: 2, icon: 'ℹ️', group: 'Info' },
    { path: '/reports', element: <ReportsPage />, label: 'Reports', order: 3, icon: '📊', group: 'Info' },
    { path: '/c4-demo', element: <C4DemoPage />, label: 'C4 Demo', order: 4, icon: '🧪', group: 'Components' },
    { path: '/c5-wave2-demo', element: <C5Wave2DemoPage />, label: 'C5 Wave 2', order: 5, icon: 'W2', group: 'Components' },
    { path: '/c6-demo', element: <C6DemoPage />, label: 'C6 Demo', order: 6, icon: 'C6', group: 'Components' },
    { path: '/c7-demo', element: <C7DemoPage />, label: 'C7 Demo', order: 7, icon: 'C7', group: 'Components' },
    { path: '/c8-demo', element: <C8DemoPage />, label: 'C8 Demo', order: 8, icon: 'C8', group: 'Components' },
    { path: '/c9-demo', element: <C9DemoPage />, label: 'C9 Demo', order: 9, icon: 'C9', group: 'Components' },
    { path: '/c10-demo', element: <C10DemoPage />, label: 'C10 Demo', order: 10, icon: 'C10', group: 'Components' },
    { path: '/c11-showcase', element: <C11ShowcasePage />, label: 'C11 Showcase', order: 11, icon: 'C11', group: 'Components' },
    { path: '/c12-responsive-demo', element: <C12ResponsiveDemoPage />, label: 'C12 Responsive', order: 12, icon: 'C12', group: 'Components' },
    { path: '/layout-showcase', element: <LayoutShowcasePage />, label: 'Layouts', order: 13, icon: 'LAY', group: 'Components' },
    { path: '/form-engine-demo', element: <FormEngineDemoPage />, label: 'Form Engine', order: 14, icon: '🧩', group: 'Components' },
  ],
  themes: [
    {
      id: 'consumer-ocean',
      label: 'Ocean',
      description: 'Example consumer-defined theme to demonstrate extensibility',
      variables: {
        '--spacing-xs': '0.25rem',
        '--spacing-sm': '0.5rem',
        '--spacing-md': '0.75rem',
        '--spacing-lg': '1rem',
        '--spacing-xl': '1.5rem',
        '--font-size-xs': '0.75rem',
        '--font-size-sm': '0.875rem',
        '--font-size-md': '1rem',
        '--font-size-lg': '1.2rem',
        '--font-size-xl': '2rem',
        '--font-weight-regular': '400',
        '--font-weight-medium': '500',
        '--font-weight-semibold': '600',
        '--font-weight-bold': '700',
        '--surface': '#f0f8ff',
        '--border': '#c4dff6',
        '--text': '#0f3554',
        '--muted': '#436a88',
        '--primary-hover': '#d8ecfb',
        '--bg': '#eaf4fb',
        '--brand': '#0b5fa5',
        '--link': '#0b5fa5',
        '--link-hover': '#084a80',
        '--color-primary': '#0b5fa5',
        '--color-secondary': '#0f3554',
        '--color-success': '#117a65',
        '--color-warning': '#9c6b00',
        '--color-error': '#c44536',
        '--radius-sm': '0.25rem',
        '--radius-md': '0.5rem',
        '--radius-lg': '0.9rem',
        '--radius-pill': '999px',
        '--elevation-sm': '0 8px 20px rgba(11, 95, 165, 0.12)',
        '--elevation-md': '0 16px 40px rgba(11, 95, 165, 0.18)',
      },
    },
  ],
}

const initResult = initializeFramework(framework, frameworkConfig)
if (!initResult.success) {
  console.error('[App] Framework initialization failed:', initResult.errors)
}
if (initResult.warnings.length > 0) {
  console.warn('[App] Framework warnings:', initResult.warnings)
}

export default function App() {
  return (
    <LayoutProvider
      framework={framework}
      appTitle={frameworkConfig.appTitle}
      appLogo={frameworkConfig.appLogo}
      defaultLayoutId={frameworkConfig.defaultLayoutId}
      defaultThemeId={frameworkConfig.defaultThemeId}
      routePolicy={(route) => !route.permissions?.includes('admin')}
      routePolicyContext={{ roles: ['user'] }}
      initialSlotInjections={slotInjections}
    >
      <LayoutRenderer />
    </LayoutProvider>
  )
}
