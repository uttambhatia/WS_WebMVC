param(
    [string]$ResourceGroupName = "rg-reactconsumer-centralus",
    [string]$Location = "centralus",
    [string]$AppServicePlanName = "reactconsumer-plan",
    [ValidateSet("F1", "S1")]
    [string]$AppServicePlanSku = "S1",
    [string]$WebAppName = "",
    [string]$NodeVersion = "20-lts",
    [string]$StartupCommand = "pm2 serve /home/site/wwwroot --no-daemon --spa --port 8080",
    [string]$SubscriptionId = "",
    [switch]$SkipInfra,
    [switch]$SkipBuild,
    [switch]$SkipZipDeploy,
    [switch]$WhatIf
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Invoke-Checked {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Exe,
        [Parameter(Mandatory = $true)]
        [string[]]$Args,
        [Parameter(Mandatory = $true)]
        [string]$Step
    )

    Write-Host "`n==> $Step"
    Write-Host "$Exe $($Args -join ' ')"

    if ($WhatIf) {
        Write-Host "[WhatIf] Skipped command execution"
        return
    }

    & $Exe @Args
    if ($LASTEXITCODE -ne 0) {
        throw "Step failed: $Step"
    }
}

function Assert-Command {
    param([string]$Name)
    if (-not (Get-Command $Name -ErrorAction SilentlyContinue)) {
        throw "Required command not found: $Name"
    }
}

Assert-Command -Name "az"
if (-not $SkipBuild) {
    Assert-Command -Name "npm"
}

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$templatePath = Join-Path $scriptDir "template.json"
$parametersPath = Join-Path $scriptDir "parameters.json"
$projectRoot = Resolve-Path (Join-Path $scriptDir "..\..")
$distPath = Join-Path $projectRoot "dist"
$zipPath = Join-Path $projectRoot "dist.zip"

if (-not (Test-Path $templatePath)) {
    throw "Template file not found: $templatePath"
}
if (-not (Test-Path $parametersPath)) {
    throw "Parameters file not found: $parametersPath"
}

if ([string]::IsNullOrWhiteSpace($WebAppName)) {
    $WebAppName = "reactconsumer-ui-$(Get-Date -Format 'yyMMddHHmmss')"
}

Write-Host "Deployment settings"
Write-Host "- Resource Group: $ResourceGroupName"
Write-Host "- Location: $Location"
Write-Host "- App Service Plan: $AppServicePlanName ($AppServicePlanSku)"
Write-Host "- Web App Name: $WebAppName"
Write-Host "- Project Root: $projectRoot"

if (-not [string]::IsNullOrWhiteSpace($SubscriptionId)) {
    Invoke-Checked -Exe "az" -Args @("account", "set", "--subscription", $SubscriptionId) -Step "Set Azure subscription"
}

if (-not $WhatIf) {
    Invoke-Checked -Exe "az" -Args @("account", "show", "--output", "none") -Step "Validate Azure login"
}

Invoke-Checked -Exe "az" -Args @("group", "create", "--name", $ResourceGroupName, "--location", $Location, "--output", "none") -Step "Create or update resource group"

if (-not $SkipInfra) {
    Invoke-Checked -Exe "az" -Args @(
        "deployment", "group", "create",
        "--resource-group", $ResourceGroupName,
        "--template-file", $templatePath,
        "--parameters", "@$parametersPath",
        "--parameters",
        "location=$Location",
        "appServicePlanName=$AppServicePlanName",
        "appServicePlanSku=$AppServicePlanSku",
        "webAppName=$WebAppName",
        "nodeVersion=$NodeVersion",
        "startupCommand=$StartupCommand",
        "--output", "none"
    ) -Step "Deploy ARM template"
}

if (-not $SkipBuild) {
    Push-Location $projectRoot
    try {
        Invoke-Checked -Exe "npm" -Args @("install") -Step "Install npm dependencies"
        Invoke-Checked -Exe "npm" -Args @("run", "build") -Step "Build React app"

        if (-not (Test-Path $distPath)) {
            throw "Build output not found: $distPath"
        }

        if (Test-Path $zipPath) {
            Write-Host "`n==> Remove old artifact"
            if (-not $WhatIf) {
                Remove-Item $zipPath -Force
            }
        }

        Write-Host "`n==> Create deployment zip"
        $tarCmd = Get-Command tar -ErrorAction SilentlyContinue
        if ($null -ne $tarCmd) {
            Write-Host "tar -a -c -f $zipPath -C $distPath ."
            if (-not $WhatIf) {
                & tar -a -c -f $zipPath -C $distPath .
                if ($LASTEXITCODE -ne 0) {
                    throw "Failed to create zip with tar"
                }
            }
        }
        else {
            Write-Host "Compress-Archive -Path $distPath\* -DestinationPath $zipPath -Force"
            if (-not $WhatIf) {
                Compress-Archive -Path (Join-Path $distPath "*") -DestinationPath $zipPath -Force
            }
        }
    }
    finally {
        Pop-Location
    }
}

if (-not $SkipZipDeploy) {
    if (-not (Test-Path $zipPath) -and -not $WhatIf) {
        throw "Deployment package not found: $zipPath"
    }

    Invoke-Checked -Exe "az" -Args @(
        "webapp", "deploy",
        "--resource-group", $ResourceGroupName,
        "--name", $WebAppName,
        "--src-path", $zipPath,
        "--type", "zip",
        "--clean", "true",
        "--output", "none"
    ) -Step "Zip deploy application"
}

Write-Host "`nDeployment completed successfully"
Write-Host "Web URL: https://$WebAppName.azurewebsites.net"
