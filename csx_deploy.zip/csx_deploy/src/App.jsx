import { useMemo, useState } from "react";

const methods = ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS", "HEAD"];

function createHeaderRow(id) {
  return { id, key: "", value: "" };
}

export default function App() {
  const [endpoint, setEndpoint] = useState("https://jsonplaceholder.typicode.com/posts/1");
  const [method, setMethod] = useState("GET");
  const [headers, setHeaders] = useState([createHeaderRow(1)]);
  const [payload, setPayload] = useState("{\n  \"title\": \"sample\"\n}");
  const [status, setStatus] = useState("Idle");
  const [response, setResponse] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const headersPreview = useMemo(() => {
    const formatted = headers
      .filter((h) => h.key.trim())
      .reduce((acc, h) => ({ ...acc, [h.key.trim()]: h.value }), {});

    return Object.keys(formatted).length ? JSON.stringify(formatted, null, 2) : "{}";
  }, [headers]);

  function updateHeader(id, field, value) {
    setHeaders((prev) => prev.map((h) => (h.id === id ? { ...h, [field]: value } : h)));
  }

  function addHeader() {
    setHeaders((prev) => [...prev, createHeaderRow(Date.now())]);
  }

  function removeHeader(id) {
    setHeaders((prev) => (prev.length === 1 ? prev : prev.filter((h) => h.id !== id)));
  }

  async function sendRequest(event) {
    event.preventDefault();
    setStatus("Sending request...");
    setResponse("");
    setIsLoading(true);

    try {
      const requestHeaders = headers
        .filter((h) => h.key.trim())
        .reduce((acc, h) => ({ ...acc, [h.key.trim()]: h.value }), {});

      const config = {
        method,
        headers: requestHeaders,
      };

      if (!["GET", "HEAD"].includes(method) && payload.trim()) {
        config.body = payload;
      }

      const result = await fetch(endpoint, config);
      const contentType = result.headers.get("content-type") || "";
      const text = await result.text();

      const output = contentType.includes("application/json")
        ? JSON.stringify(JSON.parse(text || "{}"), null, 2)
        : text;

      setStatus(`Completed: ${result.status} ${result.statusText}`);
      setResponse(output || "No response body.");
    } catch (error) {
      setStatus("Request failed");
      setResponse(error instanceof Error ? error.message : "Unknown error");
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <div className="page-shell">
      <div className="orb orb-left" />
      <div className="orb orb-right" />

      <main className="tester-card">
        <header className="title-block">
          <p className="eyebrow">Sample React UI</p>
          <h1>API Tester Form</h1>
          <p>Compose requests with URL, HTTP method, headers, and body payload.</p>
        </header>

        <form className="tester-form" onSubmit={sendRequest}>
          <label>
            Endpoint URL
            <input
              type="url"
              value={endpoint}
              onChange={(e) => setEndpoint(e.target.value)}
              placeholder="https://api.example.com/items"
              required
            />
          </label>

          <label>
            HTTP Method
            <select value={method} onChange={(e) => setMethod(e.target.value)}>
              {methods.map((item) => (
                <option key={item} value={item}>
                  {item}
                </option>
              ))}
            </select>
          </label>

          <section className="headers-group">
            <div className="section-heading">
              <h2>Headers</h2>
              <button type="button" className="ghost-btn" onClick={addHeader}>
                Add Header
              </button>
            </div>

            {headers.map((row) => (
              <div key={row.id} className="header-row">
                <input
                  type="text"
                  placeholder="Header key"
                  value={row.key}
                  onChange={(e) => updateHeader(row.id, "key", e.target.value)}
                />
                <input
                  type="text"
                  placeholder="Header value"
                  value={row.value}
                  onChange={(e) => updateHeader(row.id, "value", e.target.value)}
                />
                <button
                  type="button"
                  className="danger-btn"
                  onClick={() => removeHeader(row.id)}
                  aria-label="Remove header"
                >
                  Remove
                </button>
              </div>
            ))}
          </section>

          <label>
            Body Payload
            <textarea
              rows="8"
              value={payload}
              onChange={(e) => setPayload(e.target.value)}
              placeholder="Raw body payload"
            />
          </label>

          <button type="submit" className="submit-btn" disabled={isLoading}>
            {isLoading ? "Sending..." : "Send Request"}
          </button>
        </form>

        <section className="result-grid">
          <article>
            <h3>Status</h3>
            <pre>{status}</pre>
          </article>
          <article>
            <h3>Headers Preview</h3>
            <pre>{headersPreview}</pre>
          </article>
          <article className="response-block">
            <h3>Response</h3>
            <pre>{response || "Response will appear here."}</pre>
          </article>
        </section>
      </main>
    </div>
  );
}
