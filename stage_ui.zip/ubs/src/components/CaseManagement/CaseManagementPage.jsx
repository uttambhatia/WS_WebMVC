/**
 * CaseManagementPage
 *
 * Shows a searchable/sortable table of all test-case workflows (from /snapshots).
 * Above the table: "New Test Case" button that opens StageFlowPanelDemo in create mode.
 * Per-row actions: View, Resume, Approve — open StageFlowPanelDemo in the right mode.
 *
 * Status logic (from completedUpTo, 0-indexed stage index):
 *   >= 4  → Completed
 *   == 2  → Pending Approval
 *   == 3  → Rejected (if approval stageData flagged) | In Progress
 *   else  → In Progress
 */

import { useCallback, useEffect, useMemo, useState } from "react";
import DataTable from "../DataTable/DataTable";
import StageFlowPanelDemo, {
  buildInitialStageStates,
} from "../StageFlowPanel/StageFlowPanelDemo";
import {
  listSnapshots,
  loadSnapshot,
} from "../../services/testManagementService";
import "./CaseManagementPage.css";

/* ------------------------------------------------------------------ */
/*  Status helpers                                                     */
/* ------------------------------------------------------------------ */
async function resolveStatus(summary) {
  const { completedUpTo } = summary;
  if (completedUpTo >= 4) return "Completed";
  if (completedUpTo === 2) return "Pending Approval";
  if (completedUpTo === 3) {
    try {
      const snap = await loadSnapshot(summary.caseId);
      const ap = snap.stageData?.["approval"];
      const isRejected =
        ap?._sfpStatus === "rejected" || ap?.decision === "reject";
      return isRejected ? "Rejected" : "In Progress";
    } catch {
      return "In Progress";
    }
  }
  return "In Progress";
}

/* ------------------------------------------------------------------ */
/*  Status badge                                                       */
/* ------------------------------------------------------------------ */
const STATUS_META = {
  Completed:          { cls: "cm__badge--green"  },
  "Pending Approval": { cls: "cm__badge--yellow" },
  Rejected:           { cls: "cm__badge--red"    },
  "In Progress":      { cls: "cm__badge--blue"   },
};

function StatusBadge({ status }) {
  const meta = STATUS_META[status] ?? {};
  return (
    <span className={`cm__badge ${meta.cls ?? ""}`}>{status}</span>
  );
}

/* ------------------------------------------------------------------ */
/*  Actions cell                                                       */
/* ------------------------------------------------------------------ */
function ActionButtons({ row, onView, onResume, onApprove }) {
  const { caseId, status } = row;
  return (
    <div className="cm__row-actions">
      {status === "Pending Approval" && (
        <button
          type="button"
          className="cm__act-btn cm__act-btn--primary"
          onClick={() => onApprove(caseId)}
        >
          Approve
        </button>
      )}
      {(status === "In Progress" || status === "Pending Approval") && (
        <button
          type="button"
          className="cm__act-btn cm__act-btn--secondary"
          onClick={() => onResume(caseId)}
        >
          Resume
        </button>
      )}
      <button
        type="button"
        className="cm__act-btn cm__act-btn--ghost"
        onClick={() => onView(caseId)}
      >
        View
      </button>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Back bar shared by create / view / resume sub-views               */
/* ------------------------------------------------------------------ */
function BackBar({ onBack, label }) {
  return (
    <div className="cm__back-bar">
      <button type="button" className="cm__back-btn" onClick={onBack}>
        ← Back to Cases
      </button>
      {label && <span className="cm__back-label">{label}</span>}
    </div>
  );
}

/* ================================================================== */
/*  Page component                                                     */
/* ================================================================== */
export default function CaseManagementPage() {
  /* page mode: list | create | view | resume */
  const [pageMode, setPageMode] = useState("list");

  /* case list */
  const [cases, setCases]         = useState([]);
  const [loadingList, setLoading] = useState(false);
  const [listError, setListError] = useState(null);

  /* active case for view / resume */
  const [activeCase, setActiveCase] = useState(null);
  // { caseId, completedUpTo, initialStageStates }

  /* ---- Load case list ---- */
  const loadCases = useCallback(async () => {
    setLoading(true);
    setListError(null);
    try {
      const summaries = await listSnapshots();
      const enriched = await Promise.all(
        summaries.map(async (s) => ({
          caseId:       s.caseId,
          completedUpTo: s.completedUpTo,
          status:       await resolveStatus(s),
        }))
      );
      setCases(enriched);
    } catch {
      setListError("Could not load cases. Check the API connection.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadCases();
  }, [loadCases]);

  /* ---- Action handlers ---- */
  const handleView = useCallback(async (caseId) => {
    try {
      const snap = await loadSnapshot(caseId);
      setActiveCase({
        caseId,
        completedUpTo: snap.completedUpTo ?? -1,
        initialStageStates: buildInitialStageStates(snap.stageData),
      });
      setPageMode("view");
    } catch {
      alert(`Could not load snapshot for case: ${caseId}`);
    }
  }, []);

  const handleResume = useCallback(async (caseId) => {
    try {
      const snap = await loadSnapshot(caseId);
      setActiveCase({
        caseId,
        completedUpTo: snap.completedUpTo ?? -1,
        initialStageStates: buildInitialStageStates(snap.stageData),
      });
      setPageMode("resume");
    } catch {
      alert(`Could not load snapshot for case: ${caseId}`);
    }
  }, []);

  /* Approve navigates straight to approval stage via resume */
  const handleApprove = handleResume;

  const handleBack = useCallback(() => {
    setPageMode("list");
    setActiveCase(null);
    loadCases(); // refresh after possible changes
  }, [loadCases]);

  /* ---- Column definitions ---- */
  const columns = useMemo(
    () => [
      { key: "caseId",  label: "Case Id", width: "35%", sortable: true },
      {
        key: "status",
        label: "Status",
        width: "25%",
        render: (v) => <StatusBadge status={v} />,
      },
      {
        key: "actions",
        label: "Actions",
        width: "40%",
        render: (_, row) => (
          <ActionButtons
            row={row}
            onView={handleView}
            onResume={handleResume}
            onApprove={handleApprove}
          />
        ),
      },
    ],
    [handleView, handleResume, handleApprove]
  );

  /* ================================================================ */
  /*  Sub-views                                                        */
  /* ================================================================ */

  if (pageMode === "create") {
    return (
      <div className="cm">
        <BackBar onBack={handleBack} label="New Test Case" />
        <StageFlowPanelDemo mode="create" onSaved={loadCases} />
      </div>
    );
  }

  if (pageMode === "view" && activeCase) {
    return (
      <div className="cm">
        <BackBar
          onBack={handleBack}
          label={
            <>
              Viewing case: <strong>{activeCase.caseId}</strong>
            </>
          }
        />
        <StageFlowPanelDemo
          mode="view"
          initialCaseId={activeCase.caseId}
          initialStageStates={activeCase.initialStageStates}
        />
      </div>
    );
  }

  if (pageMode === "resume" && activeCase) {
    return (
      <div className="cm">
        <BackBar
          onBack={handleBack}
          label={
            <>
              Resuming case: <strong>{activeCase.caseId}</strong>
            </>
          }
        />
        <StageFlowPanelDemo
          mode="resume"
          initialCaseId={activeCase.caseId}
          initialCompletedUpTo={activeCase.completedUpTo}
          initialStageStates={activeCase.initialStageStates}
          onSaved={loadCases}
        />
      </div>
    );
  }

  /* ================================================================ */
  /*  List view (default)                                              */
  /* ================================================================ */
  return (
    <div className="cm">
      {/* Header */}
      <div className="cm__header">
        <div>
          <h2 className="cm__title">Case Management</h2>
          <p className="cm__subtitle">
            View, resume, and approve test-case workflows.
          </p>
        </div>
        <button
          type="button"
          className="cm__btn cm__btn--new"
          onClick={() => setPageMode("create")}
        >
          + New Test Case
        </button>
      </div>

      {/* Error */}
      {listError && <p className="cm__message cm__message--error">{listError}</p>}

      {/* Loading */}
      {loadingList && !listError && (
        <p className="cm__message">Loading cases…</p>
      )}

      {/* Table */}
      {!loadingList && !listError && (
        <>
          <div className="cm__toolbar">
            <span className="cm__count">
              {cases.length} case{cases.length !== 1 ? "s" : ""}
            </span>
            <button
              type="button"
              className="cm__refresh-btn"
              onClick={loadCases}
              title="Refresh list"
            >
              ↺ Refresh
            </button>
          </div>

          <DataTable
            columns={columns}
            data={cases}
            pageSize={10}
            pageSizeOptions={[5, 10, 25, 50]}
            sortableColumns={["caseId", "status"]}
            searchableColumns={["caseId", "status"]}
            paginationPlacement="top"
          />
        </>
      )}
    </div>
  );
}
