﻿/**
 * StageFlowPanelDemo.jsx
 *
 * Demonstrates StageFlowPanel wired with five real-world stages:
 *   1. Case ID Creation
 *   2. Upload Requirement Document
 *   3. Validation
 *   4. Approval
 *   5. Test Generation
 *
 * Each form component:
 *   - Uses forwardRef + useImperativeHandle to expose { validate(), submit() }
 *   - Receives serviceData / stageStatus / errorMessage / onSubmitStart/Success/Error
 */

import { forwardRef, useCallback, useRef } from "react";
import StageFlowPanel from "./StageFlowPanel";
import CaseIdFormPanel from "../forms/CaseIdFormPanel/CaseIdFormPanel";
import UploadDocFormPanel from "../forms/UploadDocFormPanel/UploadDocFormPanel";
import ValidationFormPanel from "../forms/ValidationFormPanel/ValidationFormPanel";
import ApprovalFormPanel from "../forms/ApprovalFormPanel/ApprovalFormPanel";
import TestGenFormPanel from "../forms/TestGenFormPanel/TestGenFormPanel";
import {
  createCaseId,
  fetchCaseIdList,
  getTaskId,
  uploadDocument,
  uploadGitlabIssue,
  completeTask,
  fetchTaskVariables,
  approveOrReject,
  fetchTestCases,
  exportTestCases,
  saveStageSnapshot,
} from "../../services/testManagementService";

/* ------------------------------------------------------------------ */
/*  Stage SVG Icons                                                    */
/* ------------------------------------------------------------------ */
function CaseIdIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"
      strokeLinecap="round" strokeLinejoin="round">
      <rect x="3" y="5" width="18" height="14" rx="2" />
      <path d="M8 5V3m8 2V3" />
      <path d="M7 10h5m-5 4h10" />
    </svg>
  );
}

function UploadDocIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"
      strokeLinecap="round" strokeLinejoin="round">
      <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
      <polyline points="14 2 14 8 20 8" />
      <line x1="12" y1="18" x2="12" y2="12" />
      <polyline points="9 15 12 12 15 15" />
    </svg>
  );
}

function ValidationIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"
      strokeLinecap="round" strokeLinejoin="round">
      <path d="M12 2L3 7v5c0 5.25 3.75 10.15 9 11.34C17.25 22.15 21 17.25 21 12V7z" />
      <polyline points="9 12 11 14 15 10" />
    </svg>
  );
}

function ApprovalIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"
      strokeLinecap="round" strokeLinejoin="round">
      <path d="M14 9V5a3 3 0 0 0-6 0v4H5a1 1 0 0 0-1 1v9a1 1 0 0 0 1 1h14
               a1 1 0 0 0 1-1V10a1 1 0 0 0-1-1h-3z" />
      <polyline points="9 13 11 15 15 11" />
    </svg>
  );
}

function TestGenIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"
      strokeLinecap="round" strokeLinejoin="round">
      <polyline points="16 18 22 12 16 6" />
      <polyline points="8 6 2 12 8 18" />
      <line x1="12" y1="2" x2="12" y2="22" />
    </svg>
  );
}

/* ================================================================== */
/*  BPMN Process Task IDs — update these to match your process def   */
/* ================================================================== */
const PROCESS_TASK = {
  UPLOAD_DOC:  "ProcessTask_UploadDoc",   // TODO: replace with actual BPMN task id
  VALIDATION:  "ProcessTask_Validation",  // TODO: replace with actual BPMN task id
  TEST_GEN:    "ProcessTask_TestGen",     // TODO: replace with actual BPMN task id
};

/* ================================================================== */
/*  Response mappers — normalise raw API shapes to UI contracts       */
/*  Keep all backend-to-UI field mapping here, never in form panels.  */
/* ================================================================== */

/**
 * Stage 3 — Validation
 * Maps raw fetchTaskVariables response → ValidationFormPanel contract.
 *
 * UI contract shape:
 *   taskId              {string|null}
 *   document            {string|null}   uploaded document name / filename
 *   quality_percentage  {string|null}
 *   rating              {string|null}
 *   rating_explanation  {string|null}
 *   action_items        {Array<{ requirementId, missingFields[], recommendation[] }>}
 *   user_story_criteria {Array<{ criterion, criterionMeets, explanation, recommendation }>}
 *   summary_report      {Array<{ requirementId, mandatoryFieldItems }>}
 *
 * Source JSON path (validation.json / getVariables response):
 *   agentResponse.questions[0].reason.payload.task.result
 *     .details[0]  → per-document data
 *     .summary_report.details[]  → summary rows
 */
function mapValidationData(raw, taskId) {
  // Traverse nested response to the result node
  const result   = raw?.agentResponse?.questions?.[0]?.reason?.payload?.task?.result ?? {};
  const detail   = Array.isArray(result.details) ? result.details[0] : {};
  const req      = detail?.requirement ?? {};
  const qRating  = req?.quality_rating ?? {};
  const summaryDetails = Array.isArray(result.summary_report?.details)
    ? result.summary_report.details
    : [];

  // action_items — from requirements[]: requirement_id, missing_fields[], hitl_actions[]
  const action_items = Array.isArray(req.requirements)
    ? req.requirements.map((r) => ({
        requirementId: r.requirement_id  ?? null,
        missingFields: Array.isArray(r.missing_fields) ? r.missing_fields : [],
        recommendation: Array.isArray(r.hitl_actions)  ? r.hitl_actions  : [],
      }))
    : [];

  // user_story_criteria — from user_story_validation[]: criterion, meets, explanation, hitl_action
  const user_story_criteria = Array.isArray(req.user_story_validation)
    ? req.user_story_validation.map((u) => ({
        criterion:      u.criterion   ?? null,
        criterionMeets: u.meets       ?? null,
        explanation:    u.explanation ?? null,
        recommendation: u.hitl_action ?? null,
      }))
    : [];

  // summary_report — from summary_report.details[]: requirement_id, mandatory_fields_status
  const summary_report = summaryDetails.map((s) => ({
    requirementId:       s.requirement_id          ?? null,
    mandatoryFieldItems: s.mandatory_fields_status ?? null,
  }));

  return {
    taskId,
    document:           detail?.filename                   ?? null,
    quality_percentage: qRating?.quality_rating            ?? null,
    rating:             qRating?.quality_comment           ?? null,
    rating_explanation: qRating?.quality_rating_explanation ?? null,
    action_items,
    user_story_criteria,
    summary_report,
  };
}

/**
 * Stage 5 — Test Generation
 * Maps raw fetchTestCases (testgeneration.json) response → TestGenFormPanel contract.
 *
 * Source JSON path:
 *   testGenerationResult.details[0].test_cases[]
 *     .testCaseId, .requirementId, .testDescription
 *     .preConditions[]          → preconditions[]
 *     .testSteps[].action       → testStepAction[]
 *
 * UI contract shape:
 *   taskId     {string|null}
 *   testcases  {Array<{ testCaseId, requirementId, testDescription,
 *                       preconditions, testStepAction }>}
 */
function mapTestGenData(raw, taskId) {
  const details = raw?.testGenerationResult?.details ?? [];
  const allCases = details.flatMap((d) =>
    Array.isArray(d.test_cases) ? d.test_cases : []
  );

  const testcases = allCases.map((tc) => ({
    testCaseId:      tc.testCaseId      ?? null,
    requirementId:   tc.requirementId   ?? null,
    testDescription: tc.testDescription ?? null,
    preconditions:   Array.isArray(tc.preConditions)
      ? tc.preConditions
      : [],
    testStepAction:  Array.isArray(tc.testSteps)
      ? tc.testSteps.map((s) => s.action ?? "").filter(Boolean)
      : [],
  }));

  return { taskId, testcases };
}

/* ================================================================== */
/*  Stage entry services — each fetches its own taskId from caseId   */
/* ================================================================== */

/**
 * Stage 2 — Upload Doc: fetch taskId for the upload BPMN task.
 */
async function getTaskIdService({ "case-id": caseId }) {
  const taskId = await getTaskId(caseId, PROCESS_TASK.UPLOAD_DOC);
  return taskId;
}

/**
 * Stage 3 — Validation: fetch variables then map to UI contract.
 */
async function fetchVariablesService({ "case-id": caseId }) {
  const taskId = await getTaskId(caseId, PROCESS_TASK.VALIDATION);
  const raw    = await fetchTaskVariables(taskId);
  return mapValidationData(raw, taskId);
}

/**
 * Stage 5 — Test Generation: fetch test cases then map to UI contract.
 */
async function fetchTestCasesService({ "case-id": caseId }) {
  const taskId = await getTaskId(caseId, PROCESS_TASK.TEST_GEN);
  const raw    = await fetchTestCases(taskId);
  return mapTestGenData(raw, taskId);
}

/* ================================================================== */
/*  forwardRef wrappers â€” bind init-time props to form panels         */
/* ================================================================== */

const CaseIdStageForm = forwardRef(function CaseIdStageForm(props, ref) {
  return (
    <CaseIdFormPanel
      ref={ref}
      {...props}
      title="Case ID Creation"
      fetchService={fetchCaseIdList}
      createService={createCaseId}
    />
  );
});

const UploadDocStageForm = forwardRef(function UploadDocStageForm(props, ref) {
  return (
    <UploadDocFormPanel
      ref={ref}
      {...props}
      title="Upload Requirement Document"
      gitlabService={uploadGitlabIssue}
      documentService={uploadDocument}
      completeService={completeTask}
    />
  );
});

const ValidationStageForm = forwardRef(function ValidationStageForm(props, ref) {
  return (
    <ValidationFormPanel
      ref={ref}
      {...props}
      title="Validation"
    />
  );
});

const ApprovalStageForm = forwardRef(function ApprovalStageForm(props, ref) {
  return (
    <ApprovalFormPanel
      ref={ref}
      {...props}
      title="Approval"
      approveService={(taskId) => approveOrReject(taskId, "approve")}
      rejectService={(taskId) => approveOrReject(taskId, "reject")}
      maxLength={500}
    />
  );
});

const TestGenStageForm = forwardRef(function TestGenStageForm(props, ref) {
  return (
    <TestGenFormPanel
      ref={ref}
      {...props}
      title="Test Case Generation"
      exportService={(taskId) => exportTestCases(taskId)}
    />
  );
});

/* ================================================================== */
/*  Stage definitions â€” real form panels wired with real services     */
/* ================================================================== */
const STAGES = [
  {
    id:                 "case-id",
    name:               "Case ID",
    icon:               <CaseIdIcon />,
    component:          CaseIdStageForm,
    showReloadOnFailure: true,
  },
  {
    id:                 "upload-doc",
    name:               "Upload Document",
    icon:               <UploadDocIcon />,
    service:            getTaskIdService,
    component:          UploadDocStageForm,
    showReloadOnFailure: true,
  },
  {
    id:                 "validation",
    name:               "Validation",
    icon:               <ValidationIcon />,
    service:            fetchVariablesService,
    component:          ValidationStageForm,
    showReloadOnFailure: true,
  },
  {
    id:                 "approval",
    name:               "Approval",
    icon:               <ApprovalIcon />,
    component:          ApprovalStageForm,
    showReloadOnFailure: false,
  },
  {
    id:                 "test-gen",
    name:               "Test Generation",
    icon:               <TestGenIcon />,
    service:            fetchTestCasesService,
    autoSubmit:         true,
    component:          TestGenStageForm,
    showReloadOnFailure: true,
  },
];

/* ================================================================== */
/* ------------------------------------------------------------------ */
/*  Snapshot helpers                                                   */
/* ------------------------------------------------------------------ */
/**
 * When saving a rejected stage, embed _sfpStatus so the status can be
 * faithfully restored when the snapshot is loaded later.
 * For non-object serviceData (e.g. plain taskId string) or non-rejected
 * stages there is nothing to embed — we return the original data as-is.
 */
function withStatus(serviceData, completedStatus) {
  if (completedStatus === "rejected" && serviceData !== null && typeof serviceData === "object") {
    return { ...serviceData, _sfpStatus: "rejected" };
  }
  return serviceData;
}

/**
 * Rebuild initialStageStates from a snapshot's stageData map.
 * Strips the internal _sfpStatus metadata key before setting serviceData,
 * and applies a backward-compatible fallback for older snapshots that never
 * stored _sfpStatus (checks decision === "reject" on approval data).
 */
export function buildInitialStageStates(stageData) {
  const initial = {};
  for (const [stageId, rawData] of Object.entries(stageData ?? {})) {
    const status =
      rawData?._sfpStatus ??
      (rawData?.decision === "reject" ? "rejected" : "success");
    let data = rawData;
    if (rawData && typeof rawData === "object" && "_sfpStatus" in rawData) {
      const { _sfpStatus: _ignored, ...rest } = rawData;
      data = rest;
    }
    initial[stageId] = { status, serviceData: data };
  }
  return initial;
}

/* ================================================================== */
/*  StageFlowPanelDemo                                                 */
/*  mode="create"  — start a brand-new workflow                        */
/*  mode="view"    — read-only snapshot view                           */
/*  mode="resume"  — resume an in-progress workflow                    */
/* ================================================================== */
export default function StageFlowPanelDemo({
  mode                = "create",
  initialCaseId       = null,
  initialCompletedUpTo = -1,
  initialStageStates  = null,
  onSaved             = null,     // called after each successful snapshot save
}) {
  const activeCaseIdRef   = useRef(mode !== "create" ? initialCaseId : null);
  const completedUpToRef  = useRef(mode !== "create" ? initialCompletedUpTo : -1);
  const stageDataRef      = useRef({});

  const handleStageComplete = useCallback(
    (stageId, serviceData, stageIndex, completedStatus) => {
      const caseId = activeCaseIdRef.current;
      if (!caseId) return;

      const dataToSave = withStatus(serviceData, completedStatus);
      stageDataRef.current[stageId] = dataToSave;
      if (stageIndex > completedUpToRef.current) completedUpToRef.current = stageIndex;

      saveStageSnapshot(caseId, stageId, dataToSave, completedUpToRef.current)
        .then(() => onSaved?.())
        .catch(console.error);
    },
    [onSaved]
  );

  /* Captures the caseId when stage 0 (case-id) finishes during creation */
  const handleStageCompleteWithCaseId = useCallback(
    (stageId, serviceData, stageIndex, completedStatus) => {
      if (stageId === "case-id" && serviceData) {
        activeCaseIdRef.current  = serviceData;
        completedUpToRef.current = -1;
        stageDataRef.current     = {};
      }
      handleStageComplete(stageId, serviceData, stageIndex, completedStatus);
    },
    [handleStageComplete]
  );

  if (mode === "view") {
    return (
      <StageFlowPanel
        key={`view-${initialCaseId}`}
        stages={STAGES}
        viewMode
        initialStageStates={initialStageStates}
      />
    );
  }

  if (mode === "resume") {
    return (
      <StageFlowPanel
        key={`resume-${initialCaseId}`}
        stages={STAGES}
        resumeMode
        initialStageStates={initialStageStates}
        onStageComplete={handleStageComplete}
      />
    );
  }

  // create mode (default)
  return (
    <StageFlowPanel
      key="active"
      stages={STAGES}
      showReloadOnFailure={false}
      onStageComplete={handleStageCompleteWithCaseId}
      lockCompletedStages={true}
    />
  );
}
