/**
 * DataTable — responsive sortable, filterable, paginated data table.
 *
 * Props:
 *   columns            {Array<{key: string, label: string, width?: string, truncate?: number, verticalAlign?: string}>}  Column definitions.
 *                        width:         optional percentage width, e.g. "20%". Omit to let the browser size automatically.
 *                        truncate:      max character length before showing "more…" / "less…" toggle. Only applies to plain-text cells (no render fn).
 *                        verticalAlign: CSS vertical-align value for all cells in this column, e.g. "top".
 *   data               {Array<Object>}                        Row data (client mode).
 *   pageSize           {number}                               Rows per page (default: 10).
 *   pageSizeOptions    {number[]}                             Enables a per-page selector with these choices. Omit or pass [] to disable (default: disabled).
 *   sortableColumns    {string[]}                             Keys of sortable columns.
 *   searchableColumns  {string[]}                             Keys of searchable columns.
 *   serverSide         {boolean}                              Enable server-side mode.
 *   service            {async fn(params) → {data, total}}    Required when serverSide=true.
 *   downloadExcel      {boolean}                              Show Excel download button.
 *   loading            {boolean}                              External loading override.
 *   paginationPlacement {"top"|"bottom"|"both"}              Where to render the pagination bar (default: "bottom").
 *   className          {string}
 *
 * Server-side params shape:
 *   { page: number, pageSize: number,
 *     sort: Array<{key, dir: 'asc'|'desc'}>,
 *     filters: Object<key, string> }
 */

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import * as XLSX from "xlsx";
import "./DataTable.css";

/* ---- Icons ---- */
function DownloadIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 14 14" fill="none" aria-hidden="true">
      <path d="M7 2v7m0 0-3-3m3 3 3-3M2 11h10" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  );
}

function ChevronLeftIcon() {
  return (
    <svg className="dt__page-arrow" viewBox="0 0 14 14" fill="none" aria-hidden="true">
      <path d="M9 11 5 7l4-4" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  );
}

function ChevronRightIcon() {
  return (
    <svg className="dt__page-arrow" viewBox="0 0 14 14" fill="none" aria-hidden="true">
      <path d="M5 3l4 4-4 4" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  );
}

function SpinnerIcon({ className }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <circle cx="12" cy="12" r="9" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeDasharray="42 14"/>
    </svg>
  );
}

/* ---- Sort icon ---- */
function SortIcon({ dir }) {
  return (
    <span className="dt__sort-icon" aria-hidden="true">
      <span className={`dt__sort-arrow dt__sort-arrow--up${dir === "asc" ? " dt__sort-arrow--active" : ""}`} />
      <span className={`dt__sort-arrow dt__sort-arrow--down${dir === "desc" ? " dt__sort-arrow--active" : ""}`} />
    </span>
  );
}

/* ---- Truncated text cell ---- */
function TruncatedText({ value, limit }) {
  const [expanded, setExpanded] = useState(false);
  const text = value == null ? "" : String(value);
  if (text.length <= limit) return <>{text}</>;
  return expanded ? (
    <>{text}{" "}<button type="button" className="dt__toggle-text" onClick={() => setExpanded(false)}>less...</button></>
  ) : (
    <>{text.slice(0, limit).trimEnd()}&hellip;{" "}<button type="button" className="dt__toggle-text" onClick={() => setExpanded(true)}>more...</button></>
  );
}

/* ---- Helpers ---- */
function cellValue(row, key) {
  const v = row[key];
  if (v === null || v === undefined) return "";
  if (Array.isArray(v)) return v.join(", ");
  return String(v);
}

function applyClientFilters(data, filters) {
  return data.filter((row) =>
    Object.entries(filters).every(([key, term]) => {
      if (!term) return true;
      return cellValue(row, key).toLowerCase().includes(term.toLowerCase());
    })
  );
}

function applyClientSort(data, sort) {
  if (!sort.length) return data;
  return [...data].sort((a, b) => {
    for (const { key, dir } of sort) {
      const av = cellValue(a, key).toLowerCase();
      const bv = cellValue(b, key).toLowerCase();
      const cmp = av < bv ? -1 : av > bv ? 1 : 0;
      if (cmp !== 0) return dir === "asc" ? cmp : -cmp;
    }
    return 0;
  });
}

function downloadAsExcel(rows, columns, filename = "export") {
  const header = columns.map((c) => c.label);
  const body = rows.map((row) =>
    columns.map((c) => {
      const v = row[c.key];
      if (v === null || v === undefined) return "";
      if (Array.isArray(v)) return v.join(", ");
      return v;
    })
  );
  const ws = XLSX.utils.aoa_to_sheet([header, ...body]);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Data");
  XLSX.writeFile(wb, `${filename}.xlsx`);
}

/* ---- Component ---- */
export default function DataTable({
  columns = [],
  data = [],
  pageSize: defaultPageSize = 10,
  pageSizeOptions = [],
  sortableColumns = [],
  searchableColumns = [],
  serverSide = false,
  service,
  downloadExcel = false,
  loading: externalLoading = false,
  paginationPlacement = "bottom",
  className = "",
}) {
  const [filters, setFilters] = useState({});
  const [sort, setSort] = useState([]); // [{key, dir}]
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(defaultPageSize);

  // Server-side state
  const [serverData, setServerData] = useState([]);
  const [serverTotal, setServerTotal] = useState(0);
  const [serverLoading, setServerLoading] = useState(false);
  const abortRef = useRef(null);

  /* ---- Server-side fetch ---- */
  const fetchServerData = useCallback(async () => {
    if (!serverSide || !service) return;
    abortRef.current?.();
    let cancelled = false;
    abortRef.current = () => { cancelled = true; };

    setServerLoading(true);
    try {
      const params = { page, pageSize, sort, filters };
      const result = await service(params);
      if (!cancelled) {
        setServerData(Array.isArray(result?.data) ? result.data : []);
        setServerTotal(typeof result?.total === "number" ? result.total : 0);
      }
    } catch (_) {
      if (!cancelled) { setServerData([]); setServerTotal(0); }
    } finally {
      if (!cancelled) setServerLoading(false);
    }
  }, [serverSide, service, page, pageSize, sort, filters]);

  useEffect(() => {
    if (serverSide) fetchServerData();
  }, [fetchServerData, serverSide]);

  /* Reset page when filters/sort/pageSize change */
  useEffect(() => { setPage(1); }, [filters, sort, pageSize]);

  /* Sync pageSize when defaultPageSize prop changes */
  useEffect(() => { setPageSize(defaultPageSize); }, [defaultPageSize]);

  /* ---- Client-side derived data ---- */
  const clientFiltered = useMemo(() => {
    if (serverSide) return serverData;
    return applyClientFilters(data, filters);
  }, [serverSide, data, serverData, filters]);

  const clientSorted = useMemo(() => {
    if (serverSide) return clientFiltered;
    return applyClientSort(clientFiltered, sort);
  }, [serverSide, clientFiltered, sort]);

  const totalRows = serverSide ? serverTotal : clientSorted.length;
  const totalPages = Math.max(1, Math.ceil(totalRows / pageSize));

  const pageRows = useMemo(() => {
    if (serverSide) return clientFiltered; // server already paged
    const start = (page - 1) * pageSize;
    return clientSorted.slice(start, start + pageSize);
  }, [serverSide, clientFiltered, clientSorted, page, pageSize]);

  /* ---- Sort toggle ---- */
  const toggleSort = (key) => {
    if (!sortableColumns.includes(key)) return;
    setSort((prev) => {
      const existing = prev.find((s) => s.key === key);
      if (!existing) return [...prev, { key, dir: "asc" }];
      if (existing.dir === "asc") return prev.map((s) => s.key === key ? { key, dir: "desc" } : s);
      return prev.filter((s) => s.key !== key);
    });
  };

  const getSortDir = (key) => sort.find((s) => s.key === key)?.dir;

  /* ---- Filter change ---- */
  const setFilter = (key, val) =>
    setFilters((prev) => ({ ...prev, [key]: val }));

  /* ---- Excel download ---- */
  const handleDownload = () => {
    const rows = serverSide ? clientFiltered : clientSorted;
    downloadAsExcel(rows, columns);
  };

  const isLoading = externalLoading || serverLoading;
  const hasSearchRow = searchableColumns.length > 0;
  const hasPageSizeSelector = pageSizeOptions.length > 1;

  const paginationBar = !isLoading && totalRows > 0 ? (
    <div className="dt__pagination">
      <button
        type="button"
        className="dt__page-btn"
        onClick={() => setPage((p) => Math.max(1, p - 1))}
        disabled={page === 1}
        aria-label="Previous page"
      >
        <ChevronLeftIcon />
        Prev
      </button>

      <span className="dt__page-info">
        Page {page} of {totalPages}
        <span style={{ margin: "0 6px", color: "var(--ubs-c-text-faint)" }}>·</span>
        {totalRows} record{totalRows !== 1 ? "s" : ""}
      </span>

      {hasPageSizeSelector && (
        <label className="dt__page-size-label">
          Rows
          <select
            className="dt__page-size-select"
            value={pageSize}
            onChange={(e) => setPageSize(Number(e.target.value))}
            aria-label="Rows per page"
          >
            {pageSizeOptions.map((n) => (
              <option key={n} value={n}>{n}</option>
            ))}
          </select>
        </label>
      )}

      <button
        type="button"
        className="dt__page-btn"
        onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
        disabled={page === totalPages}
        aria-label="Next page"
      >
        Next
        <ChevronRightIcon />
      </button>
    </div>
  ) : null;

  const showTop    = paginationPlacement === "top"  || paginationPlacement === "both";
  const showBottom = paginationPlacement === "bottom" || paginationPlacement === "both";

  return (
    <div className={`dt${className ? ` ${className}` : ""}`}>
      {/* Toolbar */}
      {downloadExcel && (
        <div className="dt__toolbar">
          <button
            type="button"
            className="dt__btn"
            onClick={handleDownload}
            disabled={isLoading || totalRows === 0}
            title="Download as Excel"
          >
            <DownloadIcon />
            Download Excel
          </button>
        </div>
      )}

      {showTop && paginationBar}
      <div className="dt__wrap">
        {isLoading ? (
          <div className="dt__loading">
            <SpinnerIcon className="dt__spinner" />
            Loading…
          </div>
        ) : (
          <table className="dt__table" role="grid">
            {columns.some((c) => c.width) && (
              <colgroup>
                {columns.map((col) => (
                  <col key={col.key} style={col.width ? { width: col.width } : undefined} />
                ))}
              </colgroup>
            )}
            <thead className="dt__thead">
              {/* Header row */}
              <tr>
                {columns.map((col) => {
                  const sortable = sortableColumns.includes(col.key);
                  const dir = getSortDir(col.key);
                  return (
                    <th
                      key={col.key}
                      className={`dt__th${sortable ? " dt__th--sortable" : ""}`}
                      scope="col"
                      onClick={sortable ? () => toggleSort(col.key) : undefined}
                      aria-sort={dir ? (dir === "asc" ? "ascending" : "descending") : undefined}
                      tabIndex={sortable ? 0 : undefined}
                      onKeyDown={sortable ? (e) => { if (e.key === "Enter") toggleSort(col.key); } : undefined}
                    >
                      <span className="dt__th-inner">
                        {col.label}
                        {sortable && <SortIcon dir={dir} />}
                      </span>
                    </th>
                  );
                })}
              </tr>

              {/* Search row */}
              {hasSearchRow && (
                <tr className="dt__search-row">
                  {columns.map((col) => (
                    <th key={col.key} className="dt__th" scope="col">
                      {searchableColumns.includes(col.key) ? (
                        <input
                          type="text"
                          className="dt__search-input"
                          placeholder={`Filter ${col.label}…`}
                          value={filters[col.key] ?? ""}
                          onChange={(e) => setFilter(col.key, e.target.value)}
                          aria-label={`Filter by ${col.label}`}
                        />
                      ) : null}
                    </th>
                  ))}
                </tr>
              )}
            </thead>

            <tbody className="dt__tbody">
              {pageRows.length === 0 ? (
                <tr>
                  <td colSpan={columns.length} className="dt__empty">
                    No records found.
                  </td>
                </tr>
              ) : (
                pageRows.map((row, ri) => (
                  <tr key={ri}>
                    {columns.map((col) => (
                      <td key={col.key} className="dt__td"
                        style={col.verticalAlign ? { verticalAlign: col.verticalAlign } : undefined}>
                        {col.render
                          ? col.render(row[col.key], row)
                          : col.truncate
                            ? <TruncatedText value={row[col.key]} limit={col.truncate} />
                            : (row[col.key] ?? "—")}
                      </td>
                    ))}
                  </tr>
                ))
              )}
            </tbody>
          </table>
        )}
      </div>

      {showBottom && paginationBar}
    </div>
  );
}
