package com.ubs.testmanagement.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Handles test management case-level operations.
 *
 * Endpoint 1  : POST /app/EO7/api/testmanagement-case/start             – create new case id
 * Endpoint 1.1: POST /app/EO7/api/testmanagement-case/list              – fetch list of case ids
 * Endpoint 2  : GET  /app/EO7/api/testmanagement-case/{caseId}/task     – get task id
 * Endpoint S1 : PUT  /app/EO7/api/testmanagement-case/{caseId}/snapshot – save stage data
 * Endpoint S2 : GET  /app/EO7/api/testmanagement-case/{caseId}/snapshot – load snapshot
 * Endpoint S3 : GET  /app/EO7/api/testmanagement-case/snapshots         – list all snapshots
 */
@RestController
@RequestMapping("/app/EO7/api/testmanagement-case")
public class TestManagementCaseController {

    // --- Mutable seed list so newly created IDs are included in /list ------
    private static final List<String> SEED_CASE_IDS = new ArrayList<>(
            Arrays.asList("TST-C001-A1B2C3D4", "TST-C001-E5F6G7H8"));

    /**
     * In-memory snapshot store.
     * Structure: caseId → { stageId → stageData, "_completedUpTo" → int }
     * The reserved "_completedUpTo" key is stripped before returning stageData to clients.
     */
    static final Map<String, Map<String, Object>> SNAPSHOTS = new ConcurrentHashMap<>();

    // -----------------------------------------------------------------------
    // Endpoint 1 – Create new test case id
    // POST /app/EO7/api/testmanagement-case/start?caseDefinitionKey=TST-C001
    // -----------------------------------------------------------------------
    @PostMapping("/start")
    public ResponseEntity<String> createCase(
            @RequestParam(name = "caseDefinitionKey", defaultValue = "TST-C001") String caseDefinitionKey) {

        String newCaseId = caseDefinitionKey + "-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        SEED_CASE_IDS.add(newCaseId);
        return ResponseEntity.ok(newCaseId);
    }

    // -----------------------------------------------------------------------
    // Endpoint 1.1 – Fetch list of test case ids
    // POST /app/EO7/api/testmanagement-case/list?caseDefinitionKey=TST-C001
    // -----------------------------------------------------------------------
    @PostMapping("/list")
    public ResponseEntity<List<String>> listCases(
            @RequestParam(name = "caseDefinitionKey", defaultValue = "TST-C001") String caseDefinitionKey) {

        return ResponseEntity.ok(SEED_CASE_IDS);
    }

    // -----------------------------------------------------------------------
    // Endpoint 2 – Create and get a task id for a given case
    // GET /app/EO7/api/testmanagement-case/{caseId}/task?processTaskId=ProcessTask_3
    // -----------------------------------------------------------------------
    @GetMapping("/{caseId}/task")
    public ResponseEntity<String> getTaskId(
            @PathVariable String caseId,
            @RequestParam(name = "processTaskId", defaultValue = "ProcessTask_3") String processTaskId) {

        String taskId = processTaskId + "-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        return ResponseEntity.ok(taskId);
    }

    // -----------------------------------------------------------------------
    // Endpoint S1 – Save one stage's form data for a case
    // PUT /app/EO7/api/testmanagement-case/{caseId}/snapshot
    // Body: { "stageId": "upload", "data": { ... }, "completedUpTo": 2 }
    // -----------------------------------------------------------------------
    @PutMapping("/{caseId}/snapshot")
    public ResponseEntity<String> saveSnapshot(
            @PathVariable String caseId,
            @RequestBody Map<String, Object> body) {

        String stageId = (String) body.get("stageId");
        Object data = body.get("data");
        if (stageId == null || data == null) {
            return ResponseEntity.badRequest().body("Failed: 'stageId' and 'data' are required.");
        }
        Map<String, Object> snapshot = SNAPSHOTS.computeIfAbsent(caseId, k -> new ConcurrentHashMap<>());
        snapshot.put(stageId, data);
        Object completedUpTo = body.get("completedUpTo");
        if (completedUpTo != null) {
            snapshot.put("_completedUpTo", completedUpTo);
        }
        return ResponseEntity.ok("Saved");
    }

    // -----------------------------------------------------------------------
    // Endpoint S2 – Load all saved stage data for a case
    // GET /app/EO7/api/testmanagement-case/{caseId}/snapshot
    // Returns: { "caseId": "...", "completedUpTo": 2, "stageData": { stageId: data, ... } }
    // -----------------------------------------------------------------------
    @GetMapping("/{caseId}/snapshot")
    public ResponseEntity<Map<String, Object>> loadSnapshot(@PathVariable String caseId) {
        Map<String, Object> snapshot = SNAPSHOTS.get(caseId);
        if (snapshot == null) {
            return ResponseEntity.notFound().build();
        }
        Map<String, Object> stageData = new HashMap<>(snapshot);
        Object completedUpTo = stageData.remove("_completedUpTo");

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("caseId", caseId);
        result.put("completedUpTo", completedUpTo != null ? completedUpTo : 0);
        result.put("stageData", stageData);
        return ResponseEntity.ok(result);
    }

    // -----------------------------------------------------------------------
    // Endpoint S3 – List all case IDs that have saved snapshots
    // GET /app/EO7/api/testmanagement-case/snapshots
    // Returns: [ { "caseId": "...", "completedUpTo": 2 }, ... ]
    // -----------------------------------------------------------------------
    @GetMapping("/snapshots")
    public ResponseEntity<List<Map<String, Object>>> listSnapshots() {
        List<Map<String, Object>> result = new ArrayList<>();
        for (Map.Entry<String, Map<String, Object>> entry : SNAPSHOTS.entrySet()) {
            Map<String, Object> item = new LinkedHashMap<>();
            item.put("caseId", entry.getKey());
            Object completedUpTo = entry.getValue().get("_completedUpTo");
            item.put("completedUpTo", completedUpTo != null ? completedUpTo : 0);
            result.add(item);
        }
        return ResponseEntity.ok(result);
    }
}
