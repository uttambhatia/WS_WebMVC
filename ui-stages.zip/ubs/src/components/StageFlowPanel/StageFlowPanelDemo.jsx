﻿/**
 * StageFlowPanelDemo.jsx
 *
 * Demonstrates StageFlowPanel wired with five real-world stages:
 *   1. Case ID Creation
 *   2. Upload Requirement Document
 *   3. Validation
 *   4. Approval
 *   5. Test Generation
 *
 * Each form component:
 *   - Uses forwardRef + useImperativeHandle to expose { validate(), submit() }
 *   - Receives serviceData / stageStatus / errorMessage / onSubmitStart/Success/Error
 */

import { forwardRef } from "react";
import StageFlowPanel from "./StageFlowPanel";
import CaseIdFormPanel from "../forms/CaseIdFormPanel/CaseIdFormPanel";
import UploadDocFormPanel from "../forms/UploadDocFormPanel/UploadDocFormPanel";
import ValidationFormPanel from "../forms/ValidationFormPanel/ValidationFormPanel";
import ApprovalFormPanel from "../forms/ApprovalFormPanel/ApprovalFormPanel";
import TestGenFormPanel from "../forms/TestGenFormPanel/TestGenFormPanel";
import {
  createCaseId,
  fetchCaseIdList,
  getTaskId,
  uploadDocument,
  uploadGitlabIssue,
  completeTask,
  fetchTaskVariables,
  approveOrReject,
  fetchTestCases,
  exportTestCases,
} from "../../services/testManagementService";

/* ------------------------------------------------------------------ */
/*  Stage SVG Icons                                                    */
/* ------------------------------------------------------------------ */
function CaseIdIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"
      strokeLinecap="round" strokeLinejoin="round">
      <rect x="3" y="5" width="18" height="14" rx="2" />
      <path d="M8 5V3m8 2V3" />
      <path d="M7 10h5m-5 4h10" />
    </svg>
  );
}

function UploadDocIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"
      strokeLinecap="round" strokeLinejoin="round">
      <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
      <polyline points="14 2 14 8 20 8" />
      <line x1="12" y1="18" x2="12" y2="12" />
      <polyline points="9 15 12 12 15 15" />
    </svg>
  );
}

function ValidationIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"
      strokeLinecap="round" strokeLinejoin="round">
      <path d="M12 2L3 7v5c0 5.25 3.75 10.15 9 11.34C17.25 22.15 21 17.25 21 12V7z" />
      <polyline points="9 12 11 14 15 10" />
    </svg>
  );
}

function ApprovalIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"
      strokeLinecap="round" strokeLinejoin="round">
      <path d="M14 9V5a3 3 0 0 0-6 0v4H5a1 1 0 0 0-1 1v9a1 1 0 0 0 1 1h14
               a1 1 0 0 0 1-1V10a1 1 0 0 0-1-1h-3z" />
      <polyline points="9 13 11 15 15 11" />
    </svg>
  );
}

function TestGenIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"
      strokeLinecap="round" strokeLinejoin="round">
      <polyline points="16 18 22 12 16 6" />
      <polyline points="8 6 2 12 8 18" />
      <line x1="12" y1="2" x2="12" y2="22" />
    </svg>
  );
}

/* TODO: remove this delay helper before production */
const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

/* ================================================================== */
/*  BPMN Process Task IDs — update these to match your process def   */
/* ================================================================== */
const PROCESS_TASK = {
  UPLOAD_DOC:  "ProcessTask_UploadDoc",   // TODO: replace with actual BPMN task id
  VALIDATION:  "ProcessTask_Validation",  // TODO: replace with actual BPMN task id
  TEST_GEN:    "ProcessTask_TestGen",     // TODO: replace with actual BPMN task id
};

/* ================================================================== */
/*  Stage entry services — each fetches its own taskId from caseId   */
/* ================================================================== */

/**
 * Stage 2 — Upload Doc: fetch taskId for the upload BPMN task.
 */
async function getTaskIdService({ "case-id": caseId }) {
  await delay(30000); // TODO: remove before production
  const taskId = await getTaskId(caseId, PROCESS_TASK.UPLOAD_DOC);
  return taskId;
}

/**
 * Stage 3 — Validation: fetch own taskId, then fetch validation variables.
 * Merges taskId into result so the form can display it.
 */
async function fetchVariablesService({ "case-id": caseId }) {
  await delay(30000); // TODO: remove before production
  const taskId = await getTaskId(caseId, PROCESS_TASK.VALIDATION);
  const vars = await fetchTaskVariables(taskId);
  return { ...vars, taskId };
}

/**
 * Stage 5 — Test Generation: fetch own taskId, then fetch test cases.
 * Merges taskId into result so the form can display it.
 */
async function fetchTestCasesService({ "case-id": caseId }) {
  await delay(30000); // TODO: remove before production
  const taskId = await getTaskId(caseId, PROCESS_TASK.TEST_GEN);
  const testcases = await fetchTestCases(taskId);
  return { taskId, testcases };
}

/* ================================================================== */
/*  forwardRef wrappers â€” bind init-time props to form panels         */
/* ================================================================== */

const CaseIdStageForm = forwardRef(function CaseIdStageForm(props, ref) {
  return (
    <CaseIdFormPanel
      ref={ref}
      {...props}
      title="Case ID Creation"
      fetchService={fetchCaseIdList}
      createService={createCaseId}
    />
  );
});

const UploadDocStageForm = forwardRef(function UploadDocStageForm(props, ref) {
  return (
    <UploadDocFormPanel
      ref={ref}
      {...props}
      title="Upload Requirement Document"
      gitlabService={uploadGitlabIssue}
      documentService={uploadDocument}
      completeService={completeTask}
    />
  );
});

const ValidationStageForm = forwardRef(function ValidationStageForm(props, ref) {
  return (
    <ValidationFormPanel
      ref={ref}
      {...props}
      title="Validation"
    />
  );
});

const ApprovalStageForm = forwardRef(function ApprovalStageForm(props, ref) {
  return (
    <ApprovalFormPanel
      ref={ref}
      {...props}
      title="Approval"
      approveService={(taskId) => approveOrReject(taskId, "approve")}
      rejectService={(taskId) => approveOrReject(taskId, "reject")}
      maxLength={500}
    />
  );
});

const TestGenStageForm = forwardRef(function TestGenStageForm(props, ref) {
  return (
    <TestGenFormPanel
      ref={ref}
      {...props}
      title="Test Case Generation"
      exportService={(taskId) => exportTestCases(taskId)}
    />
  );
});

/* ================================================================== */
/*  Stage definitions â€” real form panels wired with real services     */
/* ================================================================== */
const STAGES = [
  {
    id:                 "case-id",
    name:               "Case ID",
    icon:               <CaseIdIcon />,
    component:          CaseIdStageForm,
    showReloadOnFailure: true,
  },
  {
    id:                 "upload-doc",
    name:               "Upload Document",
    icon:               <UploadDocIcon />,
    service:            getTaskIdService,
    component:          UploadDocStageForm,
    showReloadOnFailure: true,
  },
  {
    id:                 "validation",
    name:               "Validation",
    icon:               <ValidationIcon />,
    service:            fetchVariablesService,
    component:          ValidationStageForm,
    showReloadOnFailure: true,
  },
  {
    id:                 "approval",
    name:               "Approval",
    icon:               <ApprovalIcon />,
    component:          ApprovalStageForm,
    showReloadOnFailure: false,
  },
  {
    id:                 "test-gen",
    name:               "Test Generation",
    icon:               <TestGenIcon />,
    service:            fetchTestCasesService,
    autoSubmit:         true,
    component:          TestGenStageForm,
    showReloadOnFailure: true,
  },
];

/* ================================================================== */
/*  Demo wrapper                                                       */
/* ================================================================== */
export default function StageFlowPanelDemo() {
  return (
    <div style={{ maxWidth: 860, margin: "0 auto" }}>
      <StageFlowPanel stages={STAGES} showReloadOnFailure={false} />
    </div>
  );
}
