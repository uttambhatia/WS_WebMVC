/**
 * UploadDocFormPanel — Stage 2 form: upload via Gitlab URL or file.
 *
 * StageFlowPanel interface: validate() / submit()
 *
 * Initialization props:
 *   title              {string}
 *   gitlabService      {async fn(taskId, url, token) → any}
 *   documentService    {async fn(taskId, file, onProgress) → any}
 *   completeService    {async fn(taskId) → any}   Called after successful upload.
 *
 * serviceData from StageFlowPanel stage service is expected to be the taskId string.
 */

import { forwardRef, useImperativeHandle, useState } from "react";
import FileUploader from "../../FileUploader/FileUploader";
import "../FormPanel.css";

function SpinnerIcon({ className }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <circle cx="12" cy="12" r="9" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeDasharray="42 14"/>
    </svg>
  );
}

const UploadDocFormPanel = forwardRef(function UploadDocFormPanel(
  {
    serviceData,       // taskId string from SFP stage service
    stageStatus,
    onSubmitStart,
    onSubmitSuccess,
    onSubmitError,
    // Wiring-time
    title = "Upload Requirement Document",
    gitlabService,
    documentService,
    completeService,
  },
  ref
) {
  const taskId = serviceData ?? null;

  const [source, setSource] = useState(null); // 'gitlab' | 'document'
  const [gitlabUrl, setGitlabUrl] = useState("");
  const [gitlabToken, setGitlabToken] = useState("");
  const [uploading, setUploading] = useState(false);
  const [status, setStatus] = useState(null);
  const [validationError, setValidationError] = useState(null);

  /* ---- Validation logic ---- */
  const validate = () => {
    if (!source) {
      setValidationError("Please select a source of requirement.");
      return false;
    }
    if (source === "gitlab" && (!gitlabUrl.trim() || !gitlabToken.trim())) {
      setValidationError("Gitlab URL and Gitlab Token are required.");
      return false;
    }
    // document uploads are handled entirely within FileUploader
    setValidationError(null);
    return true;
  };

  /* ---- StageFlowPanel contract ---- */
  useImperativeHandle(ref, () => ({
    validate,
    async submit() {
      // For gitlab, submit triggers the upload; for document the FileUploader
      // handles its own upload — only validate here.
      if (!validate()) return { success: false };
      if (source === "gitlab") {
        return handleGitlabUpload();
      }
      // Document path: FileUploader already uploaded; just signal success.
      onSubmitSuccess?.(taskId);
      return { success: true };
    },
  }));

  /* Gitlab upload handler */
  const handleGitlabUpload = async () => {
    if (!validate() || uploading) return { success: false };
    onSubmitStart?.();
    setUploading(true);
    setStatus(null);
    try {
      await gitlabService?.(taskId, gitlabUrl, gitlabToken);
      await completeService?.(taskId);
      setStatus({ type: "success", message: "Upload completed successfully." });
      onSubmitSuccess?.(taskId);
      return { success: true };
    } catch (err) {
      const msg = err?.response?.data?.message ?? err?.message ?? "Upload failed.";
      setStatus({ type: "error", message: msg });
      onSubmitError?.(msg);
      return { success: false };
    } finally {
      setUploading(false);
    }
  };

  /* Document upload service — passed directly to FileUploader */
  const handleDocumentUpload = async (file) => {
    try {
      await documentService?.(taskId, file, undefined);
      await completeService?.(taskId);
      onSubmitSuccess?.(taskId);
    } catch (err) {
      throw err; // FileUploader shows its own inline error — no duplicate needed
    }
  };

  return (
    <div className="fp">
      {/* Title bar */}
      <div className="fp__titlebar">
        <h2 className="fp__title">{title}</h2>
        {taskId && (
          <span className="fp__task-id">
            Task Id: <strong>{taskId}</strong>
          </span>
        )}
      </div>

      <div className="fp__body">
        {/* Source of requirement */}
        <div className="fp__field">
          <label className="fp__field-label">
            Source of Requirement <span className="fp__required">*</span>
          </label>
          <div className="fp__radio-group" role="radiogroup" aria-label="Source of Requirement">
            <label className="fp__radio-label">
              <input
                type="radio"
                name="source"
                value="gitlab"
                checked={source === "gitlab"}
                onChange={() => { setSource("gitlab"); setValidationError(null); }}
                disabled={uploading}
              />
              Gitlab
            </label>
            <label className="fp__radio-label">
              <input
                type="radio"
                name="source"
                value="document"
                checked={source === "document"}
                onChange={() => { setSource("document"); setValidationError(null); }}
                disabled={uploading}
              />
              Document
            </label>
          </div>
          {validationError && (
            <span className="fp__validation-error" role="alert">{validationError}</span>
          )}
        </div>

        {/* Gitlab branch */}
        {source === "gitlab" && (
          <div className="fp__branch">
            <h3 className="fp__branch-title">Gitlab</h3>
            <div className="fp__row-2">
              <div className="fp__field">
                <label className="fp__field-label">
                  Gitlab URL <span className="fp__required">*</span>
                </label>
                <input
                  type="url"
                  className="fp__input"
                  placeholder="https://gitlab.com/…"
                  value={gitlabUrl}
                  onChange={(e) => setGitlabUrl(e.target.value)}
                  disabled={uploading}
                />
              </div>
              <div className="fp__field">
                <label className="fp__field-label">
                  Gitlab Token <span className="fp__required">*</span>
                </label>
                <input
                  type="password"
                  className="fp__input"
                  placeholder="glpat-…"
                  value={gitlabToken}
                  onChange={(e) => setGitlabToken(e.target.value)}
                  disabled={uploading}
                  autoComplete="off"
                />
              </div>
            </div>
            <div className="fp__form-actions">
              <button
                type="button"
                className="fp__btn fp__btn--primary"
                onClick={handleGitlabUpload}
                disabled={uploading || !taskId || !gitlabUrl.trim() || !gitlabToken.trim()}
              >
                {uploading ? <SpinnerIcon className="fp__spinner" /> : null}
                {uploading ? "Uploading…" : "Upload"}
              </button>
            </div>
          </div>
        )}

        {/* Document branch */}
        {source === "document" && (
          <div className="fp__branch">
            <h3 className="fp__branch-title">Upload Document</h3>
            <div className="fp__field">
              <label className="fp__field-label">
                Upload Requirement Document <span className="fp__required">*</span>
              </label>
              <FileUploader
                multiple={false}
                accept=".pdf,.docx,.doc,.txt,.md"
                service={handleDocumentUpload}
                disabled={uploading || !taskId}
              />
            </div>
          </div>
        )}

        {/* Status */}
        {status && (
          <div className={`fp__status fp__status--${status.type}`} role="alert">
            {status.message}
          </div>
        )}
      </div>
    </div>
  );
});

export default UploadDocFormPanel;
