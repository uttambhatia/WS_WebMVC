/**
 * ValidationFormPanel — Stage 3: read-only validation result viewer.
 *
 * StageFlowPanel interface: validate() / submit()
 * validate() and submit() are auto-success (read-only panel).
 *
 * Data source: serviceData (from stage's fetchTaskVariables service).
 * Falls back to dummy data if service data is not yet available.
 *
 * Initialization props:
 *   title  {string}
 */

import { forwardRef, useImperativeHandle } from "react";
import DataTable from "../../DataTable/DataTable";
import "../FormPanel.css";

/* ---- Dummy / fallback data ---- */
const DUMMY_SUMMARY = {
  document_name: "requirements_v2.docx",
  quality_percentage: "84%",
  rating: "Good",
  rating_explanation: "Most mandatory fields are present. Minor gaps in section 3.",
};

const DUMMY_ACTION_ITEMS = [
  { req_id: "REQ-001", missing_fields: "Priority, Acceptance Criteria", recommendation: "Add priority level and acceptance criteria." },
  { req_id: "REQ-005", missing_fields: "Owner", recommendation: "Assign a requirement owner." },
];

const DUMMY_USER_STORY = [
  { criterion: "User story format", criterion_meets: "Yes", explanation: "Follows 'As a / I want / So that' format.", recommendation: "—" },
  { criterion: "Acceptance criteria present", criterion_meets: "Partial", explanation: "Some stories lack criteria.", recommendation: "Add criteria for REQ-003, REQ-007." },
];

const DUMMY_SUMMARY_REPORT = [
  { req_id: "REQ-001", mandatory_field_items: "Title, Description, Priority, Acceptance Criteria" },
  { req_id: "REQ-002", mandatory_field_items: "Title, Description" },
  { req_id: "REQ-005", mandatory_field_items: "Title, Description, Owner" },
];

const ACTION_COLS    = [{ key: "req_id", label: "Requirement Id" }, { key: "missing_fields", label: "Missing Fields" }, { key: "recommendation", label: "Recommendation" }];
const USER_STORY_COLS = [{ key: "criterion", label: "Criterion" }, { key: "criterion_meets", label: "Criterion Meets" }, { key: "explanation", label: "Explanation" }, { key: "recommendation", label: "Recommendation" }];
const SUMMARY_COLS   = [{ key: "req_id", label: "Requirement Id" }, { key: "mandatory_field_items", label: "Mandatory Field Items" }];

const ValidationFormPanel = forwardRef(function ValidationFormPanel(
  {
    serviceData,
    stageStatus,
    onSubmitStart,
    onSubmitSuccess,
    onSubmitError,
    title = "Validation",
  },
  ref
) {
  /* Extract data — use real service data if present, else dummy */
  const vars = serviceData ?? {};
  const summary = {
    document_name:       vars.document_name       ?? DUMMY_SUMMARY.document_name,
    quality_percentage:  vars.quality_percentage  ?? DUMMY_SUMMARY.quality_percentage,
    rating:              vars.rating              ?? DUMMY_SUMMARY.rating,
    rating_explanation:  vars.rating_explanation  ?? DUMMY_SUMMARY.rating_explanation,
  };
  const actionItems   = Array.isArray(vars.action_items)        ? vars.action_items        : DUMMY_ACTION_ITEMS;
  const userStory     = Array.isArray(vars.user_story_criteria) ? vars.user_story_criteria : DUMMY_USER_STORY;
  const summaryReport = Array.isArray(vars.summary_report)      ? vars.summary_report      : DUMMY_SUMMARY_REPORT;

  const taskId = vars.taskId ?? null;

  /* ---- StageFlowPanel contract ---- */
  useImperativeHandle(ref, () => ({
    validate() { return true; },
    async submit() {
      onSubmitStart?.();
      onSubmitSuccess?.(serviceData);
      return { success: true };
    },
  }));

  const CARDS = [
    { label: "Document",           value: summary.document_name },
    { label: "Quality Percentage", value: summary.quality_percentage },
    { label: "Rating",             value: summary.rating },
    { label: "Rating Explanation", value: summary.rating_explanation },
  ];

  const isReady = stageStatus === "ready" || stageStatus === "success";
  const isLoading = stageStatus === "idle" || stageStatus === "loading";

  return (
    <div className="fp">
      {/* Title bar */}
      <div className="fp__titlebar">
        <h2 className="fp__title">{title}</h2>
        {isReady && taskId && (
          <span className="fp__task-id">
            Task Id: <strong>{taskId}</strong>
          </span>
        )}
      </div>

      {isLoading ? (
        <div className="fp__loading">
          <svg className="fp__loading-spinner" viewBox="0 0 24 24" fill="none" aria-hidden="true">
            <circle cx="12" cy="12" r="9" stroke="currentColor" strokeWidth="2.5"
              strokeLinecap="round" strokeDasharray="42 14" />
          </svg>
          <span>Loading validation results…</span>
        </div>
      ) : !isReady ? null : (
        <div className="fp__body">
          {/* Summary cards */}
          <div className="fp__cards">
            {CARDS.map((c) => (
              <div key={c.label} className="fp__card">
                <span className="fp__card-label">{c.label}</span>
                <span className="fp__card-value">{c.value}</span>
              </div>
            ))}
          </div>

          <hr className="fp__divider" />

          {/* Action Items */}
          <p className="fp__section-title">Action Items</p>
          <DataTable
            columns={ACTION_COLS}
            data={actionItems}
            pageSize={10}
            sortableColumns={["req_id"]}
            searchableColumns={["req_id", "missing_fields"]}
          />

          <hr className="fp__divider" />

          {/* User Story Criteria */}
          <p className="fp__section-title">User Story Criteria</p>
          <DataTable
            columns={USER_STORY_COLS}
            data={userStory}
            pageSize={10}
            sortableColumns={["criterion", "criterion_meets"]}
            searchableColumns={["criterion"]}
          />

          <hr className="fp__divider" />

          {/* Summary Report */}
          <p className="fp__section-title">Summary Report</p>
          <DataTable
            columns={SUMMARY_COLS}
            data={summaryReport}
            pageSize={10}
            sortableColumns={["req_id"]}
            searchableColumns={["req_id"]}
            downloadExcel
          />
        </div>
      )}
    </div>
  );
});

export default ValidationFormPanel;
