/**
 * ApprovalFormPanel — Stage 4: approve or reject with comment.
 *
 * StageFlowPanel interface: validate() / submit()
 *
 * Initialization props:
 *   title           {string}
 *   approveService  {async fn(taskId, text) → any}
 *   rejectService   {async fn(taskId, text) → any}
 *   maxLength       {number}   Textarea character limit (default: 500).
 *
 * serviceData from StageFlowPanel is not used for taskId resolution.
 * taskId is read from stagesContext["validation"].taskId (Stage 3's own task).
 */

import { forwardRef, useImperativeHandle, useRef, useState } from "react";
import ApproveReject from "../../ApproveReject/ApproveReject";
import "../FormPanel.css";

const ApprovalFormPanel = forwardRef(function ApprovalFormPanel(
  {
    serviceData,
    stagesContext,
    stageStatus,
    onSubmitStart,
    onSubmitSuccess,
    onSubmitRejected,
    onSubmitError,
    // Wiring-time
    title = "Approval",
    approveService,
    rejectService,
    maxLength = 500,
  },
  ref
) {
  // taskId always comes from Stage 3 ("validation") which fetches its own taskId
  // and stores it in serviceData. Approval has no own service, so stagesContext is
  // the only reliable source.
  const taskId = stagesContext?.["validation"]?.taskId ?? null;
  const lastActionRef = useRef(null); // 'approve' | 'reject' | null
  const [done, setDone] = useState(false);

  /* ---- Bound service wrappers ----
   * Only perform the API call and return the result.
   * No stage lifecycle callbacks here — ApproveReject handles its own button
   * spinner, and stage transitions (SUCCESS / REJECTED / ERROR) are fired
   * exclusively through the onApprove / onReject props below so they are
   * never called twice and the stage circle never spins on a form action. */
  const boundApprove = approveService
    ? (text) => approveService(taskId, text)
    : undefined;

  const boundReject = rejectService
    ? (text) => rejectService(taskId, text)
    : undefined;

  /* ---- StageFlowPanel contract ---- */
  useImperativeHandle(ref, () => ({
    validate() { return true; },
    async submit() {
      // Submission is triggered by the Approve/Reject buttons inside ApproveReject.
      // If the user already clicked one, we're done.
      if (done) {
        if (lastActionRef.current === "reject") {
          onSubmitRejected?.();
          return { success: true };
        }
        onSubmitSuccess?.(lastActionRef.current);
        return { success: true };
      }
      // Auto-submit not applicable here; user must click a button.
      onSubmitError?.("Please click Approve or Reject to proceed.");
      return { success: false };
    },
  }));

  return (
    <div className="fp">
      {/* Title bar */}
      <div className="fp__titlebar">
        <h2 className="fp__title">{title}</h2>
        {taskId && (
          <span className="fp__task-id">
            Task Id: <strong>{taskId}</strong>
          </span>
        )}
      </div>

      <div className="fp__body">
        <ApproveReject
          approveService={boundApprove}
          rejectService={boundReject}
          maxLength={maxLength}
          placeholder="Add a comment before approving or rejecting (optional)…"
          onApprove={(result) => {
            setDone(true);
            lastActionRef.current = "approve";
            onSubmitSuccess?.(result);
          }}
          onReject={(result) => {
            setDone(true);
            lastActionRef.current = "reject";
            onSubmitRejected?.(result);
          }}
          disabled={done}
        />
      </div>
    </div>
  );
});

export default ApprovalFormPanel;
