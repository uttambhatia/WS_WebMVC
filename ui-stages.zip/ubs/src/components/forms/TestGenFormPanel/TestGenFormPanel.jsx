/**
 * TestGenFormPanel — Stage 5: display test generation results + export.
 *
 * StageFlowPanel interface: validate() / submit()
 * validate() and submit() are auto-success (read-only result panel).
 *
 * Initialization props:
 *   title          {string}
 *   exportService  {async fn(taskId, params) → blob download}  exportTestCases service.
 *
 * serviceData from StageFlowPanel stage service (fetchTestCases):
 *   expected shape: { taskId, testcases: Array<{...}> }
 *   Falls back to dummy data for display.
 */

import { forwardRef, useImperativeHandle, useState } from "react";
import DataTable from "../../DataTable/DataTable";
import "../FormPanel.css";

/* ---- Dummy data ---- */
const DUMMY_TEST_CASES = [
  { test_case_id: "TC-001", req_id: "REQ-001", description: "Verify user login with valid credentials", preconditions: "User account exists", step_action: "Enter valid username and password, click Login" },
  { test_case_id: "TC-002", req_id: "REQ-001", description: "Verify user login fails with invalid password", preconditions: "User account exists", step_action: "Enter valid username and wrong password, click Login" },
  { test_case_id: "TC-003", req_id: "REQ-002", description: "Verify document upload accepts PDF format", preconditions: "User is authenticated", step_action: "Navigate to upload, select a PDF file, click Upload" },
  { test_case_id: "TC-004", req_id: "REQ-002", description: "Verify document upload rejects unsupported format", preconditions: "User is authenticated", step_action: "Select an unsupported file type, click Upload" },
  { test_case_id: "TC-005", req_id: "REQ-003", description: "Verify approval notification sent on approve", preconditions: "Task is in approval stage", step_action: "Click Approve, verify notification sent" },
];

const TC_COLS = [
  { key: "test_case_id",  label: "Test Case Id"       },
  { key: "req_id",        label: "Requirement Id"     },
  { key: "description",   label: "Test Description"   },
  { key: "preconditions", label: "Pre-conditions"     },
  { key: "step_action",   label: "Test Step Action"   },
];

function SpinnerIcon({ className }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <circle cx="12" cy="12" r="9" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeDasharray="42 14"/>
    </svg>
  );
}

function ExportIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 14 14" fill="none" aria-hidden="true">
      <path d="M7 2v7m0 0-3-3m3 3 3-3M2 11h10" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  );
}

const TestGenFormPanel = forwardRef(function TestGenFormPanel(
  {
    serviceData,
    stageStatus,
    onSubmitStart,
    onSubmitSuccess,
    onSubmitError,
    // Wiring-time
    title = "Test Case Generation",
    exportService,
  },
  ref
) {
  const taskId    = serviceData?.taskId ?? (typeof serviceData === "string" ? serviceData : null);
  const testcases = Array.isArray(serviceData?.testcases) ? serviceData.testcases : DUMMY_TEST_CASES;

  /* Export panel state */
  const [exportOpen, setExportOpen]       = useState(false);
  const [exportPath, setExportPath]       = useState("");
  const [exportEmail, setExportEmail]     = useState("");
  const [exportPrereq, setExportPrereq]   = useState("");
  const [exporting, setExporting]         = useState(false);
  const [exportStatus, setExportStatus]   = useState(null);
  const [exportErrors, setExportErrors]   = useState({});

  /* ---- StageFlowPanel contract ---- */
  useImperativeHandle(ref, () => ({
    validate() { return true; },
    async submit() {
      onSubmitStart?.();
      onSubmitSuccess?.(serviceData);
      return { success: true };
    },
  }));

  /* ---- Export ---- */
  const validateExport = () => {
    const errs = {};
    if (!exportPath.trim())  errs.path  = "Test Case Path is required.";
    if (!exportEmail.trim()) errs.email = "Created by Email Id is required.";
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(exportEmail)) errs.email = "Invalid email address.";
    setExportErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleExportClick = () => {
    if (!exportOpen) {
      setExportOpen(true);
      return;
    }
    // "Export Now" clicked
    if (!validateExport()) return;
    setExporting(true);
    setExportStatus(null);
    const params = { path: exportPath, email: exportEmail, prerequisites: exportPrereq };
    (exportService ? exportService(taskId, params) : Promise.resolve())
      .then(() => setExportStatus({ type: "success", message: "Export completed successfully." }))
      .catch((err) => {
        const msg = err?.response?.data?.message ?? err?.message ?? "Export failed.";
        setExportStatus({ type: "error", message: msg });
      })
      .finally(() => setExporting(false));
  };

  const isReady = stageStatus === "ready" || stageStatus === "success";
  const isLoading = stageStatus === "idle" || stageStatus === "loading";

  return (
    <div className="fp">
      {/* Title bar */}
      <div className="fp__titlebar">
        <h2 className="fp__title">{title}</h2>
        {isReady && taskId && (
          <span className="fp__task-id">
            Task Id: <strong>{taskId}</strong>
          </span>
        )}
      </div>

      {isLoading ? (
        <div className="fp__loading">
          <svg className="fp__loading-spinner" viewBox="0 0 24 24" fill="none" aria-hidden="true">
            <circle cx="12" cy="12" r="9" stroke="currentColor" strokeWidth="2.5"
              strokeLinecap="round" strokeDasharray="42 14" />
          </svg>
          <span>Generating test cases…</span>
        </div>
      ) : !isReady ? null : (
        <div className="fp__body">
        {/* Export bar */}
        <div className="fp__export-bar">
          <span className="fp__export-label">Test Generation Result</span>

          {/* Inline fields slide in when export is open */}
          {exportOpen && (
            <div className="fp__export-fields">
              <div className="fp__field" style={{ marginBottom: 0 }}>
                <input
                  type="text"
                  className="fp__input"
                  placeholder="Test Case Path *"
                  value={exportPath}
                  onChange={(e) => setExportPath(e.target.value)}
                  disabled={exporting}
                  aria-label="Test Case Path"
                  style={{ width: 180 }}
                />
                <span className="fp__validation-error" role="alert"
                  aria-hidden={!exportErrors.path}
                  style={{ visibility: exportErrors.path ? "visible" : "hidden" }}>
                  {exportErrors.path || "\u00a0"}
                </span>
              </div>
              <div className="fp__field" style={{ marginBottom: 0 }}>
                <input
                  type="email"
                  className="fp__input"
                  placeholder="Created by Email Id *"
                  value={exportEmail}
                  onChange={(e) => setExportEmail(e.target.value)}
                  disabled={exporting}
                  aria-label="Created by Email Id"
                  style={{ width: 200 }}
                />
                <span className="fp__validation-error" role="alert"
                  aria-hidden={!exportErrors.email}
                  style={{ visibility: exportErrors.email ? "visible" : "hidden" }}>
                  {exportErrors.email || "\u00a0"}
                </span>
              </div>
              <div className="fp__field" style={{ marginBottom: 0 }}>
                <input
                  type="text"
                  className="fp__input"
                  placeholder="Test Case Pre-requisites"
                  value={exportPrereq}
                  onChange={(e) => setExportPrereq(e.target.value)}
                  disabled={exporting}
                  aria-label="Test Case Pre-requisites"
                  style={{ width: 200 }}
                />
                <span className="fp__validation-error" aria-hidden style={{ visibility: "hidden" }}>
                  &nbsp;
                </span>
              </div>
            </div>
          )}

          <button
            type="button"
            className="fp__btn fp__btn--grey"
            onClick={handleExportClick}
            disabled={exporting}
            title={exportOpen ? "Click to export" : "Open export options"}
          >
            {exporting ? (
              <SpinnerIcon className="fp__spinner" />
            ) : (
              <ExportIcon />
            )}
            {exporting ? "Exporting…" : exportOpen ? "Export Now" : "Export"}
          </button>

          {exportOpen && (
            <button
              type="button"
              className="fp__btn fp__btn--ghost"
              onClick={() => {
                setExportOpen(false);
                setExportPath("");
                setExportEmail("");
                setExportPrereq("");
                setExportErrors({});
                setExportStatus(null);
              }}
              disabled={exporting}
              title="Cancel export"
            >
              Cancel
            </button>
          )}
        </div>

        {/* Export status */}
        {exportStatus && (
          <div className={`fp__status fp__status--${exportStatus.type}`} role="alert">
            {exportStatus.message}
          </div>
        )}

        <hr className="fp__divider" />

        {/* Test cases data table */}
        <DataTable
          columns={TC_COLS}
          data={testcases}
          pageSize={10}
          sortableColumns={["test_case_id", "req_id"]}
          searchableColumns={["test_case_id", "req_id", "description"]}
          downloadExcel
        />
      </div>
      )}
    </div>
  );
});

export default TestGenFormPanel;
