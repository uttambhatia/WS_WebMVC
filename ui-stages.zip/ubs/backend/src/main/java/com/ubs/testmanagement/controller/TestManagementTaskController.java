package com.ubs.testmanagement.controller;

import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.*;

/**
 * Handles test management task-level operations.
 *
 * Endpoint 3  : POST /app/EO7/api/testmanagement-task/{taskId}/upload         – upload document
 * Endpoint 3.1: POST /app/EO7/api/testmanagement-task/{taskId}/gitlabIssue   – gitlab upload
 * Endpoint 4  : POST /app/EO7/api/testmanagement-task/{taskId}/complete       – complete task
 * Endpoint 5  : GET  /app/EO7/api/testmanagement-task/{taskId}/variables      – fetch variables
 * Endpoint 6  : GET  /app/EO7/api/testmanagement-task/{taskId}/{action}       – approve / reject
 * Endpoint 7  : GET  /app/EO7/api/testmanagement-task/{taskId}/testcases      – fetch test cases
 * Endpoint 8  : GET  /app/EO7/api/testmanagement-task/{taskId}/export         – export test cases
 */
@RestController
@RequestMapping("/app/EO7/api/testmanagement-task")
public class TestManagementTaskController {

    // -----------------------------------------------------------------------
    // Endpoint 3 – Upload requirement document
    // POST /app/EO7/api/testmanagement-task/{taskId}/upload
    // Body: multipart/form-data  "file"
    // -----------------------------------------------------------------------
    @PostMapping("/{taskId}/upload")
    public ResponseEntity<String> uploadDocument(
            @PathVariable String taskId,
            @RequestParam("file") MultipartFile file) {

        if (file == null || file.isEmpty()) {
            return ResponseEntity.badRequest().body("Failed: No file received.");
        }
        return ResponseEntity.ok("Success");
    }

    // -----------------------------------------------------------------------
    // Endpoint 3.1 – Gitlab upload
    // POST /app/EO7/api/testmanagement-task/{taskId}/gitlabIssue
    //      ?gitlabIssue={url}&gitlabToken={token}
    // -----------------------------------------------------------------------
    @PostMapping("/{taskId}/gitlabIssue")
    public ResponseEntity<String> gitlabUpload(
            @PathVariable String taskId,
            @RequestParam("gitlabIssue") String gitlabIssue,
            @RequestParam("gitlabToken") String gitlabToken) {

        if (gitlabIssue == null || gitlabIssue.isBlank() || gitlabToken == null || gitlabToken.isBlank()) {
            return ResponseEntity.badRequest().body("Failed: Missing gitlab url or token.");
        }
        return ResponseEntity.ok("Success");
    }

    // -----------------------------------------------------------------------
    // Endpoint 4 – Post Upload – Complete task
    // POST /app/EO7/api/testmanagement-task/{taskId}/complete
    // -----------------------------------------------------------------------
    @PostMapping("/{taskId}/complete")
    public ResponseEntity<String> completeTask(@PathVariable String taskId) {
        return ResponseEntity.ok("Success");
    }

    // -----------------------------------------------------------------------
    // Endpoint 5 – Validation – Fetch variables on task
    // GET /app/EO7/api/testmanagement-task/{taskId}/variables
    // -----------------------------------------------------------------------
    @GetMapping("/{taskId}/variables")
    public ResponseEntity<Map<String, Object>> getVariables(@PathVariable String taskId) {

        // --- Action Items ---
        List<Map<String, Object>> actionItems = new ArrayList<>();

        Map<String, Object> actionItem1 = new LinkedHashMap<>();
        actionItem1.put("requirementId", "REQ-001");
        actionItem1.put("missingFields", "Acceptance Criteria");
        actionItem1.put("recommendation", "Add acceptance criteria for each requirement");
        actionItems.add(actionItem1);

        Map<String, Object> actionItem2 = new LinkedHashMap<>();
        actionItem2.put("requirementId", "REQ-002");
        actionItem2.put("missingFields", "Priority Level");
        actionItem2.put("recommendation", "Define priority for each requirement");
        actionItems.add(actionItem2);

        // --- User Story Criteria ---
        List<Map<String, Object>> userStoryCriteria = new ArrayList<>();

        Map<String, Object> criteria1 = new LinkedHashMap<>();
        criteria1.put("criterion", "User Story Format");
        criteria1.put("criterionMeets", true);
        criteria1.put("explanation", "Stories follow As-a / I-want / So-that format");
        criteria1.put("recommendation", "");
        userStoryCriteria.add(criteria1);

        Map<String, Object> criteria2 = new LinkedHashMap<>();
        criteria2.put("criterion", "Acceptance Criteria");
        criteria2.put("criterionMeets", false);
        criteria2.put("explanation", "Acceptance criteria missing in 2 stories");
        criteria2.put("recommendation", "Add acceptance criteria to each user story");
        userStoryCriteria.add(criteria2);

        // --- Summary Report ---
        List<Map<String, Object>> summaryReport = new ArrayList<>();

        Map<String, Object> summary1 = new LinkedHashMap<>();
        summary1.put("requirementId", "REQ-001");
        summary1.put("mandatoryFieldItems", "Priority, Due Date");
        summaryReport.add(summary1);

        Map<String, Object> summary2 = new LinkedHashMap<>();
        summary2.put("requirementId", "REQ-002");
        summary2.put("mandatoryFieldItems", "Acceptance Criteria");
        summaryReport.add(summary2);

        // --- Compose top-level response ---
        Map<String, Object> response = new LinkedHashMap<>();
        response.put("document", "Requirements_v1.docx");
        response.put("quality_percentage", 85);
        response.put("rating", "Good");
        response.put("rating_explanation",
                "The document covers most requirements with minor gaps in acceptance criteria and priority fields.");
        response.put("action_items", actionItems);
        response.put("user_story_criteria", userStoryCriteria);
        response.put("summary_report", summaryReport);

        return ResponseEntity.ok(response);
    }

    // -----------------------------------------------------------------------
    // Endpoint 6 – Approval / Rejection
    // GET /app/EO7/api/testmanagement-task/{taskId}/{action}
    //     where {action} = "approve" | "reject"
    // -----------------------------------------------------------------------
    @GetMapping("/{taskId}/{action}")
    public ResponseEntity<String> approveOrReject(
            @PathVariable String taskId,
            @PathVariable String action) {

        if ("approve".equalsIgnoreCase(action)) {
            return ResponseEntity.ok("Success");
        } else if ("reject".equalsIgnoreCase(action)) {
            return ResponseEntity.ok("Success");
        }
        return ResponseEntity.badRequest().body("Failed: Unknown action '" + action + "'. Use 'approve' or 'reject'.");
    }

    // -----------------------------------------------------------------------
    // Endpoint 7 – Fetch Test Cases
    // GET /app/EO7/api/testmanagement-task/{taskId}/testcases
    // -----------------------------------------------------------------------
    @GetMapping("/{taskId}/testcases")
    public ResponseEntity<Map<String, Object>> getTestCases(@PathVariable String taskId) {

        List<Map<String, Object>> testCases = new ArrayList<>();

        Map<String, Object> tc1 = new LinkedHashMap<>();
        tc1.put("testCaseId", "TC-001");
        tc1.put("requirementId", "REQ-001");
        tc1.put("testDescription", "Verify successful login with valid credentials");
        tc1.put("preconditions", "User account must exist in the system");
        tc1.put("testStepAction",
                "1. Navigate to login page. 2. Enter valid username and password. 3. Click Login. 4. Verify dashboard is displayed.");
        testCases.add(tc1);

        Map<String, Object> tc2 = new LinkedHashMap<>();
        tc2.put("testCaseId", "TC-002");
        tc2.put("requirementId", "REQ-002");
        tc2.put("testDescription", "Verify requirement document upload success");
        tc2.put("preconditions", "User is logged in and has a valid PDF document");
        tc2.put("testStepAction",
                "1. Navigate to Upload screen. 2. Select a PDF file. 3. Click Upload. 4. Verify success notification.");
        testCases.add(tc2);

        Map<String, Object> response = new LinkedHashMap<>();
        response.put("taskId", taskId);
        response.put("testcases", testCases);

        return ResponseEntity.ok(response);
    }

    // -----------------------------------------------------------------------
    // Endpoint 8 – Export Test Cases (download)
    // GET /app/EO7/api/testmanagement-task/{taskId}/export
    // -----------------------------------------------------------------------
    @GetMapping("/{taskId}/export")
    public ResponseEntity<byte[]> exportTestCases(@PathVariable String taskId) {

        // Build a minimal CSV representing the exported test cases
        String csvContent =
                "Test Case Id,Requirement Id,Test Description,Pre-conditions,Test Step Action\r\n" +
                "TC-001,REQ-001,Verify successful login with valid credentials," +
                        "User account must exist in the system," +
                        "\"1. Navigate to login page. 2. Enter valid username and password. 3. Click Login. 4. Verify dashboard is displayed.\"\r\n" +
                "TC-002,REQ-002,Verify requirement document upload success," +
                        "User is logged in and has a valid PDF document," +
                        "\"1. Navigate to Upload screen. 2. Select a PDF file. 3. Click Upload. 4. Verify success notification.\"\r\n";

        byte[] csvBytes = csvContent.getBytes();

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION,
                        "attachment; filename=\"testcases-" + taskId + ".csv\"")
                .contentType(MediaType.parseMediaType("text/csv"))
                .contentLength(csvBytes.length)
                .body(csvBytes);
    }
}
