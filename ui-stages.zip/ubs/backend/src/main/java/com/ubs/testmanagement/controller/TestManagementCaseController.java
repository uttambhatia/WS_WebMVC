package com.ubs.testmanagement.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;
import java.util.UUID;

/**
 * Handles test management case-level operations.
 *
 * Endpoint 1  : POST /app/EO7/api/testmanagement-case/start   – create new case id
 * Endpoint 1.1: POST /app/EO7/api/testmanagement-case/list    – fetch list of case ids
 * Endpoint 2  : GET  /app/EO7/api/testmanagement-case/{caseId}/task – get task id
 */
@RestController
@RequestMapping("/app/EO7/api/testmanagement-case")
public class TestManagementCaseController {

    // --- Dummy seed data ---------------------------------------------------
    private static final List<String> SEED_CASE_IDS = Arrays.asList(
            "TST-C001-A1B2C3D4",
            "TST-C001-E5F6G7H8"
    );

    // -----------------------------------------------------------------------
    // Endpoint 1 – Create new test case id
    // POST /app/EO7/api/testmanagement-case/start?caseDefinitionKey=TST-C001
    // -----------------------------------------------------------------------
    @PostMapping("/start")
    public ResponseEntity<String> createCase(
            @RequestParam(name = "caseDefinitionKey", defaultValue = "TST-C001") String caseDefinitionKey) {

        String newCaseId = caseDefinitionKey + "-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        return ResponseEntity.ok(newCaseId);
    }

    // -----------------------------------------------------------------------
    // Endpoint 1.1 – Fetch list of test case ids
    // POST /app/EO7/api/testmanagement-case/list?caseDefinitionKey=TST-C001
    // -----------------------------------------------------------------------
    @PostMapping("/list")
    public ResponseEntity<List<String>> listCases(
            @RequestParam(name = "caseDefinitionKey", defaultValue = "TST-C001") String caseDefinitionKey) {

        return ResponseEntity.ok(SEED_CASE_IDS);
    }

    // -----------------------------------------------------------------------
    // Endpoint 2 – Create and get a task id for a given case
    // GET /app/EO7/api/testmanagement-case/{caseId}/task?processTaskId=ProcessTask_3
    // -----------------------------------------------------------------------
    @GetMapping("/{caseId}/task")
    public ResponseEntity<String> getTaskId(
            @PathVariable String caseId,
            @RequestParam(name = "processTaskId", defaultValue = "ProcessTask_3") String processTaskId) {

        String taskId = processTaskId + "-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        return ResponseEntity.ok(taskId);
    }
}
