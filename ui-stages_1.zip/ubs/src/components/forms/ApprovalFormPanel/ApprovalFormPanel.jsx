/**
 * ApprovalFormPanel — Stage 4: approve or reject with comment.
 *
 * StageFlowPanel interface: validate() / submit()
 *
 * Initialization props:
 *   title           {string}
 *   approveService  {async fn(taskId, text) → any}
 *   rejectService   {async fn(taskId, text) → any}
 *   maxLength       {number}   Textarea character limit (default: 500).
 *
 * serviceData from StageFlowPanel is not used for taskId resolution.
 * taskId is read from stagesContext["validation"].taskId (Stage 3's own task).
 */

import { forwardRef, useImperativeHandle, useMemo, useRef, useState } from "react";
import ApproveReject from "../../ApproveReject/ApproveReject";
import "../FormPanel.css";

const APPROVER_NAMES = [
  "Alice Morgan", "James Thornton", "Priya Nair",
  "Carlos Ortega", "Nina Blackwell", "Ethan Sato",
];

const ApprovalFormPanel = forwardRef(function ApprovalFormPanel(
  {
    serviceData,
    stagesContext,
    stageStatus,
    onSubmitStart,
    onSubmitSuccess,
    onSubmitRejected,
    onSubmitError,
    // Wiring-time
    title = "Approval",
    subtitle = "Review the validation summary and approve or reject the requirement document.",
    approveService,
    rejectService,
    maxLength = 500,
    readOnly = false,
  },
  ref
) {
  const taskId = stagesContext?.["validation"]?.taskId ?? null;
  const lastActionRef = useRef(null); // 'approve' | 'reject' | null
  // Stores the complete payload so submit() can re-use it if the user clicks Next
  const submitPayloadRef = useRef(null);
  const [done, setDone] = useState(false);
  const [comment, setComment] = useState("");
  const [commentError, setCommentError] = useState(null);

  /* Random approver name — stable for this form instance */
  const approvedBy = useMemo(
    () => APPROVER_NAMES[Math.floor(Math.random() * APPROVER_NAMES.length)],
    []
  );

  /* Validation summary from Stage 3 */
  const valData = stagesContext?.["validation"] ?? {};
  const summaryCards = [
    { label: "Quality Percentage", value: valData.quality_percentage ?? "—" },
    {
      label: "Rating",
      value: valData.rating ?? "—",
      sub:   valData.rating_explanation ?? null,
    },
  ];

  /* ---- Bound service wrappers ---- */
  const boundApprove = approveService
    ? (text) => approveService(taskId, text)
    : undefined;

  const boundReject = rejectService
    ? (text) => rejectService(taskId, text)
    : undefined;

  /* ---- StageFlowPanel contract ---- */
  useImperativeHandle(ref, () => ({
    validate() {
      if (!comment.trim()) {
        setCommentError("Comments are required.");
        return false;
      }
      setCommentError(null);
      return true;
    },
    async submit() {
      if (!comment.trim()) {
        setCommentError("Comments are required.");
        onSubmitError?.("Please add a comment before approving or rejecting.");
        return { success: false };
      }
      if (done && submitPayloadRef.current) {
        const payload = submitPayloadRef.current;
        if (payload.decision === "reject") {
          onSubmitRejected?.(payload);
        } else {
          onSubmitSuccess?.(payload);
        }
        return { success: true };
      }
      onSubmitError?.("Please click Approve or Reject to proceed.");
      return { success: false };
    },
  }));

  return (
    <div className="fp">
      {/* Title bar */}
      <div className="fp__titlebar">
        <div className="fp__titlebar-top">
          <h2 className="fp__title">{title}</h2>
          {taskId && (
            <span className="fp__task-id">
              Task Id: <strong>{taskId}</strong>
            </span>
          )}
        </div>
        {subtitle && <p className="fp__subtitle">{subtitle}</p>}
      </div>

      <div className="fp__body">
        {/* Validation Summary */}
        <p className="fp__section-title">Validation Summary</p>
        <div className="fp__cards">
          {summaryCards.map((c) => (
            <div key={c.label} className="fp__card">
              <span className="fp__card-label">{c.label}</span>
              <span className="fp__card-value">{c.value}</span>
              {c.sub && <span className="fp__card-sub">{c.sub}</span>}
            </div>
          ))}
        </div>

        {readOnly ? (
          <div style={{ marginTop: "var(--ubs-sp-4, 1rem)" }}>
            {serviceData?.decision && (
              <div className="fp__field">
                <span className="fp__field-label">Decision</span>
                <span
                  className="fp__value"
                  style={{
                    color: serviceData.decision === "approve"
                      ? "var(--ubs-c-success, #1a7f37)"
                      : "var(--ubs-c-danger, #cf222e)",
                    textTransform: "capitalize",
                  }}
                >
                  {serviceData.decision === "approve" ? "Approved" : "Rejected"}
                </span>
              </div>
            )}
            {serviceData?.comment && (
              <div className="fp__field">
                <span className="fp__field-label">Comments</span>
                <span className="fp__value" style={{ whiteSpace: "pre-wrap" }}>{serviceData.comment}</span>
              </div>
            )}
            <div className="fp__field">
              <span className="fp__field-label">Approved By</span>
              <span className="fp__approved-by">{serviceData?.approvedBy ?? approvedBy}</span>
            </div>
          </div>
        ) : (
        /* Approve / Reject with mandatory comment + Approved By in between */
        <ApproveReject
          approveService={boundApprove}
          rejectService={boundReject}
          maxLength={maxLength}
          placeholder="Add a comment before approving or rejecting…"
          label="Comments"
          required
          value={comment}
          onChange={(val) => {
            setComment(val);
            if (val.trim()) setCommentError(null);
          }}
          commentError={commentError}
          middleSlot={
            <div className="fp__field">
              <span className="fp__field-label">Approved By</span>
              <span className="fp__approved-by">{approvedBy}</span>
            </div>
          }
          onApprove={() => {
            const payload = { decision: "approve", comment, approvedBy };
            submitPayloadRef.current = payload;
            setDone(true);
            lastActionRef.current = "approve";
            onSubmitSuccess?.(payload);
          }}
          onReject={() => {
            const payload = { decision: "reject", comment, approvedBy };
            submitPayloadRef.current = payload;
            setDone(true);
            lastActionRef.current = "reject";
            onSubmitRejected?.(payload);
          }}
          disabled={done}
        />
        )}
      </div>
    </div>
  );
});

export default ApprovalFormPanel;
