/**
 * CaseIdFormPanel — Stage 1 form: select or create a Case ID.
 *
 * StageFlowPanel interface (via forwardRef):
 *   validate() → boolean
 *   submit()   → { success: boolean }
 *
 * Props (received from StageFlowPanel):
 *   serviceData    — result of the stage's entry service (unused in stage 1)
 *   stageStatus    — current stage status string
 *   onSubmitStart  — callback
 *   onSubmitSuccess — callback(taskId)
 *   onSubmitError  — callback(message)
 *
 * Initialization props (passed at wiring time):
 *   title          {string}   Panel title (default: "Case ID")
 *   fetchService   {async fn} → string[]   Fetches existing case IDs.
 *   createService  {async fn} → string     Creates a new case ID.
 *   getTaskService {async fn(caseId)} → string  Fetches task ID for caseId.
 */

import { forwardRef, useImperativeHandle, useRef, useState } from "react";
import IdSelectorCreator from "../../IdSelectorCreator/IdSelectorCreator";
import "../FormPanel.css";

const CaseIdFormPanel = forwardRef(function CaseIdFormPanel(
  {
    // StageFlowPanel-injected
    serviceData,
    stageStatus,
    onSubmitStart,
    onSubmitSuccess,
    onSubmitError,
    // Wiring-time props
    title = "Case ID",
    subtitle = "Select an existing case or create a new one to begin.",
    fetchService,
    createService,
    getTaskService,
    readOnly = false,
  },
  ref
) {
  const [selectedId, setSelectedId] = useState(null);
  const [validationError, setValidationError] = useState(null);

  /* ---- StageFlowPanel contract ---- */
  useImperativeHandle(ref, () => ({
    validate() {
      if (!selectedId) {
        setValidationError("Please select or create a Case ID before proceeding.");
        return false;
      }
      setValidationError(null);
      return true;
    },
    async submit() {
      if (!selectedId) return { success: false };
      onSubmitStart?.();
      try {
        let taskId = selectedId;
        if (getTaskService) {
          taskId = await getTaskService(selectedId);
        }
        onSubmitSuccess?.(taskId);
        return { success: true };
      } catch (err) {
        const msg = err?.response?.data?.message ?? err?.message ?? "Failed to retrieve task ID.";
        onSubmitError?.(msg);
        return { success: false };
      }
    },
  }));

  const handleSelect = (id) => {
    setSelectedId(id);
    setValidationError(null);
  };

  /* ---- Read-only view (view mode) ---- */
  if (readOnly) {
    return (
      <div className="fp">
        <div className="fp__titlebar">
          <div className="fp__titlebar-top">
            <h2 className="fp__title">{title}</h2>
          </div>
          {subtitle && <p className="fp__subtitle">{subtitle}</p>}
        </div>
        <div className="fp__body">
          <div className="fp__field">
            <span className="fp__field-label">Case ID</span>
            <span className="fp__value">{serviceData ?? "—"}</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fp">
      {/* Title bar */}
      <div className="fp__titlebar">
        <div className="fp__titlebar-top">
          <h2 className="fp__title">{title}</h2>
        </div>
        {subtitle && <p className="fp__subtitle">{subtitle}</p>}
      </div>

      <div className="fp__body">
        <div className="fp__field">
          <label className="fp__field-label">
            Case ID <span className="fp__required">*</span>
          </label>
          <IdSelectorCreator
            fetchService={fetchService}
            createService={createService}
            placeholder="Select or create a Case ID…"
            value={selectedId}
            onSelect={handleSelect}
          />
          {validationError && (
            <span className="fp__validation-error" role="alert">{validationError}</span>
          )}
        </div>
      </div>
    </div>
  );
});

export default CaseIdFormPanel;
