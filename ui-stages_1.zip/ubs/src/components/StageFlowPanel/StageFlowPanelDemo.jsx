﻿/**
 * StageFlowPanelDemo.jsx
 *
 * Demonstrates StageFlowPanel wired with five real-world stages:
 *   1. Case ID Creation
 *   2. Upload Requirement Document
 *   3. Validation
 *   4. Approval
 *   5. Test Generation
 *
 * Each form component:
 *   - Uses forwardRef + useImperativeHandle to expose { validate(), submit() }
 *   - Receives serviceData / stageStatus / errorMessage / onSubmitStart/Success/Error
 */

import { forwardRef, useCallback, useEffect, useRef, useState } from "react";
import StageFlowPanel from "./StageFlowPanel";
import CaseIdFormPanel from "../forms/CaseIdFormPanel/CaseIdFormPanel";
import UploadDocFormPanel from "../forms/UploadDocFormPanel/UploadDocFormPanel";
import ValidationFormPanel from "../forms/ValidationFormPanel/ValidationFormPanel";
import ApprovalFormPanel from "../forms/ApprovalFormPanel/ApprovalFormPanel";
import TestGenFormPanel from "../forms/TestGenFormPanel/TestGenFormPanel";
import {
  createCaseId,
  fetchCaseIdList,
  getTaskId,
  uploadDocument,
  uploadGitlabIssue,
  completeTask,
  fetchTaskVariables,
  approveOrReject,
  fetchTestCases,
  exportTestCases,
  saveStageSnapshot,
  loadSnapshot,
  listSnapshots,
} from "../../services/testManagementService";

/* ------------------------------------------------------------------ */
/*  Stage SVG Icons                                                    */
/* ------------------------------------------------------------------ */
function CaseIdIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"
      strokeLinecap="round" strokeLinejoin="round">
      <rect x="3" y="5" width="18" height="14" rx="2" />
      <path d="M8 5V3m8 2V3" />
      <path d="M7 10h5m-5 4h10" />
    </svg>
  );
}

function UploadDocIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"
      strokeLinecap="round" strokeLinejoin="round">
      <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
      <polyline points="14 2 14 8 20 8" />
      <line x1="12" y1="18" x2="12" y2="12" />
      <polyline points="9 15 12 12 15 15" />
    </svg>
  );
}

function ValidationIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"
      strokeLinecap="round" strokeLinejoin="round">
      <path d="M12 2L3 7v5c0 5.25 3.75 10.15 9 11.34C17.25 22.15 21 17.25 21 12V7z" />
      <polyline points="9 12 11 14 15 10" />
    </svg>
  );
}

function ApprovalIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"
      strokeLinecap="round" strokeLinejoin="round">
      <path d="M14 9V5a3 3 0 0 0-6 0v4H5a1 1 0 0 0-1 1v9a1 1 0 0 0 1 1h14
               a1 1 0 0 0 1-1V10a1 1 0 0 0-1-1h-3z" />
      <polyline points="9 13 11 15 15 11" />
    </svg>
  );
}

function TestGenIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"
      strokeLinecap="round" strokeLinejoin="round">
      <polyline points="16 18 22 12 16 6" />
      <polyline points="8 6 2 12 8 18" />
      <line x1="12" y1="2" x2="12" y2="22" />
    </svg>
  );
}

/* TODO: remove this delay helper before production */
const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

/* ================================================================== */
/*  BPMN Process Task IDs — update these to match your process def   */
/* ================================================================== */
const PROCESS_TASK = {
  UPLOAD_DOC:  "ProcessTask_UploadDoc",   // TODO: replace with actual BPMN task id
  VALIDATION:  "ProcessTask_Validation",  // TODO: replace with actual BPMN task id
  TEST_GEN:    "ProcessTask_TestGen",     // TODO: replace with actual BPMN task id
};

/* ================================================================== */
/*  Stage entry services — each fetches its own taskId from caseId   */
/* ================================================================== */

/**
 * Stage 2 — Upload Doc: fetch taskId for the upload BPMN task.
 */
async function getTaskIdService({ "case-id": caseId }) {
  await delay(30000); // TODO: remove before production
  const taskId = await getTaskId(caseId, PROCESS_TASK.UPLOAD_DOC);
  return taskId;
}

/**
 * Stage 3 — Validation: fetch own taskId, then fetch validation variables.
 * Merges taskId into result so the form can display it.
 */
async function fetchVariablesService({ "case-id": caseId }) {
  await delay(30000); // TODO: remove before production
  const taskId = await getTaskId(caseId, PROCESS_TASK.VALIDATION);
  const vars = await fetchTaskVariables(taskId);
  return { ...vars, taskId };
}

/**
 * Stage 5 — Test Generation: fetch own taskId, then fetch test cases.
 * Merges taskId into result so the form can display it.
 */
async function fetchTestCasesService({ "case-id": caseId }) {
  await delay(30000); // TODO: remove before production
  const taskId = await getTaskId(caseId, PROCESS_TASK.TEST_GEN);
  const testcases = await fetchTestCases(taskId);
  return { taskId, testcases };
}

/* ================================================================== */
/*  forwardRef wrappers â€” bind init-time props to form panels         */
/* ================================================================== */

const CaseIdStageForm = forwardRef(function CaseIdStageForm(props, ref) {
  return (
    <CaseIdFormPanel
      ref={ref}
      {...props}
      title="Case ID Creation"
      fetchService={fetchCaseIdList}
      createService={createCaseId}
    />
  );
});

const UploadDocStageForm = forwardRef(function UploadDocStageForm(props, ref) {
  return (
    <UploadDocFormPanel
      ref={ref}
      {...props}
      title="Upload Requirement Document"
      gitlabService={uploadGitlabIssue}
      documentService={uploadDocument}
      completeService={completeTask}
    />
  );
});

const ValidationStageForm = forwardRef(function ValidationStageForm(props, ref) {
  return (
    <ValidationFormPanel
      ref={ref}
      {...props}
      title="Validation"
    />
  );
});

const ApprovalStageForm = forwardRef(function ApprovalStageForm(props, ref) {
  return (
    <ApprovalFormPanel
      ref={ref}
      {...props}
      title="Approval"
      approveService={(taskId) => approveOrReject(taskId, "approve")}
      rejectService={(taskId) => approveOrReject(taskId, "reject")}
      maxLength={500}
    />
  );
});

const TestGenStageForm = forwardRef(function TestGenStageForm(props, ref) {
  return (
    <TestGenFormPanel
      ref={ref}
      {...props}
      title="Test Case Generation"
      exportService={(taskId) => exportTestCases(taskId)}
    />
  );
});

/* ================================================================== */
/*  Stage definitions â€” real form panels wired with real services     */
/* ================================================================== */
const STAGES = [
  {
    id:                 "case-id",
    name:               "Case ID",
    icon:               <CaseIdIcon />,
    component:          CaseIdStageForm,
    showReloadOnFailure: true,
  },
  {
    id:                 "upload-doc",
    name:               "Upload Document",
    icon:               <UploadDocIcon />,
    service:            getTaskIdService,
    component:          UploadDocStageForm,
    showReloadOnFailure: true,
  },
  {
    id:                 "validation",
    name:               "Validation",
    icon:               <ValidationIcon />,
    service:            fetchVariablesService,
    component:          ValidationStageForm,
    showReloadOnFailure: true,
  },
  {
    id:                 "approval",
    name:               "Approval",
    icon:               <ApprovalIcon />,
    component:          ApprovalStageForm,
    showReloadOnFailure: false,
  },
  {
    id:                 "test-gen",
    name:               "Test Generation",
    icon:               <TestGenIcon />,
    service:            fetchTestCasesService,
    autoSubmit:         true,
    component:          TestGenStageForm,
    showReloadOnFailure: true,
  },
];

/* ================================================================== */
/* ------------------------------------------------------------------ */
/*  Snapshot helpers                                                   */
/* ------------------------------------------------------------------ */
/**
 * When saving a rejected stage, embed _sfpStatus so the status can be
 * faithfully restored when the snapshot is loaded later.
 * For non-object serviceData (e.g. plain taskId string) or non-rejected
 * stages there is nothing to embed — we return the original data as-is.
 */
function withStatus(serviceData, completedStatus) {
  if (completedStatus === "rejected" && serviceData !== null && typeof serviceData === "object") {
    return { ...serviceData, _sfpStatus: "rejected" };
  }
  return serviceData;
}

/**
 * Rebuild initialStageStates from a snapshot's stageData map.
 * Strips the internal _sfpStatus metadata key before setting serviceData,
 * and applies a backward-compatible fallback for older snapshots that never
 * stored _sfpStatus (checks decision === "reject" on approval data).
 */
function buildInitialStageStates(stageData) {
  const initial = {};
  for (const [stageId, rawData] of Object.entries(stageData ?? {})) {
    const status =
      rawData?._sfpStatus ??
      (rawData?.decision === "reject" ? "rejected" : "success");
    let data = rawData;
    if (rawData && typeof rawData === "object" && "_sfpStatus" in rawData) {
      const { _sfpStatus: _ignored, ...rest } = rawData;
      data = rest;
    }
    initial[stageId] = { status, serviceData: data };
  }
  return initial;
}

/* ================================================================== */
/*  Demo wrapper                                                       */
/* ================================================================== */
export default function StageFlowPanelDemo() {
  /* Active case id tracked so we can associate snapshots to the right case */
  const activeCaseIdRef = useRef(null);
  /* Track the highest completed stage index so completedUpTo is accurate */
  const completedUpToRef = useRef(-1);
  /* stageData accumulated during the active workflow */
  const stageDataRef = useRef({});

  /* ---- History list ---- */
  const [history, setHistory] = useState([]); // [{ caseId, completedUpTo }]
  const [historyError, setHistoryError] = useState(null);

  const refreshHistory = useCallback(() => {
    listSnapshots()
      .then(setHistory)
      .catch(() => setHistoryError("Could not load history."));
  }, []);

  useEffect(() => {
    refreshHistory();
  }, [refreshHistory]);

  /* ---- View mode ---- */
  const [viewState, setViewState] = useState(null); // { caseId, initialStageStates }
  /* ---- Resume mode ---- */
  const [resumeState, setResumeState] = useState(null); // { caseId, initialStageStates }

  const handleViewCase = useCallback(async (caseId) => {
    try {
      const snap = await loadSnapshot(caseId);
      setViewState({ caseId, initialStageStates: buildInitialStageStates(snap.stageData) });
      setResumeState(null);
    } catch {
      alert(`Could not load snapshot for case ${caseId}`);
    }
  }, []);

  const handleResumeCase = useCallback(async (caseId) => {
    try {
      const snap = await loadSnapshot(caseId);
      // Pre-populate refs so subsequent saves go to the right case with correct counters
      activeCaseIdRef.current  = caseId;
      completedUpToRef.current = snap.completedUpTo ?? -1;
      stageDataRef.current     = { ...(snap.stageData ?? {}) };
      setResumeState({ caseId, initialStageStates: buildInitialStageStates(snap.stageData) });
      setViewState(null);
    } catch {
      alert(`Could not load snapshot for case ${caseId}`);
    }
  }, []);

  /* ---- Save on stage complete ---- */
  const handleStageComplete = useCallback((stageId, serviceData, stageIndex, completedStatus) => {
    const caseId = activeCaseIdRef.current;
    if (!caseId) return;

    // Embed _sfpStatus for rejected stages so the snapshot can restore the correct icon/state
    const dataToSave = withStatus(serviceData, completedStatus);

    // Persist stage data locally so we can resend it when a later stage also saves
    stageDataRef.current[stageId] = dataToSave;

    if (stageIndex > completedUpToRef.current) {
      completedUpToRef.current = stageIndex;
    }

    saveStageSnapshot(caseId, stageId, dataToSave, completedUpToRef.current)
      .then(() => refreshHistory())
      .catch(console.error);
  }, [refreshHistory]);

  /* Capture caseId when stage 0 (case-id) completes */
  const handleStageCompleteWithCaseId = useCallback((stageId, serviceData, stageIndex, completedStatus) => {
    if (stageId === "case-id" && serviceData) {
      activeCaseIdRef.current = serviceData;
      completedUpToRef.current = -1;
      stageDataRef.current = {};
    }
    handleStageComplete(stageId, serviceData, stageIndex, completedStatus);
  }, [handleStageComplete]);

  /* Reset active session when starting a new workflow */
  const handleStartNew = useCallback(() => {
    activeCaseIdRef.current = null;
    completedUpToRef.current = -1;
    stageDataRef.current = {};
    setViewState(null);
    setResumeState(null);
  }, []);

  return (
    <div style={{ maxWidth: 900, margin: "0 auto", padding: "1rem" }}>
      {/* ---- History panel ---- */}
      <div style={{
        marginBottom: "1.5rem",
        padding: "0.75rem 1rem",
        border: "1px solid var(--color-border, #dde1e7)",
        borderRadius: "6px",
        background: "var(--color-surface-2, #f8f9fb)",
      }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "0.5rem" }}>
          <strong style={{ fontSize: "0.875rem" }}>Case History</strong>
          <div style={{ display: "flex", gap: "0.5rem" }}>
            <button
              type="button"
              onClick={refreshHistory}
              style={{ fontSize: "0.75rem", cursor: "pointer" }}
            >
              Refresh
            </button>
            {(viewState || resumeState) && (
              <button
                type="button"
                onClick={handleStartNew}
                style={{ fontSize: "0.75rem", cursor: "pointer" }}
              >
                ✕ Close
              </button>
            )}
          </div>
        </div>

        {historyError && (
          <p style={{ color: "red", fontSize: "0.75rem", margin: 0 }}>{historyError}</p>
        )}

        {history.length === 0 && !historyError && (
          <p style={{ color: "var(--color-text-muted, #888)", fontSize: "0.75rem", margin: 0 }}>
            No saved cases yet.
          </p>
        )}

        {history.length > 0 && (
          <ul style={{ margin: 0, padding: 0, listStyle: "none", display: "flex", flexWrap: "wrap", gap: "0.4rem" }}>
            {history.map(({ caseId, completedUpTo }) => (
              <li key={caseId} style={{ display: "flex", alignItems: "center", gap: "0.25rem" }}>
                <button
                  type="button"
                  onClick={() => handleViewCase(caseId)}
                  style={{
                    background: "none",
                    border: "none",
                    color: "var(--color-accent, #0066cc)",
                    cursor: "pointer",
                    fontSize: "0.8rem",
                    textDecoration: "underline",
                    padding: "2px 4px",
                  }}
                  title={`View — ${completedUpTo + 1} stage(s) completed`}
                >
                  {caseId}
                </button>
                <button
                  type="button"
                  onClick={() => handleResumeCase(caseId)}
                  style={{
                    background: "none",
                    border: "1px solid var(--color-accent, #0066cc)",
                    borderRadius: "3px",
                    color: "var(--color-accent, #0066cc)",
                    cursor: "pointer",
                    fontSize: "0.7rem",
                    padding: "1px 6px",
                    lineHeight: 1.5,
                  }}
                  title={`Resume from stage ${completedUpTo + 2}`}
                >
                  Resume
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>

      {/* ---- View mode panel ---- */}
      {viewState ? (
        <div>
          <p style={{ fontSize: "0.8rem", color: "var(--color-text-muted, #888)", marginBottom: "0.5rem" }}>
            Viewing saved case: <strong>{viewState.caseId}</strong>
          </p>
          <StageFlowPanel
            key={`view-${viewState.caseId}`}
            stages={STAGES}
            viewMode
            initialStageStates={viewState.initialStageStates}
          />
        </div>
      ) : resumeState ? (
        /* ---- Resume mode panel ---- */
        <div>
          <p style={{ fontSize: "0.8rem", color: "var(--color-text-muted, #888)", marginBottom: "0.5rem" }}>
            Resuming case: <strong>{resumeState.caseId}</strong>
          </p>
          <StageFlowPanel
            key={`resume-${resumeState.caseId}`}
            stages={STAGES}
            resumeMode
            initialStageStates={resumeState.initialStageStates}
            onStageComplete={handleStageComplete}
          />
        </div>
      ) : (
        /* ---- Active workflow panel ---- */
        <StageFlowPanel
          key="active"
          stages={STAGES}
          showReloadOnFailure={false}
          onStageComplete={handleStageCompleteWithCaseId}
          lockCompletedStages={true}
        />
      )}
    </div>
  );
}
